# Geo Zeta PDF a Audio V65 - audio estable restaurado + marcado doble

Base segura:
- El motor de audio, la extraccion de texto y la reproduccion son los mismos de la V61 que si emitia voz.
- Se conservaron los dos tipos de marcado de la V63.

Correccion puntual:
- Al abrir esta version por primera vez, se limpia una sola vez el estado de reproduccion defectuoso dejado por las versiones 62, 63 o 64.
- Se detiene cualquier servicio TTS antiguo y se borra el falso estado activo/pausado/preparando.
- Despues de esa limpieza, el boton inicia el audio con el flujo estable original de la V61.

Marcado:
- Subrayado debajo del texto.
- Resaltado transparente detras del texto.
- Color independiente para cada tipo desde Ajustes.

Version:
- versionCode: 65
- versionName: 65.0-stable-audio-state-reset-dual-mark
