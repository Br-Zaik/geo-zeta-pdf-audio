package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

public class ZoomImageView extends ImageView {
    public interface OnSingleTapListener {
        void onSingleTap();
    }

    public interface OnHorizontalSwipeListener {
        void onSwipeLeft();
        void onSwipeRight();
    }

    private static final float MIN_SCALE = 1.0f;
    private static final float MAX_SCALE = 5.0f;

    private final Matrix imageMatrixInternal = new Matrix();
    private final PointF last = new PointF();
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestureDetector;
    private final float[] matrixValues = new float[9];
    private float userScale = 1.0f;
    private boolean dragging;
    private OnSingleTapListener onSingleTapListener;
    private OnHorizontalSwipeListener onHorizontalSwipeListener;

    public ZoomImageView(Context context) {
        this(context, null);
    }

    public ZoomImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        super.setScaleType(ScaleType.MATRIX);

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                float factor = detector.getScaleFactor();
                float next = Math.max(MIN_SCALE, Math.min(MAX_SCALE, userScale * factor));
                factor = next / userScale;
                userScale = next;
                imageMatrixInternal.postScale(factor, factor, detector.getFocusX(), detector.getFocusY());
                constrainMatrix();
                return true;
            }
        });

        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (userScale > 1.05f) {
                    resetZoom();
                } else {
                    float factor = 2.2f;
                    userScale = factor;
                    imageMatrixInternal.postScale(factor, factor, e.getX(), e.getY());
                    constrainMatrix();
                }
                return true;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                if (onSingleTapListener != null) onSingleTapListener.onSingleTap();
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (onHorizontalSwipeListener == null || userScale > 1.05f || e1 == null || e2 == null) {
                    return false;
                }
                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();
                if (Math.abs(dx) > 110f && Math.abs(dx) > Math.abs(dy) * 1.25f && Math.abs(velocityX) > 350f) {
                    if (dx < 0) onHorizontalSwipeListener.onSwipeLeft();
                    else onHorizontalSwipeListener.onSwipeRight();
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        post(new Runnable() {
            @Override
            public void run() {
                fitImageToView();
            }
        });
    }

    @Override
    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        if (imageMatrixInternal == null) return;
        // La causa real del "tick" al abrir una imagen: antes el encuadre se
        // aplicaba siempre en el siguiente frame (via post), asi que por un
        // instante la imagen se mostraba a su escala nativa (con MATRIX,
        // arrancando desde la esquina superior izquierda), lo que se veia como
        // agrandada y cortada por la derecha, hasta que el frame siguiente
        // acomodaba el zoom. Si la vista ya tiene tamano conocido -- el caso
        // normal, porque para cuando la imagen carga la pantalla ya esta
        // dibujada -- se encuadra ya mismo, sin esperar un frame extra.
        if (getWidth() > 0 && getHeight() > 0) {
            fitImageToView();
        } else {
            post(new Runnable() {
                @Override
                public void run() {
                    fitImageToView();
                }
            });
        }
    }

    public void resetZoom() {
        fitImageToView();
    }

    public void setOnSingleTapListener(OnSingleTapListener listener) {
        this.onSingleTapListener = listener;
    }

    public void setOnHorizontalSwipeListener(OnHorizontalSwipeListener listener) {
        this.onHorizontalSwipeListener = listener;
    }

    private void fitImageToView() {
        Drawable drawable = getDrawable();
        if (drawable == null || getWidth() <= 0 || getHeight() <= 0) return;

        float drawableWidth = Math.max(1f, drawable.getIntrinsicWidth());
        float drawableHeight = Math.max(1f, drawable.getIntrinsicHeight());
        float availableWidth = Math.max(1f, getWidth() - getPaddingLeft() - getPaddingRight());
        float availableHeight = Math.max(1f, getHeight() - getPaddingTop() - getPaddingBottom());
        float fitScale = Math.min(availableWidth / drawableWidth, availableHeight / drawableHeight);
        float dx = getPaddingLeft() + (availableWidth - drawableWidth * fitScale) / 2f;
        float dy = getPaddingTop() + (availableHeight - drawableHeight * fitScale) / 2f;

        imageMatrixInternal.reset();
        imageMatrixInternal.postScale(fitScale, fitScale);
        imageMatrixInternal.postTranslate(dx, dy);
        userScale = 1.0f;
        constrainMatrix();
        invalidate();
    }

    private RectF getDisplayRect() {
        Drawable drawable = getDrawable();
        if (drawable == null) return null;
        RectF rect = new RectF(0f, 0f, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        imageMatrixInternal.mapRect(rect);
        return rect;
    }

    private void constrainMatrix() {
        RectF rect = getDisplayRect();
        if (rect == null) {
            setImageMatrix(imageMatrixInternal);
            return;
        }

        float availableWidth = Math.max(1f, getWidth() - getPaddingLeft() - getPaddingRight());
        float availableHeight = Math.max(1f, getHeight() - getPaddingTop() - getPaddingBottom());
        float leftBound = getPaddingLeft();
        float topBound = getPaddingTop();
        float rightBound = leftBound + availableWidth;
        float bottomBound = topBound + availableHeight;

        float dx = 0f;
        float dy = 0f;

        if (rect.width() <= availableWidth) {
            dx = leftBound + (availableWidth - rect.width()) / 2f - rect.left;
        } else {
            if (rect.left > leftBound) dx = leftBound - rect.left;
            else if (rect.right < rightBound) dx = rightBound - rect.right;
        }

        if (rect.height() <= availableHeight) {
            dy = topBound + (availableHeight - rect.height()) / 2f - rect.top;
        } else {
            if (rect.top > topBound) dy = topBound - rect.top;
            else if (rect.bottom < bottomBound) dy = bottomBound - rect.bottom;
        }

        imageMatrixInternal.postTranslate(dx, dy);
        setImageMatrix(imageMatrixInternal);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        boolean zoomed = userScale > 1.02f || scaleDetector.isInProgress();

        if (getParent() != null) {
            if (action == MotionEvent.ACTION_POINTER_DOWN || zoomed) {
                getParent().requestDisallowInterceptTouchEvent(true);
            } else if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
                getParent().requestDisallowInterceptTouchEvent(false);
            }
        }

        scaleDetector.onTouchEvent(event);
        gestureDetector.onTouchEvent(event);

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                last.set(event.getX(), event.getY());
                dragging = true;
                break;
            case MotionEvent.ACTION_MOVE:
                if (dragging && !scaleDetector.isInProgress() && userScale > 1.02f) {
                    float dx = event.getX() - last.x;
                    float dy = event.getY() - last.y;
                    imageMatrixInternal.postTranslate(dx, dy);
                    constrainMatrix();
                    last.set(event.getX(), event.getY());
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                constrainMatrix();
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                break;
            default:
                break;
        }
        return true;
    }
}
