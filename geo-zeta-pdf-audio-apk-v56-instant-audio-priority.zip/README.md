# Geo Zeta PDF a Audio V56 Instant Audio Priority

Base:
- V55 Page Audio Sync.

Correcciones:
- Precalienta el motor TextToSpeech al abrir la app.
- Al abrir PDF, vuelve a precalentar el audio.
- La página visible se prepara con prioridad.
- Al tocar reproducir, la extracción del texto no espera detrás del prefetch.
- Al cambiar de página con audio activo, la página nueva se extrae con prioridad.
- Evita que el botón play tarde tanto por estar esperando cola de páginas.
- Notificación más limpia: texto principal sin duplicar demasiado.

Mantiene:
- Ajustes profesionales.
- Tema claro/oscuro.
- Subrayado fino debajo del texto.
- Reglas arriba/abajo.
- Guardar imagen PNG.
- Guardar audio WAV.
- Limpieza de texto para evitar "ene".
- PdfRenderer, PDFBox y TextToSpeech.
