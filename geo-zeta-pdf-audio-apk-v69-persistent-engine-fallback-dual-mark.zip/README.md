# Geo Zeta PDF a Audio V69

Esta version conserva el visor PDF, la cache, las reglas y los dos tipos de marcado. El cambio principal es un motor de voz persistente separado del ciclo de vida corto del servicio de reproduccion.

## Motor de voz nuevo

- TextToSpeech se inicializa desde la clase Application al abrir el proceso.
- La misma instancia se reutiliza al cambiar de pagina, pausar, reanudar y abrir Ajustes.
- Se intenta primero el motor elegido por el usuario.
- Si ese motor falla, se intenta el motor predeterminado del sistema, Google TTS si esta instalado y despues los demas motores disponibles.
- Cada intento queda aislado para que una respuesta tardia de un motor anterior no rompa el actual.
- El servicio de audio ya no destruye el motor al terminar una pagina o al cerrar la notificacion.
- El boton cambia a pausa solo cuando llega el callback real de inicio de voz.
- El texto largo se divide en fragmentos seguros y se reproduce en orden.
- Se mantienen foco de audio, canal multimedia, notificacion y WakeLock.

## Ajustes de voz

En Ajustes aparecen:

- Motor de voz: permite elegir Automatico o un motor instalado.
- Probar voz: reproduce una frase sin depender del PDF.
- Estado y paquete del motor activo.
- Opcion Reintentar para reiniciar la deteccion.

## PDF y cache

- La pagina visible se extrae con prioridad.
- El texto se guarda en RAM y en el almacenamiento privado de la app.
- El PDF completo se indexa en segundo plano con un documento independiente.
- Play usa el texto ya guardado cuando existe.

## Marcado conservado

- Subrayado debajo del texto.
- Resaltado transparente detras del texto.
- Color independiente para subrayado y resaltado.
- Compatibilidad con marcas anteriores.

## Version

- versionCode: 69
- versionName: 69.0-persistent-engine-fallback-instant-cache-dual-mark

El flujo de GitHub Actions compila el proyecto extraido o el ZIP `geo-zeta-pdf-audio-apk-v69-persistent-engine-fallback-dual-mark.zip` colocado en la raiz.
