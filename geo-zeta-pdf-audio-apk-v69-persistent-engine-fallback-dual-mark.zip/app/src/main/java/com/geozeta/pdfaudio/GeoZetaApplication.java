package com.geozeta.pdfaudio;

import android.app.Application;

public class GeoZetaApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        TtsEngineManager.getInstance(this).initialize(null);
    }
}
