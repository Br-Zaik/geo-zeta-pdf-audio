package com.tesoreria.caja.data

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

val PE: Locale = Locale("es", "PE")

fun soles(centavos: Long): String = String.format(PE, "S/ %,.2f", centavos / 100.0)
fun fechaHora(t: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", PE).format(Date(t))
fun fechaCorta(t: Long): String = SimpleDateFormat("dd/MM/yyyy", PE).format(Date(t))

fun parseCentavos(texto: String): Long? {
    var s = texto.trim().replace("S/", "", ignoreCase = true).replace(" ", "")
    if (s.isBlank()) return null
    s = when {
        s.contains(',') && s.contains('.') -> s.replace(",", "")
        s.contains(',') -> s.replace(',', '.')
        else -> s
    }
    if (!s.matches(Regex("\\d+(\\.\\d{0,2})?"))) return null
    val partes = s.split('.')
    val entero = partes[0].toLongOrNull() ?: return null
    val dec = when {
        partes.size == 1 || partes[1].isEmpty() -> 0L
        partes[1].length == 1 -> partes[1].toLong() * 10L
        else -> partes[1].take(2).toLong()
    }
    return entero * 100L + dec
}

enum class EstadoPago { SIN_ENVIAR, PENDIENTE, APROBADO, RECHAZADO }
enum class MedioPago { YAPE, MANUAL }
enum class Rol { SOCIO, PRESIDENTE, TESORERO, PERSONALIZADO }
enum class EstadoMiembro { INVITADO, ACTIVO, BLOQUEADO, RETIRADO }
enum class Permiso {
    APROBAR_PAGOS,
    REGISTRAR_PAGO_MANUAL,
    GESTIONAR_COBROS,
    REGISTRAR_GASTOS,
    GESTIONAR_MIEMBROS,
    VER_DETALLE_PAGOS
}

data class Socio(
    val numero: Int,
    val nombre: String,
    val rol: Rol = Rol.SOCIO,
    val estado: EstadoMiembro = EstadoMiembro.ACTIVO,
    val permisosExtra: Set<Permiso> = emptySet()
)

data class Cobro(
    val id: Int,
    val titulo: String,
    val monto: Long,
    val creado: Long,
    val cierra: Long,
    val cerrado: Boolean = false,
    val extensionTexto: String = ""
)

data class Pago(
    val id: Int,
    val cobroId: Int,
    val socio: Int,
    val monto: Long,
    val estado: EstadoPago,
    val enviado: Long,
    val operacion: String,
    val ocrMonto: Long,
    val nota: String = "",
    val medio: MedioPago = MedioPago.YAPE,
    val fechaOcr: String = "",
    val horaOcr: String = "",
    val codigoSeguridad: String = ""
)

data class Gasto(
    val id: Int,
    val concepto: String,
    val monto: Long,
    val fecha: Long,
    val firmaTesorero: Boolean = false,
    val firmadoTesoreroEn: Long? = null,
    val firmaPresidente: Boolean = false,
    val firmadoPresidenteEn: Long? = null,
    val anulado: Boolean = false,
    val motivoAnulacion: String = ""
) {
    val aprobado: Boolean get() = firmaTesorero && firmaPresidente && !anulado
}

data class Acta(
    val cobroId: Int,
    val titulo: String,
    val monto: Long,
    val cierre: Long,
    val recaudado: Long,
    val pagaron: List<Int>,
    val faltaron: List<Int>,
    val estados: Map<Int, EstadoPago> = emptyMap()
)

object Caja {
    val socios = mutableStateListOf<Socio>()
    val cobros = mutableStateListOf<Cobro>()
    val pagos = mutableStateListOf<Pago>()
    val gastos = mutableStateListOf<Gasto>()
    val actas = mutableStateListOf<Acta>()
    val bitacora = mutableStateListOf<String>()

    private val claves = mutableMapOf<Int, String>()
    private val reseteos = mutableMapOf<Int, Long>()
    val sesion = mutableStateOf<Socio?>(null)

    private var seqCobro = 1
    private var seqPago = 1
    private var seqGasto = 1

    val esAdmin: Boolean get() = sesion.value?.rol == Rol.TESORERO
    val esPresidente: Boolean get() = sesion.value?.rol == Rol.PRESIDENTE

    fun permisosBase(rol: Rol): Set<Permiso> = when (rol) {
        Rol.TESORERO -> Permiso.values().toSet()
        Rol.PRESIDENTE -> emptySet()
        Rol.SOCIO -> emptySet()
        Rol.PERSONALIZADO -> emptySet()
    }

    fun tienePermiso(socio: Socio?, permiso: Permiso): Boolean =
        socio != null && socio.estado == EstadoMiembro.ACTIVO &&
            (permiso in permisosBase(socio.rol) || permiso in socio.permisosExtra)

    fun ingresos(): Long = pagos.filter { it.estado == EstadoPago.APROBADO }.sumOf { it.monto }
    fun egresos(): Long = gastos.filter { it.aprobado }.sumOf { it.monto }
    fun saldo(): Long = ingresos() - egresos()
    fun comprometidoPendiente(): Long = gastos.filter { !it.aprobado && !it.anulado && it.firmaTesorero }.sumOf { it.monto }
    fun disponibleParaGastos(): Long = (saldo() - comprometidoPendiente()).coerceAtLeast(0L)

    fun cobroActivo(): Cobro? = cobros.firstOrNull { !it.cerrado }
    private fun ultimoPago(cobroId: Int, numero: Int): Pago? = pagos.filter { it.cobroId == cobroId && it.socio == numero }.maxByOrNull { it.id }
    fun estadoDe(cobroId: Int, numero: Int): EstadoPago = ultimoPago(cobroId, numero)?.estado ?: EstadoPago.SIN_ENVIAR
    fun pagoDe(cobroId: Int, numero: Int): Pago? = ultimoPago(cobroId, numero)
    fun miembrosActivos(): List<Socio> = socios.filter { it.estado != EstadoMiembro.RETIRADO }
    fun faltantes(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) != EstadoPago.APROBADO }.sorted()
    fun noEnviaron(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.SIN_ENVIAR }.sorted()
    fun porRevisar(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.PENDIENTE }.sorted()
    fun rechazados(cobroId: Int): List<Int> = miembrosActivos().map { it.numero }.filter { estadoDe(cobroId, it) == EstadoPago.RECHAZADO }.sorted()
    fun aprobados(cobroId: Int): Int = miembrosActivos().count { estadoDe(cobroId, it.numero) == EstadoPago.APROBADO }
    fun recaudado(cobroId: Int): Long = pagos.filter { it.cobroId == cobroId && it.estado == EstadoPago.APROBADO }.sumOf { it.monto }

    fun crearCobro(titulo: String, monto: Long, horas: Int) {
        if (cobroActivo() != null) return
        val ahora = System.currentTimeMillis()
        cobros.add(Cobro(seqCobro++, titulo, monto, ahora, ahora + horas * 3_600_000L))
        anotar("abrió el cobro \"$titulo\" por ${soles(monto)}, plazo $horas h")
    }

    fun extenderCobro(id: Int, horasExtra: Int) {
        if (horasExtra <= 0) return
        val i = cobros.indexOfFirst { it.id == id }
        if (i < 0 || cobros[i].cerrado) return
        val nuevoCierre = cobros[i].cierra + horasExtra * 3_600_000L
        cobros[i] = cobros[i].copy(
            cierra = nuevoCierre,
            extensionTexto = "Plazo extendido +$horasExtra h · hasta ${fechaHora(nuevoCierre)}"
        )
        anotar("extendió $horasExtra h el cobro \"${cobros[i].titulo}\" hasta ${fechaHora(nuevoCierre)}")
    }

    fun cerrarCobro(id: Int) {
        val i = cobros.indexOfFirst { it.id == id }
        if (i < 0 || cobros[i].cerrado) return
        val c = cobros[i]
        cobros[i] = c.copy(cerrado = true)
        val estados = miembrosActivos().associate { it.numero to estadoDe(id, it.numero) }
        val pagaron = estados.filterValues { it == EstadoPago.APROBADO }.keys.sorted()
        val faltaron = estados.filterValues { it != EstadoPago.APROBADO }.keys.sorted()
        actas.add(Acta(id, c.titulo, c.monto, System.currentTimeMillis(), recaudado(id), pagaron, faltaron, estados))
        anotar("cerró el cobro \"${c.titulo}\" y guardó el acta")
    }

    fun revisarVencidos() {
        val ahora = System.currentTimeMillis()
        cobros.filter { !it.cerrado && it.cierra <= ahora }.forEach { cerrarCobro(it.id) }
    }

    fun registrarPago(cobroId: Int, numero: Int, monto: Long, operacion: String, ocr: Long, fechaOcr: String = "", horaOcr: String = "", codigoSeguridad: String = "") {
        val cobro = cobros.firstOrNull { it.id == cobroId } ?: return
        if (cobro.cerrado || System.currentTimeMillis() >= cobro.cierra) return
        pagos.add(Pago(seqPago++, cobroId, numero, monto, EstadoPago.PENDIENTE, System.currentTimeMillis(), operacion.trim(), ocr, medio = MedioPago.YAPE, fechaOcr = fechaOcr, horaOcr = horaOcr, codigoSeguridad = codigoSeguridad))
        anotar("envió comprobante Yape del socio $numero por ${soles(monto)}")
    }

    fun registrarPagoManual(cobroId: Int, numero: Int, monto: Long) {
        val cobro = cobros.firstOrNull { it.id == cobroId } ?: return
        val socio = socio(numero) ?: return
        if (cobro.cerrado || socio.estado == EstadoMiembro.RETIRADO) return
        val op = "MANUAL-${System.currentTimeMillis()}-$numero"
        pagos.add(Pago(seqPago++, cobroId, numero, monto, EstadoPago.APROBADO, System.currentTimeMillis(), op, monto, nota = "Pago registrado directamente por administración", medio = MedioPago.MANUAL))
        anotar("registró pago MANUAL de N.º $numero ${socio.nombre} por ${soles(monto)}")
    }

    fun corregirAsignacionPago(id: Int, nuevoNumero: Int) {
        val i = pagos.indexOfFirst { it.id == id }
        val nuevo = socio(nuevoNumero) ?: return
        if (i < 0 || nuevo.estado == EstadoMiembro.RETIRADO) return
        val anterior = pagos[i].socio
        if (anterior == nuevoNumero) return
        pagos[i] = pagos[i].copy(socio = nuevoNumero, nota = (pagos[i].nota + " · Corregido desde N.º $anterior").trim(' ', '·'))
        anotar("corrigió la asignación del pago ${pagos[i].id}: N.º $anterior → N.º $nuevoNumero ${nuevo.nombre}")
    }

    fun aprobarPago(id: Int) {
        val i = pagos.indexOfFirst { it.id == id }
        if (i < 0 || pagos[i].estado != EstadoPago.PENDIENTE) return
        pagos[i] = pagos[i].copy(estado = EstadoPago.APROBADO)
        anotar("aprobó el pago del socio ${pagos[i].socio} por ${soles(pagos[i].monto)}")
    }

    fun rechazarPago(id: Int, motivo: String) {
        val i = pagos.indexOfFirst { it.id == id }
        if (i < 0 || pagos[i].estado != EstadoPago.PENDIENTE) return
        pagos[i] = pagos[i].copy(estado = EstadoPago.RECHAZADO, nota = motivo.trim())
        anotar("rechazó el pago del socio ${pagos[i].socio}: ${motivo.trim()}")
    }

    fun pendientes(): List<Pago> = pagos.filter { it.estado == EstadoPago.PENDIENTE }.sortedByDescending { it.enviado }
    fun operacionRepetida(operacion: String, exceptoPago: Int = -1, socioActual: Int? = null): Boolean = pagos.any {
        it.operacion == operacion.trim() && it.id != exceptoPago && !(socioActual != null && it.socio == socioActual && it.estado == EstadoPago.RECHAZADO)
    }

    fun crearGasto(concepto: String, monto: Long) {
        if (monto <= 0L || monto > disponibleParaGastos()) return
        val ahora = System.currentTimeMillis()
        gastos.add(Gasto(seqGasto++, concepto, monto, ahora, firmaTesorero = true, firmadoTesoreroEn = ahora))
        anotar("registró el gasto \"$concepto\" por ${soles(monto)}; falta firma del presidente")
    }

    fun firmarGasto(id: Int, comoPresidente: Boolean) {
        val i = gastos.indexOfFirst { it.id == id }
        if (i < 0 || gastos[i].anulado) return
        val ahora = System.currentTimeMillis()
        gastos[i] = if (comoPresidente) {
            if (gastos[i].firmaPresidente) return else gastos[i].copy(firmaPresidente = true, firmadoPresidenteEn = ahora)
        } else {
            if (gastos[i].firmaTesorero) return else gastos[i].copy(firmaTesorero = true, firmadoTesoreroEn = ahora)
        }
        anotar(if (comoPresidente) "firmó como presidente el gasto \"${gastos[i].concepto}\"" else "firmó como tesorero el gasto \"${gastos[i].concepto}\"")
    }

    fun gastosPorFirmar(): List<Gasto> = gastos.filter { !it.aprobado && !it.anulado }

    fun tieneClave(numero: Int): Boolean = claves.containsKey(numero)
    fun reseteoAbierto(numero: Int): Boolean {
        val hasta = reseteos[numero] ?: return false
        if (hasta <= System.currentTimeMillis()) { reseteos.remove(numero); return false }
        return true
    }
    fun horasDeReseteo(numero: Int): Long {
        val hasta = reseteos[numero] ?: return 0
        return ceil((hasta - System.currentTimeMillis()).coerceAtLeast(0L) / 3_600_000.0).toLong()
    }
    fun necesitaCrearClave(numero: Int): Boolean = !tieneClave(numero) || reseteoAbierto(numero)
    fun crearClave(numero: Int, clave: String) {
        claves[numero] = clave
        reseteos.remove(numero)
        val i = socios.indexOfFirst { it.numero == numero }
        if (i >= 0 && socios[i].estado == EstadoMiembro.INVITADO) socios[i] = socios[i].copy(estado = EstadoMiembro.ACTIVO)
        anotar("creó una nueva contraseña para el socio $numero")
    }
    fun validar(numero: Int, clave: String): Boolean = claves[numero] == clave
    fun resetear(numero: Int) {
        if (!tieneClave(numero)) return
        reseteos[numero] = System.currentTimeMillis() + 24 * 3_600_000L
        anotar("liberó la contraseña del socio $numero por 24 h")
    }

    fun socio(numero: Int): Socio? = socios.firstOrNull { it.numero == numero }

    fun invitarMiembro(numero: Int, nombre: String, rol: Rol, permisos: Set<Permiso>) {
        if (numero !in 1..35 || socio(numero) != null || nombre.isBlank()) return
        socios.add(Socio(numero, nombre.trim(), rol, EstadoMiembro.INVITADO, permisos))
        anotar("invitó a N.º $numero ${nombre.trim()} con rol ${rol.name}")
    }

    fun cambiarRol(numero: Int, rol: Rol, permisos: Set<Permiso>) {
        val i = socios.indexOfFirst { it.numero == numero }
        if (i < 0 || socios[i].rol == Rol.TESORERO) return
        val antes = socios[i].rol
        socios[i] = socios[i].copy(rol = rol, permisosExtra = permisos)
        anotar("cambió el rol de N.º $numero de ${antes.name} a ${rol.name}")
    }

    fun cambiarEstadoMiembro(numero: Int, estado: EstadoMiembro) {
        val i = socios.indexOfFirst { it.numero == numero }
        if (i < 0 || socios[i].rol == Rol.TESORERO) return
        socios[i] = socios[i].copy(estado = estado)
        anotar("cambió el estado de N.º $numero a ${estado.name}")
    }

    fun cerrarSesiones(numero: Int) {
        anotar("solicitó cerrar las sesiones del socio $numero (simulado offline)")
    }

    private fun anotar(accion: String) {
        val actor = sesion.value
        val quien = if (actor == null) "Sistema" else "N° ${actor.numero} ${actor.nombre.substringBefore(" ")}" 
        bitacora.add(0, "${fechaHora(System.currentTimeMillis())}  ·  $quien  ·  $accion")
    }

    fun cargarDemo() {
        if (socios.isNotEmpty()) return
        val nombres = listOf(
            "Ronny Edilberto Afata Gonzales", "Yesber Alferez Ancalle", "Luz Clarita Alvarez Huancara",
            "Rosales Arphi Pauccara", "Cinthya Luz Berna Laura", "Ruben Carlos Pucho", "Alahor Castro Quispe",
            "Jamil Elar Ccorahua Ccama", "Ronaldiño Ccorimanya Yauri", "Jhon Tony Champi Tarifa",
            "Fausto Checca Huaylla", "Karen Massiel Chuchullo Pari", "Lisbeth Katerine Condori Saico",
            "Luz Eliana Cuti Cusihuaman", "Franklin Roberto Florez Condori", "Nayely Merly Huamanchoque Puma",
            "Delia Yuli Huamani Condorcahuana", "Brayan Jhonatan Huarca Anccasi", "Fabian Alexis Kana Chaco",
            "Jessica Gladys Leandro Ramirez", "Reiner Mendigure Katata", "Brian Pacco Huayhua",
            "Jhon Jhojan Pacco Quispe", "Katy Rosalia Phacsi Callahuasi", "Bhunden Fhan Alex Quispe Puma",
            "Williams Manuel Suclle Hancco", "Oscar Rene Suico Cuti", "Ronal Alex Suico Cuti",
            "Rodrigo Diego Umasi Hualla", "Zulma Nayely Velazco Florez"
        )
        nombres.forEachIndexed { i, nombre ->
            val numero = i + 1
            socios.add(Socio(numero, nombre, if (numero == 22) Rol.TESORERO else Rol.SOCIO))
        }
        socios.forEach { if (it.numero != 12 && it.numero != 27) claves[it.numero] = "123456" }
        val ahora = System.currentTimeMillis()

        cobros.add(Cobro(seqCobro++, "Cuota agosto", 2500, ahora - 40 * 24 * 3_600_000L, ahora - 38 * 24 * 3_600_000L, true))
        val pagaronAgosto = (1..30).filterNot { it in listOf(9, 21) }
        pagaronAgosto.forEach { pagos.add(Pago(seqPago++, 1, it, 2500, EstadoPago.APROBADO, ahora - 39 * 24 * 3_600_000L, "0086${400 + it}", 2500)) }
        val estadosAgosto = (1..30).associateWith { if (it in pagaronAgosto) EstadoPago.APROBADO else EstadoPago.SIN_ENVIAR }
        actas.add(Acta(1, "Cuota agosto", 2500, ahora - 38 * 24 * 3_600_000L, pagaronAgosto.size * 2500L, pagaronAgosto, listOf(9, 21), estadosAgosto))

        cobros.add(Cobro(seqCobro++, "Día del Niño", 400, ahora - 5 * 3_600_000L, ahora + 9 * 3_600_000L))
        val aprobados = listOf(1, 2, 3, 5, 7, 8, 10, 11, 13, 14, 16, 17, 18, 20, 22, 23, 24, 25, 27, 28, 29)
        aprobados.forEach { pagos.add(Pago(seqPago++, 2, it, 400, EstadoPago.APROBADO, ahora - 3 * 3_600_000L, "0091${200 + it}", 400)) }
        listOf(4, 12, 19).forEach { pagos.add(Pago(seqPago++, 2, it, 400, EstadoPago.PENDIENTE, ahora - 40 * 60_000L, "0091${200 + it}", 400)) }
        pagos.add(Pago(seqPago++, 2, 30, 400, EstadoPago.RECHAZADO, ahora - 70 * 60_000L, "0091230", 400, "No figura en la cuenta del tesorero"))

        gastos.add(Gasto(seqGasto++, "Bocaditos reunión de agosto", 6000, ahora - 30 * 24 * 3_600_000L, true, ahora - 30 * 24 * 3_600_000L, true, ahora - 29 * 24 * 3_600_000L))
        gastos.add(Gasto(seqGasto++, "Globos y sorpresas", 4500, ahora - 2 * 3_600_000L, true, ahora - 2 * 3_600_000L, false))
        anotar("cargó los datos de demostración")
    }
}
