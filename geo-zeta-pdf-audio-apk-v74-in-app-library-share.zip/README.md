# Geo Zeta PDF a Audio V74 - Mis archivos y compartir

Esta versión parte de V73. Mantiene el lector, la reproducción rápida, el segundo plano, la pantalla apagada, las reglas y el sistema de marcado.

## Cambios

- Nuevo apartado **Mis archivos** dentro de la app.
- Acceso directo desde la barra superior y también desde Ajustes.
- Dos pestañas: **Audios** e **Imágenes**.
- Los audios se pueden reproducir dentro de la app con play, pausa, barra de avance y duración.
- Las imágenes se pueden abrir y revisar dentro de la app.
- Cada archivo permite abrir, compartir, cambiar nombre y eliminar.
- Compartir usa el menú normal de Android para WhatsApp, Telegram, Drive, correo y otras apps compatibles.
- Al terminar de guardar una imagen o un audio aparece la opción de verlo o compartirlo.
- Los archivos se organizan automáticamente en las carpetas internas de Geo Zeta para audio e imágenes.
- Los rangos largos de audio se guardan por página dentro de una carpeta del rango para evitar un único archivo demasiado pesado.

## Versión

- versionCode: 74
- versionName: 74.0-in-app-library-share

El flujo de GitHub Actions genera el APK debug como artefacto descargable.
