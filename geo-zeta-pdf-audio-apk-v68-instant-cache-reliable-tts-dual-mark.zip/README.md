# Geo Zeta PDF a Audio V68

Esta version parte de la interfaz y funciones de V67, conserva el doble marcado y reemplaza el flujo de texto/voz que podia quedar bloqueado.

## Cambios de audio

- El motor TextToSpeech se calienta al abrir la aplicacion.
- Play usa una sola solicitud urgente para la pagina elegida.
- La pagina visible se prepara antes de tocar Play.
- La aplicacion guarda el texto extraido en RAM y tambien en disco.
- El PDF completo se indexa progresivamente en segundo plano sin ocupar la cola urgente.
- La extraccion urgente y la indexacion usan documentos PDF independientes.
- El boton solo muestra pausa cuando el motor confirma que comenzo a hablar.
- El texto largo se divide en fragmentos menores al limite de Android TTS.
- Se comprueba el resultado de speak(), los callbacks de inicio, error, fin y detencion.
- Se agregaron tiempo limite de inicializacion, preparacion, extraccion e inicio de voz.
- Se configura el canal multimedia, volumen TTS, foco de audio y WakeLock para pantalla apagada.
- Se declaran los motores TTS en Android 11 o superior.
- Los errores ya no dejan el reproductor indefinidamente en preparacion.

## Cache

El texto de las paginas queda dentro de los datos privados de la aplicacion. La primera apertura puede requerir extraer cada pagina; las paginas ya preparadas y las reaperturas del mismo PDF deben responder mucho mas rapido. Cambiar las reglas superior/inferior crea un cache separado para respetar el area visible.

## Marcado conservado

- Subrayado debajo del texto.
- Resaltado transparente detras del texto.
- Color independiente para cada herramienta.
- Compatibilidad con marcas anteriores.

## Version

- versionCode: 68
- versionName: 68.0-instant-cache-reliable-tts-dual-mark

El flujo de GitHub Actions acepta dos formas: proyecto extraido en el repositorio o el ZIP `geo-zeta-pdf-audio-apk-v68-instant-cache-reliable-tts-dual-mark.zip` colocado en la raiz.
