# PDFBox
-keep class org.apache.pdfbox.** { *; }
-keep class com.tom_roush.pdfbox.** { *; }
-keep class org.apache.fontbox.** { *; }

# AndroidX
-keep class androidx.** { *; }
-keep interface androidx.** { *; }

# Keep all classes with Keep annotation
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}
