# Geo Zeta PDF a Audio V23

Rediseño de la confí inferior:
- Barra inferior simple estilo académico Geo Zeta.
- Botones principales visibles:
  - Audio
  - Anterior
  - Play/Pausa
  - Siguiente
  - Tuerquita
- La tuerquita abre una hoja de configuración compacta.
- Las opciones avanzadas ya no se ven todo el tiempo ni tapan tanto el PDF.
- Mantiene las pestañas Audio, Marcar, Vista y Exportar dentro de la hoja.
- Se conserva el resto de funciones de V22.

Objetivo:
- Parecido al estilo limpio que pediste, pero con toque propio.
