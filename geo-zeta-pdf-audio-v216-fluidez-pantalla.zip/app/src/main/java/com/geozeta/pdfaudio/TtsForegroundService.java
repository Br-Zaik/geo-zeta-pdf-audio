package com.geozeta.pdfaudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.widget.RemoteViews;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TtsForegroundService extends Service {
    public static final String ACTION_START = "com.geozeta.pdfaudio.START";
    public static final String ACTION_WARMUP = "com.geozeta.pdfaudio.WARMUP";
    public static final String ACTION_PREPARE = "com.geozeta.pdfaudio.PREPARE";
    public static final String ACTION_STOP = "com.geozeta.pdfaudio.STOP";
    public static final String ACTION_TOGGLE = "com.geozeta.pdfaudio.TOGGLE";
    public static final String ACTION_NEXT = "com.geozeta.pdfaudio.NEXT";
    public static final String ACTION_PREV = "com.geozeta.pdfaudio.PREV";
    public static final String ACTION_REPORT_RANGE = "com.geozeta.pdfaudio.REPORT_RANGE";
    public static final String ACTION_SEEK_PAGE = "com.geozeta.pdfaudio.SEEK_PAGE";
    public static final String ACTION_PAGE_CHANGED = "com.geozeta.pdfaudio.PAGE_CHANGED";
    /** V211. Cambio de velocidad aplicado en caliente, suene o no suene. */
    public static final String ACTION_SET_RATE = "com.geozeta.pdfaudio.SET_RATE";

    public static final String EXTRA_PAGE = "page";
    public static final String EXTRA_AUTOPLAY = "autoplay";
    public static final String EXTRA_PAGE_TEXT = "page_text";
    public static final String EXTRA_FAST_RESUME_AUDIO = "fast_resume_audio";
    public static final String EXTRA_FAST_RESUME_TEXT = "fast_resume_text";
    public static final String EXTRA_TTS_LANGUAGE = "tts_language";
    public static final String EXTRA_TTS_REGION = "tts_region";
    public static final String ERROR_MISSING_VOICE_PREFIX = "VOICE_MISSING:";
    public static final String EXTRA_ACTIVE = "active";
    public static final String EXTRA_PAUSED = "paused";
    public static final String EXTRA_STATE = "playback_state";
    public static final String EXTRA_MESSAGE = "playback_message";
    public static final String EXTRA_CHUNK_TEXT = "reading_chunk_text";
    public static final String EXTRA_CHUNK_INDEX = "reading_chunk_index";
    public static final String EXTRA_RANGE_START = "reading_range_start";
    public static final String EXTRA_RANGE_END = "reading_range_end";

    public static final int STATE_STOPPED = 0;
    public static final int STATE_PREPARING = 1;
    public static final int STATE_PLAYING = 2;
    public static final int STATE_PAUSED = 3;
    public static final int STATE_ERROR = 4;

    private static final String CHANNEL_ID = "pdf_audio_playback_v69";
    private static final int NOTIFICATION_ID = 69;
    private static final String PREFS_NAME = "pdf_audio_prefs";
    private static final String PREF_TTS_ACTIVE = "tts_service_active";
    private static final String PREF_TTS_PAUSED = "tts_service_paused";
    private static final String PREF_TTS_CURRENT_PAGE = "tts_current_page";
    private static final String PREF_TTS_STATE = "tts_service_state";
    private static final String PREF_TTS_MESSAGE = "tts_service_message";
    // V198. Posicion fina: ademas de la pagina se guarda el fragmento y el
    // caracter. Si Android recicla el proceso con la pantalla apagada, al
    // volver se reanuda donde estaba la voz y no al principio de la pagina.
    public static final String PREF_TTS_CHUNK_INDEX = "tts_current_chunk_v198";
    public static final String PREF_TTS_CHUNK_OFFSET = "tts_current_offset_v198";

    public interface PageProvider {
        void requestPageText(int page, PageTextCallback callback);
    }

    public interface PageTextCallback {
        default void onFastText(String text) {}
        void onText(String text);
    }

    private static final Map<Integer, String> PAGE_MAP =
            new ConcurrentHashMap<Integer, String>();
    private static final Map<Integer, String> FAST_PAGE_MAP =
            new ConcurrentHashMap<Integer, String>();
    private static volatile PageProvider pageProvider;

    public static void setPageProvider(PageProvider provider) {
        pageProvider = provider;
    }

    public static void clearPages() {
        PAGE_MAP.clear();
        FAST_PAGE_MAP.clear();
    }


    public static void setPageText(int page, String text) {
        if (page >= 0) PAGE_MAP.put(page, text == null ? "" : text);
    }

    public static void setPageFastText(int page, String text) {
        if (page >= 0 && text != null && text.trim().length() > 0) {
            FAST_PAGE_MAP.put(page, text);
        }
    }


    private static volatile TtsForegroundService liveInstance;

    /**
     * True only when there is a real in-memory paused session that can resume
     * immediately on the requested page. Persisted PAUSED preferences alone are
     * not enough after the process/service has been recreated.
     */
    public static boolean canResumePausedPage(int page) {
        TtsForegroundService service = liveInstance;
        if (service == null) return false;
        if (service.playbackState != STATE_PAUSED || !service.paused
                || service.currentPageAbsolute != page) return false;
        if (service.fastResumeAudioActive && service.fastResumeAudioPaused
                && service.fastResumePlayer != null) return true;
        return service.currentChunks != null
                && !service.currentChunks.isEmpty()
                && service.currentChunkIndex >= 0
                && service.currentChunkIndex < service.currentChunks.size();
    }

    /**
     * Distingue una sesión real en memoria de un estado persistido antiguo.
     * Después de que Android mata el proceso, las preferencias pueden conservar
     * PLAYING/PREPARING aunque ya no exista nada que reproducir.
     */
    public static boolean hasLivePlaybackSession() {
        TtsForegroundService service = liveInstance;
        if (service == null) return false;
        int state = service.playbackState;
        if (state != STATE_PREPARING && state != STATE_PLAYING && state != STATE_PAUSED) {
            return false;
        }
        return service.reading || service.paused || state == STATE_PREPARING
                || service.fastResumeAudioActive;
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TtsEngineManager engineManager;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private PowerManager powerManager;
    private PowerManager.WakeLock wakeLock;
    private Runnable wakeLockRenewal;

    private boolean reading;
    private boolean paused;
    private boolean waitingForProvider;
    private boolean foregroundStarted;
    private boolean currentUtteranceStarted;
    private boolean waitingForEngine;
    private boolean fastStartPageActive;
    private boolean waitingForFastStartRemainder;
    // Diagnostico de latencia: marca cuando el usuario pide audio y cuando el
    // motor entrega realmente el primer sonido. Solo escribe en el log.
    private long playRequestedAtMs;
    private String playRequestOrigin = "";
    private boolean latencyReported;
    private String fastStartSpokenText;
    private int playbackState = STATE_STOPPED;
    private int sessionId;
    // Every call to speak() gets a never-reused id. Session/chunk ids alone can
    // repeat after pause/retry/rebuild, allowing a late callback from an old
    // engine to look current. This serial closes that race completely.
    private long utteranceSerial;
    private int currentPageAbsolute;
    private int totalPages;
    private int currentChunkIndex;
    private int chunkRetryCount;
    private int engineRestartCount;
    private boolean slowEngineRetryUsed;
    private int lastRangeStart;
    private int lastRangeEnd = 1;
    private List<String> currentChunks = Collections.emptyList();
    private final ConcurrentHashMap<Integer, Boolean> servicePrefetchingPages =
            new ConcurrentHashMap<Integer, Boolean>();
    private String activeUtteranceId;
    private Runnable stallWatchdog;
    private int stallMissCount;
    private long lastSpeechProgressMs;
    private long currentUtteranceStartedAtMs;
    private long currentUtteranceMinimumWatchdogMs;
    /** Primera mirada recien despues de este tiempo, para no cortar el arranque. */
    /** V198. Ventana del rescate de arranque (puente de audio). */
    private static final long START_RESCUE_MS = 800L;
    /**
     * V206. Cuanto se sigue esperando a un motor de voz lento, contado desde que
     * el usuario pidio audio. Mientras no pase, un arranque lento se reintenta
     * solo y el boton sigue en "..."; antes se rendia al segundo intento y
     * volvia a Play sin avisar, y habia que pulsar otra vez.
     */
    private static final long SLOW_ENGINE_MAX_WAIT_MS = 45000L;
    private static final long STALL_FIRST_CHECK_MS = 3000L;
    private static final long STALL_CHECK_MS = 1200L;
    /** Comprobaciones seguidas en silencio necesarias para dar por terminada la frase. */
    private static final int STALL_MISSES_NEEDED = 2;
    /** Si hubo avance hace menos de esto, el motor esta vivo y no se toca nada. */
    private static final long STALL_PROGRESS_GRACE_MS = 3000L;
    // Con la pantalla apagada algunos motores reportan isSpeaking=false durante
    // instantes aunque el audio siga vivo. El minimo estimado de voz impide
    // cortar antes de tiempo, asi que aqui no hace falta esperar tantos segundos
    // al final de cada pagina.
    private static final long SCREEN_OFF_STALL_FIRST_CHECK_MS = 3200L;
    private static final long SCREEN_OFF_STALL_CHECK_MS = 1200L;
    private static final int SCREEN_OFF_STALL_MISSES_NEEDED = 2;
    private static final long SCREEN_OFF_PROGRESS_GRACE_MS = 3500L;
    // Primer tramo corto de una pagina ya cacheada. Evita que el cambio de
    // pagina espere a que el motor sintetice de golpe un bloque muy grande.
    private static final int PAGE_START_FAST_MIN_CHARS = 900;
    private static final int PAGE_START_FAST_MIN_SPLIT = 220;
    private static final int PAGE_START_FAST_MAX_CHARS = 560;
    // Lease renovable: mantiene CPU y servicio activos durante lecturas largas
    // sin depender de un unico timeout de una hora.
    private static final long WAKE_LOCK_LEASE_MS = 30L * 60L * 1000L;
    private static final long WAKE_LOCK_RENEW_MS = 20L * 60L * 1000L;
    private String title = "PDF a Audio";
    private float rate = 1.0f;
    private float pitch = 1.0f;
    private String pdfLanguage = "";
    private String pdfRegion = "";
    private Runnable providerTimeout;
    /** Pagina sobre la que ya se gasto el reintento de extraccion. */
    private int providerRetryPage = -1;
    private Runnable utteranceTimeout;
    private MediaSession mediaSession;
    /** V198. Puente de audio disponible para el rescate de arranque. */
    // V203. Puente de pausa: al pausar se graba en segundo plano lo que
    // quedaba por decir del fragmento actual, para que al reanudar suene al
    // instante en vez de tener que sintetizarlo otra vez.
    private java.io.File pauseBridgeFile;
    private String pauseBridgeText;
    private boolean pauseBridgeReady;
    private int pauseBridgePage = -1;
    private int pauseBridgeChunk = -1;
    private float pauseBridgeRate;
    private String pauseBridgeLanguage = "";
    private String pauseBridgeUtteranceId;
    private String armedBridgePath;
    private String armedBridgeText;
    private boolean armedBridgeUsed;
    private Runnable startRescue;
    private MediaPlayer fastResumePlayer;
    private boolean fastResumeAudioActive;
    private boolean fastResumeAudioPaused;
    private boolean hasSpokenInProcess;
    /**
     * Punto exacto (en caracteres, dentro del fragmento actual) donde quedo la
     * voz al pausar. Al reanudar se habla desde ahi en vez de volver al principio
     * del fragmento. Un fragmento puede ocupar casi toda la pagina, asi que
     * reiniciarlo era lo que hacia "subir" la seleccion al pausar y reanudar.
     */
    private int resumeCharOffset;
    /** Cuanto se recorto del principio del fragmento al enviarlo al motor. */
    private int spokenChunkOffset;
    /** Texto realmente entregado al motor en la orden en curso. */
    private String currentSpokenText = "";

    private final AudioManager.OnAudioFocusChangeListener focusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                @Override
                public void onAudioFocusChange(int focusChange) {
                    if (focusChange == AudioManager.AUDIOFOCUS_LOSS
                            && playbackState == STATE_PLAYING) {
                        pausePlayback();
                    }
                }
            };

    private final TtsEngineManager.UtteranceListener utteranceListener =
            new TtsEngineManager.UtteranceListener() {
                @Override
                public void onStart(final String utteranceId) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            cancelUtteranceTimeout();
                            reportPlayLatency("voz-motor");
                            currentUtteranceStarted = true;
                            hasSpokenInProcess = true;
                            chunkRetryCount = 0;
                            engineRestartCount = 0;
        slowEngineRetryUsed = false;
                            savePlaybackState(currentPageAbsolute, STATE_PLAYING,
                                    "Pagina " + (currentPageAbsolute + 1));
                            updateNotification("Pagina " + (currentPageAbsolute + 1)
                                    + " - " + String.format(Locale.US, "%.2fx", rate));
                            lastRangeStart = spokenChunkOffset;
                            lastRangeEnd = spokenChunkOffset + firstWordEnd(
                                    currentSpokenText != null && currentSpokenText.length() > 0
                                            ? currentSpokenText
                                            : currentChunks.get(currentChunkIndex));
                            broadcastReadingRange(lastRangeStart, lastRangeEnd);
                            currentUtteranceStartedAtMs = android.os.SystemClock.elapsedRealtime();
                            currentUtteranceMinimumWatchdogMs = estimateMinimumSpeechWindowMs(currentSpokenText);
                            // Desde que la voz arranca queda un vigilante despierto
                            // por si el motor deja de hablar sin avisar que termino.
                            startStallWatchdog(utteranceId);
                        }
                    });
                }

                @Override
                public void onDone(final String utteranceId) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            cancelUtteranceTimeout();
                            handleUtteranceFinished();
                        }
                    });
                }

                @Override
                public void onError(final String utteranceId, final int errorCode) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            cancelUtteranceTimeout();
                            if (chunkRetryCount < 1) {
                                chunkRetryCount++;
                                // El reintento tambien retoma desde donde iba la
                                // voz, no desde el principio del fragmento.
                                resumeCharOffset = Math.max(0, lastRangeStart);
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (reading && !paused
                                                && isCurrentUtterance(utteranceId)) {
                                            speakCurrentChunk();
                                        }
                                    }
                                }, 300L);
                            } else {
                                restartEngineOrFail("Error del motor de voz (codigo "
                                        + errorCode + ")");
                            }
                        }
                    });
                }

                @Override
                public void onStop(String utteranceId, boolean interrupted) {
                    // Stop is expected during pause, page changes and queue replacement.
                }

                @Override
                public void onRangeStart(final String utteranceId, final int start, final int end) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            noteSpeechProgress();
                            int rawStart = Math.max(0, start);
                            int rawEnd = Math.max(rawStart + 1, end);
                            lastRangeStart = spokenChunkOffset + rawStart;
                            lastRangeEnd = spokenChunkOffset + rawEnd;
                            broadcastReadingRange(lastRangeStart, lastRangeEnd);
                        }
                    });
                }
            };

    @Override
    public void onCreate() {
        super.onCreate();
        liveInstance = this;
        createChannel();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (powerManager != null) {
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    "GeoZetaPdfAudio:TtsWakeLockV69");
            wakeLock.setReferenceCounted(false);
        }
        engineManager = TtsEngineManager.getInstance(this);
        engineManager.addUtteranceListener(utteranceListener);
        // V28: the service waits for the PDF language before starting TTS.
        // Initializing here could warm the wrong language and then immediately
        // recreate the engine when Play is pressed.
        // V98: no MediaStyle/MediaSession card. Keep the reader as a compact
        // foreground-service notification controlled by our own RemoteViews.
        // V198: se agrega una MediaSession SIN cambiar esa notificacion. Solo
        // sirve para que el sistema reconozca la lectura como reproduccion de
        // medios de verdad: llegan los botones de auriculares y del coche, y el
        // servicio aguanta mejor con la pantalla apagada.
        setupMediaSession();
    }

    private void setupMediaSession() {
        try {
            mediaSession = new MediaSession(this, "GeoZetaReader");
            mediaSession.setCallback(new MediaSession.Callback() {
                @Override
                public void onPlay() {
                    if (paused) resumePlayback();
                }

                @Override
                public void onPause() {
                    if (reading && !paused) pausePlayback();
                }

                @Override
                public void onStop() {
                    stopAll();
                }

                @Override
                public void onSkipToNext() {
                    jumpToPage(currentPageAbsolute + 1);
                }

                @Override
                public void onSkipToPrevious() {
                    jumpToPage(Math.max(0, currentPageAbsolute - 1));
                }
            });
            if (Build.VERSION.SDK_INT < 26) {
                mediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS
                        | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
            }
            mediaSession.setActive(true);
        } catch (Exception ignored) {
            mediaSession = null;
        }
    }

    /**
     * Espeja el estado real de la lectura. Sin esto el sistema no sabe si hay
     * algo sonando y trata la app como ociosa al apagarse la pantalla.
     */
    private void updateMediaSessionState(int state) {
        if (mediaSession == null) return;
        try {
            int sessionState;
            if (state == STATE_PLAYING) sessionState = PlaybackState.STATE_PLAYING;
            else if (state == STATE_PAUSED) sessionState = PlaybackState.STATE_PAUSED;
            else if (state == STATE_PREPARING) sessionState = PlaybackState.STATE_BUFFERING;
            else sessionState = PlaybackState.STATE_STOPPED;

            mediaSession.setPlaybackState(new PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_PLAY
                            | PlaybackState.ACTION_PAUSE
                            | PlaybackState.ACTION_PLAY_PAUSE
                            | PlaybackState.ACTION_STOP
                            | PlaybackState.ACTION_SKIP_TO_NEXT
                            | PlaybackState.ACTION_SKIP_TO_PREVIOUS)
                    .setState(sessionState, PlaybackState.PLAYBACK_POSITION_UNKNOWN, rate)
                    .build());
            boolean shouldBeActive = sessionState != PlaybackState.STATE_STOPPED;
            if (mediaSession.isActive() != shouldBeActive) mediaSession.setActive(shouldBeActive);
        } catch (Exception ignored) {
        }
    }

    private void releaseMediaSession() {
        if (mediaSession == null) return;
        try {
            mediaSession.setActive(false);
            mediaSession.release();
        } catch (Exception ignored) {
        }
        mediaSession = null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_NOT_STICKY;
        String action = intent.getAction();

        if (ACTION_SET_RATE.equals(action)) {
            applyRateChange(intent);
            return START_NOT_STICKY;
        }

        if (ACTION_WARMUP.equals(action)) {
            // Precalentar solo si no esta hablando ahora mismo. Con la lectura
            // sonando no hace falta: el modelo ya esta cargado en memoria.
            //
            // V211. Antes tambien se salia estando en PAUSA, y ahi estaba el
            // "vuelvo despues de un rato y el Play tarda": si Android habia
            // matado el proceso del motor mientras la app estaba en segundo
            // plano, nadie lo comprobaba y la muerte se descubria recien al
            // pulsar Play. En pausa nada esta sonando, asi que la comprobacion
            // silenciosa es segura y la reconexion pasa antes del Play.
            // V212. Con una sesion viva NO se toca el motor: ni la comprobacion
            // que habla, ni readCommonExtras, ni ensureLanguage.
            //
            // En V211 deje entrar el precalentado estando en pausa y eso rompio
            // dos cosas: readCommonExtras pisaba los datos de la sesion abierta
            // (de ahi el "Preparando" que no arrancaba) y el punto mudo de la
            // comprobacion se metia en la cola del motor justo cuando se estaba
            // preparando la pagina siguiente, retrasando su arranque. Tambien se
            // sale en PREPARANDO, que es el momento exacto del cambio de pagina.
            //
            // En pausa si interesa saber si el motor sigue vivo: para eso esta
            // la comprobacion silenciosa, que pregunta al motor sin mandarle
            // nada que reproducir, asi la reconexion pasa antes del Play.
            if (reading || paused || playbackState == STATE_PREPARING) {
                if (paused && !reading) engineManager.checkConnectionSilently();
                return START_NOT_STICKY;
            }
            // V206. Primero se comprueba que el motor siga conectado de verdad.
            // Si Android lo cerro, la reconexion empieza ya, y ensureLanguage de
            // abajo simplemente se suma a esa espera en vez de creer que esta listo.
            engineManager.probeConnection();
            readCommonExtras(intent);
            if (pdfLanguage.length() > 0) engineManager.ensureLanguage(pdfLanguage, pdfRegion, null);
            else engineManager.initialize(null);
            return START_NOT_STICKY;
        }
        if (ACTION_PREPARE.equals(action)) {
            prepareForNewPage(intent);
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action)) {
            startPlayback(intent);
        } else if (ACTION_TOGGLE.equals(action)) {
            if (playbackState == STATE_PAUSED) resumePlayback();
            else if (playbackState == STATE_PLAYING) pausePlayback();
            else if (playbackState == STATE_PREPARING) pausePendingPlayback();
        } else if (ACTION_SEEK_PAGE.equals(action)) {
            readCommonExtras(intent);
            int requestedPage = intent.getIntExtra(EXTRA_PAGE, currentPageAbsolute);
            String suppliedText = intent.getStringExtra(EXTRA_PAGE_TEXT);
            if (suppliedText != null && requestedPage >= 0) {
                PAGE_MAP.put(requestedPage, suppliedText);
            }
            seekToPage(requestedPage,
                    intent.getBooleanExtra(EXTRA_AUTOPLAY, true));
        } else if (ACTION_NEXT.equals(action)) {
            jumpToPage(currentPageAbsolute + 1);
        } else if (ACTION_PREV.equals(action)) {
            jumpToPage(Math.max(0, currentPageAbsolute - 1));
        } else if (ACTION_REPORT_RANGE.equals(action)) {
            if ((reading || paused) && currentChunkIndex >= 0
                    && currentChunkIndex < currentChunks.size()) {
                broadcastReadingRange(lastRangeStart, lastRangeEnd);
            } else {
                savePlaybackState(currentPageAbsolute, playbackState,
                        "Pagina " + (currentPageAbsolute + 1));
            }
        } else if (ACTION_STOP.equals(action)) {
            stopAll();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    /**
     * Marca el instante en que el usuario pidio audio. Se conserva porque el
     * resto del servicio consulta si ya hubo un pedido en curso.
     */
    private void markPlayRequested(String origin) {
        playRequestedAtMs = android.os.SystemClock.elapsedRealtime();
        playRequestOrigin = origin == null ? "" : origin;
        latencyReported = false;
    }

    /** Cierra el pedido en curso cuando ya sono la primera palabra. */
    private void reportPlayLatency(String howItStarted) {
        if (latencyReported || playRequestedAtMs <= 0L) return;
        latencyReported = true;
    }

    private void prepareForNewPage(Intent intent) {
        sessionId++;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        releaseFastResumePlayer();
        waitingForProvider = false;
        waitingForEngine = false;
        servicePrefetchingPages.clear();
        reading = false;
        paused = false;
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        lastRangeStart = 0;
        lastRangeEnd = 1;
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        engineManager.stop();
        readCommonExtras(intent);
        ensureForeground("Preparando pagina " + (currentPageAbsolute + 1));
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Preparando pagina " + (currentPageAbsolute + 1));
    }

    private void startPlayback(Intent intent) {
        sessionId++;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        releaseFastResumePlayer();
        waitingForProvider = false;
        waitingForEngine = false;
        servicePrefetchingPages.clear();
        readCommonExtras(intent);
        currentPageAbsolute = Math.max(0, intent.getIntExtra("pageOffset", currentPageAbsolute)
                + Math.max(0, intent.getIntExtra("startIndex", 0)));
        String suppliedText = intent.getStringExtra(EXTRA_PAGE_TEXT);
        if (suppliedText != null && currentPageAbsolute >= 0) {
            PAGE_MAP.put(currentPageAbsolute, suppliedText);
        }
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        lastRangeStart = 0;
        lastRangeEnd = 1;
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        chunkRetryCount = 0;
        engineRestartCount = 0;
        slowEngineRetryUsed = false;
        reading = true;
        paused = false;
        markPlayRequested("play");
        // No detenemos el motor antes de cada Play. QUEUE_FLUSH reemplaza la cola
        // anterior y evita el costo de reiniciar la salida de voz.
        ensureForeground("Preparando pagina " + (currentPageAbsolute + 1));
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Preparando pagina " + (currentPageAbsolute + 1));

        // En un arranque frio (tambien si Android dejo enfriar/recreo el motor
        // durante esta misma sesion), el audio corto persistido habla de inmediato
        // mientras el TTS vuelve a quedar listo. Antes solo se permitia una vez por
        // proceso, por eso podia volver la espera larga despues de un rato.
        armBridgeFromIntent(intent);
        // V204. El puente de audio de esta pagina ya esta grabado en disco desde
        // que la pagina se asento. Antes solo se usaba si el motor NO estaba
        // listo, o sea como plan de emergencia; si el motor decia estar listo se
        // iba por speak() y habia que esperar a que sintetizara la primera
        // frase. Esa espera es la que se notaba al dar Play.
        //
        // Ahora se usa SIEMPRE que exista. Abrir un WAV chico que ya esta en
        // disco son milisegundos, mientras que sintetizar 280 caracteres es de
        // cientos a mas de mil. Es la misma voz, la misma velocidad y el mismo
        // texto, asi que no se nota ningun corte.
        //
        // Mientras ese primer trozo suena, el motor se prepara por detras para
        // el resto de la pagina, que es tiempo de sobra: el puente dura del
        // orden de quince segundos hablados.
        if (startFastResumeAudio(intent, sessionId)) {
            if (pdfLanguage.length() > 0) engineManager.ensureLanguage(pdfLanguage, pdfRegion, null);
            else engineManager.initialize(null);
            return;
        }
        startWhenEngineReady(sessionId);
    }

    /**
     * V198. Guarda el puente de audio de ESTA orden de Play aunque no se use
     * ahora. Si el motor dice estar listo pero no arranca (su proceso fue
     * reciclado por Android), el rescate lo lanza unos cientos de milisegundos
     * despues. Se rearma en cada Play para no soltar nunca audio de otra pagina.
     */
    private void armBridgeFromIntent(Intent intent) {
        armedBridgePath = intent == null ? null : intent.getStringExtra(EXTRA_FAST_RESUME_AUDIO);
        armedBridgeText = intent == null ? "" : cleanForTts(intent.getStringExtra(EXTRA_FAST_RESUME_TEXT));
        armedBridgeUsed = false;
    }

    private boolean startFastResumeAudio(Intent intent, final int requestSession) {
        return startFastResumeAudio(armedBridgePath, armedBridgeText, requestSession);
    }

    private boolean startFastResumeAudio(String path, String rawText, final int requestSession) {
        String spokenText = rawText == null ? "" : rawText;
        if (path == null || path.trim().length() == 0 || spokenText.length() == 0) return false;
        java.io.File file = new java.io.File(path);
        if (!file.exists() || file.length() <= 64L) return false;
        armedBridgeUsed = true;

        try {
            final MediaPlayer player = new MediaPlayer();
            if (Build.VERSION.SDK_INT >= 21) {
                player.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build());
            }
            player.setDataSource(file.getAbsolutePath());
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (requestSession != sessionId || !fastResumeAudioActive) return;
                            releaseFastResumePlayer();
                            if (!reading || paused) return;
                            savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                                    "Continuando pagina " + (currentPageAbsolute + 1));
                            updateNotification("Continuando pagina " + (currentPageAbsolute + 1));
                            if (engineManager.isReady()) {
                                continueAfterFastStart();
                            } else {
                                waitForEngineAfterFastResume(requestSession);
                            }
                        }
                    });
                }
            });
            player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (requestSession != sessionId) return;
                            releaseFastResumePlayer();
                            fastStartPageActive = false;
                            waitingForFastStartRemainder = false;
                            fastStartSpokenText = null;
                            if (reading && !paused) startWhenEngineReady(requestSession);
                        }
                    });
                    return true;
                }
            });
            player.prepare();

            fastResumePlayer = player;
            fastResumeAudioActive = true;
            fastResumeAudioPaused = false;
            fastStartPageActive = true;
            waitingForFastStartRemainder = false;
            fastStartSpokenText = spokenText;
            currentChunks = Collections.emptyList();
            currentChunkIndex = 0;
            activeUtteranceId = null;
            currentUtteranceStarted = false;
            acquirePlaybackResources();
            player.start();
            reportPlayLatency("audio-puente");
            savePlaybackState(currentPageAbsolute, STATE_PLAYING,
                    "Pagina " + (currentPageAbsolute + 1));
            updateNotification("Pagina " + (currentPageAbsolute + 1)
                    + " - " + String.format(Locale.US, "%.2fx", rate));
            return true;
        } catch (Exception ignored) {
            releaseFastResumePlayer();
            fastStartPageActive = false;
            waitingForFastStartRemainder = false;
            fastStartSpokenText = null;
            return false;
        }
    }

    private void waitForEngineAfterFastResume(final int requestSession) {
        if (requestSession != sessionId || !reading || paused) return;
        if (engineManager.isReady() && (pdfLanguage.length() == 0
                || (engineManager.isPreferredLanguageAvailable()
                && pdfLanguage.equals(engineManager.getPreferredLanguage())))) {
            waitingForEngine = false;
            continueAfterFastStart();
            return;
        }
        if (waitingForEngine) return;
        waitingForEngine = true;
        TtsEngineManager.ReadyCallback callback = new TtsEngineManager.ReadyCallback() {
            @Override
            public void onReady(String enginePackage) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (requestSession == sessionId && reading && !paused) {
                            waitingForEngine = false;
                            continueAfterFastStart();
                        }
                    }
                });
            }

            @Override
            public void onError(final String message) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (requestSession == sessionId && reading && !paused) {
                            waitingForEngine = false;
                            if (retryAfterSlowEngine(message, requestSession)) return;
                            failPlayback(message);
                        }
                    }
                });
            }
        };
        if (pdfLanguage.length() > 0) engineManager.ensureLanguage(pdfLanguage, pdfRegion, callback);
        else engineManager.initialize(callback);
    }

    private void startWhenEngineReady(final int requestSession) {
        if (engineManager.isReady() && (pdfLanguage.length() == 0
                || (engineManager.isPreferredLanguageAvailable()
                && pdfLanguage.equals(engineManager.getPreferredLanguage())))) {
            waitingForEngine = false;
            speakAbsolutePage(currentPageAbsolute);
            return;
        }
        if (waitingForEngine) return;
        waitingForEngine = true;
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Iniciando motor de voz");
        updateNotification("Iniciando motor de voz");
        TtsEngineManager.ReadyCallback callback = new TtsEngineManager.ReadyCallback() {
            @Override
            public void onReady(String enginePackage) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (requestSession == sessionId && reading && !paused) {
                            waitingForEngine = false;
                            speakAbsolutePage(currentPageAbsolute);
                        }
                    }
                });
            }

            @Override
            public void onError(final String message) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (requestSession == sessionId && reading && !paused) {
                            waitingForEngine = false;
                            if (retryAfterSlowEngine(message, requestSession)) return;
                            failPlayback(message);
                        }
                    }
                });
            }
        };
        if (pdfLanguage.length() > 0) engineManager.ensureLanguage(pdfLanguage, pdfRegion, callback);
        else engineManager.initialize(callback);
    }

    /**
     * V211. Aplica una velocidad nueva sin tener que reiniciar la pagina.
     *
     * Si esta sonando, se rehace el trozo actual desde donde iba, asi el cambio
     * se nota al instante. Si esta en pausa o parado, basta con guardar el valor
     * y tirar el audio de pausa ya grabado: estaba a la velocidad anterior y, si
     * se reutilizara, el Play sonaria otra vez a la velocidad vieja. Ese era
     * exactamente el fallo de "elijo 1.50x y tengo que elegirlo dos veces".
     */
    private void applyRateChange(Intent intent) {
        float requested = clampRate(intent.getFloatExtra("rate", rate));
        float requestedPitch = clampPitch(intent.getFloatExtra("pitch", pitch));
        boolean rateChanged = Math.abs(requested - rate) > 0.001f;
        rate = requested;
        pitch = requestedPitch;
        if (!rateChanged) return;

        clearPauseBridge();
        releaseFastResumePlayer();
        try {
            engineManager.setSpeechRate(rate);
            engineManager.setPitch(pitch);
        } catch (Exception ignored) {
        }

        if (playbackState == STATE_PLAYING && reading && !paused) {
            // Se rehace el trozo en curso con la velocidad nueva, continuando
            // desde la palabra por la que iba.
            resumeCharOffset = Math.max(0, lastRangeStart);
            sessionId++;
            cancelUtteranceTimeout();
            engineManager.stop();
            activeUtteranceId = null;
            currentUtteranceStarted = false;
            speakCurrentChunk();
            return;
        }
        if (foregroundStarted) {
            updateNotification("Pagina " + (currentPageAbsolute + 1)
                    + " - " + String.format(Locale.US, "%.2fx", rate));
        }
    }

    private void readCommonExtras(Intent intent) {
        String extraTitle = intent.getStringExtra("title");
        if (extraTitle != null && extraTitle.trim().length() > 0) title = extraTitle;
        totalPages = Math.max(0, intent.getIntExtra("totalPages", totalPages));
        currentPageAbsolute = Math.max(0,
                intent.getIntExtra("pageOffset", currentPageAbsolute));
        rate = clampRate(intent.getFloatExtra("rate", rate));
        pitch = clampPitch(intent.getFloatExtra("pitch", pitch));

        String extraLanguage = intent.getStringExtra(EXTRA_TTS_LANGUAGE);
        if (extraLanguage != null) pdfLanguage = PdfLanguageDetector.normalizeCode(extraLanguage);
        String extraRegion = intent.getStringExtra(EXTRA_TTS_REGION);
        if (extraRegion != null) pdfRegion = extraRegion.trim().toUpperCase(Locale.ROOT);
        if (pdfLanguage.length() > 0) engineManager.setPreferredLanguage(pdfLanguage, pdfRegion);
    }

    private void jumpToPage(int targetPage) {
        seekToPage(targetPage, true);
    }

    private void seekToPage(int targetPage, boolean autoplay) {
        if (totalPages > 0) targetPage = Math.min(targetPage, totalPages - 1);
        sessionId++;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        releaseFastResumePlayer();
        engineManager.stop();
        currentPageAbsolute = Math.max(0, targetPage);
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        waitingForProvider = false;
        waitingForEngine = false;
        servicePrefetchingPages.clear();
        engineRestartCount = 0;
        slowEngineRetryUsed = false;
        lastRangeStart = 0;
        lastRangeEnd = 1;

        if (autoplay) {
            reading = true;
            paused = false;
            markPlayRequested("cambio-pagina");
            ensureForeground("Preparando pagina " + (currentPageAbsolute + 1));
            savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                    "Preparando pagina " + (currentPageAbsolute + 1));
            startWhenEngineReady(sessionId);
        } else {
            reading = false;
            paused = true;
            savePlaybackState(currentPageAbsolute, STATE_PAUSED, "Pausado");
            if (foregroundStarted) updateNotification("Pausado");
            releaseAudioFocus();
            releaseWakeLock();
        }
    }

    private void pausePendingPlayback() {
        sessionId++;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        releaseFastResumePlayer();
        engineManager.stop();
        waitingForProvider = false;
        waitingForEngine = false;
        servicePrefetchingPages.clear();
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        reading = false;
        paused = true;
        savePlaybackState(currentPageAbsolute, STATE_PAUSED, "Pausado");
        if (foregroundStarted) updateNotification("Pausado");
        releaseAudioFocus();
        releaseWakeLock();
    }

    private void speakCurrentPageOrChunk() {
        if (!reading || paused) return;
        if (!currentChunks.isEmpty() && currentChunkIndex < currentChunks.size()) {
            speakCurrentChunk();
        } else {
            speakAbsolutePage(currentPageAbsolute);
        }
    }

    private void speakAbsolutePage(final int absolutePage) {
        if (!reading || paused) return;
        if (!engineManager.isReady() || (pdfLanguage.length() > 0
                && (!engineManager.isPreferredLanguageAvailable()
                || !pdfLanguage.equals(engineManager.getPreferredLanguage())))) {
            startWhenEngineReady(sessionId);
            return;
        }
        if (totalPages > 0 && absolutePage >= totalPages) {
            finishPlayback();
            return;
        }

        String stored = PAGE_MAP.get(absolutePage);
        if (stored != null) {
            String fastStart = selectFastPageStart(absolutePage, stored);
            if (fastStart.length() > 0) {
                FAST_PAGE_MAP.put(absolutePage, fastStart);
                speakFastTextForPage(absolutePage, fastStart);
                return;
            }
            speakTextForPage(absolutePage, stored);
            return;
        }
        String fast = FAST_PAGE_MAP.get(absolutePage);
        if (fast != null && fast.trim().length() > 0) {
            speakFastTextForPage(absolutePage, fast);
            return;
        }
        requestPageFromProvider(absolutePage);
    }

    private void requestPageFromProvider(final int absolutePage) {
        if (!reading || paused || waitingForProvider) return;
        final PageProvider provider = pageProvider;
        if (provider == null) {
            failPlayback("La aplicacion no pudo obtener el texto de la pagina");
            return;
        }

        waitingForProvider = true;
        final int requestSession = sessionId;
        savePlaybackState(absolutePage, STATE_PREPARING,
                "Preparando pagina " + (absolutePage + 1));
        updateNotification("Preparando pagina " + (absolutePage + 1));

        providerTimeout = new Runnable() {
            @Override
            public void run() {
                if (requestSession != sessionId || !waitingForProvider) return;
                waitingForProvider = false;
                if (!reading || paused) return;
                // V214. Antes de darse por vencido se reintenta la pagina una
                // vez. La mayoria de estos casos son una extraccion que se
                // perdio, no un PDF roto: reintentar la recupera sin que el
                // usuario vea ningun error.
                if (providerRetryPage != absolutePage) {
                    providerRetryPage = absolutePage;
                    requestPageFromProvider(absolutePage);
                    return;
                }
                failPlayback("El PDF tardo demasiado en entregar el texto");
            }
        };
        handler.postDelayed(providerTimeout, 10000L);

        try {
            provider.requestPageText(absolutePage, new PageTextCallback() {
                @Override
                public void onFastText(final String text) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (requestSession != sessionId
                                    || absolutePage != currentPageAbsolute
                                    || !reading || paused) {
                                // El texto llego tarde (pausa, cambio de pagina
                                // o sesion nueva): se suelta la espera para que
                                // la proxima vez se vuelva a pedir.
                                if (requestSession == sessionId) {
                                    cancelProviderTimeout();
                                    waitingForProvider = false;
                                }
                                return;
                            }
                            if (PAGE_MAP.containsKey(absolutePage) || fastStartPageActive) return;
                            String fast = text == null ? "" : text.trim();
                            if (fast.length() == 0) return;
                            cancelProviderTimeout();
                            waitingForProvider = false;
                            FAST_PAGE_MAP.put(absolutePage, fast);
                            speakFastTextForPage(absolutePage, fast);
                        }
                    });
                }

                @Override
                public void onText(final String text) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (requestSession != sessionId
                                    || absolutePage != currentPageAbsolute
                                    || !reading || paused) {
                                if (requestSession == sessionId) {
                                    cancelProviderTimeout();
                                    waitingForProvider = false;
                                }
                                return;
                            }
                            cancelProviderTimeout();
                            waitingForProvider = false;
                            PAGE_MAP.put(absolutePage, text == null ? "" : text);
                            if (fastStartPageActive) {
                                if (waitingForFastStartRemainder) {
                                    speakRemainderAfterFastStart(absolutePage, text);
                                }
                                return;
                            }
                            speakTextForPage(absolutePage, text);
                        }
                    });
                }
            });
        } catch (Exception ignored) {
            cancelProviderTimeout();
            waitingForProvider = false;
            failPlayback("No se pudo extraer el texto de la pagina");
        }
    }

    private void speakTextForPage(int absolutePage, String rawText) {
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        speakPreparedTextForPage(absolutePage, rawText);
    }

    private void speakFastTextForPage(int absolutePage, String rawText) {
        String fast = cleanForTts(rawText);
        if (fast.length() == 0) {
            requestPageFromProvider(absolutePage);
            return;
        }
        fastStartPageActive = true;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = fast;
        speakPreparedTextForPage(absolutePage, fast);
    }

    private void speakPreparedTextForPage(int absolutePage, String rawText) {
        if (!reading || paused || absolutePage != currentPageAbsolute) return;
        String text = cleanForTts(rawText);
        if (text.length() == 0) {
            advancePastUnreadablePage();
            return;
        }

        currentChunks = splitText(text);
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        lastRangeStart = 0;
        lastRangeEnd = currentChunks.isEmpty() ? 1 : firstWordEnd(currentChunks.get(0));
        chunkRetryCount = 0;
        if (currentChunks.isEmpty()) {
            advancePastUnreadablePage();
            return;
        }
        speakCurrentChunk();
        if (!fastStartPageActive) {
            prefetchUpcomingPage(absolutePage + 1);
        }
    }

    private String selectFastPageStart(int absolutePage, String fullRawText) {
        if (fastStartPageActive || waitingForFastStartRemainder) return "";
        String full = cleanForTts(fullRawText);
        if (full.length() < PAGE_START_FAST_MIN_CHARS) return "";

        String cachedFast = cleanForTts(FAST_PAGE_MAP.get(absolutePage));
        if (isUsableFastPageStart(full, cachedFast)) return cachedFast;

        String generated = buildFastPageStart(full);
        return isUsableFastPageStart(full, generated) ? generated : "";
    }

    private boolean isUsableFastPageStart(String full, String fast) {
        return full != null && fast != null
                && fast.length() >= PAGE_START_FAST_MIN_SPLIT
                && fast.length() < full.length()
                && full.startsWith(fast);
    }

    private String buildFastPageStart(String full) {
        if (full == null) return "";
        int end = Math.min(full.length(), PAGE_START_FAST_MAX_CHARS);
        int min = Math.min(end, PAGE_START_FAST_MIN_SPLIT);
        int split = -1;
        for (int i = end - 1; i >= min; i--) {
            char c = full.charAt(i);
            if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':') {
                split = i + 1;
                break;
            }
        }
        if (split < 0) {
            for (int i = end - 1; i >= min; i--) {
                if (Character.isWhitespace(full.charAt(i))) {
                    split = i + 1;
                    break;
                }
            }
        }
        if (split < 0) split = end;
        return full.substring(0, split).trim();
    }

    private void prefetchUpcomingPage(final int absolutePage) {
        if (absolutePage < 0 || (totalPages > 0 && absolutePage >= totalPages)) return;
        if (PAGE_MAP.containsKey(absolutePage)) return;
        final PageProvider provider = pageProvider;
        if (provider == null) return;
        if (servicePrefetchingPages.putIfAbsent(absolutePage, Boolean.TRUE) != null) return;

        final int requestSession = sessionId;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                servicePrefetchingPages.remove(absolutePage);
            }
        }, 20000L);

        try {
            provider.requestPageText(absolutePage, new PageTextCallback() {
                @Override
                public void onFastText(String text) {
                    if (requestSession != sessionId || !reading || paused) return;
                    String fast = cleanForTts(text);
                    if (fast.length() > 0) FAST_PAGE_MAP.put(absolutePage, fast);
                }

                @Override
                public void onText(String text) {
                    servicePrefetchingPages.remove(absolutePage);
                    if (requestSession != sessionId || !reading || paused) return;
                    String full = text == null ? "" : text;
                    PAGE_MAP.put(absolutePage, full);
                    String fast = selectFastPageStart(absolutePage, full);
                    if (fast.length() > 0) FAST_PAGE_MAP.put(absolutePage, fast);
                }
            });
        } catch (Exception ignored) {
            servicePrefetchingPages.remove(absolutePage);
        }
    }

    private boolean continueAfterFastStart() {
        if (!fastStartPageActive || !reading || paused) return false;
        String full = PAGE_MAP.get(currentPageAbsolute);
        if (full != null) {
            speakRemainderAfterFastStart(currentPageAbsolute, full);
            return true;
        }

        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        waitingForFastStartRemainder = true;
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Completando pagina " + (currentPageAbsolute + 1));
        requestPageFromProvider(currentPageAbsolute);
        return true;
    }

    private void speakRemainderAfterFastStart(int absolutePage, String fullText) {
        if (!reading || paused || absolutePage != currentPageAbsolute) return;
        String full = cleanForTts(fullText);
        String spoken = cleanForTts(fastStartSpokenText);
        String remainder = removeSpokenPrefix(full, spoken);

        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        FAST_PAGE_MAP.remove(absolutePage);

        if (remainder.length() == 0) {
            advanceToNextPage();
            return;
        }
        speakPreparedTextForPage(absolutePage, remainder);
    }

    private String removeSpokenPrefix(String full, String spoken) {
        if (full == null) return "";
        String safeFull = cleanForTts(full);
        String safeSpoken = cleanForTts(spoken);
        if (safeSpoken.length() == 0) return safeFull;
        if (safeFull.startsWith(safeSpoken)) {
            return safeFull.substring(safeSpoken.length()).trim();
        }

        String[] fullWords = safeFull.split("\\s+");
        String[] spokenWords = safeSpoken.split("\\s+");
        int matched = 0;
        int limit = Math.min(fullWords.length, spokenWords.length);
        while (matched < limit && normalizedWord(fullWords[matched])
                .equals(normalizedWord(spokenWords[matched]))) {
            matched++;
        }
        int required = Math.min(spokenWords.length, Math.max(3, spokenWords.length * 2 / 3));
        if (matched >= required && matched > 0) {
            StringBuilder remainder = new StringBuilder();
            for (int i = matched; i < fullWords.length; i++) {
                if (remainder.length() > 0) remainder.append(' ');
                remainder.append(fullWords[i]);
            }
            return remainder.toString().trim();
        }

        int tailLength = Math.min(28, safeSpoken.length());
        if (tailLength >= 10) {
            String tail = safeSpoken.substring(safeSpoken.length() - tailLength);
            int maxSearch = Math.min(safeFull.length(), Math.max(500, safeSpoken.length() * 3));
            int found = safeFull.substring(0, maxSearch).indexOf(tail);
            if (found >= 0) {
                return safeFull.substring(found + tail.length()).trim();
            }
        }

        int approximate = Math.min(safeFull.length(), safeSpoken.length());
        while (approximate < safeFull.length()
                && !Character.isWhitespace(safeFull.charAt(approximate))) {
            approximate++;
        }
        return safeFull.substring(Math.min(approximate, safeFull.length())).trim();
    }

    private String normalizedWord(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]", "");
    }

    private void advanceToNextPage() {
        currentPageAbsolute++;
        currentChunkIndex = 0;
        currentChunks = Collections.emptyList();
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        if (totalPages > 0 && currentPageAbsolute >= totalPages) {
            finishPlayback();
        } else {
            savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                    "Preparando pagina " + (currentPageAbsolute + 1));
            speakAbsolutePage(currentPageAbsolute);
        }
    }

    private void advancePastUnreadablePage() {
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        currentPageAbsolute++;
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        if (totalPages > 0 && currentPageAbsolute >= totalPages) {
            finishPlayback();
            return;
        }
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Preparando pagina " + (currentPageAbsolute + 1));
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (reading && !paused) speakAbsolutePage(currentPageAbsolute);
            }
        });
    }

    private void speakCurrentChunk() {
        if (!reading || paused) return;
        if (!engineManager.isReady() || (pdfLanguage.length() > 0
                && (!engineManager.isPreferredLanguageAvailable()
                || !pdfLanguage.equals(engineManager.getPreferredLanguage())))) {
            startWhenEngineReady(sessionId);
            return;
        }
        if (currentChunkIndex < 0 || currentChunkIndex >= currentChunks.size()) {
            failPlayback("El audio no pudo preparar el texto");
            return;
        }

        acquirePlaybackResources();
        engineManager.setSpeechRate(rate);
        engineManager.setPitch(pitch);

        final String fullChunk = currentChunks.get(currentChunkIndex);
        int offset = resumeCharOffset;
        if (offset < 0 || offset >= fullChunk.length()) offset = 0;
        // Se retrocede hasta el principio de la palabra para no cortarla al medio.
        while (offset > 0 && !Character.isWhitespace(fullChunk.charAt(offset - 1))) offset--;
        String textToSpeak = offset > 0 ? fullChunk.substring(offset) : fullChunk;
        if (textToSpeak.trim().length() == 0) {
            offset = 0;
            textToSpeak = fullChunk;
        }
        resumeCharOffset = 0;
        spokenChunkOffset = offset;
        currentSpokenText = textToSpeak;

        lastRangeStart = spokenChunkOffset;
        lastRangeEnd = spokenChunkOffset + firstWordEnd(textToSpeak);

        final int requestSession = sessionId;
        final long requestUtteranceSerial = ++utteranceSerial;
        final String utteranceId = "S" + requestSession + "_P" + currentPageAbsolute
                + "_C" + currentChunkIndex + "_O" + spokenChunkOffset
                + "_R" + chunkRetryCount + "_U" + requestUtteranceSerial;
        activeUtteranceId = utteranceId;
        currentUtteranceStarted = false;

        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
        int result = engineManager.speak(textToSpeak,
                TextToSpeech.QUEUE_FLUSH, params, utteranceId);
        if (result == TextToSpeech.ERROR) {
            handleSpeakRejected(requestSession);
            return;
        }
        // El seguimiento visual puede aparecer de inmediato, sin esperar a que el
        // motor devuelva onRangeStart. onStart/onRangeStart lo corrigen después.
        broadcastReadingRange(lastRangeStart, lastRangeEnd);
        scheduleUtteranceCheck(requestSession, utteranceId);
        // Despues del vigilante: scheduleUtteranceCheck limpia los avisos
        // pendientes, asi que el rescate se arma al final o se borraria solo.
        scheduleStartRescue(requestSession, utteranceId);
    }

    /**
     * V198. Rescate de arranque. El vigilante normal espera entre 2,6 y 5,2
     * segundos antes de dar por muerto al motor, y eso se nota como "el Play
     * tarda". Este mira a los 800 ms: si no hay ni onStart ni audio y tenemos el
     * puente grabado de esta pagina, se corta el intento y suena el puente
     * mientras el motor se reconecta por detras.
     *
     * Solo actua al principio de una pagina y una sola vez por Play, para no
     * cortar audio que ya iba bien.
     */
    private void scheduleStartRescue(final int requestSession, final String utteranceId) {
        cancelStartRescue();
        if (armedBridgeUsed) return;
        if (armedBridgePath == null || armedBridgePath.length() == 0) return;
        if (currentChunkIndex != 0 || spokenChunkOffset != 0 || chunkRetryCount != 0) return;
        if (fastResumeAudioActive || fastStartPageActive) return;

        startRescue = new Runnable() {
            @Override
            public void run() {
                startRescue = null;
                if (requestSession != sessionId || !isCurrentUtterance(utteranceId)) return;
                if (!reading || paused || currentUtteranceStarted) return;
                if (fastResumeAudioActive || fastStartPageActive) return;
                if (engineManager.isSpeaking()) return;

                String path = armedBridgePath;
                String text = armedBridgeText;
                // Un solo intento por Play: si el puente no sirve, no se puede
                // reprogramar o quedaria reintentando cada 800 ms.
                armedBridgeUsed = true;
                // Se corta el intento en curso antes de soltar el puente: si el
                // motor despertara tarde se oirian las dos voces encimadas.
                cancelUtteranceTimeout();
                activeUtteranceId = null;
                try { engineManager.stop(); } catch (Exception ignored) { }

                if (!startFastResumeAudio(path, text, requestSession)) {
                    speakCurrentChunk();
                    return;
                }
                if (pdfLanguage.length() > 0) {
                    engineManager.ensureLanguage(pdfLanguage, pdfRegion, null);
                } else {
                    engineManager.initialize(null);
                }
            }
        };
        handler.postDelayed(startRescue, START_RESCUE_MS);
    }

    private void cancelStartRescue() {
        if (startRescue != null) {
            handler.removeCallbacks(startRescue);
            startRescue = null;
        }
    }

    private void scheduleUtteranceCheck(final int requestSession, final String utteranceId) {
        cancelUtteranceTimeout();
        utteranceTimeout = new Runnable() {
            @Override
            public void run() {
                if (requestSession != sessionId || !isCurrentUtterance(utteranceId)
                        || !reading || paused || currentUtteranceStarted) return;
                if (engineManager.isSpeaking()) {
                    currentUtteranceStarted = true;
                    savePlaybackState(currentPageAbsolute, STATE_PLAYING,
                            "Pagina " + (currentPageAbsolute + 1));
                    updateNotification("Pagina " + (currentPageAbsolute + 1)
                            + " - " + String.format(Locale.US, "%.2fx", rate));
                } else if (chunkRetryCount < 1) {
                    chunkRetryCount++;
                    speakCurrentChunk();
                } else {
                    restartEngineOrFail("El motor recibio el texto pero no inicio el audio");
                }
            }
        };
        // Algunos motores TTS tardan varios segundos en entregar el primer
        // onStart despues de un arranque en frio. No tratar una inicializacion
        // normal como fallo ni reiniciar el motor demasiado pronto.
        long startGraceMs = hasSpokenInProcess ? 2600L : 5200L;
        handler.postDelayed(utteranceTimeout, startGraceMs);
    }

    private void handleSpeakRejected(final int requestSession) {
        if (requestSession != sessionId || !reading || paused) return;
        if (chunkRetryCount < 1) {
            chunkRetryCount++;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (requestSession == sessionId && reading && !paused) {
                        speakCurrentChunk();
                    }
                }
            }, 300L);
        } else {
            restartEngineOrFail("El motor de voz rechazo el texto");
        }
    }

    private void restartEngineOrFail(String finalMessage) {
        if (engineRestartCount < 1 && reading && !paused) {
            engineRestartCount++;
            // Preserve the latest confirmed word position across a full engine
            // rebuild. Without this, recovery could repeat a large chunk.
            resumeCharOffset = Math.max(resumeCharOffset, Math.max(0, lastRangeStart));
            chunkRetryCount = 0;
            waitingForEngine = false;
            currentUtteranceStarted = false;
            activeUtteranceId = null;
            cancelUtteranceTimeout();
            savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                    "Reiniciando motor de voz");
            updateNotification("Reiniciando motor de voz");
            engineManager.retryInitialization();
            startWhenEngineReady(sessionId);
        } else {
            // Ya se reintento y sigue fallando. Si ademas no hay ninguna voz
            // descargada para este idioma, decirlo es mucho mas util que
            // mostrar "codigo -1": la pantalla ofrece descargarla.
            String language = engineManager.getPreferredLanguage();
            if (engineManager.isPreferredVoiceMissing() && language.length() > 0) {
                failPlayback(ERROR_MISSING_VOICE_PREFIX + language);
            } else {
                failPlayback(finalMessage);
            }
        }
    }

    private boolean isCurrentUtterance(String utteranceId) {
        return utteranceId != null && utteranceId.equals(activeUtteranceId);
    }

    private List<String> splitText(String text) {
        if (text == null || text.trim().length() == 0) return Collections.emptyList();
        int engineLimit = TextToSpeech.getMaxSpeechInputLength();
        // Se usa casi todo el limite seguro del motor. Menos ordenes TTS significa
        // menos fronteras donde algunos motores introducen silencios de milisegundos.
        int maxLength = Math.max(1000, Math.min(3600, engineLimit - 120));
        ArrayList<String> chunks = new ArrayList<String>();
        String remaining = text.trim();

        while (remaining.length() > maxLength) {
            int minimum = Math.max(1, (int) (maxLength * 0.72f));
            int split = findSplitPoint(remaining, minimum, maxLength);
            String chunk = remaining.substring(0, split).trim();
            if (chunk.length() > 0) chunks.add(chunk);
            remaining = remaining.substring(split).trim();
        }
        if (remaining.length() > 0) chunks.add(remaining);
        return chunks;
    }

    private int findSplitPoint(String value, int minimum, int maximum) {
        int safeMaximum = Math.min(maximum, value.length());
        for (int i = safeMaximum - 1; i >= minimum; i--) {
            char c = value.charAt(i);
            if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':' || c == '\n') {
                return i + 1;
            }
        }
        for (int i = safeMaximum - 1; i >= minimum; i--) {
            if (Character.isWhitespace(value.charAt(i))) return i + 1;
        }
        return safeMaximum;
    }

    private void pausePlayback() {
        if (playbackState != STATE_PLAYING) return;
        cancelUtteranceTimeout();
        // V214. Si se pausa mientras el PDF todavia estaba entregando el texto
        // de la pagina, hay que soltar esa espera. Si no, waitingForProvider se
        // queda en true, el Play siguiente encuentra la puerta cerrada y la
        // lectura no vuelve a arrancar: el "Preparando" que no hace nada.
        cancelProviderTimeout();
        waitingForProvider = false;
        if (fastResumeAudioActive && fastResumePlayer != null) {
            try { fastResumePlayer.pause(); } catch (Exception ignored) {}
            fastResumeAudioPaused = true;
            reading = false;
            paused = true;
            savePlaybackState(currentPageAbsolute, STATE_PAUSED, "Pausado");
            updateNotification("Pausado");
            releaseAudioFocus();
            releaseWakeLock();
            return;
        }
        reading = false;
        paused = true;
        // Se anota donde iba la voz para reanudar exactamente ahi.
        resumeCharOffset = Math.max(0, lastRangeStart);
        // Invalidate the utterance BEFORE stop(): some engines send onDone/onStop
        // late, even after a new resume has already been queued.
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        engineManager.stop();
        savePlaybackState(currentPageAbsolute, STATE_PAUSED, "Pausado");
        updateNotification("Pausado");
        releaseAudioFocus();
        releaseWakeLock();
        preparePauseBridge();
    }

    /**
     * V203. Graba lo que quedaba por decir del fragmento actual.
     *
     * El problema de fondo: TextToSpeech no tiene pausa de verdad, solo stop().
     * Al reanudar habia que volver a sintetizar la frase desde donde iba, y eso
     * son los segundos de espera con los puntos suspensivos.
     *
     * Aqui se aprovecha que el usuario esta pausado, que es justo cuando no hay
     * prisa, para dejar ese audio ya hecho. Al pulsar play se reproduce un
     * archivo que ya existe: es instantaneo, no se sintetiza nada.
     *
     * El texto es EXACTAMENTE el que hablaria speakCurrentChunk(), incluido el
     * retroceso hasta el principio de la palabra, para que no se repita ni se
     * pierda ni media silaba.
     */
    private void preparePauseBridge() {
        clearPauseBridge();
        if (currentChunkIndex < 0 || currentChunkIndex >= currentChunks.size()) return;

        String fullChunk = currentChunks.get(currentChunkIndex);
        if (fullChunk == null || fullChunk.length() == 0) return;
        int offset = resumeCharOffset;
        if (offset < 0 || offset >= fullChunk.length()) offset = 0;
        while (offset > 0 && !Character.isWhitespace(fullChunk.charAt(offset - 1))) offset--;
        String remainder = offset > 0 ? fullChunk.substring(offset) : fullChunk;
        if (remainder.trim().length() == 0) return;

        final java.io.File target = new java.io.File(getCacheDir(), "pause_bridge_v203.wav");
        try { if (target.exists()) target.delete(); } catch (Exception ignored) { }

        final String utteranceId = "pause_" + sessionId + "_" + System.nanoTime();
        pauseBridgeFile = target;
        pauseBridgeText = remainder;
        pauseBridgePage = currentPageAbsolute;
        pauseBridgeChunk = currentChunkIndex;
        pauseBridgeRate = rate;
        pauseBridgeLanguage = pdfLanguage == null ? "" : pdfLanguage;
        pauseBridgeUtteranceId = utteranceId;
        pauseBridgeReady = false;

        Bundle params = new Bundle();
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId);
        engineManager.setSpeechRate(rate);
        engineManager.setPitch(pitch);
        engineManager.synthesizeToFile(remainder, params, target, utteranceId,
                new TtsEngineManager.FileSynthesisCallback() {
                    @Override
                    public void onCompleted() {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (!utteranceId.equals(pauseBridgeUtteranceId)) return;
                                // 44 bytes es la cabecera WAV: por debajo de eso
                                // el archivo esta vacio aunque el motor diga que
                                // termino bien.
                                pauseBridgeReady = target.exists() && target.length() > 44L;
                            }
                        });
                    }

                    @Override
                    public void onError(String message) {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (!utteranceId.equals(pauseBridgeUtteranceId)) return;
                                clearPauseBridge();
                            }
                        });
                    }
                });
    }

    private void clearPauseBridge() {
        pauseBridgeReady = false;
        pauseBridgeUtteranceId = null;
        pauseBridgeText = null;
        pauseBridgePage = -1;
        pauseBridgeChunk = -1;
        pauseBridgeLanguage = "";
        if (pauseBridgeFile != null) {
            try { if (pauseBridgeFile.exists()) pauseBridgeFile.delete(); } catch (Exception ignored) { }
            pauseBridgeFile = null;
        }
    }

    /** Solo sirve si nada cambio entre la pausa y el play. */
    private boolean pauseBridgeIsUsable() {
        if (!pauseBridgeReady || pauseBridgeFile == null || pauseBridgeText == null) return false;
        if (pauseBridgePage != currentPageAbsolute) return false;
        if (pauseBridgeChunk != currentChunkIndex) return false;
        if (Math.abs(pauseBridgeRate - rate) > 0.001f) return false;
        if (!pauseBridgeLanguage.equals(pdfLanguage == null ? "" : pdfLanguage)) return false;
        return pauseBridgeFile.exists() && pauseBridgeFile.length() > 44L;
    }

    private void resumePlayback() {
        if (playbackState != STATE_PAUSED) return;
        markPlayRequested("reanudar");
        if (fastResumeAudioActive && fastResumeAudioPaused && fastResumePlayer != null) {
            reading = true;
            paused = false;
            fastResumeAudioPaused = false;
            acquirePlaybackResources();
            try {
                fastResumePlayer.start();
                reportPlayLatency("audio-puente-reanudar");
                savePlaybackState(currentPageAbsolute, STATE_PLAYING,
                        "Pagina " + (currentPageAbsolute + 1));
                updateNotification("Pagina " + (currentPageAbsolute + 1)
                        + " - " + String.format(Locale.US, "%.2fx", rate));
                return;
            } catch (Exception ignored) {
                releaseFastResumePlayer();
            }
        }
        // V203. Si el audio de la pausa ya esta grabado, se reproduce y listo.
        // Sin sintetizar nada, sin pasar por "Preparando": suena al instante.
        if (pauseBridgeIsUsable() && startPauseBridgePlayback(sessionId)) return;

        reading = true;
        paused = false;
        chunkRetryCount = 0;
        ensureForeground("Preparando pagina " + (currentPageAbsolute + 1));
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Reanudando pagina " + (currentPageAbsolute + 1));
        speakCurrentPageOrChunk();
    }

    /**
     * V203. Reproduce el audio grabado al pausar y, cuando termina, sigue con el
     * fragmento siguiente por el camino normal.
     *
     * Es a proposito un metodo aparte y no una variante de startFastResumeAudio:
     * aquel vacia currentChunks porque reemplaza la pagina entera, y aqui hace
     * falta justo lo contrario, conservar la lista de fragmentos para poder
     * continuar donde toca.
     */
    private boolean startPauseBridgePlayback(final int requestSession) {
        final java.io.File file = pauseBridgeFile;
        if (file == null || !file.exists() || file.length() <= 44L) return false;
        try {
            final MediaPlayer player = new MediaPlayer();
            if (Build.VERSION.SDK_INT >= 21) {
                player.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build());
            }
            player.setDataSource(file.getAbsolutePath());
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (requestSession != sessionId || !fastResumeAudioActive) return;
                            releaseFastResumePlayer();
                            clearPauseBridge();
                            if (!reading || paused) return;
                            // El fragmento quedo dicho entero: sigue el siguiente,
                            // o la pagina siguiente si ya no quedan.
                            handleUtteranceFinished();
                        }
                    });
                }
            });
            player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (requestSession != sessionId) return;
                            releaseFastResumePlayer();
                            clearPauseBridge();
                            // Si el archivo fallara, se reanuda como siempre.
                            if (reading && !paused) speakCurrentPageOrChunk();
                        }
                    });
                    return true;
                }
            });
            player.prepare();

            reading = true;
            paused = false;
            chunkRetryCount = 0;
            activeUtteranceId = null;
            currentUtteranceStarted = false;
            fastResumePlayer = player;
            fastResumeAudioActive = true;
            fastResumeAudioPaused = false;
            acquirePlaybackResources();
            player.start();
            reportPlayLatency("puente-pausa");
            savePlaybackState(currentPageAbsolute, STATE_PLAYING,
                    "Pagina " + (currentPageAbsolute + 1));
            updateNotification("Pagina " + (currentPageAbsolute + 1)
                    + " - " + String.format(Locale.US, "%.2fx", rate));
            return true;
        } catch (Exception ignored) {
            releaseFastResumePlayer();
            clearPauseBridge();
            return false;
        }
    }

    private void finishPlayback() {
        releaseFastResumePlayer();
        clearPauseBridge();
        reading = false;
        paused = false;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        waitingForProvider = false;
        waitingForEngine = false;
        servicePrefetchingPages.clear();
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        savePlaybackState(Math.max(0, currentPageAbsolute - 1), STATE_STOPPED,
                "Lectura finalizada");
        updateNotification("Lectura finalizada");
        releaseAudioFocus();
        releaseWakeLock();
        stopForeground(true);
        foregroundStarted = false;
        // El servicio queda caliente para que el siguiente Play no cree otra vez
        // el motor. Android puede liberarlo si necesita memoria.
    }

    private void stopAll() {
        clearPauseBridge();
        releaseFastResumePlayer();
        sessionId++;
        reading = false;
        paused = false;
        waitingForProvider = false;
        waitingForEngine = false;
        servicePrefetchingPages.clear();
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        engineManager.stop();
        savePlaybackState(currentPageAbsolute, STATE_STOPPED, "Detenido");
        releaseAudioFocus();
        releaseWakeLock();
        stopForeground(true);
        foregroundStarted = false;
        // Se conserva el servicio y el motor para el siguiente Play.
    }

    /**
     * Si el motor solo tardo demasiado en encender, se vuelve a intentar solo,
     * sin molestar al usuario. Es lo mismo que el usuario conseguia apretando
     * Play por segunda vez.
     *
     * V206. Antes se reintentaba una sola vez y al fallar de nuevo el boton
     * volvia a Play en silencio. Ahora se sigue reintentando mientras no pasen
     * SLOW_ENGINE_MAX_WAIT_MS desde el pedido de audio. Solo despues de ese
     * tope se da por fallido, y entonces la pantalla si lo avisa.
     */
    private boolean retryAfterSlowEngine(String message, final int requestSession) {
        if (message == null || !TtsEngineManager.ERROR_ENGINE_SLOW.equals(message)) return false;
        long waitedMs = playRequestedAtMs > 0L
                ? android.os.SystemClock.elapsedRealtime() - playRequestedAtMs
                : Long.MAX_VALUE;
        if (waitedMs >= SLOW_ENGINE_MAX_WAIT_MS) return false;
        slowEngineRetryUsed = true;
        savePlaybackState(currentPageAbsolute, STATE_PREPARING, "Iniciando motor de voz");
        updateNotification("Iniciando motor de voz");
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (requestSession != sessionId || !reading || paused) return;
                startWhenEngineReady(requestSession);
            }
        }, 500L);
        return true;
    }

    private void failPlayback(String message) {
        releaseFastResumePlayer();
        sessionId++;
        reading = false;
        paused = false;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        waitingForProvider = false;
        waitingForEngine = false;
        servicePrefetchingPages.clear();
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        engineManager.stop();
        savePlaybackState(currentPageAbsolute, STATE_ERROR, message);
        if (foregroundStarted) updateNotification(message);
        releaseAudioFocus();
        releaseWakeLock();
        stopForeground(true);
        foregroundStarted = false;
        // Incluso tras un error, el administrador TTS permanece disponible.
    }

    private void releaseFastResumePlayer() {
        MediaPlayer player = fastResumePlayer;
        fastResumePlayer = null;
        fastResumeAudioActive = false;
        fastResumeAudioPaused = false;
        if (player != null) {
            try { player.setOnCompletionListener(null); } catch (Exception ignored) {}
            try { player.setOnErrorListener(null); } catch (Exception ignored) {}
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
        }
    }

    private void cancelProviderTimeout() {
        if (providerTimeout != null) {
            handler.removeCallbacks(providerTimeout);
            providerTimeout = null;
        }
    }

    /**
     * Continua la lectura cuando el fragmento actual ya termino: pasa al
     * siguiente trozo, o a la pagina siguiente si no quedan trozos.
     */
    private void handleUtteranceFinished() {
        if (currentChunkIndex + 1 < currentChunks.size()) {
            currentChunkIndex++;
            speakCurrentChunk();
            return;
        }
        if (fastStartPageActive && continueAfterFastStart()) {
            return;
        }
        advanceToNextPage();
    }

    /**
     * Vigilante contra el silencio.
     *
     * El aviso onDone del motor de voz no siempre llega. Pasa sobre todo cuando
     * el motor llevaba rato sin usarse: habla la frase y despues no avisa nada,
     * asi que la app se queda esperando un aviso que no va a venir y la lectura
     * se corta sin motivo aparente.
     *
     * Es imprescindible que este vigilante NO se adelante. Si actua mientras la
     * voz todavia esta hablando, pide el texto siguiente encima del actual y se
     * escucha entrecortado. Por eso solo continua cuando hay pruebas de que el
     * motor esta realmente detenido:
     *
     *   1. Espera una primera pausa larga antes de mirar nada.
     *   2. Cada vez que el motor informa avance (onStart u onRangeStart) se
     *      reinicia la cuenta: si informa, esta vivo.
     *   3. Necesita varias comprobaciones seguidas en silencio, y ademas que
     *      haga rato que no llega ningun aviso de avance.
     */
    private void startStallWatchdog(final String utteranceId) {
        cancelStallWatchdog();
        final int requestSession = sessionId;
        stallMissCount = 0;
        noteSpeechProgress();
        stallWatchdog = new Runnable() {
            @Override
            public void run() {
                if (requestSession != sessionId || !isCurrentUtterance(utteranceId)
                        || !reading || paused || !currentUtteranceStarted) {
                    stallWatchdog = null;
                    return;
                }

                long now = android.os.SystemClock.elapsedRealtime();
                long sinceProgress = now - lastSpeechProgressMs;
                boolean screenOn = isScreenInteractive();
                long graceMs = screenOn ? STALL_PROGRESS_GRACE_MS : SCREEN_OFF_PROGRESS_GRACE_MS;
                int missesNeeded = screenOn ? STALL_MISSES_NEEDED : SCREEN_OFF_STALL_MISSES_NEEDED;
                long nextCheckMs = screenOn ? STALL_CHECK_MS : SCREEN_OFF_STALL_CHECK_MS;
                boolean withinSafeSpeechWindow = currentUtteranceStartedAtMs > 0L
                        && (now - currentUtteranceStartedAtMs) < currentUtteranceMinimumWatchdogMs;

                boolean speaking;
                try {
                    speaking = engineManager.isSpeaking();
                } catch (Exception e) {
                    speaking = true; // Ante la duda, no interrumpir.
                }

                // Con pantalla apagada nunca se da por acabada una frase solo
                // porque isSpeaking titubee durante el minimo razonable del bloque.
                if (speaking || sinceProgress < graceMs || withinSafeSpeechWindow) {
                    stallMissCount = 0;
                } else {
                    stallMissCount++;
                    if (stallMissCount >= missesNeeded) {
                        stallWatchdog = null;
                        cancelUtteranceTimeout();
                        handleUtteranceFinished();
                        return;
                    }
                }
                handler.postDelayed(this, nextCheckMs);
            }
        };
        handler.postDelayed(stallWatchdog,
                isScreenInteractive() ? STALL_FIRST_CHECK_MS : SCREEN_OFF_STALL_FIRST_CHECK_MS);
    }

    /** Marca que el motor dio senales de vida (arranque o avance de palabra). */
    private void noteSpeechProgress() {
        lastSpeechProgressMs = android.os.SystemClock.elapsedRealtime();
        stallMissCount = 0;
    }

    private void cancelStallWatchdog() {
        if (stallWatchdog != null) {
            handler.removeCallbacks(stallWatchdog);
            stallWatchdog = null;
        }
        stallMissCount = 0;
    }

    private void cancelUtteranceTimeout() {
        cancelStartRescue();
        cancelStallWatchdog();
        if (utteranceTimeout != null) {
            handler.removeCallbacks(utteranceTimeout);
            utteranceTimeout = null;
        }
    }

    private float clampRate(float value) {
        if (value < 0.5f) return 0.5f;
        if (value > 2.0f) return 2.0f;
        return value;
    }

    private float clampPitch(float value) {
        if (value < 0.5f) return 0.5f;
        if (value > 2.0f) return 2.0f;
        return value;
    }

    private String cleanForTts(String value) {
        if (value == null) return "";
        String text = value.replace('\u00A0', ' ');
        text = text.replace("\\r\\n", "\n");
        text = text.replace("\\n", "\n");
        text = text.replace("\\r", "\n");
        text = text.replace("/n", "\n");
        text = text.replace('\r', '\n');
        text = text.replaceAll("(?m)^\\s*[\\\\/]*[NnÑñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[A-ZÑ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[a-zñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[0-9]{1,4}\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[IVXLCDMivxlcdm]{1,8}\\s*$", "");
        text = text.replaceFirst("(?i)^(\\s*[nñ]\\s+){1,10}", "");
        text = text.replaceAll("(?i)(^|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-])[nñ](?=($|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-]))", "$1");
        text = text.replaceAll("(?iu)([a-záéíóúüñ])-\\s*\\n\\s*([a-záéíóúüñ])", "$1$2");
        // Los saltos de linea de PDF suelen ser maquetacion visual, no pausas.
        // Se convierten a espacios para que una frase que continua en el siguiente
        // renglon se lea de corrido. La puntuacion real mantiene las pausas naturales.
        text = text.replaceAll("[ \t]*\n+[ \t]*", " ");
        text = text.replaceAll("[ \t]{2,}", " ");
        return text.trim();
    }


    private int firstWordEnd(String text) {
        if (text == null || text.length() == 0) return 1;
        int i = 0;
        while (i < text.length() && Character.isWhitespace(text.charAt(i))) i++;
        while (i < text.length() && !Character.isWhitespace(text.charAt(i))) i++;
        return Math.max(1, i);
    }

    private boolean isScreenInteractive() {
        PowerManager pm = powerManager;
        if (pm == null) return true;
        try {
            if (Build.VERSION.SDK_INT >= 20) return pm.isInteractive();
            return pm.isScreenOn();
        } catch (Exception ignored) {
            return true;
        }
    }

    /**
     * Limite inferior prudente de duracion de una frase. No pretende calcular
     * cuanto tardara exactamente: solo impide que el watchdog declare muerto un
     * bloque largo a los pocos segundos si Android deja de reportar isSpeaking
     * correctamente con la pantalla apagada.
     */
    private long estimateMinimumSpeechWindowMs(String text) {
        if (text == null || text.trim().length() == 0) return 5000L;
        int words = 0;
        boolean inWord = false;
        for (int i = 0; i < text.length(); i++) {
            boolean white = Character.isWhitespace(text.charAt(i));
            if (!white && !inWord) words++;
            inWord = !white;
        }
        float safeRate = Math.max(0.5f, Math.min(2.0f, rate));
        long estimate = (long) ((Math.max(1, words) * 240L) / safeRate);
        return Math.max(3500L, Math.min(180000L, estimate));
    }

    private void broadcastReadingRange(int start, int end) {
        // Con pantalla apagada no hay UI visible que actualizar. Evitar un
        // broadcast por palabra reduce trabajo de CPU/binder justo cuando Android
        // esta entrando en reposo. Al volver, MainActivity pide ACTION_REPORT_RANGE
        // y recibe inmediatamente la posicion actual.
        if (!isScreenInteractive()) return;
        try {
            String chunk = (currentChunkIndex >= 0 && currentChunkIndex < currentChunks.size())
                    ? currentChunks.get(currentChunkIndex) : "";
            Intent update = new Intent(ACTION_PAGE_CHANGED);
            update.setPackage(getPackageName());
            update.putExtra(EXTRA_PAGE, currentPageAbsolute);
            update.putExtra(EXTRA_STATE, playbackState);
            update.putExtra(EXTRA_MESSAGE, "Pagina " + (currentPageAbsolute + 1));
            update.putExtra(EXTRA_CHUNK_TEXT, chunk);
            update.putExtra(EXTRA_CHUNK_INDEX, currentChunkIndex);
            update.putExtra(EXTRA_RANGE_START, Math.max(0, start));
            update.putExtra(EXTRA_RANGE_END, Math.max(start + 1, end));
            sendBroadcast(update);
        } catch (Exception ignored) {
        }
    }

    private void savePlaybackState(int page, int state, String message) {
        playbackState = state;
        updateMediaSessionState(state);
        boolean active = state == STATE_PREPARING || state == STATE_PLAYING
                || state == STATE_PAUSED;
        // El motor necesita saberlo para no precalentar encima de una lectura en
        // curso: el precalentamiento usa QUEUE_FLUSH y cortaria el audio.
        if (engineManager != null) engineManager.setPlaybackActive(active);
        boolean isPaused = state == STATE_PAUSED;
        try {
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(PREF_TTS_ACTIVE, active)
                    .putBoolean(PREF_TTS_PAUSED, isPaused)
                    .putInt(PREF_TTS_CURRENT_PAGE, page)
                    .putInt(PREF_TTS_CHUNK_INDEX, active ? Math.max(0, currentChunkIndex) : -1)
                    .putInt(PREF_TTS_CHUNK_OFFSET, active ? Math.max(0, spokenChunkOffset + lastRangeStart) : 0)
                    .putInt(PREF_TTS_STATE, state)
                    .putString(PREF_TTS_MESSAGE, message == null ? "" : message)
                    .apply();
            Intent update = new Intent(ACTION_PAGE_CHANGED);
            update.setPackage(getPackageName());
            update.putExtra(EXTRA_PAGE, page);
            update.putExtra(EXTRA_ACTIVE, active);
            update.putExtra(EXTRA_PAUSED, isPaused);
            update.putExtra(EXTRA_STATE, state);
            update.putExtra(EXTRA_MESSAGE, message == null ? "" : message);
            sendBroadcast(update);
        } catch (Exception ignored) {
        }
    }



    private void ensureForeground(String text) {
        startForeground(NOTIFICATION_ID, buildNotification(text));
        foregroundStarted = true;
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        openIntent.putExtra("open_reading_page", true);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent prevPi = PendingIntent.getService(this, 1,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_PREV),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent togglePi = PendingIntent.getService(this, 2,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent nextPi = PendingIntent.getService(this, 3,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_NEXT),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent closePi = PendingIntent.getService(this, 4,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        boolean showPlay = playbackState == STATE_PAUSED || playbackState == STATE_STOPPED;
        String safeTitle = title == null || title.trim().length() == 0 || "PDF a Audio".equals(title)
                ? UiStrings.translate(this, "PDF a Audio") : title;
        String pageLabel = UiStrings.translate(this, totalPages > 0
                ? "Página " + (currentPageAbsolute + 1) + "/" + totalPages
                : "Página " + (currentPageAbsolute + 1));
        String status;
        if (playbackState == STATE_PLAYING) {
            status = pageLabel + " · " + UiStrings.translate(this, "Leyendo") + " · "
                    + String.format(Locale.US, "%.2fx", rate);
        } else if (playbackState == STATE_PAUSED) {
            status = pageLabel + " · " + UiStrings.translate(this, "Pausado");
        } else if (playbackState == STATE_PREPARING) {
            status = pageLabel + " · " + UiStrings.translate(this, "Preparando");
        } else {
            status = pageLabel;
        }

        RemoteViews compact = new RemoteViews(getPackageName(), R.layout.notification_pdf_audio);
        int toggleIcon = showPlay ? R.drawable.ic_media_play : R.drawable.ic_media_pause;

        bindNotificationViews(compact, safeTitle, status, toggleIcon, prevPi, togglePi, nextPi, closePi);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.ic_notification_blank)
                .setContentTitle(safeTitle)
                .setContentText(status)
                .setContentIntent(openPi)
                .setOngoing(playbackState != STATE_STOPPED && playbackState != STATE_ERROR)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCustomContentView(compact);

        // V102: no BigContentView ni estilo expandible. La notificación conserva
        // el mismo tamaño compacto al desplegar el panel.
        if (Build.VERSION.SDK_INT >= 21) {
            builder.setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setCategory(Notification.CATEGORY_SERVICE)
                    .setColor(0xFF08283A);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        if (Build.VERSION.SDK_INT < 26) builder.setPriority(Notification.PRIORITY_LOW);
        return builder.build();
    }

    private void bindNotificationViews(RemoteViews views, String safeTitle, String status,
                                       int toggleIcon, PendingIntent prevPi,
                                       PendingIntent togglePi, PendingIntent nextPi,
                                       PendingIntent closePi) {
        views.setTextViewText(R.id.notification_app_name, UiStrings.translate(this, "PDF a Audio"));
        views.setTextViewText(R.id.notification_title, safeTitle);
        views.setTextViewText(R.id.notification_status, status);
        views.setImageViewResource(R.id.notification_toggle, toggleIcon);
        views.setContentDescription(R.id.notification_prev, UiStrings.translate(this, "Anterior"));
        views.setContentDescription(R.id.notification_toggle, UiStrings.translate(this, "Reproducir o pausar"));
        views.setContentDescription(R.id.notification_next, UiStrings.translate(this, "Siguiente"));
        views.setContentDescription(R.id.notification_close, UiStrings.translate(this, "Cerrar"));
        views.setOnClickPendingIntent(R.id.notification_prev, prevPi);
        views.setOnClickPendingIntent(R.id.notification_toggle, togglePi);
        views.setOnClickPendingIntent(R.id.notification_next, nextPi);
        views.setOnClickPendingIntent(R.id.notification_close, closePi);
    }

    private void updateNotification(String text) {
        if (!foregroundStarted) return;
        NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    UiStrings.translate(this, "PDF a Audio"), NotificationManager.IMPORTANCE_LOW);
            channel.setDescription(UiStrings.translate(this, "Lectura de PDF en segundo plano"));
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.enableVibration(false);
            channel.setSound(null, null);
            NotificationManager manager =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void acquirePlaybackResources() {
        acquireAudioFocus();
        if (wakeLock != null && !wakeLock.isHeld()) {
            try { wakeLock.acquire(WAKE_LOCK_LEASE_MS); } catch (Exception ignored) {}
        }
        scheduleWakeLockRenewal();
    }

    private void scheduleWakeLockRenewal() {
        if (wakeLockRenewal != null) return;
        wakeLockRenewal = new Runnable() {
            @Override
            public void run() {
                if (!reading || paused || playbackState == STATE_STOPPED || playbackState == STATE_ERROR) {
                    wakeLockRenewal = null;
                    return;
                }
                try {
                    if (wakeLock != null) {
                        if (wakeLock.isHeld()) wakeLock.release();
                        wakeLock.acquire(WAKE_LOCK_LEASE_MS);
                    }
                } catch (Exception ignored) {
                }
                handler.postDelayed(this, WAKE_LOCK_RENEW_MS);
            }
        };
        handler.postDelayed(wakeLockRenewal, WAKE_LOCK_RENEW_MS);
    }

    private void acquireAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                if (audioFocusRequest == null) {
                    AudioAttributes attributes = new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build();
                    audioFocusRequest = new AudioFocusRequest.Builder(
                            AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(attributes)
                            .setOnAudioFocusChangeListener(focusChangeListener)
                            .setWillPauseWhenDucked(false)
                            .build();
                }
                audioManager.requestAudioFocus(audioFocusRequest);
            } else {
                audioManager.requestAudioFocus(focusChangeListener,
                        AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) {
                audioManager.abandonAudioFocusRequest(audioFocusRequest);
            } else {
                audioManager.abandonAudioFocus(focusChangeListener);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseWakeLock() {
        if (wakeLockRenewal != null) {
            handler.removeCallbacks(wakeLockRenewal);
            wakeLockRenewal = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onDestroy() {
        if (liveInstance == this) liveInstance = null;
        releaseMediaSession();
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        releaseFastResumePlayer();
        releaseAudioFocus();
        releaseWakeLock();
        if (engineManager != null) {
            engineManager.removeUtteranceListener(utteranceListener);
            engineManager.stop();
        }

        if (playbackState != STATE_STOPPED && playbackState != STATE_ERROR) {
            savePlaybackState(currentPageAbsolute, STATE_STOPPED, "Detenido");
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
