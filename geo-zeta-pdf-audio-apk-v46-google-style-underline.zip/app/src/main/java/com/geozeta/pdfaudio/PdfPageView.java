package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfPageView extends View {
    public interface PageChangeListener {
        void onPageRendered(int pageIndex, int pageCount);
        void onError(String message);
        void onHighlightsChanged(String serialized);
    }

    private static class UnderlineMark {
        int page;
        int color;
        float x1;
        float y;
        float x2;
        float thickness;

        UnderlineMark(int page, int color, float x1, float y, float x2, float thickness) {
            this.page = page;
            this.color = color;
            this.x1 = x1;
            this.y = y;
            this.x2 = x2;
            this.thickness = thickness;
        }
    }

    private final Paint paint;
    private final Paint underlinePaint;
    private final Paint handlePaint;
    private final Paint handleStrokePaint;
    private final ExecutorService executor;
    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private Bitmap bitmap;
    private int pageIndex;
    private int pageCount;
    private boolean renderBusy;
    private int pendingPage;
    private int serial;
    private float zoom;
    private float panX;
    private float panY;
    private PageChangeListener listener;
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestureDetector;
    private final Object lock = new Object();

    private boolean markMode;
    private int markColor;
    private boolean drawingSelection;
    private float selectStartX;
    private float selectStartY;
    private float selectEndX;
    private float selectEndY;
    private final Map<Integer, ArrayList<UnderlineMark>> marks;

    public PdfPageView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(238, 238, 238));
        paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);

        underlinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        underlinePaint.setStyle(Paint.Style.FILL);

        handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        handlePaint.setStyle(Paint.Style.FILL);
        handlePaint.setColor(Color.rgb(47, 107, 255));

        handleStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        handleStrokePaint.setStyle(Paint.Style.STROKE);
        handleStrokePaint.setStrokeWidth(3f);
        handleStrokePaint.setColor(Color.WHITE);

        executor = Executors.newSingleThreadExecutor();
        pendingPage = -1;
        zoom = 1.0f;
        markMode = false;
        markColor = 0xD0FFD400;
        marks = new HashMap<Integer, ArrayList<UnderlineMark>>();

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float oldZoom = zoom;
                zoom = clamp(zoom * detector.getScaleFactor(), 1.0f, 4.0f);
                float focusX = detector.getFocusX();
                float focusY = detector.getFocusY();
                panX = focusX - (focusX - panX) * (zoom / oldZoom);
                panY = focusY - (focusY - panY) * (zoom / oldZoom);
                clampPan();
                invalidate();
                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {
                requestRender();
            }
        });

        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (markMode) return true;

                if (zoom > 1.2f) {
                    zoom = 1.0f;
                    panX = 0f;
                    panY = 0f;
                } else {
                    zoom = 2.0f;
                    panX = e.getX() - e.getX() * zoom;
                    panY = e.getY() - e.getY() * zoom;
                    clampPan();
                }

                requestRender();
                invalidate();
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                if (markMode) return true;

                panX -= distanceX;
                panY -= distanceY;
                clampPan();
                invalidate();
                return true;
            }
        });
    }

    public void setPageChangeListener(PageChangeListener listener) {
        this.listener = listener;
    }

    public int getPageCount() {
        return pageCount;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setMarkMode(boolean enabled) {
        markMode = enabled;
        drawingSelection = false;
        invalidate();
    }

    public boolean isMarkMode() {
        return markMode;
    }

    public void setMarkColor(int color) {
        markColor = color;
        invalidate();
    }

    public void undoLastHighlight() {
        ArrayList<UnderlineMark> list = marks.get(pageIndex);
        if (list != null && list.size() > 0) {
            list.remove(list.size() - 1);
            notifyHighlightsChanged();
            invalidate();
        }
    }

    public void clearPageHighlights() {
        marks.remove(pageIndex);
        notifyHighlightsChanged();
        invalidate();
    }

    public void loadHighlights(String data) {
        marks.clear();

        if (data == null || data.trim().length() == 0) {
            invalidate();
            return;
        }

        try {
            String[] items = data.split(";");
            for (int i = 0; i < items.length; i++) {
                String item = items[i].trim();
                if (item.length() == 0) continue;

                String[] p = item.split(",");
                if (p.length != 6) continue;

                int page = Integer.parseInt(p[0]);
                int color = (int) Long.parseLong(p[1], 16);
                float x1 = Float.parseFloat(p[2]);
                float y = Float.parseFloat(p[3]);
                float x2 = Float.parseFloat(p[4]);
                float thickness = Float.parseFloat(p[5]);

                addMarkObject(new UnderlineMark(page, color, x1, y, x2, thickness), false);
            }
        } catch (Exception ignored) {
        }

        invalidate();
    }

    public String serializeHighlights() {
        StringBuilder builder = new StringBuilder();

        for (Map.Entry<Integer, ArrayList<UnderlineMark>> entry : marks.entrySet()) {
            ArrayList<UnderlineMark> list = entry.getValue();
            if (list == null) continue;

            for (int i = 0; i < list.size(); i++) {
                UnderlineMark h = list.get(i);
                builder.append(h.page).append(",");
                builder.append(Integer.toHexString(h.color)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.x1)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.y)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.x2)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.thickness)).append(";");
            }
        }

        return builder.toString();
    }

    public void openFile(File file) throws IOException {
        closeDocument();
        descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
        renderer = new PdfRenderer(descriptor);
        pageCount = renderer.getPageCount();
        pageIndex = 0;
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        requestRender();
    }

    public void showPage(int index) {
        if (renderer == null || pageCount <= 0) return;

        pageIndex = Math.max(0, Math.min(index, pageCount - 1));
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        requestRender();
    }

    public void nextPage() {
        showPage(pageIndex + 1);
    }

    public void previousPage() {
        showPage(pageIndex - 1);
    }

    public void fitPage() {
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        requestRender();
    }

    private void requestRender() {
        if (renderer == null || getWidth() <= 0 || getHeight() <= 0) return;

        if (renderBusy) {
            pendingPage = pageIndex;
            return;
        }

        renderBusy = true;
        final int requestedPage = pageIndex;
        final int token = ++serial;

        executor.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap produced = null;
                PdfRenderer.Page openedPage = null;

                try {
                    synchronized (lock) {
                        if (renderer == null) return;

                        openedPage = renderer.openPage(requestedPage);
                        int viewWidth = Math.max(320, getWidth());
                        float ratio = openedPage.getHeight() / (float) openedPage.getWidth();

                        int targetWidth = Math.round(viewWidth * zoom * 1.5f);
                        targetWidth = Math.max(viewWidth, Math.min(targetWidth, 3200));
                        int targetHeight = Math.round(targetWidth * ratio);
                        targetHeight = Math.max(1, Math.min(targetHeight, 4800));

                        produced = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
                        produced.eraseColor(Color.WHITE);
                        openedPage.render(produced, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    }

                    final Bitmap readyBitmap = produced;
                    produced = null;

                    post(new Runnable() {
                        @Override
                        public void run() {
                            applyRenderedBitmap(readyBitmap, token);
                        }
                    });
                } catch (Exception ex) {
                    if (produced != null && !produced.isRecycled()) produced.recycle();

                    post(new Runnable() {
                        @Override
                        public void run() {
                            notifyRenderError();
                        }
                    });
                } finally {
                    if (openedPage != null) {
                        try {
                            openedPage.close();
                        } catch (Exception ignored) {
                        }
                    }

                    post(new Runnable() {
                        @Override
                        public void run() {
                            finishRenderQueue();
                        }
                    });
                }
            }
        });
    }

    private void applyRenderedBitmap(Bitmap readyBitmap, int token) {
        if (token != serial) {
            if (readyBitmap != null && !readyBitmap.isRecycled()) readyBitmap.recycle();
            return;
        }

        Bitmap old = bitmap;
        bitmap = readyBitmap;
        if (old != null && !old.isRecycled()) old.recycle();

        clampPan();
        invalidate();

        if (listener != null) {
            listener.onPageRendered(pageIndex, pageCount);
        }
    }

    private void notifyRenderError() {
        if (listener != null) listener.onError("Error al renderizar PDF");
    }

    private void finishRenderQueue() {
        renderBusy = false;

        if (pendingPage >= 0) {
            int p = pendingPage;
            pendingPage = -1;
            pageIndex = p;
            requestRender();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        requestRender();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (bitmap == null || bitmap.isRecycled()) {
            Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            textPaint.setColor(Color.DKGRAY);
            textPaint.setTextSize(42f);
            textPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Abre un PDF", getWidth() / 2f, getHeight() / 2f, textPaint);
            return;
        }

        RectF pageRect = getCurrentPageRect();
        canvas.drawBitmap(bitmap, null, pageRect, paint);
        drawSavedUnderlines(canvas, pageRect);

        if (drawingSelection) {
            drawLiveSelection(canvas, pageRect);
        }
    }

    private void drawSavedUnderlines(Canvas canvas, RectF pageRect) {
        ArrayList<UnderlineMark> list = marks.get(pageIndex);
        if (list == null) return;

        for (int i = 0; i < list.size(); i++) {
            UnderlineMark h = list.get(i);
            drawUnderline(canvas, pageRect, h.x1, h.y, h.x2, h.thickness, h.color, false);
        }
    }

    private void drawLiveSelection(Canvas canvas, RectF pageRect) {
        float x1 = Math.min(selectStartX, selectEndX);
        float x2 = Math.max(selectStartX, selectEndX);
        float y = Math.max(selectStartY, selectEndY);

        x1 = clamp(x1, pageRect.left, pageRect.right);
        x2 = clamp(x2, pageRect.left, pageRect.right);
        y = clamp(y, pageRect.top, pageRect.bottom);

        if (x2 - x1 < 8f) return;

        float nx1 = clamp((x1 - pageRect.left) / pageRect.width(), 0f, 1f);
        float nx2 = clamp((x2 - pageRect.left) / pageRect.width(), 0f, 1f);
        float ny = clamp((y - pageRect.top) / pageRect.height(), 0f, 1f);
        float nt = clamp(5.5f / Math.max(1f, pageRect.height()), 0.0015f, 0.007f);

        drawUnderline(canvas, pageRect, nx1, ny, nx2, nt, markColor, true);
    }

    private void drawUnderline(Canvas canvas, RectF pageRect, float nx1, float ny, float nx2, float nthickness, int color, boolean handles) {
        underlinePaint.setColor(color);

        float x1 = pageRect.left + nx1 * pageRect.width();
        float x2 = pageRect.left + nx2 * pageRect.width();
        float y = pageRect.top + ny * pageRect.height();
        float thickness = Math.max(4f, nthickness * pageRect.height());

        RectF line = new RectF(x1, y - thickness / 2f, x2, y + thickness / 2f);
        canvas.drawRoundRect(line, thickness, thickness, underlinePaint);

        if (handles) {
            drawHandle(canvas, x1, y, true);
            drawHandle(canvas, x2, y, false);
        }
    }

    private void drawHandle(Canvas canvas, float x, float y, boolean left) {
        float radius = 11f;
        float stem = 20f;
        canvas.drawCircle(x, y + stem, radius, handlePaint);
        canvas.drawCircle(x, y + stem, radius, handleStrokePaint);

        RectF smallStem = new RectF(x - 3f, y, x + 3f, y + stem);
        canvas.drawRoundRect(smallStem, 3f, 3f, handlePaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (markMode && event.getPointerCount() == 1) {
            handleSelectionTouch(event);
            return true;
        }

        scaleDetector.onTouchEvent(event);
        if (!scaleDetector.isInProgress()) gestureDetector.onTouchEvent(event);

        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            clampPan();
            invalidate();
        }

        return true;
    }

    private void handleSelectionTouch(MotionEvent event) {
        int action = event.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            drawingSelection = true;
            selectStartX = event.getX();
            selectStartY = event.getY();
            selectEndX = selectStartX;
            selectEndY = selectStartY;
            invalidate();
        } else if (action == MotionEvent.ACTION_MOVE) {
            selectEndX = event.getX();
            selectEndY = event.getY();
            invalidate();
        } else if (action == MotionEvent.ACTION_UP) {
            selectEndX = event.getX();
            selectEndY = event.getY();
            drawingSelection = false;
            saveSelectionAsUnderline();
            invalidate();
        } else if (action == MotionEvent.ACTION_CANCEL) {
            drawingSelection = false;
            invalidate();
        }
    }

    private void saveSelectionAsUnderline() {
        if (bitmap == null) return;

        RectF pageRect = getCurrentPageRect();

        float x1 = Math.min(selectStartX, selectEndX);
        float x2 = Math.max(selectStartX, selectEndX);
        float y = Math.max(selectStartY, selectEndY);

        x1 = clamp(x1, pageRect.left, pageRect.right);
        x2 = clamp(x2, pageRect.left, pageRect.right);
        y = clamp(y, pageRect.top, pageRect.bottom);

        if (x2 - x1 < 18f) return;

        float nx1 = clamp((x1 - pageRect.left) / pageRect.width(), 0f, 1f);
        float nx2 = clamp((x2 - pageRect.left) / pageRect.width(), 0f, 1f);
        float ny = clamp((y - pageRect.top) / pageRect.height(), 0f, 1f);
        float nt = clamp(5.5f / Math.max(1f, pageRect.height()), 0.0015f, 0.007f);

        addMarkObject(new UnderlineMark(pageIndex, markColor, nx1, ny, nx2, nt), true);
    }

    private void addMarkObject(UnderlineMark mark, boolean notify) {
        ArrayList<UnderlineMark> list = marks.get(mark.page);

        if (list == null) {
            list = new ArrayList<UnderlineMark>();
            marks.put(mark.page, list);
        }

        list.add(mark);

        if (notify) {
            notifyHighlightsChanged();
        }
    }

    private void notifyHighlightsChanged() {
        if (listener != null) {
            listener.onHighlightsChanged(serializeHighlights());
        }
    }

    private RectF getCurrentPageRect() {
        float displayWidth = getWidth() * zoom;
        float displayHeight = displayWidth * (bitmap.getHeight() / (float) bitmap.getWidth());

        if (displayWidth <= getWidth()) panX = (getWidth() - displayWidth) / 2f;
        if (displayHeight <= getHeight()) panY = (getHeight() - displayHeight) / 2f;

        return new RectF(panX, panY, panX + displayWidth, panY + displayHeight);
    }

    private void clampPan() {
        if (bitmap == null) return;

        float displayWidth = getWidth() * zoom;
        float displayHeight = displayWidth * (bitmap.getHeight() / (float) bitmap.getWidth());

        if (displayWidth <= getWidth()) {
            panX = (getWidth() - displayWidth) / 2f;
        } else {
            panX = clamp(panX, getWidth() - displayWidth, 0f);
        }

        if (displayHeight <= getHeight()) {
            panY = (getHeight() - displayHeight) / 2f;
        } else {
            panY = clamp(panY, getHeight() - displayHeight, 0f);
        }
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public void closeDocument() {
        try {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            bitmap = null;

            if (renderer != null) renderer.close();
            if (descriptor != null) descriptor.close();
        } catch (Exception ignored) {
        }

        renderer = null;
        descriptor = null;
        pageCount = 0;
        pageIndex = 0;
    }
}
