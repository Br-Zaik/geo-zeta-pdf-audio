# Geo Zeta PDF a Audio V46 Google Style Underline

Base:
- Desde V43 estable para conservar zoom y audio.

Agregado:
- Subrayado fino tipo selección, no bloques.
- Manijas visuales durante el arrastre.
- Botones: Marcar, Color, Borrar, Limpiar.
- Guardado local por PDF.

No es OCR ni selección real perfecta por palabra todavía.
Es una versión segura intermedia para no romper zoom ni audio.

No agregado:
- Exportar PNG.
- Compartir imagen.
- Reglas arriba/abajo.
