# Geo Zeta PDF a Audio V63 Audio Restored + Dual Mark

Base estable de audio: V61 Page Notification Sync.

Corrección principal:
- Se restauró íntegramente el flujo de audio que sí reproducía en V61.
- Se retiró la optimización experimental de V62 que podía dejar el TTS sin voz.
- Se mantiene la carga prioritaria de la página visible y la lectura continua.

Mejoras que se conservan:
- Dos tipos de marcado: subrayado y resaltado.
- Color independiente para el subrayado y para el resaltado.
- Selección del tipo y ambos colores desde Ajustes.
- Compatibilidad con los subrayados antiguos.

Mantiene:
- Audio continuo y con pantalla apagada.
- Sincronización de página y notificación.
- Reglas, zoom, tema claro/oscuro.
- Guardar imagen PNG y audio WAV.
