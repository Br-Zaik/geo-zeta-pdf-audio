# Geo Zeta PDF a Audio V83

Mejoras profesionales sobre V82:

- Las imágenes guardadas se abren directamente en un visor de pantalla completa.
- Zoom con pellizco, doble toque para restablecer, navegación anterior/siguiente y compartir.
- Al guardar una página marcada, el visor de pantalla completa se abre inmediatamente.
- Nuevo selector de color bidimensional: horizontal cambia el color y vertical aclara u oscurece.
- El selector profesional se usa para subrayado, resaltado, reglas y seguimiento de lectura.
- El seguimiento visual usa una sola franja semitransparente con borde fino, separada de los marcados permanentes.
- El seguimiento recibe una posición inicial inmediatamente al enviar el texto al motor TTS.
- Selección de subrayado más estricta: se mantiene en la línea inicial salvo un movimiento vertical claro.
- Menor tolerancia vertical para evitar seleccionar accidentalmente la línea superior o inferior.
- Se mantienen las funciones de exportación, carpetas, PDF por rango y persistencia de marcados.

VersionCode: 83
VersionName: 83.0-professional-viewer-color-selection

## v85 - ajustes solicitados
- Corrige el destello blanco al volver de Ajustes.
- Galería de imágenes compacta en cuadrícula de 3 columnas.
- Visor de imágenes con navegación por deslizamiento lateral y zoom.
- Exportación PNG desde render de página de alta resolución.
- Selector de color personalizado con acabado visual mejorado.
