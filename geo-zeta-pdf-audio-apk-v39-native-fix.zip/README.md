# Geo Zeta PDF a Audio V39 Native Fix

Versión corregida de la base nativa.

Cambios frente a V38:
- Código Java más conservador.
- Se redujo uso de lambdas.
- Se agregó compileOptions Java 17.
- Mantiene PdfRenderer.
- Mantiene TextToSpeech.
- Mantiene Foreground Service.
- Mantiene PDFBox Android para extracción de texto.
