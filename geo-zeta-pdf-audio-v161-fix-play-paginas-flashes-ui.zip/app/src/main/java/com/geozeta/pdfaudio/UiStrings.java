package com.geozeta.pdfaudio;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * UI localization for the five supported app languages. PDF language detection
 * and TTS voice selection are handled separately by PdfLanguageDetector and
 * TtsEngineManager so the interface language never limits which PDF can be read.
 */
public final class UiStrings {
    public static final String PREF_LANGUAGE = "app_language_v1";
    public static final String PREF_LANGUAGE_CHOSEN = "app_language_chosen_v1";
    public static final String PREF_ONBOARDING_COMPLETE = "app_onboarding_fullscreen_v5";
    public static final String PREF_REGION = "app_region_v1";

    public static final String ES = "es";
    public static final String EN = "en";
    public static final String PT = "pt";
    public static final String HI = "hi";
    public static final String ID = "id";

    private static final Map<String, String[]> TEXT = new HashMap<>();
    private static final Map<String, String[]> REGION_NAMES = new HashMap<>();
    private static final String[] REGION_CODES = new String[]{
            "PE", "MX", "CO", "AR", "CL", "EC", "BO", "PY", "UY", "VE",
            "GT", "HN", "SV", "NI", "CR", "PA", "CU", "DO", "ES", "BR",
            "PT", "IN", "ID", "PH", "US", "GB", "CA", "AU"
    };

    static {
        // source Spanish, English, Portuguese, Hindi, Indonesian
        p("PDF a Audio", "PDF to Audio", "PDF para Áudio", "PDF से ऑडियो", "PDF ke Audio");
        p("Abrir", "Open", "Abrir", "खोलें", "Buka");
        p("Abrir archivo", "Open file", "Abrir arquivo", "फ़ाइल खोलें", "Buka file");
        p("Abrir un PDF", "Open a PDF", "Abrir um PDF", "PDF खोलें", "Buka PDF");
        p("Ajustes", "Settings", "Configurações", "सेटिंग्स", "Pengaturan");
        p("INFORMACIÓN", "INFORMATION", "INFORMAÇÕES", "जानकारी", "INFORMASI");
        p("Política de privacidad", "Privacy policy", "Política de privacidade", "गोपनीयता नीति", "Kebijakan privasi");
        p("Cómo se manejan tus datos y documentos", "How your data and documents are handled", "Como seus dados e documentos são tratados", "आपके डेटा और दस्तावेज़ कैसे संभाले जाते हैं", "Cara data dan dokumen Anda ditangani");
        p("Guardar PDF", "Save PDF", "Salvar PDF", "PDF सहेजें", "Simpan PDF");
        p("Opciones de privacidad", "Privacy options", "Opções de privacidade", "गोपनीयता विकल्प", "Opsi privasi");
        p("Cambiar tu elección sobre los anuncios", "Change your choice about ads", "Alterar sua escolha sobre anúncios", "विज्ञापनों के बारे में अपना चयन बदलें", "Ubah pilihan Anda tentang iklan");
        p("No se pudo abrir el formulario", "The form could not be opened", "Não foi possível abrir o formulário", "फ़ॉर्म नहीं खोला जा सका", "Formulir tidak dapat dibuka");
        p("Se guardará en  Geo Zeta / PDF marcados", "Will be saved in  Geo Zeta / Marked PDF", "Será salvo em  Geo Zeta / PDF marcados", "इसमें सहेजा जाएगा  Geo Zeta / Marked PDF", "Akan disimpan di  Geo Zeta / PDF ditandai");
        p("Toca una opción para guardar el PDF", "Tap an option to save the PDF", "Toque uma opção para salvar o PDF", "PDF सहेजने के लिए एक विकल्प चुनें", "Ketuk opsi untuk menyimpan PDF");
        p("Selecciona una opción y toca la flecha para continuar", "Select an option and tap the arrow to continue", "Selecione uma opção e toque na seta para continuar", "एक विकल्प चुनें और जारी रखने के लिए तीर पर टैप करें", "Pilih opsi lalu ketuk panah untuk melanjutkan");
        p("Selecciona el tipo de PDF y toca la flecha para abrirlo", "Select the PDF type and tap the arrow to open it", "Selecione o tipo de PDF e toque na seta para abri-lo", "PDF का प्रकार चुनें और खोलने के लिए तीर पर टैप करें", "Pilih jenis PDF lalu ketuk panah untuk membukanya");
        p("Elige cómo quieres leer este documento", "Choose how you want to read this document", "Escolha como deseja ler este documento", "चुनें कि आप इस दस्तावेज़ को कैसे पढ़ना चाहते हैं", "Pilih cara Anda ingin membaca dokumen ini");
        p("Creación de audio cancelada", "Audio creation canceled", "Criação de áudio cancelada", "ऑडियो बनाना रद्द किया गया", "Pembuatan audio dibatalkan");
        p("Guardar solo la página visible", "Save only the visible page", "Salvar apenas a página visível", "केवल दिखाई देने वाला पृष्ठ सहेजें", "Simpan hanya halaman yang terlihat");
        p("¿Cómo guardarlo?", "How to save it?", "Como salvar?", "इसे कैसे सहेजें?", "Bagaimana menyimpannya?");
        p("Original sin marcas", "Original without marks", "Original sem marcas", "बिना चिह्नों के मूल", "Asli tanpa tanda");
        p("Igual que el PDF original, el texto se puede leer en voz alta", "Same as the original PDF, the text can still be read aloud", "Igual ao PDF original, o texto pode ser lido em voz alta", "मूल PDF जैसा, पाठ को ज़ोर से पढ़ा जा सकता है", "Sama seperti PDF asli, teks masih bisa dibacakan");
        p("Con mis marcas", "With my marks", "Com minhas marcas", "मेरे चिह्नों के साथ", "Dengan tanda saya");
        p("Incluye subrayados y resaltados; queda como imágenes", "Includes underlines and highlights; saved as images", "Inclui sublinhados e destaques; fica como imagens", "रेखांकन और हाइलाइट शामिल; छवियों के रूप में सहेजा जाता है", "Termasuk garis bawah dan sorotan; disimpan sebagai gambar");
        p("Guardando PDF...", "Saving PDF...", "Salvando PDF...", "PDF सहेजा जा रहा है...", "Menyimpan PDF...");
        p("Guardando imagen...", "Saving image...", "Salvando imagem...", "छवि सहेजी जा रही है...", "Menyimpan gambar...");
        p("PDF guardado en Geo Zeta / PDF marcados", "PDF saved in Geo Zeta / Marked PDF", "PDF salvo em Geo Zeta / PDF marcados", "PDF सहेजा गया Geo Zeta / Marked PDF में", "PDF disimpan di Geo Zeta / PDF ditandai");
        p("Editar mis colores", "Edit my colors", "Editar minhas cores", "मेरे रंग संपादित करें", "Edit warna saya");
        p("Listo", "Done", "Pronto", "पूर्ण", "Selesai");
        p("Toca un color de la primera columna para cambiarlo", "Tap a color in the first column to change it", "Toque em uma cor da primeira coluna para alterá-la", "बदलने के लिए पहले कॉलम का रंग टैप करें", "Ketuk warna di kolom pertama untuk mengubahnya");
        p("Idioma", "Language", "Idioma", "भाषा", "Bahasa");
        p("IDIOMA", "LANGUAGE", "IDIOMA", "भाषा", "BAHASA");
        p("Idioma de la aplicación", "App language", "Idioma do aplicativo", "ऐप की भाषा", "Bahasa aplikasi");
        p("Selecciona tu idioma", "Choose your language", "Escolha seu idioma", "अपनी भाषा चुनें", "Pilih bahasa Anda");
        p("Puedes cambiarlo después en Ajustes.", "You can change it later in Settings.", "Você pode alterar depois em Configurações.", "आप इसे बाद में सेटिंग्स में बदल सकते हैं।", "Anda dapat mengubahnya nanti di Pengaturan.");
        p("Continuar", "Continue", "Continuar", "जारी रखें", "Lanjutkan");
        p("Bienvenido a PDF a Audio", "Welcome to PDF to Audio", "Bem-vindo ao PDF para Áudio", "PDF से ऑडियो में आपका स्वागत है", "Selamat datang di PDF ke Audio");
        p("Escucha tus documentos de forma simple, cómoda y sin perder tu página.", "Listen to your documents with ease and never lose your place.", "Ouça seus documentos de forma simples e confortável, sem perder sua página.", "अपने दस्तावेज़ आसानी और आराम से सुनें, बिना अपना पृष्ठ खोए।", "Dengarkan dokumen dengan mudah dan nyaman tanpa kehilangan halaman Anda.");
        p("Comenzar", "Get started", "Começar", "शुरू करें", "Mulai");
        p("Tu lector de PDFs en voz alta, rápido y fácil de usar.", "A fast, easy-to-use PDF read-aloud app.", "Seu leitor de PDFs em voz alta, rápido e fácil de usar.", "PDF को आवाज़ में पढ़ने वाला तेज़ और आसान ऐप।", "Aplikasi pembaca PDF bersuara yang cepat dan mudah digunakan.");
        p("Abre tu PDF", "Open your PDF", "Abra seu PDF", "अपना PDF खोलें", "Buka PDF Anda");
        p("Escucha con voz clara", "Listen with clear audio", "Ouça com voz clara", "स्पष्ट आवाज़ में सुनें", "Dengarkan dengan suara jelas");
        p("Sigue tu progreso", "Keep your place", "Continue de onde parou", "जहाँ छोड़ा था वहीं से जारी रखें", "Lanjutkan dari posisi terakhir");
        p("Ahorra tiempo", "Save time", "Economize tempo", "समय बचाएँ", "Hemat waktu");
        p("Convierte lectura en escucha al instante.", "Turn text into audio instantly.", "Transforme leitura em áudio instantaneamente.", "पढ़ने को तुरंत सुनने में बदलें।", "Ubah membaca menjadi mendengarkan seketika.");
        p("Ideal para estudiar", "Ideal for studying", "Ideal para estudar", "पढ़ाई के लिए आदर्श", "Ideal untuk belajar");
        p("Escucha donde y cuando quieras.", "Listen anytime, anywhere.", "Ouça onde e quando quiser.", "जहाँ और जब चाहें सुनें।", "Dengarkan kapan dan di mana saja.");
        p("Sin perder tu página", "Never lose your place", "Sem perder sua página", "अपना पृष्ठ न खोएँ", "Tanpa kehilangan halaman");
        p("Retomamos donde lo dejaste.", "Pick up where you left off.", "Retome de onde parou.", "जहाँ छोड़ा था वहीं से जारी रखें।", "Lanjutkan dari tempat terakhir.");
        p("Cambio de idioma", "Change language", "Alterar idioma", "भाषा बदलें", "Ganti bahasa");
        p("Escucha en el idioma que prefieras.", "Listen in your preferred language.", "Ouça no idioma que preferir.", "अपनी पसंद की भाषा में सुनें।", "Dengarkan dalam bahasa pilihan Anda.");
        p("Ajusta el idioma en cualquier momento", "Change the language anytime", "Altere o idioma a qualquer momento", "भाषा कभी भी बदलें", "Ubah bahasa kapan saja");
        p("Privado y seguro", "Private and secure", "Privado e seguro", "निजी और सुरक्षित", "Privat dan aman");
        p("No compartimos tus documentos.", "We never share your documents.", "Não compartilhamos seus documentos.", "हम आपके दस्तावेज़ साझा नहीं करते।", "Kami tidak membagikan dokumen Anda.");
        p("Escucha tus PDFs de forma simple y cómoda.", "Listen to your PDFs easily and comfortably.", "Ouça seus PDFs de forma simples e confortável.", "अपने PDF को सरल और आरामदायक तरीके से सुनें।", "Dengarkan PDF Anda dengan mudah dan nyaman.");
        p("Lectura fluida", "Smooth reading", "Leitura fluida", "सुगम पठन", "Pembacaan lancar");
        p("Ahorra tiempo", "Save time", "Economize tempo", "समय बचाएँ", "Hemat waktu");
        p("Tus documentos son privados y se procesan de forma segura.", "Your documents are private and processed securely.", "Seus documentos são privados e processados com segurança.", "आपके दस्तावेज़ निजी हैं और सुरक्षित रूप से संसाधित होते हैं।", "Dokumen Anda bersifat pribadi dan diproses dengan aman.");
        p("Elige tu idioma", "Choose your language", "Escolha seu idioma", "अपनी भाषा चुनें", "Pilih bahasa Anda");
        p("Selecciona el idioma que deseas usar en la aplicación.", "Select the language you want to use in the app.", "Selecione o idioma que deseja usar no aplicativo.", "ऐप में उपयोग करने के लिए भाषा चुनें।", "Pilih bahasa yang ingin Anda gunakan di aplikasi.");
        p("Idioma del dispositivo", "Device language", "Idioma do dispositivo", "डिवाइस की भाषा", "Bahasa perangkat");
        p("Puedes cambiarlo cuando quieras desde Ajustes.", "You can change it anytime in Settings.", "Você pode alterar quando quiser em Configurações.", "आप इसे सेटिंग्स में कभी भी बदल सकते हैं।", "Anda dapat mengubahnya kapan saja di Pengaturan.");
        p("Configura el idioma de la interfaz y tu país o región.", "Choose your app language and country or region.", "Configure o idioma da interface e seu país ou região.", "इंटरफ़ेस की भाषा और अपना देश या क्षेत्र सेट करें।", "Atur bahasa antarmuka dan negara atau wilayah Anda.");
        p("La región queda guardada para futuras voces y acentos.", "Your region will be used for future voice and accent options.", "Sua região será usada futuramente para opções de voz e sotaque.", "आगे चलकर आवाज़ और उच्चारण के विकल्पों के लिए आपका क्षेत्र इस्तेमाल होगा।", "Wilayah Anda akan digunakan untuk opsi suara dan aksen di masa mendatang.");
        p("La región ayuda a elegir el acento de voz cuando está disponible.", "Your region helps choose a matching voice accent when available.", "Sua região ajuda a escolher um sotaque de voz correspondente quando disponível.", "उपलब्ध होने पर आपका क्षेत्र उपयुक्त आवाज़ का उच्चारण चुनने में मदद करता है।", "Wilayah Anda membantu memilih aksen suara yang sesuai jika tersedia.");
        p("28 países", "28 countries", "28 países", "28 देश", "28 negara");
        p("Convierte y escucha tus documentos de forma simple y cómoda.", "Convert your documents to audio and listen with ease.", "Converta e ouça seus documentos de forma simples e confortável.", "अपने दस्तावेज़ों को सरल और आरामदायक तरीके से सुनें।", "Ubah dan dengarkan dokumen Anda dengan cara yang sederhana dan nyaman.");
        p("Escucha sin perder tu lugar", "Listen without losing your place", "Ouça sem perder seu lugar", "अपनी जगह खोए बिना सुनें", "Dengarkan tanpa kehilangan posisi Anda");
        p("Reproduce tus PDFs como audio y continúa desde donde lo dejaste.", "Listen to your PDFs and pick up where you left off.", "Reproduza seus PDFs como áudio e continue de onde parou.", "अपने PDF को ऑडियो की तरह चलाएँ और जहाँ छोड़ा था वहीं से जारी रखें।", "Putar PDF Anda sebagai audio dan lanjutkan dari tempat Anda berhenti.");
        p("Guarda tu progreso", "Save your progress", "Salve seu progresso", "अपनी प्रगति सहेजें", "Simpan progres Anda");
        p("Lectura fluida y natural", "Smooth and natural reading", "Leitura fluida e natural", "सुगम और प्राकृतिक पढ़ना", "Pembacaan yang lancar dan alami");
        p("Ideal para estudiar, trabajar o relajarte", "Ideal for studying, working, or relaxing", "Ideal para estudar, trabalhar ou relaxar", "पढ़ाई, काम या आराम के लिए आदर्श", "Ideal untuk belajar, bekerja, atau bersantai");
        p("Puedes cambiarlo en Ajustes.", "You can change it in Settings.", "Você pode alterar em Configurações.", "आप इसे सेटिंग्स में बदल सकते हैं।", "Anda dapat mengubahnya di Pengaturan.");
        p("Tus documentos son privados y se procesan de forma segura. Funciona sin conexión.", "Your documents are private and processed securely. Works offline.", "Seus documentos são privados e processados com segurança. Funciona offline.", "आपके दस्तावेज़ निजी हैं और सुरक्षित रूप से संसाधित होते हैं। यह ऑफ़लाइन काम करता है।", "Dokumen Anda bersifat pribadi dan diproses dengan aman. Berfungsi tanpa koneksi internet.");
        p("Idioma detectado", "Detected language", "Idioma detectado", "पहचानी गई भाषा", "Bahasa terdeteksi");
        p("Elige el idioma de la aplicación", "Choose the app language", "Escolha o idioma do aplicativo", "ऐप की भाषा चुनें", "Pilih bahasa aplikasi");
        p("Ya seleccionamos el idioma de tu teléfono. Puedes mantenerlo o elegir otro.", "We detected your device language. Keep it or choose another.", "Selecionamos o idioma do seu telefone. Você pode mantê-lo ou escolher outro.", "हमने आपके फ़ोन की भाषा चुनी है। आप इसे रख सकते हैं या दूसरी भाषा चुन सकते हैं।", "Kami memilih bahasa ponsel Anda. Anda dapat mempertahankannya atau memilih bahasa lain.");
        p("Cambiar después en Ajustes", "Change later in Settings", "Alterar depois em Configurações", "बाद में सेटिंग्स में बदलें", "Ubah nanti di Pengaturan");
        p("IDIOMA Y REGIÓN", "LANGUAGE & REGION", "IDIOMA E REGIÃO", "भाषा और क्षेत्र", "BAHASA DAN WILAYAH");
        p("Idioma y región", "Language & region", "Idioma e região", "भाषा और क्षेत्र", "Bahasa dan wilayah");
        p("País / Región", "Country / Region", "País / Região", "देश / क्षेत्र", "Negara / Wilayah");
        p("Elige tu país o región", "Choose your country or region", "Escolha seu país ou região", "अपना देश या क्षेत्र चुनें", "Pilih negara atau wilayah Anda");
        p("Buscar país...", "Search countries...", "Buscar país...", "देश खोजें...", "Cari negara...");
        p("No se encontraron países", "No countries found", "Nenhum país encontrado", "कोई देश नहीं मिला", "Negara tidak ditemukan");
        p("Configura el idioma de la interfaz y deja preparada tu región para futuras voces y acentos.", "Choose your app language and region for future voice and accent options.", "Configure o idioma da interface e deixe sua região pronta para futuras vozes e sotaques.", "इंटरफ़ेस की भाषा सेट करें और भविष्य की आवाज़ों व उच्चारणों के लिए अपना क्षेत्र तैयार रखें।", "Atur bahasa antarmuka dan siapkan wilayah Anda untuk suara dan aksen di masa mendatang.");
        p("Idioma actual", "Current language", "Idioma atual", "वर्तमान भाषा", "Bahasa saat ini");
        p("Región actual", "Current region", "Região atual", "वर्तमान क्षेत्र", "Wilayah saat ini");
        p("Aplicar", "Apply", "Aplicar", "लागू करें", "Terapkan");
        p("Cancelar", "Cancel", "Cancelar", "रद्द करें", "Batal");
        p("Cerrar", "Close", "Fechar", "बंद करें", "Tutup");
        p("Volver", "Back", "Voltar", "वापस", "Kembali");
        p("Guardar", "Save", "Salvar", "सहेजें", "Simpan");
        p("Crear", "Create", "Criar", "बनाएँ", "Buat");
        p("Eliminar", "Delete", "Excluir", "हटाएँ", "Hapus");
        p("Compartir", "Share", "Compartilhar", "साझा करें", "Bagikan");
        p("Reintentar", "Retry", "Tentar novamente", "फिर प्रयास करें", "Coba lagi");
        p("Sistema", "System", "Sistema", "सिस्टम", "Sistem");
        p("Regresar", "Back", "Voltar", "वापस", "Kembali");
        p("Siguiente", "Next", "Seguinte", "अगला", "Berikutnya");
        p("Anterior", "Previous", "Anterior", "पिछला", "Sebelumnya");
        p("Ir", "Go", "Ir", "जाएँ", "Buka");
        p("Ir a página", "Go to page", "Ir para página", "पृष्ठ पर जाएँ", "Ke halaman");
        p("Página actual", "Current page", "Página atual", "वर्तमान पृष्ठ", "Halaman saat ini");
        p("Todo el PDF", "Entire PDF", "PDF inteiro", "पूरा PDF", "Seluruh PDF");
        p("Elegir rango", "Choose range", "Escolher intervalo", "सीमा चुनें", "Pilih rentang");
        p("Rango de páginas", "Page range", "Intervalo de páginas", "पृष्ठ सीमा", "Rentang halaman");
        p("Rango inválido", "Invalid range", "Intervalo inválido", "अमान्य सीमा", "Rentang tidak valid");
        p("Completa correctamente el rango", "Enter a valid range", "Preencha o intervalo corretamente", "सीमा सही भरें", "Isi rentang dengan benar");
        p("Página, rango o todo el PDF", "Page, range or entire PDF", "Página, intervalo ou PDF inteiro", "पृष्ठ, सीमा या पूरा PDF", "Halaman, rentang, atau seluruh PDF");
        p("Por ejemplo: páginas 14 a 300", "For example: pages 14 to 300", "Por exemplo: páginas 14 a 300", "उदाहरण: पृष्ठ 14 से 300", "Contoh: halaman 14 hingga 300");

        p("APARIENCIA", "APPEARANCE", "APARÊNCIA", "दिखावट", "TAMPILAN");
        p("LECTURA Y AUDIO", "READING & AUDIO", "LEITURA E ÁUDIO", "पढ़ना और ऑडियो", "PEMBACAAN DAN AUDIO");
        p("SEGUIMIENTO VISUAL", "VISUAL TRACKING", "ACOMPANHAMENTO VISUAL", "दृश्य ट्रैकिंग", "PELACAKAN VISUAL");
        p("MARCADO", "MARKUP", "MARCAÇÃO", "मार्कअप", "PENANDAAN");
        p("ARCHIVOS Y EXPORTACIÓN", "FILES & EXPORT", "ARQUIVOS E EXPORTAÇÃO", "फ़ाइलें और निर्यात", "FILE DAN EKSPOR");
        p("Tema claro", "Light theme", "Tema claro", "हल्की थीम", "Tema terang");
        p("Tema oscuro", "Dark theme", "Tema escuro", "गहरी थीम", "Tema gelap");
        p("Fondo blanco", "White background", "Fundo branco", "सफेद पृष्ठभूमि", "Latar putih");
        p("Fondo oscuro", "Dark background", "Fundo escuro", "गहरी पृष्ठभूमि", "Latar gelap");
        p("Tema claro activado", "Light theme enabled", "Tema claro ativado", "हल्की थीम चालू", "Tema terang aktif");
        p("Tema oscuro activado", "Dark theme enabled", "Tema escuro ativado", "गहरी थीम चालू", "Tema gelap aktif");
        p("Brillo de lectura", "Reading brightness", "Brilho de leitura", "पठन चमक", "Kecerahan membaca");
        p("Brillo del sistema", "System brightness", "Brilho do sistema", "सिस्टम चमक", "Kecerahan sistem");

        p("Motor listo", "Voice engine ready", "Motor pronto", "इंजन तैयार", "Mesin siap");
        p("Motor de voz sin iniciar", "Voice engine hasn't started", "Motor de voz não iniciado", "वॉइस इंजन शुरू नहीं हुआ", "Mesin suara belum dimulai");
        p("Buscando motor de voz", "Searching for voice engine", "Procurando motor de voz", "वॉइस इंजन खोजा जा रहा है", "Mencari mesin suara");
        p("El motor de voz aun no esta listo", "The voice engine is not ready yet", "O motor de voz ainda não está pronto", "वॉइस इंजन अभी तैयार नहीं है", "Mesin suara belum siap");
        p("Android no pudo iniciar ningun motor de voz instalado", "Android could not start any installed voice engine", "O Android não conseguiu iniciar nenhum motor de voz instalado", "Android कोई भी इंस्टॉल वॉइस इंजन शुरू नहीं कर सका", "Android tidak dapat memulai mesin suara yang terpasang");
        p("El motor rechazo el audio rapido", "The voice engine couldn't generate quick-start audio", "O motor rejeitou o áudio rápido", "इंजन ने तेज़ ऑडियो अस्वीकार किया", "Mesin menolak audio cepat");
        p("No se pudo preparar el audio rapido", "Couldn't prepare quick-start audio", "Não foi possível preparar o áudio rápido", "तेज़ ऑडियो तैयार नहीं हो सका", "Audio cepat tidak dapat disiapkan");
        p("El motor rechazo la prueba de voz", "The engine rejected the voice test", "O motor rejeitou o teste de voz", "इंजन ने आवाज़ परीक्षण अस्वीकार किया", "Mesin menolak uji suara");
        p("La prueba de voz fue interrumpida", "The voice test was interrupted", "O teste de voz foi interrompido", "आवाज़ परीक्षण बाधित हुआ", "Uji suara terhenti");
        p("La preparacion del audio rapido fue interrumpida", "Quick-start audio preparation was interrupted", "A preparação do áudio rápido foi interrompida", "तेज़ ऑडियो की तैयारी बाधित हुई", "Persiapan audio cepat terhenti");
        p("motor predeterminado", "default engine", "motor padrão", "डिफ़ॉल्ट इंजन", "mesin bawaan");
        p("Motor de voz", "Voice engine", "Motor de voz", "वॉइस इंजन", "Mesin suara");
        p("Voces", "Voices", "Vozes", "आवाज़ें", "Suara");
        p("Ver voces instaladas y faltantes", "View installed and missing voices", "Ver vozes instaladas e ausentes", "इंस्टॉल और अनुपलब्ध आवाज़ें देखें", "Lihat suara yang terpasang dan yang belum tersedia");
        p("Automática (recomendada)", "Automatic (recommended)", "Automática (recomendada)", "स्वचालित (अनुशंसित)", "Otomatis (disarankan)");
        p("La app elige la mejor disponible", "The app picks the best available", "O app escolhe a melhor disponível", "ऐप सबसे अच्छी उपलब्ध आवाज़ चुनता है", "Aplikasi memilih yang terbaik");
        p("No hay más de una voz instalada para este idioma en el teléfono.", "There is only one voice installed for this language on the phone.", "Há apenas uma voz instalada para este idioma no telefone.", "इस भाषा के लिए फ़ोन में केवल एक ही आवाज़ इंस्टॉल है।", "Hanya ada satu suara yang terpasang untuk bahasa ini di ponsel.");
        p("Voz del sistema", "System voice", "Voz do sistema", "सिस्टम आवाज़", "Suara sistem");
        p("Cargando", "Loading", "Carregando", "लोड हो रहा है", "Memuat");
        p("Anuncio", "Ad", "Anúncio", "विज्ञापन", "Iklan");
        p("PÁGINAS GUARDADAS", "SAVED PAGES", "PÁGINAS SALVAS", "सहेजे गए पृष्ठ", "HALAMAN TERSIMPAN");
        p("Comprueba qué voces están listas para leer PDFs.", "Check which voices are ready to read PDFs.", "Confira quais vozes estão prontas para ler PDFs.", "देखें कि PDF पढ़ने के लिए कौन-सी आवाज़ें तैयार हैं।", "Periksa suara yang siap digunakan untuk membaca PDF.");
        p("La primera voz tarda unos segundos en sonar. Después suena al instante.", "The first voice takes a few seconds to play. After that it plays instantly.", "A primeira voz demora alguns segundos para tocar. Depois toca na hora.", "पहली आवाज़ को बजने में कुछ सेकंड लगते हैं। उसके बाद वह तुरंत बजती है।", "Suara pertama butuh beberapa detik untuk terdengar. Setelah itu langsung berbunyi.");
        p("Comprobando voces...", "Checking voices...", "Verificando vozes...", "आवाज़ें जाँची जा रही हैं...", "Memeriksa suara...");
        p("Instalada", "Installed", "Instalada", "इंस्टॉल है", "Terpasang");
        p("Solo en línea", "Online only", "Somente online", "केवल ऑनलाइन", "Hanya online");
        p("Falta descargar", "Download required", "Falta baixar", "डाउनलोड आवश्यक", "Perlu diunduh");
        p("Descargar voz", "Download voice", "Baixar voz", "आवाज़ डाउनलोड करें", "Unduh suara");
        p("Descargar voces faltantes", "Download missing voices", "Baixar vozes ausentes", "अनुपलब्ध आवाज़ें डाउनलोड करें", "Unduh suara yang belum tersedia");
        p("No se encontró el instalador de voces", "Voice installer not found", "Instalador de vozes não encontrado", "वॉइस इंस्टॉलर नहीं मिला", "Penginstal suara tidak ditemukan");
        p("Falta una voz", "Voice missing", "Falta uma voz", "एक आवाज़ उपलब्ध नहीं है", "Suara belum tersedia");
        p("Falta la voz para leer este PDF.", "A voice for this PDF is missing.", "Falta a voz para ler este PDF.", "इस PDF को पढ़ने के लिए आवश्यक आवाज़ उपलब्ध नहीं है।", "Suara untuk membaca PDF ini belum tersedia.");
        p("Idioma del PDF", "PDF language", "Idioma do PDF", "PDF की भाषा", "Bahasa PDF");
        p("No pudimos detectar con seguridad el idioma de este PDF. Elige el idioma para leerlo.", "We couldn't reliably detect this PDF's language. Choose the language to read it.", "Não foi possível detectar com segurança o idioma deste PDF. Escolha o idioma para lê-lo.", "इस PDF की भाषा भरोसेमंद तरीके से नहीं पहचानी जा सकी। पढ़ने के लिए भाषा चुनें।", "Bahasa PDF ini tidak dapat dideteksi dengan yakin. Pilih bahasa untuk membacanya.");
        p("Detectando idioma del PDF...", "Detecting PDF language...", "Detectando idioma do PDF...", "PDF की भाषा पहचानी जा रही है...", "Mendeteksi bahasa PDF...");
        p("Automatico (recomendado)", "Automatic (recommended)", "Automático (recomendado)", "स्वचालित (अनुशंसित)", "Otomatis (disarankan)");
        p("Probar voz", "Test voice", "Testar voz", "आवाज़ जाँचें", "Uji suara");
        p("Escuchar una muestra", "Listen to a sample", "Ouvir uma amostra", "नमूना सुनें", "Dengarkan contoh");
        p("Velocidad", "Speed", "Velocidade", "गति", "Kecepatan");
        p("Velocidad de lectura", "Reading speed", "Velocidade de leitura", "पढ़ने की गति", "Kecepatan membaca");
        p("Preparando motor", "Preparing engine", "Preparando motor", "इंजन तैयार हो रहा है", "Menyiapkan mesin");
        p("Preparando prueba de voz", "Preparing voice test", "Preparando teste de voz", "आवाज़ परीक्षण तैयार हो रहा है", "Menyiapkan uji suara");
        p("Reiniciando el motor de voz", "Restarting voice engine", "Reiniciando o motor de voz", "वॉइस इंजन पुनः शुरू हो रहा है", "Memulai ulang mesin suara");
        p("La voz comenzo correctamente", "Voice started successfully", "A voz iniciou corretamente", "आवाज़ सही शुरू हुई", "Suara berhasil dimulai");
        p("Prueba de voz correcta. El lector esta listo para leer el PDF.", "Voice test successful. The reader is ready.", "Teste de voz concluído. O leitor está pronto para ler o PDF.", "आवाज़ परीक्षण सफल। रीडर PDF पढ़ने के लिए तैयार है।", "Uji suara berhasil. Pembaca siap membaca PDF.");
        p("No se pudo iniciar voz", "Couldn't start voice", "Não foi possível iniciar a voz", "आवाज़ शुरू नहीं हो सकी", "Suara tidak dapat dimulai");

        p("Seguir lectura", "Follow along", "Acompanhar leitura", "पढ़ते समय साथ चलें", "Ikuti bacaan");
        p("Durante la reproducción", "During playback", "Durante a reprodução", "चलाते समय", "Saat diputar");
        p("Color del seguimiento", "Tracking color", "Cor do acompanhamento", "अनुसरण रंग", "Warna pelacakan");
        p("Tipo de marcado", "Markup type", "Tipo de marcação", "मार्कअप प्रकार", "Jenis penandaan");
        p("Grosor del subrayado", "Underline thickness", "Espessura do sublinhado", "रेखांकन की मोटाई", "Ketebalan garis bawah");
        p("Subrayado fino", "Thin underline", "Sublinhado fino", "पतला रेखांकन", "Garis bawah tipis");
        p("Subrayado doble", "Double underline", "Sublinhado duplo", "दोहरा रेखांकन", "Garis bawah ganda");
        p("Subrayado ondulado", "Wavy underline", "Sublinhado ondulado", "लहरदार रेखांकन", "Garis bawah bergelombang");
        p("Subrayado punteado", "Dotted underline", "Sublinhado pontilhado", "बिंदु रेखांकन", "Garis bawah titik-titik");
        p("Resaltado suave", "Soft highlight", "Realce suave", "हल्का हाइलाइट", "Sorotan lembut");
        p("Resaltado intenso", "Strong highlight", "Realce intenso", "गहरा हाइलाइट", "Sorotan kuat");
        p("Fino", "Thin", "Fino", "पतला", "Tipis");
        p("Medio", "Medium", "Médio", "मध्यम", "Sedang");
        p("Grueso", "Thick", "Grosso", "मोटा", "Tebal");
        p("Ejemplo", "Example", "Exemplo", "उदाहरण", "Contoh");
        p("Color del subrayado", "Underline color", "Cor do sublinhado", "रेखांकन रंग", "Warna garis bawah");
        p("Color del resaltado", "Highlight color", "Cor do realce", "हाइलाइट रंग", "Warna sorotan");
        p("Color de las reglas", "Guide color", "Cor das guias", "गाइड का रंग", "Warna panduan");
        p("Color personalizado", "Custom color", "Cor personalizada", "कस्टम रंग", "Warna khusus");
        p("Color seleccionado", "Selected color", "Cor selecionada", "चुना हुआ रंग", "Warna terpilih");
        p("Elegir color del marcado", "Choose markup color", "Escolher cor da marcação", "मार्कअप रंग चुनें", "Pilih warna penandaan");
        p("Limpiar", "Clear", "Limpar", "साफ़ करें", "Bersihkan");
        p("Solo página actual", "Current page only", "Somente página atual", "केवल वर्तमान पृष्ठ", "Hanya halaman saat ini");
        p("Subrayado simple", "Simple underline", "Sublinhado simples", "सरल रेखांकन", "Garis bawah sederhana");
        p("Reglas", "Guides", "Guias", "गाइड", "Panduan");
        p("Reglas ON", "Guides: On", "Guias: Ativas", "गाइड: चालू", "Panduan: Aktif");
        p("Reglas OFF", "Guides: Off", "Guias: Inativas", "गाइड: बंद", "Panduan: Nonaktif");
        p("Reglas activadas. Arrastra las líneas.", "Guides enabled. Drag the lines.", "Guias ativadas. Arraste as linhas.", "गाइड चालू हैं। रेखाएँ खींचें।", "Panduan aktif. Geser garis panduan.");
        p("Reglas desactivadas", "Guides disabled", "Guias desativadas", "गाइड बंद", "Panduan dinonaktifkan");
        p("Subrayar ON", "Markup: On", "Marcação: Ativa", "मार्कअप: चालू", "Penandaan: Aktif");
        p("Subrayar OFF", "Markup: Off", "Marcação: Inativa", "मार्कअप: बंद", "Penandaan: Nonaktif");
        p("Subrayado activado: un dedo marca y dos dedos mueven", "Markup on: use one finger to mark and two fingers to move.", "Marcação ativada: um dedo marca e dois dedos movem", "मार्कअप चालू: एक उंगली से चिह्नित करें, दो से चलाएँ", "Penandaan aktif: satu jari menandai, dua jari menggeser");
        p("Subrayado desactivado", "Markup disabled", "Marcação desativada", "मार्कअप बंद", "Penandaan dinonaktifkan");
        p("Subrayado activo. Arrastra sobre el texto", "Underline on. Drag over the text.", "Sublinhado ativo. Arraste sobre o texto", "रेखांकन चालू। पाठ पर खींचें", "Garis bawah aktif. Geser di atas teks");
        p("Resaltado activo. Arrastra sobre el texto", "Highlight on. Drag over the text.", "Realce ativo. Arraste sobre o texto", "हाइलाइट चालू। पाठ पर खींचें", "Sorotan aktif. Geser di atas teks");
        p("Marcado apagado", "Markup off", "Marcação desativada", "मार्कअप बंद", "Penandaan mati");
        p("Deshacer marca", "Undo mark", "Desfazer marca", "चिह्न वापस लें", "Batalkan tanda");
        p("Rehacer marca", "Redo mark", "Refazer marca", "चिह्न फिर करें", "Ulangi tanda");

        p("Mis archivos", "My files", "Meus arquivos", "मेरी फ़ाइलें", "File saya");
        p("Páginas guardadas", "Saved pages", "Páginas salvas", "सहेजे गए पृष्ठ", "Halaman tersimpan");
        p("Ir a las páginas marcadas con la estrella", "Go to pages marked with the star", "Ir para as páginas marcadas com a estrela", "तारे से चिह्नित पृष्ठों पर जाएं", "Buka halaman yang ditandai bintang");
        p("Todavía no hay páginas guardadas.\nUsa la estrella ☆ mientras lees.", "No saved pages yet.\nUse the ☆ star while reading.", "Ainda não há páginas salvas.\nUse a estrela ☆ enquanto lê.", "अभी कोई सहेजा पृष्ठ नहीं है।\nपढ़ते समय ☆ तारे का उपयोग करें।", "Belum ada halaman tersimpan.\nGunakan bintang ☆ saat membaca.");
        p("Página guardada", "Page saved", "Página salva", "पृष्ठ सहेजा गया", "Halaman disimpan");
        p("Marcador quitado", "Bookmark removed", "Marcador removido", "बुकमार्क हटाया गया", "Penanda dihapus");
        p("Guardar pagina", "Save page", "Salvar página", "पृष्ठ सहेजें", "Simpan halaman");
        p("Quitar pagina guardada", "Remove saved page", "Remover página salva", "सहेजा पृष्ठ हटाएं", "Hapus halaman tersimpan");
        p("Quitar página", "Remove page", "Remover página", "पृष्ठ हटाएं", "Hapus halaman");
        p("Guardar la página visible con sus marcas", "Save the visible page with its marks", "Salvar a página visível com suas marcas", "दृश्य पृष्ठ को उसके चिह्नों सहित सहेजें", "Simpan halaman terlihat beserta tandanya");
        p("Guardar el documento completo", "Save the whole document", "Salvar o documento inteiro", "पूरा दस्तावेज़ सहेजें", "Simpan seluruh dokumen");
        p("Buscando archivos...", "Looking for files...", "Procurando arquivos...", "फ़ाइलें खोजी जा रही हैं...", "Mencari file...");
        p("Permiso de notificaciones", "Notification permission", "Permissão de notificações", "सूचना अनुमति", "Izin notifikasi");
        p("Sin este permiso no se ven los controles del audio. Puedes activarlo desde los ajustes de la aplicación.", "Without this permission the audio controls are hidden. You can enable it from the app settings.", "Sem esta permissão os controles de áudio não aparecem. Você pode ativá-la nas configurações do aplicativo.", "इस अनुमति के बिना ऑडियो नियंत्रण नहीं दिखते। आप इसे ऐप सेटिंग्स से चालू कर सकते हैं।", "Tanpa izin ini kontrol audio tidak terlihat. Anda dapat mengaktifkannya dari pengaturan aplikasi.");
        p("Abrir ajustes", "Open settings", "Abrir configurações", "सेटिंग्स खोलें", "Buka pengaturan");
        p("Ahora no", "Not now", "Agora não", "अभी नहीं", "Nanti saja");
        p("No se pudieron abrir los ajustes", "Settings could not be opened", "Não foi possível abrir as configurações", "सेटिंग्स नहीं खोली जा सकीं", "Pengaturan tidak dapat dibuka");
        p("Actualizar archivos", "Refresh files", "Atualizar arquivos", "फ़ाइलें ताज़ा करें", "Perbarui file");
        p("Audios", "Audio", "Áudios", "ऑडियो", "Audio");
        p("Imágenes", "Images", "Imagens", "छवियाँ", "Gambar");
        p("Imagenes", "Images", "Imagens", "छवियाँ", "Gambar");
        p("PDF marcados", "Annotated PDFs", "PDFs marcados", "चिह्नित PDF", "PDF bertanda");
        p("Ver audios, imágenes y PDF guardados", "View saved audio files, images, and PDFs", "Ver áudios, imagens e PDFs salvos", "सहेजे ऑडियो, छवियाँ और PDF देखें", "Lihat audio, gambar, dan PDF tersimpan");
        p("Carpetas de guardado", "Storage folders", "Pastas de armazenamento", "सहेजने के फ़ोल्डर", "Folder penyimpanan");
        p("Audios · Imágenes · PDF", "Audio · Images · PDF", "Áudios · Imagens · PDF", "ऑडियो · छवियाँ · PDF", "Audio · Gambar · PDF");
        p("Cada formato se guarda en su propia carpeta y también aparece en Mis archivos.", "Each format is saved in its own folder and also appears in My files.", "Cada formato é salvo em sua própria pasta e também aparece em Meus arquivos.", "हर प्रारूप अपने फ़ोल्डर में सहेजा जाता है और मेरी फ़ाइलें में भी दिखता है।", "Setiap format disimpan di foldernya sendiri dan juga muncul di File saya.");
        p("Ver carpetas de guardado", "View storage folders", "Ver pastas de armazenamento", "सहेजने के फ़ोल्डर देखें", "Lihat folder penyimpanan");
        p("Ver imágenes en cuadrícula", "View images in grid", "Ver imagens em grade", "छवियाँ ग्रिड में देखें", "Lihat gambar dalam kisi");
        p("Ver imágenes en lista", "View images in list", "Ver imagens em lista", "छवियाँ सूची में देखें", "Lihat gambar dalam daftar");
        p("No hay imágenes guardadas", "No saved images", "Não há imagens salvas", "कोई सहेजी छवि नहीं", "Tidak ada gambar tersimpan");
        p("Todavía no hay audios guardados.\nCrea uno desde Ajustes > Crear audio.", "No audio files saved yet.\nCreate one from Settings > Create audio.", "Ainda não há áudios salvos.\nCrie um em Configurações > Criar áudio.", "अभी कोई ऑडियो सहेजा नहीं गया।\nसेटिंग्स > ऑडियो बनाएँ से बनाएँ।", "Belum ada audio tersimpan.\nBuat dari Pengaturan > Buat audio.");
        p("Todavía no hay imágenes guardadas.\nGuarda una página marcada desde Ajustes.", "No images saved yet.\nSave an annotated page from Settings.", "Ainda não há imagens salvas.\nSalve uma página marcada em Configurações.", "अभी कोई छवि सहेजी नहीं गई।\nसेटिंग्स से चिह्नित पृष्ठ सहेजें।", "Belum ada gambar tersimpan.\nSimpan halaman bertanda dari Pengaturan.");
        p("Todavía no hay PDF marcados.\nUsa Guardar PDF marcado desde Ajustes.", "No annotated PDFs saved yet.\nUse Save annotated PDF in Settings.", "Ainda não há PDFs marcados.\nUse Salvar PDF marcado em Configurações.", "अभी कोई चिह्नित PDF नहीं है।\nसेटिंग्स में चिह्नित PDF सहेजें का उपयोग करें।", "Belum ada PDF bertanda.\nGunakan Simpan PDF bertanda dari Pengaturan.");

        p("Crear audio", "Create audio", "Criar áudio", "ऑडियो बनाएँ", "Buat audio");
        p("Bloqueado", "Locked", "Bloqueado", "लॉक", "Terkunci");
        p("Desbloqueado", "Unlocked", "Desbloqueado", "अनलॉक", "Terbuka");
        p("Mira un anuncio para desbloquear durante 8 horas:", "Watch an ad to unlock for 8 hours:", "Assista a um anúncio para desbloquear por 8 horas:", "8 घंटे के लिए अनलॉक करने हेतु एक विज्ञापन देखें:", "Tonton iklan untuk membuka selama 8 jam:");
        p("Lectura OCR de PDFs escaneados", "OCR reading for scanned PDFs", "Leitura OCR de PDFs digitalizados", "स्कैन किए गए PDF के लिए OCR पढ़ना", "Pembacaan OCR untuk PDF hasil pindai");
        p("Guardar audio", "Save audio", "Salvar áudio", "ऑडियो सहेजें", "Simpan audio");
        p("Guardar imagen", "Save image", "Salvar imagem", "छवि सहेजें", "Simpan gambar");
        p("El resto de las herramientas sigue disponible gratis.", "All other tools remain available for free.", "As outras ferramentas continuam disponíveis gratuitamente.", "बाकी सभी टूल मुफ़्त उपलब्ध रहते हैं।", "Semua alat lainnya tetap tersedia gratis.");
        p("Desbloquear funciones avanzadas", "Unlock advanced features", "Desbloquear recursos avançados", "उन्नत सुविधाएँ अनलॉक करें", "Buka fitur lanjutan");
        p("Ver anuncio y desbloquear", "Watch ad and unlock", "Ver anúncio e desbloquear", "विज्ञापन देखें और अनलॉक करें", "Tonton iklan dan buka");
        p("No se puede mostrar el anuncio hasta completar las opciones de privacidad.", "The ad cannot be shown until the privacy options are completed.", "O anúncio não pode ser exibido até concluir as opções de privacidade.", "गोपनीयता विकल्प पूरे होने तक विज्ञापन नहीं दिखाया जा सकता।", "Iklan tidak dapat ditampilkan sampai opsi privasi diselesaikan.");
        p("Preparando anuncio...", "Preparing ad...", "Preparando anúncio...", "विज्ञापन तैयार हो रहा है...", "Menyiapkan iklan...");
        p("No hay un anuncio disponible ahora. Inténtalo de nuevo.", "No ad is available right now. Try again.", "Não há anúncio disponível agora. Tente novamente.", "अभी कोई विज्ञापन उपलब्ध नहीं है। फिर प्रयास करें।", "Tidak ada iklan yang tersedia saat ini. Coba lagi.");
        p("No se pudo preparar el anuncio", "The ad could not be prepared", "Não foi possível preparar o anúncio", "विज्ञापन तैयार नहीं हो सका", "Iklan tidak dapat disiapkan");
        p("Preparando privacidad para anuncios...", "Preparing ad privacy...", "Preparando privacidade dos anúncios...", "विज्ञापन गोपनीयता तैयार हो रही है...", "Menyiapkan privasi iklan...");
        p("No se puede mostrar el anuncio con la configuración de privacidad actual.", "The ad cannot be shown with the current privacy settings.", "O anúncio não pode ser exibido com as configurações de privacidade atuais.", "मौजूदा गोपनीयता सेटिंग के साथ विज्ञापन नहीं दिखाया जा सकता।", "Iklan tidak dapat ditampilkan dengan pengaturan privasi saat ini.");
        p("No se pudo mostrar el anuncio. Inténtalo de nuevo.", "The ad could not be shown. Try again.", "Não foi possível exibir o anúncio. Tente novamente.", "विज्ञापन नहीं दिखाया जा सका। फिर प्रयास करें।", "Iklan tidak dapat ditampilkan. Coba lagi.");
        p("Funciones avanzadas desbloqueadas durante 8 horas", "Advanced features unlocked for 8 hours", "Recursos avançados desbloqueados por 8 horas", "उन्नत सुविधाएँ 8 घंटे के लिए अनलॉक हुईं", "Fitur lanjutan terbuka selama 8 jam");
        p("Tipo de PDF", "PDF type", "Tipo de PDF", "PDF प्रकार", "Jenis PDF");
        p("PDF con texto", "Text PDF", "PDF com texto", "टेक्स्ट PDF", "PDF dengan teks");
        p("Usa el lector normal y conserva todas las herramientas", "Use the normal reader and keep all tools", "Use o leitor normal e mantenha todas as ferramentas", "सामान्य रीडर का उपयोग करें और सभी टूल रखें", "Gunakan pembaca normal dan pertahankan semua alat");
        p("PDF escaneado (OCR)", "Scanned PDF (OCR)", "PDF digitalizado (OCR)", "स्कैन किया हुआ PDF (OCR)", "PDF hasil pindai (OCR)");
        p("Reconoce páginas escaneadas en el dispositivo", "Recognizes scanned pages on the device", "Reconhece páginas digitalizadas no dispositivo", "डिवाइस पर स्कैन किए गए पृष्ठों को पहचानता है", "Mengenali halaman hasil pindai di perangkat");
        p("Requiere desbloqueo", "Requires unlock", "Requer desbloqueio", "अनलॉक आवश्यक", "Memerlukan buka akses");
        p("Lectura OCR", "OCR reading", "Leitura OCR", "OCR पढ़ना", "Pembacaan OCR");
        p("Subrayado y seguimiento no están disponibles en modo OCR", "Underline and follow-along are not available in OCR mode", "Sublinhado e acompanhamento não estão disponíveis no modo OCR", "OCR मोड में रेखांकन और पढ़ने का अनुसरण उपलब्ध नहीं है", "Garis bawah dan pelacakan bacaan tidak tersedia dalam mode OCR");
        p("No se pudo preparar la privacidad para anuncios.", "Ad privacy could not be prepared.", "Não foi possível preparar a privacidade dos anúncios.", "विज्ञापन गोपनीयता तैयार नहीं की जा सकी।", "Privasi iklan tidak dapat disiapkan.");
        p("Crear un audio de la página visible", "Create audio from the current page", "Criar áudio da página visível", "दिख रहे पृष्ठ का ऑडियो बनाएँ", "Buat audio dari halaman yang terlihat");
        p("Crear audios organizados por páginas", "Create separate audio files by page", "Criar áudios organizados por páginas", "पृष्ठ के अनुसार ऑडियो बनाएँ", "Buat audio per halaman");
        p("Toca el botón para la página actual o elige otra opción", "Tap the button for the current page or choose another option", "Toque no botão para a página atual ou escolha outra opção", "वर्तमान पृष्ठ के लिए बटन दबाएँ या दूसरा विकल्प चुनें", "Ketuk tombol untuk halaman saat ini atau pilih opsi lain");
        p("Toca una opción para guardar el audio", "Tap an option to save the audio", "Toque uma opção para salvar o áudio", "ऑडियो सहेजने के लिए एक विकल्प चुनें", "Ketuk opsi untuk menyimpan audio");
        p("Se guardará en  Geo Zeta / Audios", "Saved to Geo Zeta / Audios", "Será salvo em Geo Zeta / Audios", "यह Geo Zeta / Audios में सहेजा जाएगा", "Akan disimpan di Geo Zeta / Audios");
        p("Preparando exportación de audio...", "Preparing audio export...", "Preparando exportação de áudio...", "ऑडियो निर्यात तैयार हो रहा है...", "Menyiapkan ekspor audio...");
        p("Audio terminado", "Audio ready", "Áudio concluído", "ऑडियो पूरा हुआ", "Audio selesai");
        p("Creación de audio", "Audio creation", "Criação de áudio", "ऑडियो निर्माण", "Pembuatan audio");
        p("Progreso al guardar el audio del PDF", "Progress while saving the PDF audio", "Progresso ao salvar o áudio do PDF", "PDF ऑडियो सहेजने की प्रगति", "Kemajuan saat menyimpan audio PDF");
        p("Creando audio", "Creating audio", "Criando áudio", "ऑडियो बन रहा है", "Membuat audio");
        p("Página", "Page", "Página", "पृष्ठ", "Halaman");
        p("de", "of", "de", "में से", "dari");
        p("archivo(s) en Mis archivos", "file(s) in My files", "arquivo(s) em Meus arquivos", "फ़ाइल(ें) मेरी फ़ाइलों में", "berkas di File Saya");
        p("Audio guardado", "Audio saved", "Áudio salvo", "ऑडियो सहेजा गया", "Audio tersimpan");
        p("Imagen guardada", "Image saved", "Imagem salva", "छवि सहेजी गई", "Gambar tersimpan");
        p("PDF guardado", "PDF saved", "PDF salvo", "PDF सहेजा गया", "PDF tersimpan");
        p("Ver audios", "View audio files", "Ver áudios", "ऑडियो देखें", "Lihat audio");
        p("Galería", "Gallery", "Galeria", "गैलरी", "Galeri");
        p("Reproducir", "Play", "Reproduzir", "चलाएँ", "Putar");
        p("Reproducir o pausar", "Play or pause", "Reproduzir ou pausar", "चलाएँ या रोकें", "Putar atau jeda");
        p("Ⅱ Pausar", "Ⅱ Pause", "Ⅱ Pausar", "Ⅱ रोकें", "Ⅱ Jeda");
        p("▶ Reproducir", "▶ Play", "▶ Reproduzir", "▶ चलाएँ", "▶ Putar");
        p("Compartir archivo", "Share file", "Compartilhar arquivo", "फ़ाइल साझा करें", "Bagikan file");
        p("Cambiar nombre", "Rename", "Renomear", "नाम बदलें", "Ubah nama");
        p("Eliminar archivo", "Delete file", "Excluir arquivo", "फ़ाइल हटाएँ", "Hapus file");
        p("Tamaño pendiente", "Calculating size...", "Tamanho pendente", "आकार लंबित", "Ukuran belum tersedia");
        p("Nombre inválido", "Invalid name", "Nome inválido", "अमान्य नाम", "Nama tidak valid");
        p("Ya existe un archivo con ese nombre", "A file with that name already exists", "Já existe um arquivo com esse nome", "इस नाम की फ़ाइल पहले से मौजूद है", "File dengan nama itu sudah ada");
        p("Nombre actualizado", "Name updated", "Nome atualizado", "नाम अपडेट हुआ", "Nama diperbarui");
        p("Archivo eliminado", "File deleted", "Arquivo excluído", "फ़ाइल हटाई गई", "File dihapus");
        p("No se pudo cambiar el nombre", "Could not rename file", "Não foi possível renomear o arquivo", "फ़ाइल का नाम नहीं बदला जा सका", "Nama file tidak dapat diubah");
        p("No se pudo eliminar", "Could not delete", "Não foi possível excluir", "हटाया नहीं जा सका", "Tidak dapat menghapus");
        p("No se pudo abrir el archivo", "Could not open file", "Não foi possível abrir o arquivo", "फ़ाइल नहीं खुल सकी", "File tidak dapat dibuka");
        p("No se pudo compartir el archivo", "Could not share file", "Não foi possível compartilhar o arquivo", "फ़ाइल साझा नहीं हो सकी", "File tidak dapat dibagikan");
        p("No se pudo abrir el audio", "Could not open audio", "Não foi possível abrir o áudio", "ऑडियो नहीं खुल सका", "Audio tidak dapat dibuka");
        p("No se pudo abrir la imagen", "Could not open image", "Não foi possível abrir a imagem", "छवि नहीं खुल सकी", "Gambar tidak dapat dibuka");

        p("Guardar página marcada", "Save annotated page", "Salvar página marcada", "चिह्नित पृष्ठ सहेजें", "Simpan halaman bertanda");
        p("PNG limpio sin reglas visibles", "Clean PNG without visible guides", "PNG limpo sem réguas visíveis", "दिखाई देने वाली रेखाओं के बिना साफ PNG", "PNG bersih tanpa garis panduan");
        p("Guardar PDF marcado", "Save annotated PDF", "Salvar PDF marcado", "चिह्नित PDF सहेजें", "Simpan PDF bertanda");
        p("Exportar el documento con subrayados", "Export the PDF with annotations", "Exportar o documento com marcações", "मार्कअप सहित दस्तावेज़ निर्यात करें", "Ekspor dokumen dengan penandaan");
        p("Guardar un PDF nuevo con los subrayados y resaltados actuales.", "Save a new PDF with the current underlines and highlights.", "Salvar um novo PDF com os sublinhados e realces atuais.", "वर्तमान रेखांकन और हाइलाइट के साथ नया PDF सहेजें।", "Simpan PDF baru dengan garis bawah dan sorotan saat ini.");
        p("Exportando PDF marcado...", "Exporting annotated PDF...", "Exportando PDF marcado...", "चिह्नित PDF निर्यात हो रहा है...", "Mengekspor PDF bertanda...");
        p("Abre un PDF primero", "Open a PDF first", "Abra um PDF primeiro", "पहले PDF खोलें", "Buka PDF terlebih dahulu");
        p("No se pudo abrir el PDF", "Could not open PDF", "Não foi possível abrir o PDF", "PDF नहीं खुल सका", "PDF tidak dapat dibuka");
        p("Error al cargar PDF", "Error loading PDF", "Erro ao carregar PDF", "PDF लोड करने में त्रुटि", "Gagal memuat PDF");
        p("No se pudo guardar el PDF", "Could not save PDF", "Não foi possível salvar o PDF", "PDF सहेजा नहीं जा सका", "PDF tidak dapat disimpan");
        p("No se pudo renderizar ninguna página", "No page could be rendered", "Nenhuma página pôde ser renderizada", "कोई पृष्ठ रेंडर नहीं हो सका", "Tidak ada halaman yang dapat dirender");
        p("No se pudo guardar la imagen", "Could not save image", "Não foi possível salvar a imagem", "छवि सहेजी नहीं जा सकी", "Gambar tidak dapat disimpan");

        p("Marcadores", "Bookmarks", "Marcadores", "बुकमार्क", "Penanda");
        p("Marcadores. Página actual guardada", "Bookmark added for current page", "Marcadores. Página atual salva", "बुकमार्क। वर्तमान पृष्ठ सहेजा गया", "Penanda. Halaman saat ini disimpan");
        p("Todavía no hay páginas guardadas", "No saved pages yet", "Ainda não há páginas salvas", "अभी कोई पृष्ठ सहेजा नहीं गया", "Belum ada halaman tersimpan");

        p("Acepta el permiso de notificaciones para ver los controles del audio", "Allow notifications to show audio controls", "Permita notificações para ver os controles de áudio", "ऑडियो नियंत्रण देखने के लिए सूचनाएँ अनुमति दें", "Izinkan notifikasi untuk melihat kontrol audio");
        p("Leyendo", "Reading", "Lendo", "पढ़ रहा है", "Membaca");
        p("Preparando", "Preparing", "Preparando", "तैयार हो रहा है", "Menyiapkan");
        p("Pausado", "Paused", "Pausado", "रुका हुआ", "Dijeda");
        p("Detenido", "Stopped", "Parado", "रुका", "Berhenti");
        p("Lectura finalizada", "Reading complete", "Leitura concluída", "पठन पूरा हुआ", "Pembacaan selesai");
        p("Iniciando motor de voz", "Starting voice engine", "Iniciando motor de voz", "वॉइस इंजन शुरू हो रहा है", "Memulai mesin suara");
        p("Reiniciando motor de voz", "Restarting voice engine", "Reiniciando motor de voz", "वॉइस इंजन पुनः शुरू हो रहा है", "Memulai ulang mesin suara");
        p("Lectura de PDF en segundo plano", "Reading PDF in the background", "Leitura de PDF em segundo plano", "पृष्ठभूमि में PDF पठन", "Membaca PDF di latar belakang");
        p("El PDF tardo demasiado en entregar el texto", "The PDF took too long to load the text", "O PDF demorou demais para fornecer o texto", "PDF से पाठ मिलने में बहुत समय लगा", "PDF terlalu lama memberikan teks");
        p("No se pudo extraer el texto de la pagina", "Could not extract text from the page", "Não foi possível extrair o texto da página", "पृष्ठ से पाठ नहीं निकाला जा सका", "Teks halaman tidak dapat diekstrak");
        p("El audio no pudo preparar el texto", "Couldn't prepare text for audio", "O áudio não conseguiu preparar o texto", "ऑडियो पाठ तैयार नहीं कर सका", "Audio tidak dapat menyiapkan teks");
        p("El motor recibio el texto pero no inicio el audio", "The voice engine received the text but didn't start playback", "O motor recebeu o texto, mas não iniciou o áudio", "इंजन को पाठ मिला लेकिन ऑडियो शुरू नहीं हुआ", "Mesin menerima teks tetapi audio tidak dimulai");
        p("El motor de voz rechazo el texto", "The voice engine rejected the text", "O motor de voz rejeitou o texto", "वॉइस इंजन ने पाठ अस्वीकार किया", "Mesin suara menolak teks");
        p("La aplicacion no pudo obtener el texto de la pagina", "The app couldn't extract text from the page", "O aplicativo não conseguiu obter o texto da página", "ऐप पृष्ठ से पाठ नहीं ले सका", "Aplikasi tidak dapat mengambil teks halaman");
        r("PE", "Perú", "Peru", "Peru", "पेरू", "Peru");
        r("MX", "México", "Mexico", "México", "मेक्सिको", "Meksiko");
        r("CO", "Colombia", "Colombia", "Colômbia", "कोलंबिया", "Kolombia");
        r("AR", "Argentina", "Argentina", "Argentina", "अर्जेंटीना", "Argentina");
        r("CL", "Chile", "Chile", "Chile", "चिली", "Chili");
        r("EC", "Ecuador", "Ecuador", "Equador", "इक्वाडोर", "Ekuador");
        r("BO", "Bolivia", "Bolivia", "Bolívia", "बोलिविया", "Bolivia");
        r("PY", "Paraguay", "Paraguay", "Paraguai", "पराग्वे", "Paraguay");
        r("UY", "Uruguay", "Uruguay", "Uruguai", "उरुग्वे", "Uruguay");
        r("VE", "Venezuela", "Venezuela", "Venezuela", "वेनेज़ुएला", "Venezuela");
        r("GT", "Guatemala", "Guatemala", "Guatemala", "ग्वाटेमाला", "Guatemala");
        r("HN", "Honduras", "Honduras", "Honduras", "होंडुरास", "Honduras");
        r("SV", "El Salvador", "El Salvador", "El Salvador", "अल सल्वाडोर", "El Salvador");
        r("NI", "Nicaragua", "Nicaragua", "Nicarágua", "निकारागुआ", "Nikaragua");
        r("CR", "Costa Rica", "Costa Rica", "Costa Rica", "कोस्टा रिका", "Kosta Rika");
        r("PA", "Panamá", "Panama", "Panamá", "पनामा", "Panama");
        r("CU", "Cuba", "Cuba", "Cuba", "क्यूबा", "Kuba");
        r("DO", "República Dominicana", "Dominican Republic", "República Dominicana", "डोमिनिकन गणराज्य", "Republik Dominika");
        r("ES", "España", "Spain", "Espanha", "स्पेन", "Spanyol");
        r("BR", "Brasil", "Brazil", "Brasil", "ब्राज़ील", "Brasil");
        r("PT", "Portugal", "Portugal", "Portugal", "पुर्तगाल", "Portugal");
        r("IN", "India", "India", "Índia", "भारत", "India");
        r("ID", "Indonesia", "Indonesia", "Indonésia", "इंडोनेशिया", "Indonesia");
        r("PH", "Filipinas", "Philippines", "Filipinas", "फिलीपींस", "Filipina");
        r("US", "Estados Unidos", "United States", "Estados Unidos", "संयुक्त राज्य अमेरिका", "Amerika Serikat");
        r("GB", "Reino Unido", "United Kingdom", "Reino Unido", "यूनाइटेड किंगडम", "Britania Raya");
        r("CA", "Canadá", "Canada", "Canadá", "कनाडा", "Kanada");
        r("AU", "Australia", "Australia", "Austrália", "ऑस्ट्रेलिया", "Australia");
    }

    private UiStrings() {}

    private static void p(String es, String en, String pt, String hi, String id) {
        TEXT.put(es, new String[]{es, en, pt, hi, id});
    }

    private static void r(String code, String es, String en, String pt, String hi, String id) {
        REGION_NAMES.put(code, new String[]{es, en, pt, hi, id});
    }

    public static String detectDeviceLanguage() {
        String language = Locale.getDefault().getLanguage();
        if (language == null) return EN;
        language = language.toLowerCase(Locale.ROOT);
        if (language.equals("es")) return ES;
        if (language.equals("pt")) return PT;
        if (language.equals("hi")) return HI;
        if (language.equals("id") || language.equals("in")) return ID;
        return EN;
    }

    public static String currentLanguage(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("pdf_audio_prefs", Context.MODE_PRIVATE);
        return normalize(prefs.getString(PREF_LANGUAGE, detectDeviceLanguage()));
    }

    public static String normalize(String language) {
        if (PT.equals(language)) return PT;
        if (HI.equals(language)) return HI;
        if (ID.equals(language) || "in".equals(language)) return ID;
        if (ES.equals(language)) return ES;
        return EN;
    }

    public static String languageName(String language) {
        language = normalize(language);
        if (ES.equals(language)) return "Español";
        if (PT.equals(language)) return "Português";
        if (HI.equals(language)) return "हिन्दी";
        if (ID.equals(language)) return "Bahasa Indonesia";
        return "English";
    }


    /**
     * Region del telefono. Muchos equipos salen de fabrica con la region del
     * sistema en "US" aunque el usuario este en otro pais, asi que en ese caso
     * consultamos el pais de la SIM antes de resignarnos. No requiere permisos
     * ni conexion: es informacion que el sistema ya tiene.
     */
    public static String detectDeviceRegion(Context context, String language) {
        String country = Locale.getDefault().getCountry();
        if (country != null) {
            country = country.toUpperCase(Locale.ROOT);
            // "US" es el valor por defecto de fabrica mas comun, asi que no lo
            // damos por bueno sin confirmarlo con la SIM.
            if (REGION_NAMES.containsKey(country) && !"US".equals(country)) return country;
        }

        String simCountry = detectSimRegion(context);
        if (simCountry != null && REGION_NAMES.containsKey(simCountry)) return simCountry;

        if (country != null && REGION_NAMES.containsKey(country)) return country;
        return defaultRegionForLanguage(language);
    }

    private static String detectSimRegion(Context context) {
        if (context == null) return null;
        try {
            android.telephony.TelephonyManager tm =
                    (android.telephony.TelephonyManager) context.getSystemService(
                            Context.TELEPHONY_SERVICE);
            if (tm == null) return null;
            // Pais del operador de red primero (donde esta el telefono ahora),
            // y si no hay senal, el pais de la propia SIM.
            String network = tm.getNetworkCountryIso();
            if (network != null && network.trim().length() == 2) {
                return network.trim().toUpperCase(Locale.ROOT);
            }
            String sim = tm.getSimCountryIso();
            if (sim != null && sim.trim().length() == 2) {
                return sim.trim().toUpperCase(Locale.ROOT);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static String defaultRegionForLanguage(String language) {
        language = normalize(language);
        if (PT.equals(language)) return "BR";
        if (HI.equals(language)) return "IN";
        if (ID.equals(language)) return "ID";
        if (ES.equals(language)) return "ES";
        return "US";
    }

    public static String detectDeviceRegion(String language) {
        String country = Locale.getDefault().getCountry();
        if (country != null) {
            country = country.toUpperCase(Locale.ROOT);
            if (REGION_NAMES.containsKey(country)) return country;
        }
        return defaultRegionForLanguage(language);
    }

    public static String normalizeRegion(String region, String language, Context context) {
        if (region != null) {
            region = region.toUpperCase(Locale.ROOT);
            if (REGION_NAMES.containsKey(region)) return region;
        }
        return detectDeviceRegion(context, language);
    }

    public static String normalizeRegion(String region, String language) {
        if (region != null) {
            region = region.toUpperCase(Locale.ROOT);
            if (REGION_NAMES.containsKey(region)) return region;
        }
        return detectDeviceRegion(language);
    }

    public static String[] regionCodes() {
        return REGION_CODES.clone();
    }


    public static String regionName(String region, String language) {
        region = normalizeRegion(region, language);
        String[] names = REGION_NAMES.get(region);
        return names == null ? region : names[index(normalize(language))];
    }

    public static String translate(Context context, String source) {
        return translate(currentLanguage(context), source);
    }

    public static String translate(String language, String source) {
        if (source == null || source.length() == 0) return source;
        language = normalize(language);
        if (ES.equals(language)) return source;

        String[] exact = TEXT.get(source);
        if (exact != null) return exact[index(language)];

        // Dynamic UI strings.
        String out;
        out = prefix(language, source, "Velocidad: ", "Speed: ", "Velocidade: ", "गति: ", "Kecepatan: ");
        if (out != null) return out;
        out = prefix(language, source, "Listo: ", "Ready: ", "Pronto: ", "तैयार: ", "Siap: ");
        if (out != null) return out;
        if (!source.startsWith("Preparando pagina ")) {
            out = prefix(language, source, "Preparando ", "Preparing ", "Preparando ", "तैयार हो रहा है: ", "Menyiapkan ");
            if (out != null) return out;
        }
        if (source.startsWith("No se pudo exportar la página ")) {
            String page = source.substring("No se pudo exportar la página ".length());
            if (EN.equals(language)) return "Could not export page " + page;
            if (PT.equals(language)) return "Não foi possível exportar a página " + page;
            if (HI.equals(language)) return "पृष्ठ " + page + " निर्यात नहीं हो सका";
            return "Halaman " + page + " tidak dapat diekspor";
        }
        out = prefix(language, source, "Eliminar marcador de página ", "Delete bookmark for page ", "Excluir marcador da página ", "पृष्ठ का बुकमार्क हटाएँ ", "Hapus penanda halaman ");
        if (out != null) return out;
        out = prefix(language, source, "★ Quitar página ", "★ Remove page ", "★ Remover página ", "★ पृष्ठ हटाएँ ", "★ Hapus halaman ");
        if (out != null) return out;
        out = prefix(language, source, "☆ Guardar página ", "☆ Save page ", "☆ Salvar página ", "☆ पृष्ठ सहेजें ", "☆ Simpan halaman ");
        if (out != null) return out;
        out = prefix(language, source, "Color personalizado ", "Custom color ", "Cor personalizada ", "कस्टम रंग ", "Warna khusus ");
        if (out != null) return out;
        out = prefix(language, source, "Crear color personalizado ", "Create custom color ", "Criar cor personalizada ", "कस्टम रंग बनाएँ ", "Buat warna khusus ");
        if (out != null) return out;
        out = prefix(language, source, "Color base ", "Base color ", "Cor base ", "मूल रंग ", "Warna dasar ");
        if (out != null) return out;

        out = prefix(language, source, "Audios\n", "Audio\n", "Áudios\n", "ऑडियो\n", "Audio\n");
        if (out != null) return out;
        out = prefix(language, source, "Imágenes\n", "Images\n", "Imagens\n", "छवियाँ\n", "Gambar\n");
        if (out != null) return out;
        out = prefix(language, source, "PDF\n", "PDF\n", "PDF\n", "PDF\n", "PDF\n");
        if (out != null) return out;

        if (source.startsWith("Página ") || source.startsWith("Pagina ")) {
            String rest = source.substring(source.indexOf(' ') + 1);
            int of = rest.indexOf(" de ");
            if (of >= 0) {
                String left = rest.substring(0, of);
                String right = rest.substring(of + 4);
                if (EN.equals(language)) return "Page " + left + " of " + right;
                if (PT.equals(language)) return "Página " + left + " de " + right;
                if (HI.equals(language)) return "पृष्ठ " + left + " / " + right;
                return "Halaman " + left + " dari " + right;
            }
            return word(language, "Page", "Página", "पृष्ठ", "Halaman") + " " + rest;
        }
        if (source.startsWith("Desde (1 - ")) {
            String rest = source.substring("Desde ".length());
            return word(language, "From", "De", "से", "Dari") + " " + rest;
        }
        if (source.startsWith("Hasta (1 - ")) {
            String rest = source.substring("Hasta ".length());
            return word(language, "To", "Até", "तक", "Sampai") + " " + rest;
        }
        if (source.startsWith("¿Eliminar ") && source.endsWith("?")) {
            String name = source.substring("¿Eliminar ".length(), source.length() - 1);
            if (EN.equals(language)) return "Delete " + name + "?";
            if (PT.equals(language)) return "Excluir " + name + "?";
            if (HI.equals(language)) return name + " हटाएँ?";
            return "Hapus " + name + "?";
        }
        if (source.endsWith(" archivo(s) guardado(s) en Mis archivos")) {
            String count = source.substring(0, source.indexOf(' '));
            if (EN.equals(language)) return count + " file(s) saved in My files";
            if (PT.equals(language)) return count + " arquivo(s) salvo(s) em Meus arquivos";
            if (HI.equals(language)) return count + " फ़ाइल मेरी फ़ाइलें में सहेजी गई";
            return count + " file disimpan di File saya";
        }

        out = prefix(language, source, "Motor listo", "Engine ready", "Motor pronto", "इंजन तैयार", "Mesin siap");
        if (out != null) return out;
        if (!source.startsWith("Iniciando pagina ")) {
            out = prefix(language, source, "Iniciando ", "Starting ", "Iniciando ", "शुरू हो रहा है ", "Memulai ");
            if (out != null) return out;
        }
        out = prefix(language, source, "Error del motor de voz: ", "Voice engine error: ", "Erro do motor de voz: ", "वॉइस इंजन त्रुटि: ", "Kesalahan mesin suara: ");
        if (out != null) return out;
        out = prefix(language, source, "Error al preparar el audio rapido: ", "Error preparing fast audio: ", "Erro ao preparar áudio rápido: ", "तेज़ ऑडियो तैयार करने में त्रुटि: ", "Gagal menyiapkan audio cepat: ");
        if (out != null) return out;
        out = prefix(language, source, "Error del motor de voz (codigo ", "Voice engine error (code ", "Erro do motor de voz (código ", "वॉइस इंजन त्रुटि (कोड ", "Kesalahan mesin suara (kode ");
        if (out != null) return out;

        // Common service phrases with page numbers.
        out = prefix(language, source, "Preparando pagina ", "Preparing page ", "Preparando página ", "पृष्ठ तैयार हो रहा है ", "Menyiapkan halaman ");
        if (out != null) return out;
        out = prefix(language, source, "Iniciando pagina ", "Starting page ", "Iniciando página ", "पृष्ठ शुरू हो रहा है ", "Memulai halaman ");
        if (out != null) return out;
        out = prefix(language, source, "Reanudando pagina ", "Resuming page ", "Retomando página ", "पृष्ठ फिर शुरू हो रहा है ", "Melanjutkan halaman ");
        if (out != null) return out;
        out = prefix(language, source, "Continuando pagina ", "Continuing page ", "Continuando página ", "पृष्ठ जारी है ", "Melanjutkan halaman ");
        if (out != null) return out;
        out = prefix(language, source, "Completando pagina ", "Finishing page ", "Concluindo página ", "पृष्ठ पूरा हो रहा है ", "Menyelesaikan halaman ");
        if (out != null) return out;

        // Status combinations shown in notification.
        String translated = source;
        translated = translated.replace(" · Pausado", " · " + translate(language, "Pausado"));
        translated = translated.replace(" · Preparando", " · " + translate(language, "Preparando"));
        if (translated.contains(" · Leyendo · ")) {
            String reading = EN.equals(language) ? "Reading" : PT.equals(language) ? "Lendo" : HI.equals(language) ? "पढ़ रहा है" : "Membaca";
            translated = translated.replace(" · Leyendo · ", " · " + reading + " · ");
        }
        if (!translated.equals(source)) {
            if (translated.startsWith("Página ")) {
                translated = word(language, "Page", "Página", "पृष्ठ", "Halaman") + translated.substring("Página".length());
            }
            return translated;
        }

        return source;
    }

    private static int index(String language) {
        if (EN.equals(language)) return 1;
        if (PT.equals(language)) return 2;
        if (HI.equals(language)) return 3;
        if (ID.equals(language)) return 4;
        return 0;
    }

    private static String prefix(String language, String source, String es, String en, String pt, String hi, String id) {
        if (!source.startsWith(es)) return null;
        String[] values = new String[]{es, en, pt, hi, id};
        return values[index(language)] + source.substring(es.length());
    }

    private static String word(String language, String en, String pt, String hi, String id) {
        if (EN.equals(language)) return en;
        if (PT.equals(language)) return pt;
        if (HI.equals(language)) return hi;
        return id;
    }
}
