package com.tesoreria.caja.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tesoreria.caja.data.Caja
import com.tesoreria.caja.data.EstadoMiembro
import com.tesoreria.caja.data.Rol
import com.tesoreria.caja.data.Socio
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class Paso { SPLASH, NUMERO, CONFIRMAR, CLAVE, NUEVA_CLAVE }
private enum class Modo { USUARIO, ADMIN }

@Composable
fun PantallaLogin(alEntrar: (Socio) -> Unit) {
    var paso by remember { mutableStateOf(Paso.SPLASH) }
    var modo by remember { mutableStateOf(Modo.USUARIO) }
    var numero by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var clave2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var accesoCorrecto by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        delay(1250)
        paso = Paso.NUMERO
    }

    fun entrarConAnimacion(socio: Socio) {
        if (accesoCorrecto) return
        accesoCorrecto = true
        error = ""
        scope.launch {
            delay(850)
            alEntrar(socio)
        }
    }

    Box(Modifier.fillMaxSize().background(Fondo)) {
        FondoAnimado()

        AnimatedContent(
            targetState = paso,
            transitionSpec = {
                (fadeIn(tween(300)) + slideInVertically(tween(390)) { it / 12 }) togetherWith
                    (fadeOut(tween(210)) + slideOutVertically(tween(280)) { -it / 14 })
            },
            label = "loginFlow"
        ) { actual ->
            when (actual) {
                Paso.SPLASH -> SplashPremium()
                else -> LoginContenido(
                    paso = actual,
                    modo = modo,
                    numero = numero,
                    clave = clave,
                    clave2 = clave2,
                    error = error,
                    accesoCorrecto = accesoCorrecto,
                    cambiarModo = { modo = it; error = "" },
                    cambiarNumero = { numero = it.filter(Char::isDigit).take(2); error = "" },
                    cambiarClave = { clave = it; error = "" },
                    cambiarClave2 = { clave2 = it; error = "" },
                    volver = {
                        if (!accesoCorrecto) {
                            error = ""
                            clave = ""
                            clave2 = ""
                            paso = when (actual) {
                                Paso.CONFIRMAR -> Paso.NUMERO
                                Paso.CLAVE, Paso.NUEVA_CLAVE -> Paso.CONFIRMAR
                                else -> Paso.NUMERO
                            }
                        }
                    },
                    continuarNumero = {
                        val n = numero.toIntOrNull()
                        val socio = n?.let(Caja::socio)
                        when {
                            n == null || n !in 1..35 -> error = "Escribe un número válido del 1 al 35"
                            socio == null && n in 31..35 -> error = "Esa plaza está bloqueada hasta que el tesorero invite a alguien"
                            socio == null -> error = "Ese número no está registrado"
                            socio.estado == EstadoMiembro.BLOQUEADO -> error = "Esta cuenta está bloqueada. Habla con el tesorero."
                            socio.estado == EstadoMiembro.RETIRADO -> error = "Esta cuenta ya no está activa"
                            modo == Modo.ADMIN && socio.rol == Rol.SOCIO -> error = "Este acceso es solo para administración"
                            else -> paso = Paso.CONFIRMAR
                        }
                    },
                    confirmarIdentidad = {
                        val socio = numero.toIntOrNull()?.let(Caja::socio)
                        if (socio != null) {
                            paso = if (Caja.necesitaCrearClave(socio.numero)) Paso.NUEVA_CLAVE else Paso.CLAVE
                            error = ""
                        }
                    },
                    iniciar = {
                        val socio = numero.toIntOrNull()?.let(Caja::socio)
                        when {
                            socio == null -> error = "No se encontró la cuenta"
                            Caja.validar(socio.numero, clave) -> entrarConAnimacion(socio)
                            else -> error = "Contraseña incorrecta"
                        }
                    },
                    crear = {
                        val socio = numero.toIntOrNull()?.let(Caja::socio)
                        if (socio == null) error = "No se encontró la cuenta"
                        else {
                            val n = socio.numero
                            val esLiberacion = Caja.tieneClave(n)
                            when {
                                esLiberacion && !Caja.reseteoAbierto(n) -> error = "La autorización de 24 horas ya venció"
                                clave.length < 6 -> error = "Usa al menos 6 caracteres"
                                clave != clave2 -> error = "Las contraseñas no coinciden"
                                clave == n.toString() || clave == n.toString().padStart(2, '0') -> error = "No uses tu número de lista como contraseña"
                                else -> {
                                    Caja.crearClave(n, clave)
                                    entrarConAnimacion(socio)
                                }
                            }
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun SplashPremium() {
    val inf = rememberInfiniteTransition(label = "splash")
    val pulso by inf.animateFloat(0.95f, 1.045f, infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "pulse")
    val giro by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(5000, easing = LinearEasing)), label = "spin")
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(136.dp).scale(pulso), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().rotate(giro)) {
                drawArc(VerdeBrillante.copy(alpha = .55f), -20f, 185f, false, style = Stroke(width = 2.dp.toPx()))
                drawArc(VerdeNeon.copy(alpha = .28f), 190f, 110f, false, style = Stroke(width = 5.dp.toPx()))
            }
            Box(Modifier.size(88.dp).background(VerdeBrillante.copy(alpha = .08f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Shield, null, tint = VerdeBrillante, modifier = Modifier.size(52.dp))
            }
        }
        Spacer(Modifier.height(28.dp))
        Text("Tesorería", color = Texto, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(7.dp))
        Text("Control · Orden · Transparencia", color = Tenue, fontSize = 13.sp)
        Spacer(Modifier.height(42.dp))
        BarraCarga()
        Spacer(Modifier.height(11.dp))
        Text("Preparando tu acceso…", color = Tenue, fontSize = 11.sp)
    }
}

@Composable
private fun LoginContenido(
    paso: Paso,
    modo: Modo,
    numero: String,
    clave: String,
    clave2: String,
    error: String,
    accesoCorrecto: Boolean,
    cambiarModo: (Modo) -> Unit,
    cambiarNumero: (String) -> Unit,
    cambiarClave: (String) -> Unit,
    cambiarClave2: (String) -> Unit,
    volver: () -> Unit,
    continuarNumero: () -> Unit,
    confirmarIdentidad: () -> Unit,
    iniciar: () -> Unit,
    crear: () -> Unit
) {
    val socio = numero.toIntOrNull()?.let(Caja::socio)
    val shake = remember { Animatable(0f) }
    LaunchedEffect(error) {
        if (error.isNotBlank()) {
            repeat(3) {
                shake.animateTo(11f, tween(55))
                shake.animateTo(-11f, tween(55))
            }
            shake.animateTo(0f, tween(70))
        }
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (paso != Paso.NUMERO) {
            Row(Modifier.fillMaxWidth()) {
                Box(
                    Modifier.size(42.dp).background(Panel, CircleShape).border(1.dp, Borde, CircleShape).clickable(enabled = !accesoCorrecto) { volver() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.ArrowBack, null, tint = Texto, modifier = Modifier.size(20.dp)) }
            }
            Spacer(Modifier.height(10.dp))
        }

        NucleoSeguridad(paso, error.isNotBlank(), accesoCorrecto)
        Spacer(Modifier.height(14.dp))
        IndicadorPaso(paso, accesoCorrecto)
        Spacer(Modifier.height(18.dp))

        Box(Modifier.offset(x = shake.value.dp)) {
            when (paso) {
                Paso.NUMERO -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Bienvenido", color = Texto, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Inicia sesión para continuar", color = Tenue, fontSize = 13.sp)
                        Spacer(Modifier.height(22.dp))
                        SegmentedMode(modo, cambiarModo)
                        Spacer(Modifier.height(16.dp))
                        TarjetaPremium {
                            Etiqueta(if (modo == Modo.ADMIN) "ACCESO DE ADMINISTRACIÓN" else "ACCESO PERSONAL", VerdeBrillante)
                            Spacer(Modifier.height(10.dp))
                            Campo(numero, cambiarNumero, "Número de lista · Ej. 22", numerico = true)
                            Spacer(Modifier.height(14.dp))
                            Boton(if (modo == Modo.ADMIN) "Continuar como administrador  →" else "Continuar  →", Modifier.fillMaxWidth()) { continuarNumero() }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("Acceso local seguro para probar la aplicación", color = Tenue.copy(alpha = .72f), fontSize = 10.sp)
                    }
                }

                Paso.CONFIRMAR -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Confirma tu acceso", color = Texto, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(5.dp))
                        Text("Verifica los datos antes de continuar", color = Tenue, fontSize = 12.sp)
                        Spacer(Modifier.height(20.dp))
                        TarjetaPremium {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(50.dp).background(VerdeNeon.copy(alpha = .10f), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                                    Icon(if (modo == Modo.ADMIN) Icons.Rounded.AdminPanelSettings else Icons.Rounded.Shield, null, tint = VerdeBrillante)
                                }
                                Spacer(Modifier.width(13.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(socio?.nombre.orEmpty(), color = Texto, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(3.dp))
                                    Text("N.º ${socio?.numero ?: ""} · ${rolBonito(socio?.rol)}", color = Tenue, fontSize = 11.sp)
                                }
                            }
                            Spacer(Modifier.height(18.dp))
                            Boton("Sí, continuar  →", Modifier.fillMaxWidth()) { confirmarIdentidad() }
                            Spacer(Modifier.height(9.dp))
                            Boton("No, volver", Modifier.fillMaxWidth(), relleno = false, color = Tenue) { volver() }
                        }
                    }
                }

                Paso.CLAVE -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (accesoCorrecto) "Acceso concedido" else "Ingresa tu contraseña", color = Texto, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(5.dp))
                        Text("N.º ${socio?.numero} · ${socio?.nombre?.substringBefore(" ")}", color = Tenue, fontSize = 12.sp)
                        Spacer(Modifier.height(20.dp))
                        TarjetaPremium {
                            Campo(clave, cambiarClave, "Contraseña", clave = true)
                            Spacer(Modifier.height(14.dp))
                            Boton(if (accesoCorrecto) "✓ Acceso concedido" else "Iniciar sesión  →", Modifier.fillMaxWidth(), activo = !accesoCorrecto) { iniciar() }
                            Spacer(Modifier.height(12.dp))
                            Text("¿Olvidaste tu contraseña? Solicita una liberación al tesorero.", color = VerdeBrillante, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }

                Paso.NUEVA_CLAVE -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (accesoCorrecto) "Contraseña creada" else "Crea tu contraseña", color = Texto, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(5.dp))
                        Text("Será tu acceso personal", color = Tenue, fontSize = 12.sp)
                        Spacer(Modifier.height(20.dp))
                        TarjetaPremium {
                            Campo(clave, cambiarClave, "Nueva contraseña", clave = true)
                            Spacer(Modifier.height(10.dp))
                            Campo(clave2, cambiarClave2, "Confirmar contraseña", clave = true)
                            Spacer(Modifier.height(15.dp))
                            ReglaClave(clave.length >= 6, "Al menos 6 caracteres")
                            ReglaClave(clave != numero && clave != numero.padStart(2, '0'), "No uses tu número de lista")
                            ReglaClave(clave.isNotEmpty() && clave == clave2, "Ambas contraseñas coinciden")
                            Spacer(Modifier.height(15.dp))
                            Boton(if (accesoCorrecto) "✓ Listo" else "Crear contraseña  →", Modifier.fillMaxWidth(), activo = !accesoCorrecto) { crear() }
                        }
                    }
                }
                else -> Unit
            }
        }

        AnimatedVisibility(visible = error.isNotBlank() && !accesoCorrecto) {
            Box(
                Modifier.fillMaxWidth().padding(top = 13.dp).background(Rojo.copy(alpha = .10f), RoundedCornerShape(13.dp)).border(1.dp, Rojo.copy(alpha = .35f), RoundedCornerShape(13.dp)).padding(11.dp)
            ) { Text(error, color = Rojo, fontSize = 11.sp) }
        }

        if (paso == Paso.CLAVE && !accesoCorrecto) {
            Spacer(Modifier.height(15.dp))
            Text("Demo offline · contraseña inicial 123456", color = Tenue.copy(alpha = .62f), fontSize = 9.sp)
        }
    }
}

@Composable
private fun SegmentedMode(modo: Modo, cambiar: (Modo) -> Unit) {
    BoxWithConstraints(
        Modifier.fillMaxWidth().height(52.dp).background(Panel, RoundedCornerShape(17.dp)).border(1.dp, Borde, RoundedCornerShape(17.dp)).padding(4.dp)
    ) {
        val ancho = (maxWidth - 8.dp) / 2f
        val x by animateDpAsState(if (modo == Modo.USUARIO) 0.dp else ancho, tween(280, easing = FastOutSlowInEasing), label = "modoX")
        Box(
            Modifier.offset(x = x).width(ancho).fillMaxHeight().background(GradientePrincipal, RoundedCornerShape(14.dp))
        )
        Row(Modifier.fillMaxSize()) {
            ModoTexto("Usuario", modo == Modo.USUARIO, Modifier.weight(1f)) { cambiar(Modo.USUARIO) }
            ModoTexto("Administrador", modo == Modo.ADMIN, Modifier.weight(1f)) { cambiar(Modo.ADMIN) }
        }
    }
}

@Composable
private fun ModoTexto(texto: String, activo: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val color by animateColorAsState(if (activo) FondoProfundo else Tenue, label = "modoColor")
    Box(modifier.fillMaxHeight().clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(texto, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NucleoSeguridad(paso: Paso, error: Boolean, correcto: Boolean) {
    val inf = rememberInfiniteTransition(label = "securityCore")
    val giro by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(if (paso == Paso.CLAVE || paso == Paso.NUEVA_CLAVE) 3600 else 5600, easing = LinearEasing)), label = "coreSpin")
    val pulso by inf.animateFloat(.95f, 1.035f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "corePulse")
    val colorObjetivo = when {
        correcto -> Verde
        error -> Rojo
        paso == Paso.CONFIRMAR -> Cian
        else -> VerdeBrillante
    }
    val color by animateColorAsState(colorObjetivo, tween(220), label = "coreColor")
    var faseExito by remember { mutableIntStateOf(0) }
    LaunchedEffect(correcto) {
        faseExito = 0
        if (correcto) {
            faseExito = 1
            delay(260)
            faseExito = 2
        }
    }

    Box(Modifier.size(104.dp).scale(if (correcto) 1.06f else pulso), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().rotate(giro)) {
            drawArc(color.copy(alpha = .75f), -30f, if (correcto) 330f else 205f, false, style = Stroke(width = 2.4.dp.toPx()))
            drawArc(VerdeNeon.copy(alpha = if (correcto) .75f else .24f), 190f, 95f, false, style = Stroke(width = 5.dp.toPx()))
            for (i in 0..2) {
                drawCircle(color.copy(alpha = .12f - i * .025f), radius = size.minDimension * (.36f + i * .07f))
            }
        }
        Box(
            Modifier.size(68.dp).background(color.copy(alpha = .09f), CircleShape).border(1.dp, color.copy(alpha = .42f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            val estado = when {
                correcto && faseExito >= 2 -> 4
                correcto && faseExito == 1 -> 3
                error -> 2
                paso == Paso.CLAVE || paso == Paso.NUEVA_CLAVE -> 1
                else -> 0
            }
            AnimatedContent(targetState = estado, label = "coreIcon") { e ->
                val icon = when (e) {
                    4 -> Icons.Rounded.CheckCircle
                    3 -> Icons.Rounded.LockOpen
                    2 -> Icons.Rounded.Lock
                    1 -> Icons.Rounded.Lock
                    else -> Icons.Rounded.Shield
                }
                Icon(icon, null, tint = color, modifier = Modifier.size(if (e == 4) 36.dp else 32.dp))
            }
        }
    }
}

@Composable
private fun IndicadorPaso(paso: Paso, correcto: Boolean) {
    if (paso == Paso.NUMERO) return
    val actual = when (paso) {
        Paso.CONFIRMAR -> 1
        Paso.CLAVE, Paso.NUEVA_CLAVE -> 2
        else -> 0
    }
    Row(Modifier.width(110.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        repeat(3) { i ->
            val activo = correcto || i <= actual
            Box(
                Modifier.weight(1f).height(4.dp).background(if (activo) VerdeBrillante else Borde, RoundedCornerShape(99.dp))
            )
        }
    }
}

@Composable
private fun ReglaClave(ok: Boolean, texto: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
        Icon(Icons.Rounded.CheckCircle, null, tint = if (ok) Verde else Tenue.copy(alpha = .45f), modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(8.dp))
        Text(texto, color = if (ok) Texto else Tenue, fontSize = 11.sp)
    }
}

@Composable
private fun FondoAnimado() {
    val inf = rememberInfiniteTransition(label = "bg")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(8000, easing = LinearEasing), RepeatMode.Reverse), label = "t")
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawCircle(VerdeBrillante.copy(alpha = .035f), size.minDimension * .60f, center = androidx.compose.ui.geometry.Offset(w * (.82f - .08f * t), h * .13f))
        drawCircle(VerdeNeon.copy(alpha = .025f), size.minDimension * .46f, center = androidx.compose.ui.geometry.Offset(w * .06f, h * (.84f + .04f * t)))
        val paso = w / 7f
        for (i in 1..6) {
            drawLine(VerdeBrillante.copy(alpha = .018f), androidx.compose.ui.geometry.Offset(i * paso, 0f), androidx.compose.ui.geometry.Offset(i * paso, h), 1f)
        }
        for (i in 1..10) {
            val x = ((i * 83f) % w)
            val y = ((i * 137f + t * 90f) % h)
            drawCircle(VerdeBrillante.copy(alpha = .10f), 1.6.dp.toPx(), androidx.compose.ui.geometry.Offset(x, y))
        }
    }
}

@Composable
private fun BarraCarga() {
    val inf = rememberInfiniteTransition(label = "load")
    val p by inf.animateFloat(.15f, .82f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "progress")
    Box(Modifier.width(180.dp).height(5.dp).background(Borde.copy(alpha = .55f), RoundedCornerShape(9.dp))) {
        Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(GradientePrincipal, RoundedCornerShape(9.dp)))
    }
}

private fun rolBonito(rol: Rol?): String = when (rol) {
    Rol.TESORERO -> "Tesorero"
    Rol.PRESIDENTE -> "Presidente"
    else -> "Usuario"
}
