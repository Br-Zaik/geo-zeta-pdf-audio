# Geo Zeta PDF a Audio V80

Cambios principales:

- Se mantiene eliminada la caja de texto; cualquier caja antigua se convierte en subrayado simple.
- Gestos corregidos durante el marcado: un dedo inicia una marca solo cuando toca texto real; dos dedos permiten mover y ampliar la página con la herramienta activa; un dedo sobre espacio vacío desplaza la página.
- Se evita que un arrastre vertical para subir o bajar termine subrayando bloques completos del PDF.
- Color de las reglas configurable desde la pantalla principal: toque normal activa/desactiva y pulsación prolongada abre la paleta, incluida la opción de color personalizado.
- Nuevo marcador de lectura semitransparente que sigue la línea que el motor está leyendo. Puede activarse/desactivarse desde el botón superior y cambiarse de color con pulsación prolongada.
- El marcador de lectura y las reglas no se incluyen en imágenes ni PDF exportados.
- Guardar PDF marcado permite página actual, rango de páginas (por ejemplo 4 a 59) o documento completo.
- Galería, carpetas separadas, colores personalizados, audios, imágenes y PDF marcados se mantienen.
- Ajustes adicionales para reducir el inicio del audio: se elimina el calentamiento duplicado por cada Play, la primera frase se acorta y la verificación de inicio del motor se realiza antes.

Versión:
- versionCode: 80
- versionName: 80.0-reading-marker-gestures-rule-color-pdf-range
