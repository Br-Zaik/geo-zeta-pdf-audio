package com.geozeta.pdfaudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TtsForegroundService extends Service {
    public static final String ACTION_START = "com.geozeta.pdfaudio.START";
    public static final String ACTION_WARMUP = "com.geozeta.pdfaudio.WARMUP";
    public static final String ACTION_PREPARE = "com.geozeta.pdfaudio.PREPARE";
    public static final String ACTION_STOP = "com.geozeta.pdfaudio.STOP";
    public static final String ACTION_TOGGLE = "com.geozeta.pdfaudio.TOGGLE";
    public static final String ACTION_NEXT = "com.geozeta.pdfaudio.NEXT";
    public static final String ACTION_PREV = "com.geozeta.pdfaudio.PREV";
    public static final String ACTION_PAGE_CHANGED = "com.geozeta.pdfaudio.PAGE_CHANGED";

    public static final String EXTRA_PAGE = "page";
    public static final String EXTRA_ACTIVE = "active";
    public static final String EXTRA_PAUSED = "paused";
    public static final String EXTRA_STATE = "playback_state";
    public static final String EXTRA_MESSAGE = "playback_message";
    public static final String EXTRA_CHUNK_TEXT = "reading_chunk_text";
    public static final String EXTRA_CHUNK_INDEX = "reading_chunk_index";
    public static final String EXTRA_RANGE_START = "reading_range_start";
    public static final String EXTRA_RANGE_END = "reading_range_end";

    public static final int STATE_STOPPED = 0;
    public static final int STATE_PREPARING = 1;
    public static final int STATE_PLAYING = 2;
    public static final int STATE_PAUSED = 3;
    public static final int STATE_ERROR = 4;

    private static final String CHANNEL_ID = "pdf_audio_playback_v69";
    private static final int NOTIFICATION_ID = 69;
    private static final String PREFS_NAME = "pdf_audio_prefs";
    private static final String PREF_TTS_ACTIVE = "tts_service_active";
    private static final String PREF_TTS_PAUSED = "tts_service_paused";
    private static final String PREF_TTS_CURRENT_PAGE = "tts_current_page";
    private static final String PREF_TTS_STATE = "tts_service_state";
    private static final String PREF_TTS_MESSAGE = "tts_service_message";

    public interface PageProvider {
        void requestPageText(int page, PageTextCallback callback);
    }

    public interface PageTextCallback {
        void onText(String text);
    }

    private static final Map<Integer, String> PAGE_MAP =
            new ConcurrentHashMap<Integer, String>();
    private static volatile PageProvider pageProvider;

    public static void setPageProvider(PageProvider provider) {
        pageProvider = provider;
    }

    public static void clearPages() {
        PAGE_MAP.clear();
    }

    public static void addPage(String text) {
        PAGE_MAP.put(PAGE_MAP.size(), text == null ? "" : text);
    }

    public static void setPageText(int page, String text) {
        if (page >= 0) PAGE_MAP.put(page, text == null ? "" : text);
    }

    public static int pageCount() {
        return PAGE_MAP.size();
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TtsEngineManager engineManager;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private PowerManager.WakeLock wakeLock;

    private boolean reading;
    private boolean paused;
    private boolean waitingForProvider;
    private boolean foregroundStarted;
    private boolean currentUtteranceStarted;
    private boolean waitingForEngine;
    private int playbackState = STATE_STOPPED;
    private int sessionId;
    private int currentPageAbsolute;
    private int totalPages;
    private int currentChunkIndex;
    private int chunkRetryCount;
    private int engineRestartCount;
    private List<String> currentChunks = Collections.emptyList();
    private String activeUtteranceId;
    private String title = "PDF a Audio";
    private float rate = 1.0f;
    private float pitch = 1.0f;
    private Runnable providerTimeout;
    private Runnable utteranceTimeout;

    private final AudioManager.OnAudioFocusChangeListener focusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                @Override
                public void onAudioFocusChange(int focusChange) {
                    if (focusChange == AudioManager.AUDIOFOCUS_LOSS
                            && playbackState == STATE_PLAYING) {
                        pausePlayback();
                    }
                }
            };

    private final TtsEngineManager.UtteranceListener utteranceListener =
            new TtsEngineManager.UtteranceListener() {
                @Override
                public void onStart(final String utteranceId) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            cancelUtteranceTimeout();
                            currentUtteranceStarted = true;
                            chunkRetryCount = 0;
                            engineRestartCount = 0;
                            savePlaybackState(currentPageAbsolute, STATE_PLAYING,
                                    "Pagina " + (currentPageAbsolute + 1));
                            updateNotification("Pagina " + (currentPageAbsolute + 1)
                                    + " - " + String.format(Locale.US, "%.2fx", rate));
                            broadcastReadingRange(0, firstWordEnd(currentChunks.get(currentChunkIndex)));
                        }
                    });
                }

                @Override
                public void onDone(final String utteranceId) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            cancelUtteranceTimeout();
                            if (currentChunkIndex + 1 < currentChunks.size()) {
                                currentChunkIndex++;
                                speakCurrentChunk();
                                return;
                            }
                            currentPageAbsolute++;
                            currentChunkIndex = 0;
                            currentChunks = Collections.emptyList();
                            activeUtteranceId = null;
                            currentUtteranceStarted = false;
                            if (totalPages > 0 && currentPageAbsolute >= totalPages) {
                                finishPlayback();
                            } else {
                                savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                                        "Preparando pagina " + (currentPageAbsolute + 1));
                                speakAbsolutePage(currentPageAbsolute);
                            }
                        }
                    });
                }

                @Override
                public void onError(final String utteranceId, final int errorCode) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            cancelUtteranceTimeout();
                            if (chunkRetryCount < 1) {
                                chunkRetryCount++;
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (reading && !paused
                                                && isCurrentUtterance(utteranceId)) {
                                            speakCurrentChunk();
                                        }
                                    }
                                }, 300L);
                            } else {
                                restartEngineOrFail("Error del motor de voz (codigo "
                                        + errorCode + ")");
                            }
                        }
                    });
                }

                @Override
                public void onStop(String utteranceId, boolean interrupted) {
                    // Stop is expected during pause, page changes and queue replacement.
                }

                @Override
                public void onRangeStart(final String utteranceId, final int start, final int end) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            broadcastReadingRange(start, end);
                        }
                    });
                }
            };

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (powerManager != null) {
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    "GeoZetaPdfAudio:TtsWakeLockV69");
            wakeLock.setReferenceCounted(false);
        }
        engineManager = TtsEngineManager.getInstance(this);
        engineManager.addUtteranceListener(utteranceListener);
        engineManager.initialize(null);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_NOT_STICKY;
        String action = intent.getAction();

        if (ACTION_WARMUP.equals(action)) {
            engineManager.initialize(null);
            return START_NOT_STICKY;
        }
        if (ACTION_PREPARE.equals(action)) {
            prepareForNewPage(intent);
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action)) {
            startPlayback(intent);
        } else if (ACTION_TOGGLE.equals(action)) {
            if (playbackState == STATE_PAUSED) resumePlayback();
            else if (playbackState == STATE_PLAYING) pausePlayback();
        } else if (ACTION_NEXT.equals(action)) {
            jumpToPage(currentPageAbsolute + 1);
        } else if (ACTION_PREV.equals(action)) {
            jumpToPage(Math.max(0, currentPageAbsolute - 1));
        } else if (ACTION_STOP.equals(action)) {
            stopAll();
        }
        return START_NOT_STICKY;
    }

    private void prepareForNewPage(Intent intent) {
        sessionId++;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        waitingForProvider = false;
        waitingForEngine = false;
        reading = false;
        paused = false;
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        engineManager.stop();
        readCommonExtras(intent);
        ensureForeground("Preparando pagina " + (currentPageAbsolute + 1));
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Preparando pagina " + (currentPageAbsolute + 1));
    }

    private void startPlayback(Intent intent) {
        sessionId++;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        waitingForProvider = false;
        waitingForEngine = false;
        readCommonExtras(intent);
        currentPageAbsolute = Math.max(0, intent.getIntExtra("pageOffset", currentPageAbsolute)
                + Math.max(0, intent.getIntExtra("startIndex", 0)));
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        chunkRetryCount = 0;
        engineRestartCount = 0;
        reading = true;
        paused = false;
        // No detenemos el motor antes de cada Play. QUEUE_FLUSH reemplaza la cola
        // anterior y evita el costo de reiniciar la salida de voz.
        ensureForeground("Preparando pagina " + (currentPageAbsolute + 1));
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Preparando pagina " + (currentPageAbsolute + 1));
        startWhenEngineReady(sessionId);
    }

    private void startWhenEngineReady(final int requestSession) {
        if (engineManager.isReady()) {
            waitingForEngine = false;
            speakAbsolutePage(currentPageAbsolute);
            return;
        }
        if (waitingForEngine) return;
        waitingForEngine = true;
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Iniciando motor de voz");
        updateNotification("Iniciando motor de voz");
        engineManager.initialize(new TtsEngineManager.ReadyCallback() {
            @Override
            public void onReady(String enginePackage) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (requestSession == sessionId && reading && !paused) {
                            waitingForEngine = false;
                            speakAbsolutePage(currentPageAbsolute);
                        }
                    }
                });
            }

            @Override
            public void onError(final String message) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (requestSession == sessionId && reading && !paused) {
                            waitingForEngine = false;
                            failPlayback(message);
                        }
                    }
                });
            }
        });
    }

    private void readCommonExtras(Intent intent) {
        String extraTitle = intent.getStringExtra("title");
        if (extraTitle != null && extraTitle.trim().length() > 0) title = extraTitle;
        totalPages = Math.max(0, intent.getIntExtra("totalPages", totalPages));
        currentPageAbsolute = Math.max(0,
                intent.getIntExtra("pageOffset", currentPageAbsolute));
        rate = clampRate(intent.getFloatExtra("rate", rate));
        pitch = clampPitch(intent.getFloatExtra("pitch", pitch));
    }

    private void jumpToPage(int targetPage) {
        if (totalPages > 0) targetPage = Math.min(targetPage, totalPages - 1);
        sessionId++;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        engineManager.stop();
        currentPageAbsolute = Math.max(0, targetPage);
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        waitingForProvider = false;
        waitingForEngine = false;
        engineRestartCount = 0;
        reading = true;
        paused = false;
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Preparando pagina " + (currentPageAbsolute + 1));
        startWhenEngineReady(sessionId);
    }

    private void speakCurrentPageOrChunk() {
        if (!reading || paused) return;
        if (!currentChunks.isEmpty() && currentChunkIndex < currentChunks.size()) {
            speakCurrentChunk();
        } else {
            speakAbsolutePage(currentPageAbsolute);
        }
    }

    private void speakAbsolutePage(final int absolutePage) {
        if (!reading || paused) return;
        if (!engineManager.isReady()) {
            startWhenEngineReady(sessionId);
            return;
        }
        if (totalPages > 0 && absolutePage >= totalPages) {
            finishPlayback();
            return;
        }

        String stored = PAGE_MAP.get(absolutePage);
        if (stored != null) {
            speakTextForPage(absolutePage, stored);
            return;
        }
        requestPageFromProvider(absolutePage);
    }

    private void requestPageFromProvider(final int absolutePage) {
        if (!reading || paused || waitingForProvider) return;
        final PageProvider provider = pageProvider;
        if (provider == null) {
            failPlayback("La aplicacion no pudo obtener el texto de la pagina");
            return;
        }

        waitingForProvider = true;
        final int requestSession = sessionId;
        savePlaybackState(absolutePage, STATE_PREPARING,
                "Preparando pagina " + (absolutePage + 1));
        updateNotification("Preparando pagina " + (absolutePage + 1));

        providerTimeout = new Runnable() {
            @Override
            public void run() {
                if (requestSession == sessionId && waitingForProvider && reading && !paused) {
                    waitingForProvider = false;
                    failPlayback("El PDF tardo demasiado en entregar el texto");
                }
            }
        };
        handler.postDelayed(providerTimeout, 15000L);

        try {
            provider.requestPageText(absolutePage, new PageTextCallback() {
                @Override
                public void onText(final String text) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (requestSession != sessionId
                                    || absolutePage != currentPageAbsolute
                                    || !reading || paused) return;
                            cancelProviderTimeout();
                            waitingForProvider = false;
                            PAGE_MAP.put(absolutePage, text == null ? "" : text);
                            speakTextForPage(absolutePage, text);
                        }
                    });
                }
            });
        } catch (Exception ignored) {
            cancelProviderTimeout();
            waitingForProvider = false;
            failPlayback("No se pudo extraer el texto de la pagina");
        }
    }

    private void speakTextForPage(int absolutePage, String rawText) {
        if (!reading || paused || absolutePage != currentPageAbsolute) return;
        String text = cleanForTts(rawText);
        if (text.length() == 0) {
            currentPageAbsolute++;
            currentChunks = Collections.emptyList();
            currentChunkIndex = 0;
            if (totalPages > 0 && currentPageAbsolute >= totalPages) {
                finishPlayback();
            } else {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        speakAbsolutePage(currentPageAbsolute);
                    }
                });
            }
            return;
        }

        currentChunks = splitText(text);
        currentChunkIndex = 0;
        chunkRetryCount = 0;
        if (currentChunks.isEmpty()) {
            failPlayback("La pagina no contiene texto que el motor pueda leer");
            return;
        }
        speakCurrentChunk();
    }

    private void speakCurrentChunk() {
        if (!reading || paused) return;
        if (!engineManager.isReady()) {
            startWhenEngineReady(sessionId);
            return;
        }
        if (currentChunkIndex < 0 || currentChunkIndex >= currentChunks.size()) {
            failPlayback("El audio no pudo preparar el texto");
            return;
        }

        acquirePlaybackResources();
        engineManager.setSpeechRate(rate);
        engineManager.setPitch(pitch);

        final int requestSession = sessionId;
        final String utteranceId = "S" + requestSession + "_P" + currentPageAbsolute
                + "_C" + currentChunkIndex + "_R" + chunkRetryCount;
        activeUtteranceId = utteranceId;
        currentUtteranceStarted = false;

        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
        int result = engineManager.speak(currentChunks.get(currentChunkIndex),
                TextToSpeech.QUEUE_FLUSH, params, utteranceId);
        if (result == TextToSpeech.ERROR) {
            handleSpeakRejected(requestSession);
            return;
        }
        scheduleUtteranceCheck(requestSession, utteranceId);
    }

    private void scheduleUtteranceCheck(final int requestSession, final String utteranceId) {
        cancelUtteranceTimeout();
        utteranceTimeout = new Runnable() {
            @Override
            public void run() {
                if (requestSession != sessionId || !isCurrentUtterance(utteranceId)
                        || !reading || paused || currentUtteranceStarted) return;
                if (engineManager.isSpeaking()) {
                    currentUtteranceStarted = true;
                    savePlaybackState(currentPageAbsolute, STATE_PLAYING,
                            "Pagina " + (currentPageAbsolute + 1));
                    updateNotification("Pagina " + (currentPageAbsolute + 1)
                            + " - " + String.format(Locale.US, "%.2fx", rate));
                } else if (chunkRetryCount < 1) {
                    chunkRetryCount++;
                    speakCurrentChunk();
                } else {
                    restartEngineOrFail("El motor recibio el texto pero no inicio el audio");
                }
            }
        };
        handler.postDelayed(utteranceTimeout, 1800L);
    }

    private void handleSpeakRejected(final int requestSession) {
        if (requestSession != sessionId || !reading || paused) return;
        if (chunkRetryCount < 1) {
            chunkRetryCount++;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (requestSession == sessionId && reading && !paused) {
                        speakCurrentChunk();
                    }
                }
            }, 300L);
        } else {
            restartEngineOrFail("El motor de voz rechazo el texto");
        }
    }

    private void restartEngineOrFail(String finalMessage) {
        if (engineRestartCount < 1 && reading && !paused) {
            engineRestartCount++;
            chunkRetryCount = 0;
            waitingForEngine = false;
            currentUtteranceStarted = false;
            activeUtteranceId = null;
            cancelUtteranceTimeout();
            savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                    "Reiniciando motor de voz");
            updateNotification("Reiniciando motor de voz");
            engineManager.retryInitialization();
            startWhenEngineReady(sessionId);
        } else {
            failPlayback(finalMessage);
        }
    }

    private boolean isCurrentUtterance(String utteranceId) {
        return utteranceId != null && utteranceId.equals(activeUtteranceId);
    }

    private List<String> splitText(String text) {
        if (text == null || text.trim().length() == 0) return Collections.emptyList();
        int engineLimit = TextToSpeech.getMaxSpeechInputLength();
        int maxLength = Math.max(700, Math.min(2800, engineLimit - 300));
        ArrayList<String> chunks = new ArrayList<String>();
        String remaining = text.trim();

        // Arranque rapido: la primera orden contiene solo la primera frase o linea
        // util. Mientras se escucha, el resto de la pagina ya queda dividido en RAM.
        int fastStartMax = Math.min(72, maxLength);
        if (remaining.length() > fastStartMax) {
            int split = findFastStartSplitPoint(remaining, fastStartMax);
            String firstChunk = remaining.substring(0, split).trim();
            if (firstChunk.length() > 0) chunks.add(firstChunk);
            remaining = remaining.substring(split).trim();
        }

        // Los siguientes bloques siguen siendo grandes para conservar continuidad y
        // no introducir pausas innecesarias durante la lectura de la pagina.
        while (remaining.length() > maxLength) {
            int minimum = Math.max(1, (int) (maxLength * 0.55f));
            int split = findSplitPoint(remaining, minimum, maxLength);
            String chunk = remaining.substring(0, split).trim();
            if (chunk.length() > 0) chunks.add(chunk);
            remaining = remaining.substring(split).trim();
        }
        if (remaining.length() > 0) chunks.add(remaining);
        return chunks;
    }

    private int findFastStartSplitPoint(String value, int maximum) {
        int safeMaximum = Math.min(maximum, value.length());
        int minimum = Math.min(28, Math.max(1, safeMaximum / 4));

        // Se elige el primer cierre natural, no el ultimo, para soltar la voz antes.
        for (int i = minimum; i < safeMaximum; i++) {
            char c = value.charAt(i);
            if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':' || c == '\n') {
                return i + 1;
            }
        }
        for (int i = safeMaximum - 1; i >= minimum; i--) {
            if (Character.isWhitespace(value.charAt(i))) return i + 1;
        }
        return safeMaximum;
    }

    private int findSplitPoint(String value, int minimum, int maximum) {
        int safeMaximum = Math.min(maximum, value.length());
        for (int i = safeMaximum - 1; i >= minimum; i--) {
            char c = value.charAt(i);
            if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':' || c == '\n') {
                return i + 1;
            }
        }
        for (int i = safeMaximum - 1; i >= minimum; i--) {
            if (Character.isWhitespace(value.charAt(i))) return i + 1;
        }
        return safeMaximum;
    }

    private void pausePlayback() {
        if (playbackState != STATE_PLAYING) return;
        cancelUtteranceTimeout();
        reading = false;
        paused = true;
        engineManager.stop();
        savePlaybackState(currentPageAbsolute, STATE_PAUSED, "Pausado");
        updateNotification("Pausado");
        releaseAudioFocus();
        releaseWakeLock();
    }

    private void resumePlayback() {
        if (playbackState != STATE_PAUSED) return;
        reading = true;
        paused = false;
        chunkRetryCount = 0;
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Reanudando pagina " + (currentPageAbsolute + 1));
        speakCurrentPageOrChunk();
    }

    private void finishPlayback() {
        reading = false;
        paused = false;
        waitingForProvider = false;
        waitingForEngine = false;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        savePlaybackState(Math.max(0, currentPageAbsolute - 1), STATE_STOPPED,
                "Lectura finalizada");
        updateNotification("Lectura finalizada");
        releaseAudioFocus();
        releaseWakeLock();
        stopForeground(true);
        foregroundStarted = false;
        // El servicio queda caliente para que el siguiente Play no cree otra vez
        // el motor. Android puede liberarlo si necesita memoria.
    }

    private void stopAll() {
        sessionId++;
        reading = false;
        paused = false;
        waitingForProvider = false;
        waitingForEngine = false;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        engineManager.stop();
        savePlaybackState(currentPageAbsolute, STATE_STOPPED, "Detenido");
        releaseAudioFocus();
        releaseWakeLock();
        stopForeground(true);
        foregroundStarted = false;
        // Se conserva el servicio y el motor para el siguiente Play.
    }

    private void failPlayback(String message) {
        sessionId++;
        reading = false;
        paused = false;
        waitingForProvider = false;
        waitingForEngine = false;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        engineManager.stop();
        savePlaybackState(currentPageAbsolute, STATE_ERROR, message);
        if (foregroundStarted) updateNotification(message);
        releaseAudioFocus();
        releaseWakeLock();
        stopForeground(true);
        foregroundStarted = false;
        // Incluso tras un error, el administrador TTS permanece disponible.
    }

    private void cancelProviderTimeout() {
        if (providerTimeout != null) {
            handler.removeCallbacks(providerTimeout);
            providerTimeout = null;
        }
    }

    private void cancelUtteranceTimeout() {
        if (utteranceTimeout != null) {
            handler.removeCallbacks(utteranceTimeout);
            utteranceTimeout = null;
        }
    }

    private float clampRate(float value) {
        if (value < 0.5f) return 0.5f;
        if (value > 2.0f) return 2.0f;
        return value;
    }

    private float clampPitch(float value) {
        if (value < 0.5f) return 0.5f;
        if (value > 2.0f) return 2.0f;
        return value;
    }

    private String cleanForTts(String value) {
        if (value == null) return "";
        String text = value.replace('\u00A0', ' ');
        text = text.replace("\\r\\n", "\n");
        text = text.replace("\\n", "\n");
        text = text.replace("\\r", "\n");
        text = text.replace("/n", "\n");
        text = text.replace('\r', '\n');
        text = text.replaceAll("(?m)^\\s*[\\\\/]*[NnÑñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[A-ZÑ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[a-zñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[0-9]{1,4}\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[IVXLCDMivxlcdm]{1,8}\\s*$", "");
        text = text.replaceFirst("(?i)^(\\s*[nñ]\\s+){1,10}", "");
        text = text.replaceAll("(?i)(^|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-])[nñ](?=($|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-]))", "$1");
        text = text.replaceAll("(?iu)([a-záéíóúüñ])-\\s*\\n\\s*([a-záéíóúüñ])", "$1$2");
        text = text.replaceAll("[ \\t]{2,}", " ");
        text = text.replaceAll("\\n[ \\t]+", "\n");
        text = text.replaceAll("\\n{3,}", "\n\n");
        return text.trim();
    }


    private int firstWordEnd(String text) {
        if (text == null || text.length() == 0) return 1;
        int i = 0;
        while (i < text.length() && Character.isWhitespace(text.charAt(i))) i++;
        while (i < text.length() && !Character.isWhitespace(text.charAt(i))) i++;
        return Math.max(1, i);
    }

    private void broadcastReadingRange(int start, int end) {
        try {
            String chunk = (currentChunkIndex >= 0 && currentChunkIndex < currentChunks.size())
                    ? currentChunks.get(currentChunkIndex) : "";
            Intent update = new Intent(ACTION_PAGE_CHANGED);
            update.setPackage(getPackageName());
            update.putExtra(EXTRA_PAGE, currentPageAbsolute);
            update.putExtra(EXTRA_STATE, playbackState);
            update.putExtra(EXTRA_MESSAGE, "Pagina " + (currentPageAbsolute + 1));
            update.putExtra(EXTRA_CHUNK_TEXT, chunk);
            update.putExtra(EXTRA_CHUNK_INDEX, currentChunkIndex);
            update.putExtra(EXTRA_RANGE_START, Math.max(0, start));
            update.putExtra(EXTRA_RANGE_END, Math.max(start + 1, end));
            sendBroadcast(update);
        } catch (Exception ignored) {
        }
    }

    private void savePlaybackState(int page, int state, String message) {
        playbackState = state;
        boolean active = state == STATE_PREPARING || state == STATE_PLAYING
                || state == STATE_PAUSED;
        boolean isPaused = state == STATE_PAUSED;
        try {
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(PREF_TTS_ACTIVE, active)
                    .putBoolean(PREF_TTS_PAUSED, isPaused)
                    .putInt(PREF_TTS_CURRENT_PAGE, page)
                    .putInt(PREF_TTS_STATE, state)
                    .putString(PREF_TTS_MESSAGE, message == null ? "" : message)
                    .apply();
            Intent update = new Intent(ACTION_PAGE_CHANGED);
            update.setPackage(getPackageName());
            update.putExtra(EXTRA_PAGE, page);
            update.putExtra(EXTRA_ACTIVE, active);
            update.putExtra(EXTRA_PAUSED, isPaused);
            update.putExtra(EXTRA_STATE, state);
            update.putExtra(EXTRA_MESSAGE, message == null ? "" : message);
            sendBroadcast(update);
        } catch (Exception ignored) {
        }
    }

    private void ensureForeground(String text) {
        startForeground(NOTIFICATION_ID, buildNotification(text));
        foregroundStarted = true;
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        openIntent.putExtra("open_reading_page", true);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent prevPi = PendingIntent.getService(this, 1,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_PREV),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent togglePi = PendingIntent.getService(this, 2,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent nextPi = PendingIntent.getService(this, 3,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_NEXT),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stopPi = PendingIntent.getService(this, 4,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        boolean showPlay = playbackState == STATE_PAUSED;
        builder.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("PDF a Audio")
                .setContentText(text)
                .setSubText(title)
                .setContentIntent(openPi)
                .setOngoing(playbackState != STATE_STOPPED && playbackState != STATE_ERROR)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .addAction(android.R.drawable.ic_media_previous, "Anterior", prevPi)
                .addAction(showPlay ? android.R.drawable.ic_media_play
                                : android.R.drawable.ic_media_pause,
                        showPlay ? "Reanudar" : "Pausar", togglePi)
                .addAction(android.R.drawable.ic_media_next, "Siguiente", nextPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPi);
        if (Build.VERSION.SDK_INT >= 21) {
            builder.setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setCategory(Notification.CATEGORY_TRANSPORT)
                    .setColor(0xFF0B3C58)
                    .setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2));
        }
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        if (Build.VERSION.SDK_INT < 26) builder.setPriority(Notification.PRIORITY_DEFAULT);
        return builder.build();
    }

    private void updateNotification(String text) {
        if (!foregroundStarted) return;
        NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "PDF a Audio", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Lectura de PDF en segundo plano");
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.enableVibration(false);
            channel.setSound(null, null);
            NotificationManager manager =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void acquirePlaybackResources() {
        acquireAudioFocus();
        if (wakeLock != null && !wakeLock.isHeld()) {
            try { wakeLock.acquire(60 * 60 * 1000L); } catch (Exception ignored) {}
        }
    }

    private void acquireAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                if (audioFocusRequest == null) {
                    AudioAttributes attributes = new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build();
                    audioFocusRequest = new AudioFocusRequest.Builder(
                            AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(attributes)
                            .setOnAudioFocusChangeListener(focusChangeListener)
                            .setWillPauseWhenDucked(false)
                            .build();
                }
                audioManager.requestAudioFocus(audioFocusRequest);
            } else {
                audioManager.requestAudioFocus(focusChangeListener,
                        AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) {
                audioManager.abandonAudioFocusRequest(audioFocusRequest);
            } else {
                audioManager.abandonAudioFocus(focusChangeListener);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onDestroy() {
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        releaseAudioFocus();
        releaseWakeLock();
        if (engineManager != null) {
            engineManager.removeUtteranceListener(utteranceListener);
            engineManager.stop();
        }
        if (playbackState != STATE_STOPPED && playbackState != STATE_ERROR) {
            savePlaybackState(currentPageAbsolute, STATE_STOPPED, "Detenido");
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
