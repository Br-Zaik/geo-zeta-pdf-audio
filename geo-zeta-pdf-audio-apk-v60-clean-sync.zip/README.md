# Geo Zeta PDF a Audio V59 Cache Speed

Base:
- V58 Fluid Audio Cache.

Correcciones:
- Aumenta caché de audio:
  - prepara ventana grande de páginas alrededor de la página visible;
  - precalienta hasta 20 páginas siguientes al reproducir;
  - usa un documento PDF separado para la reproducción, para que Play no espere el caché general;
  - mantiene preparación de todo el PDF en segundo plano.
- Velocidades reales:
  - 0.75x;
  - 1.0x;
  - 1.25x;
  - 1.5x;
  - 1.75x;
  - 2.0x.
- La velocidad elegida se guarda.
- La velocidad se aplica al TextToSpeech y también al audio exportado.
- Si cambias velocidad mientras está reproduciendo, reinicia la lectura de la página actual con esa velocidad.

Mantiene:
- Audio continuo.
- Ajustes profesionales.
- Tema claro/oscuro.
- Subrayado fino debajo.
- Reglas.
- Guardar imagen PNG.
- Guardar audio WAV.
- Limpieza del “ene”.
- Notificación multimedia.
