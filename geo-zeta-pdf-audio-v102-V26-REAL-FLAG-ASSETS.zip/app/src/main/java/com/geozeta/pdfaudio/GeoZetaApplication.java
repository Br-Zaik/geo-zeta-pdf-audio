package com.geozeta.pdfaudio;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;

/**
 * Starts the process-wide TTS engine as early as possible.
 *
 * TtsEngineManager performs one silent pipeline prime when the selected engine
 * becomes ready. Keeping the warm-up in one place avoids two QUEUE_FLUSH primes
 * competing with the first real Play request.
 */
public class GeoZetaApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // No iniciar TextToSpeech dentro del tramo crítico de Application.onCreate.
        // Un pequeño retraso deja que la Activity pinte su primer frame y aun así
        // comienza a calentar la voz antes de que el usuario llegue a pulsar Play.
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                TtsEngineManager.getInstance(GeoZetaApplication.this).initialize(null);
            }
        }, 180L);
    }
}
