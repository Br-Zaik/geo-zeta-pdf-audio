# Geo Zeta PDF a Audio V58 Fluid Audio Cache

Base:
- V57 Audio Core Fix.

Objetivo:
- Audio fluido y continuo como función principal de la app.

Cambios:
- Al abrir PDF, empieza a preparar texto de todas las páginas en segundo plano.
- La preparación inicia desde la página visible y luego sigue con el resto.
- Al tocar Play, la página visible tiene prioridad máxima.
- Si saltas varias páginas y esa página ya está preparada, reproduce casi al toque.
- Si saltas a una página no preparada, esa página pasa a prioridad inmediata.
- Cuando reproduce una página, precalienta las 5 páginas siguientes.
- El servicio de audio pide automáticamente la siguiente página cuando termina la actual.
- Ya no depende de una cola corta que se acaba después de 2 páginas.
- Se pasa totalPages al servicio para terminar solo al final del PDF, no antes.

Mantiene:
- Ajustes profesionales.
- Tema claro/oscuro.
- Subrayado fino debajo.
- Reglas.
- Guardar imagen PNG.
- Guardar audio WAV.
- Limpieza del “ene”.
- Notificación multimedia.

Nota honesta:
- Si saltas a una página que jamás fue preparada, puede haber una pequeña espera por extracción de texto. La app intenta reducir eso preparando todo el PDF en segundo plano.
