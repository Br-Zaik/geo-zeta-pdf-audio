package com.geozeta.pdfaudio;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 55);
        }

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidTTS");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.evaluateJavascript("window.syncNativePage && window.syncNativePage();", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void clearNativePages() {
            TtsForegroundService.clearPages();
        }

        @JavascriptInterface
        public void addNativePage(String text) {
            TtsForegroundService.addPage(text == null ? "" : text);
        }

        @JavascriptInterface
        public int getNativePageCount() {
            return TtsForegroundService.getPageCount();
        }

        @JavascriptInterface
        public void startBackgroundRead(int startIndex, String title) {
            Intent i = new Intent(MainActivity.this, TtsForegroundService.class);
            i.setAction(TtsForegroundService.ACTION_START);
            i.putExtra("startIndex", startIndex);
            i.putExtra("title", title == null ? "PDF a Audio" : title);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        }

        @JavascriptInterface
        public void stopBackgroundRead() {
            Intent i = new Intent(MainActivity.this, TtsForegroundService.class);
            i.setAction(TtsForegroundService.ACTION_STOP);
            startService(i);
        }

        @JavascriptInterface
        public int getCurrentPage() {
            SharedPreferences prefs = getSharedPreferences(TtsForegroundService.PREFS, MODE_PRIVATE);
            return prefs.getInt("currentPage", 1);
        }

        @JavascriptInterface
        public boolean isReading() {
            SharedPreferences prefs = getSharedPreferences(TtsForegroundService.PREFS, MODE_PRIVATE);
            return prefs.getBoolean("isReading", false);
        }
    }
}
