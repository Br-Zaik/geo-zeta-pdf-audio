# Geo Zeta PDF a Audio V7

Correcciones:
- Ya no se regresa sola a página 1.
- Agrega Ir a página.
- Corrige reproducción en segundo plano preparando páginas en partes.
- Mantiene PDF grande, reproductor inferior, zoom y filtros.
