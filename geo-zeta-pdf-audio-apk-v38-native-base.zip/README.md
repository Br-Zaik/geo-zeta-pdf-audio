# Geo Zeta PDF a Audio V38 Native Base

Reconstrucción nativa, sin WebView y sin PDF.js.

Incluye:
- Android PdfRenderer para visor PDF.
- TextToSpeech separado para audio.
- Foreground Service para segundo plano.
- PDFBox Android para extraer texto.
- Zoom con dedos en vista nativa.
- Cambio de página sin detener audio.
- Recordar último PDF y página.

No incluye todavía:
- Subrayado.
- OCR.
- Exportar PNG.
- Modo estudio.
- Reglas arriba/abajo.
