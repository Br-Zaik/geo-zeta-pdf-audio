package com.geozeta.pdfaudio;

import android.content.Context; import android.os.*; import com.tom_roush.pdfbox.android.PDFBoxResourceLoader; import com.tom_roush.pdfbox.pdmodel.PDDocument; import com.tom_roush.pdfbox.text.PDFTextStripper; import java.io.File; import java.util.Map; import java.util.concurrent.*;
public class TextRepository { public interface TextCallback{void onText(String text);} private final ExecutorService executor=Executors.newSingleThreadExecutor(); private final Handler main=new Handler(Looper.getMainLooper()); private final Map<Integer,String> cache=new ConcurrentHashMap<>(); private PDDocument document;
    public TextRepository(Context c){PDFBoxResourceLoader.init(c);} public synchronized void open(File file){close();cache.clear();executor.execute(()->{try{PDDocument doc=PDDocument.load(file); synchronized(this){document=doc;}}catch(Exception ignored){}});} 
    public void getPageText(int page0,TextCallback cb){String cached=cache.get(page0); if(cached!=null){main.post(()->cb.onText(cached));return;} executor.execute(()->{String text=""; try{PDDocument doc; synchronized(this){doc=document;} if(doc!=null){PDFTextStripper s=new PDFTextStripper(); int p=page0+1; s.setStartPage(p); s.setEndPage(p); text=s.getText(doc); if(text==null)text=""; text=text.replaceAll("\\s+\\n","\\n").trim(); cache.put(page0,text);}}catch(Exception ignored){} String finalText=text; main.post(()->cb.onText(finalText));});}
    public void prefetch(int from,int count,int total){for(int i=0;i<count;i++){int p=from+i;if(p>=0&&p<total&&!cache.containsKey(p))getPageText(p,t->{});}}
    public synchronized void close(){try{if(document!=null)document.close();}catch(Exception ignored){} document=null;}
}
