package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.*;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.view.*;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfPageView extends View {
    public interface PageChangeListener { void onPageRendered(int pageIndex, int pageCount); void onError(String message); }
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final ExecutorService renderExecutor = Executors.newSingleThreadExecutor();
    private PdfRenderer renderer; private ParcelFileDescriptor fd; private Bitmap bitmap;
    private int pageIndex=0,pageCount=0,renderSerial=0,pendingPage=-1; private boolean renderBusy=false;
    private float zoom=1f, panX=0f, panY=0f; private PageChangeListener listener; private final Object lock=new Object();
    private final ScaleGestureDetector scaleDetector; private final GestureDetector gestureDetector;

    public PdfPageView(Context c){ super(c); setBackgroundColor(Color.rgb(238,238,238));
        scaleDetector=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            public boolean onScale(ScaleGestureDetector d){ float old=zoom; zoom=clamp(zoom*d.getScaleFactor(),1f,4.2f); float fx=d.getFocusX(), fy=d.getFocusY(); panX=fx-(fx-panX)*(zoom/old); panY=fy-(fy-panY)*(zoom/old); clampPan(); invalidate(); return true; }
            public void onScaleEnd(ScaleGestureDetector d){ requestRender(); }
        });
        gestureDetector=new GestureDetector(c,new GestureDetector.SimpleOnGestureListener(){
            public boolean onDoubleTap(MotionEvent e){ if(zoom>1.2f){zoom=1f;panX=0;panY=0;}else{zoom=2.2f;panX=e.getX()-e.getX()*zoom;panY=e.getY()-e.getY()*zoom;clampPan();} requestRender(); invalidate(); return true; }
            public boolean onScroll(MotionEvent e1,MotionEvent e2,float dx,float dy){ panX-=dx; panY-=dy; clampPan(); invalidate(); return true; }
        });
    }
    public void setPageChangeListener(PageChangeListener l){listener=l;} public int getPageCount(){return pageCount;} public int getPageIndex(){return pageIndex;}
    public void openFile(File f)throws IOException{ closeDocument(); fd=ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY); renderer=new PdfRenderer(fd); pageCount=renderer.getPageCount(); pageIndex=0; zoom=1f; panX=0; panY=0; requestRender(); }
    public void showPage(int i){ if(renderer==null||pageCount<=0)return; pageIndex=Math.max(0,Math.min(i,pageCount-1)); zoom=1f; panX=0; panY=0; requestRender(); }
    public void nextPage(){showPage(pageIndex+1);} public void previousPage(){showPage(pageIndex-1);} public void fitPage(){zoom=1f;panX=0;panY=0;requestRender();}
    private void requestRender(){ if(renderer==null||getWidth()<=0||getHeight()<=0)return; final int req=pageIndex; if(renderBusy){pendingPage=req;return;} renderBusy=true; final int serial=++renderSerial;
        renderExecutor.execute(()->{ Bitmap nb=null; try{ synchronized(lock){ if(renderer==null)return; PdfRenderer.Page page=renderer.openPage(req); int viewW=Math.max(320,getWidth()); float ratio=page.getHeight()/(float)page.getWidth(); int targetW=Math.round(viewW*zoom*1.55f); targetW=Math.max(viewW,Math.min(targetW,3600)); int targetH=Math.round(targetW*ratio); targetH=Math.max(1,Math.min(targetH,5200)); nb=Bitmap.createBitmap(targetW,targetH,Bitmap.Config.ARGB_8888); nb.eraseColor(Color.WHITE); page.render(nb,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); page.close(); }
            Bitmap finalB=nb; post(()->{ if(serial!=renderSerial){ if(finalB!=null&&!finalB.isRecycled())finalB.recycle(); return;} Bitmap old=bitmap; bitmap=finalB; if(old!=null&&!old.isRecycled())old.recycle(); clampPan(); invalidate(); if(listener!=null)listener.onPageRendered(pageIndex,pageCount); });
        }catch(Exception ex){ if(nb!=null&&!nb.isRecycled())nb.recycle(); post(()->{ if(listener!=null)listener.onError("Error al renderizar PDF"); }); }
        finally{ post(()->{ renderBusy=false; if(pendingPage>=0){ int p=pendingPage; pendingPage=-1; pageIndex=p; requestRender(); } }); }});
    }
    protected void onSizeChanged(int w,int h,int ow,int oh){super.onSizeChanged(w,h,ow,oh);requestRender();}
    protected void onDraw(Canvas c){super.onDraw(c); if(bitmap==null||bitmap.isRecycled()){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(Color.DKGRAY);p.setTextSize(42);p.setTextAlign(Paint.Align.CENTER);c.drawText("Abre un PDF",getWidth()/2f,getHeight()/2f,p);return;} float dw=getWidth()*zoom; float dh=dw*(bitmap.getHeight()/(float)bitmap.getWidth()); if(dw<=getWidth())panX=(getWidth()-dw)/2f; if(dh<=getHeight())panY=(getHeight()-dh)/2f; c.drawBitmap(bitmap,null,new RectF(panX,panY,panX+dw,panY+dh),paint);}
    public boolean onTouchEvent(MotionEvent e){ scaleDetector.onTouchEvent(e); if(!scaleDetector.isInProgress())gestureDetector.onTouchEvent(e); if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){clampPan();invalidate();} return true;}
    private void clampPan(){ if(bitmap==null)return; float dw=getWidth()*zoom; float dh=dw*(bitmap.getHeight()/(float)bitmap.getWidth()); panX=dw<=getWidth()?(getWidth()-dw)/2f:clamp(panX,getWidth()-dw,0); panY=dh<=getHeight()?(getHeight()-dh)/2f:clamp(panY,getHeight()-dh,0); }
    private float clamp(float v,float min,float max){return Math.max(min,Math.min(max,v));}
    public void closeDocument(){try{if(bitmap!=null&&!bitmap.isRecycled())bitmap.recycle();bitmap=null;if(renderer!=null)renderer.close();if(fd!=null)fd.close();}catch(Exception ignored){} renderer=null;fd=null;pageCount=0;pageIndex=0;}
}
