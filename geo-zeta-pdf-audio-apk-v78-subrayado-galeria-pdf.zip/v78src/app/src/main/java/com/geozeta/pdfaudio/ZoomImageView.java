package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

public class ZoomImageView extends ImageView {
    private static final float MIN_SCALE = 1.0f;
    private static final float MAX_SCALE = 5.0f;

    private final Matrix imageMatrixInternal = new Matrix();
    private final PointF last = new PointF();
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestureDetector;
    private float userScale = 1.0f;
    private boolean dragging;

    public ZoomImageView(Context context) {
        this(context, null);
    }

    public ZoomImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        super.setScaleType(ScaleType.MATRIX);

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float factor = detector.getScaleFactor();
                float next = Math.max(MIN_SCALE, Math.min(MAX_SCALE, userScale * factor));
                factor = next / userScale;
                userScale = next;
                imageMatrixInternal.postScale(factor, factor, detector.getFocusX(), detector.getFocusY());
                setImageMatrix(imageMatrixInternal);
                return true;
            }
        });

        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (userScale > 1.05f) {
                    resetZoom();
                } else {
                    float factor = 2.2f;
                    userScale = factor;
                    imageMatrixInternal.postScale(factor, factor, e.getX(), e.getY());
                    setImageMatrix(imageMatrixInternal);
                }
                return true;
            }
        });
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        post(new Runnable() {
            @Override
            public void run() {
                fitImageToView();
            }
        });
    }

    @Override
    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        post(new Runnable() {
            @Override
            public void run() {
                fitImageToView();
            }
        });
    }

    public void resetZoom() {
        fitImageToView();
    }

    private void fitImageToView() {
        Drawable drawable = getDrawable();
        if (drawable == null || getWidth() <= 0 || getHeight() <= 0) return;

        float drawableWidth = Math.max(1f, drawable.getIntrinsicWidth());
        float drawableHeight = Math.max(1f, drawable.getIntrinsicHeight());
        float availableWidth = Math.max(1f, getWidth() - getPaddingLeft() - getPaddingRight());
        float availableHeight = Math.max(1f, getHeight() - getPaddingTop() - getPaddingBottom());
        float fitScale = Math.min(availableWidth / drawableWidth, availableHeight / drawableHeight);
        float dx = getPaddingLeft() + (availableWidth - drawableWidth * fitScale) / 2f;
        float dy = getPaddingTop() + (availableHeight - drawableHeight * fitScale) / 2f;

        imageMatrixInternal.reset();
        imageMatrixInternal.postScale(fitScale, fitScale);
        imageMatrixInternal.postTranslate(dx, dy);
        userScale = 1.0f;
        setImageMatrix(imageMatrixInternal);
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        gestureDetector.onTouchEvent(event);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                last.set(event.getX(), event.getY());
                dragging = true;
                break;
            case MotionEvent.ACTION_MOVE:
                if (dragging && !scaleDetector.isInProgress() && userScale > 1.0f) {
                    float dx = event.getX() - last.x;
                    float dy = event.getY() - last.y;
                    imageMatrixInternal.postTranslate(dx, dy);
                    setImageMatrix(imageMatrixInternal);
                    last.set(event.getX(), event.getY());
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                break;
            default:
                break;
        }
        return true;
    }
}
