# Geo Zeta PDF a Audio V62 Fast Audio + Dual Mark

Base: V61 Page Notification Sync.

Mejoras de esta versión:
- Reproducción más rápida al pulsar Play.
- Agrupa solicitudes repetidas de texto de la misma página.
- Descarta preparaciones antiguas al cambiar rápidamente de página.
- Evita iniciar dos veces la extracción cuando el motor TTS termina de cargar.
- Reanudación directa desde el servicio de audio.
- Dos tipos de marcado: subrayado y resaltado.
- Color independiente para el subrayado y para el resaltado.
- Selección del tipo y ambos colores desde Ajustes.
- Los subrayados antiguos siguen siendo compatibles.

Mantiene:
- Audio continuo y con pantalla apagada.
- Sincronización de página y notificación.
- Reglas, zoom, tema claro/oscuro.
- Guardar imagen PNG y audio WAV.
