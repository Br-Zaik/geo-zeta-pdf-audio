# Geo Zeta PDF a Audio V11

Cambios:
- Quita zoom + y -.
- Zoom con dos dedos.
- Renderizado de PDF más nítido usando canvas HD.
- Reglas rojas movibles: solo lee el texto entre la regla superior e inferior.
- El área fuera de las reglas no se lee.
- Mantiene segundo plano, velocidad, voces básicas, logo, guardar PDF y última página.
