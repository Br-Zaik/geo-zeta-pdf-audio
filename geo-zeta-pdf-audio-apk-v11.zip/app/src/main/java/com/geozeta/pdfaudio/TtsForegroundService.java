package com.geozeta.pdfaudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.ArrayList;
import java.util.Locale;

public class TtsForegroundService extends Service {
    public static final String ACTION_START = "com.geozeta.pdfaudio.START";
    public static final String ACTION_STOP = "com.geozeta.pdfaudio.STOP";
    public static final String ACTION_NEXT = "com.geozeta.pdfaudio.NEXT";
    public static final String ACTION_PREV = "com.geozeta.pdfaudio.PREV";
    public static final String PREFS = "GeoZetaTtsPrefs";
    private static final String CHANNEL_ID = "pdf_audio_playback";
    private static final int NOTIFICATION_ID = 72;

    private static final ArrayList<String> PAGES = new ArrayList<>();
    public static synchronized void clearPages() { PAGES.clear(); }
    public static synchronized void addPage(String text) { PAGES.add(text == null ? "" : text); }
    public static synchronized int getPageCount() { return PAGES.size(); }

    private TextToSpeech tts;
    private boolean ready = false;
    private boolean reading = false;
    private int currentIndex = 0;
    private String title = "PDF a Audio";
    private float rate = 0.95f;
    private float pitch = 1.0f;
    private int pendingStart = -1;
    private String pendingTitle = null;
    private float pendingRate = 0.95f;
    private float pendingPitch = 1.0f;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("es", "PE"));
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(new Locale("es", "ES"));
                }
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id) {
                        if (!reading) return;
                        currentIndex++;
                        if (currentIndex < getPageCount()) speakCurrentPage();
                        else stopEverything();
                    }
                    @Override public void onError(String id) { stopEverything(); }
                });
                ready = true;
                if (pendingStart >= 0) {
                    startReading(pendingStart, pendingTitle, pendingRate, pendingPitch);
                    pendingStart = -1;
                }
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_STICKY;
        String action = intent.getAction();

        if (ACTION_START.equals(action)) {
            int start = intent.getIntExtra("startIndex", 0);
            String t = intent.getStringExtra("title");
            float r = intent.getFloatExtra("rate", 0.95f);
            float p = intent.getFloatExtra("pitch", 1.0f);
            if (!ready) {
                pendingStart = start; pendingTitle = t; pendingRate = r; pendingPitch = p;
                startForeground(NOTIFICATION_ID, buildNotification("Preparando audio...", start + 1));
            } else startReading(start, t, r, p);
        } else if (ACTION_STOP.equals(action)) stopEverything();
        else if (ACTION_NEXT.equals(action)) nextPage();
        else if (ACTION_PREV.equals(action)) prevPage();

        return START_STICKY;
    }

    private void startReading(int start, String incomingTitle, float incomingRate, float incomingPitch) {
        if (getPageCount() == 0) { stopEverything(); return; }
        currentIndex = Math.max(0, Math.min(start, getPageCount() - 1));
        title = incomingTitle == null || incomingTitle.trim().isEmpty() ? "PDF a Audio" : incomingTitle;
        rate = Math.max(0.55f, Math.min(2.0f, incomingRate));
        pitch = Math.max(0.55f, Math.min(1.8f, incomingPitch));
        reading = true;
        saveState();
        startForeground(NOTIFICATION_ID, buildNotification("Leyendo página " + (currentIndex + 1), currentIndex + 1));
        speakCurrentPage();
    }

    private synchronized String getPageText(int index) {
        if (index < 0 || index >= PAGES.size()) return "";
        return PAGES.get(index);
    }

    private void speakCurrentPage() {
        int count = getPageCount();
        if (!ready || count == 0 || currentIndex < 0 || currentIndex >= count) { stopEverything(); return; }
        saveState();
        updateNotification("Leyendo página " + (currentIndex + 1), currentIndex + 1);
        String text = getPageText(currentIndex);
        if (text == null || text.trim().isEmpty()) {
            currentIndex++;
            if (currentIndex < getPageCount()) speakCurrentPage();
            else stopEverything();
            return;
        }
        if (text.length() > 30000) text = text.substring(0, 30000);
        tts.stop();
        tts.setSpeechRate(rate);
        tts.setPitch(pitch);
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "PAGE_" + currentIndex);
    }

    private void nextPage() {
        if (getPageCount() == 0) return;
        currentIndex = Math.min(getPageCount() - 1, currentIndex + 1);
        reading = true;
        speakCurrentPage();
    }

    private void prevPage() {
        if (getPageCount() == 0) return;
        currentIndex = Math.max(0, currentIndex - 1);
        reading = true;
        speakCurrentPage();
    }

    private void stopEverything() {
        reading = false;
        saveState();
        if (tts != null) tts.stop();
        stopForeground(true);
        stopSelf();
    }

    private void saveState() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putInt("currentPage", currentIndex + 1)
            .putBoolean("isReading", reading)
            .putString("title", title)
            .apply();
    }

    private void updateNotification(String text, int page) {
        NotificationManager m = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (m != null) m.notify(NOTIFICATION_ID, buildNotification(text, page));
    }

    private Notification buildNotification(String text, int page) {
        PendingIntent openPi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stopPi = PendingIntent.getService(this, 1, new Intent(this, TtsForegroundService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent nextPi = PendingIntent.getService(this, 2, new Intent(this, TtsForegroundService.class).setAction(ACTION_NEXT), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent prevPi = PendingIntent.getService(this, 3, new Intent(this, TtsForegroundService.class).setAction(ACTION_PREV), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(text + " • " + String.format("%.1fx", rate))
            .setSubText("Página " + page)
            .setContentIntent(openPi)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_previous, "Anterior", prevPi)
            .addAction(android.R.drawable.ic_media_next, "Siguiente", nextPi)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPi);

        if (Build.VERSION.SDK_INT >= 21) b.setVisibility(Notification.VISIBILITY_PUBLIC);
        return b.build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "PDF a Audio", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Lectura de PDF a audio en segundo plano");
            NotificationManager m = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (m != null) m.createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
