# Geo Zeta - PDF a Voz y Audio

Lector de PDF para Android con lectura en voz alta (TTS), disponible en
cinco idiomas: espanol, ingles, portugues, hindi e indonesio.

## Funciones

- Lectura en voz alta de PDFs con el motor TTS del propio dispositivo
- Reproduccion en segundo plano con controles en la notificacion
- Zoom independiente por pagina (cada pagina recuerda el suyo)
- Subrayado y marcado de texto sobre la pagina
- Exportar cualquier pagina como imagen PNG
- Reglas de recorte para ignorar encabezados y pies de pagina
- Seleccion de voz, velocidad y region

## Estructura

- `MainActivity.java` - interfaz principal y control general
- `PdfPageView.java` - renderizado de paginas, zoom, marcado
- `TextRepository.java` - extraccion y cache de texto
- `SelectionTextRepository.java` - texto para seleccion manual
- `TtsForegroundService.java` - reproduccion de audio en segundo plano
- `ExportKeepAliveService.java` - crea el audio (Crear audio) en segundo plano: cola al motor, un solo archivo
- `AudioExportWriter.java` - une los trozos del motor en un unico M4A (AAC) sin clics; WAV de respaldo
- `TtsEngineManager.java` - gestion del motor de voz
- `UiStrings.java` - todos los textos en los cinco idiomas

## Compilacion

El proyecto compila por GitHub Actions (`.github/workflows/`), que genera:

- **APK debug** para instalar y probar directamente
- **AAB de release** firmado, listo para subir a Google Play

Para compilar en local hace falta crear un archivo `keystore.properties`
siguiendo el modelo de `keystore.properties.ejemplo`. Ese archivo y el
keystore nunca se suben al repositorio.

## Notas tecnicas

- `minSdk` 23, `targetSdk` 36
- PDFBox (`com.tom-roush:pdfbox-android`) para leer los PDF
- R8 activado en release; las reglas de `proguard-rules.pro` son
  necesarias para que PDFBox y BouncyCastle no fallen al ofuscar
- Los PDF se abren con el selector del sistema (SAF): no se piden
  permisos de almacenamiento

## Cambios V218

- Lectura sin huecos: el trozo o la pagina siguiente se encola en el motor
  (QUEUE_ADD) mientras suena el actual. El motor nunca queda parado, lo que
  evita que Honor/Huawei lo congelen con la pantalla apagada.
- Primer tramo de pagina mas corto (arranque de voz mas rapido) y precarga de
  dos paginas por delante.
- Sesion multimedia con metadatos y tipo mediaPlayback explicito.
- Ajustes > Lectura con pantalla apagada: guia y accesos directos a
  "Inicio de apps" y "Optimizacion de bateria" (se muestra sola una vez en
  Honor/Huawei).
- Crear audio: un solo archivo .m4a para todo el rango, sintesis en cola,
  uniones con fundido, estimacion de tiempo restante, sigue aunque se cierre
  la pantalla de la app. Pausa la lectura mientras se crea.
- Guardar imagen/PDF y demas trabajo pesado en hilos de prioridad de fondo
  (sin cortes en la voz mientras se guarda).
