package com.geozeta.pdfaudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import androidx.core.app.ServiceCompat;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * V218. Crea el audio de un PDF de principio a fin, en UN SOLO archivo.
 *
 * Antes la creacion vivia dentro de la pantalla (MainActivity) y este servicio
 * solo sostenia la notificacion. Eso tenia tres problemas:
 *   - cada pagina salia en un .wav aparte (un rango de 6 paginas = 6 archivos),
 *   - el motor recibia un trozo, lo terminaba, esperaba el aviso y recien ahi
 *     recibia el siguiente: el motor pasaba parte del tiempo parado,
 *   - si Android cerraba la pantalla de la app, la creacion moria a mitad.
 *
 * Ahora todo el trabajo esta aqui:
 *   - el texto de las paginas siguientes se va extrayendo por adelantado,
 *   - el motor siempre tiene varios trozos en cola (nunca espera a la app),
 *   - cada trozo terminado se agrega enseguida, en orden, a un unico archivo
 *     M4A (ver AudioExportWriter), con uniones limpias sin clics,
 *   - al final el archivo se publica en Musica / Geo Zeta.
 *
 * La velocidad maxima la pone el motor de voz del telefono: sintetiza de a un
 * trozo por vez y eso no depende de la app. Lo que si depende de la app (los
 * tiempos muertos entre trozos y entre paginas) se elimino.
 */
public class ExportKeepAliveService extends Service {

    // Ordenes
    public static final String ACTION_START_EXPORT = "com.geozeta.pdfaudio.EXPORT_START";
    public static final String ACTION_CANCEL_EXPORT = "com.geozeta.pdfaudio.EXPORT_CANCEL";
    /** Se conserva por compatibilidad: solo quita la notificacion si no hay trabajo. */
    public static final String ACTION_DISMISS = "com.geozeta.pdfaudio.EXPORT_DISMISS";

    // Aviso a la pantalla
    public static final String ACTION_EXPORT_STATUS = "com.geozeta.pdfaudio.EXPORT_STATUS";
    public static final String EXTRA_STATUS = "export_status";
    public static final String EXTRA_PERCENT = "percent";
    public static final String EXTRA_FILE_PATH = "file_path";
    public static final String EXTRA_PARTIAL = "partial";
    public static final int STATUS_RUNNING = 1;
    public static final int STATUS_DONE = 2;
    public static final int STATUS_FAILED = 3;
    public static final int STATUS_CANCELED = 4;

    // Datos de la orden
    public static final String EXTRA_START_PAGE = "start_page";
    public static final String EXTRA_END_PAGE = "end_page";
    public static final String EXTRA_OUTPUT_DIR = "output_dir";
    public static final String EXTRA_BASE_NAME = "base_name";
    public static final String EXTRA_LANGUAGE = "language";
    public static final String EXTRA_REGION = "region";
    public static final String EXTRA_RATE = "rate";
    public static final String EXTRA_ENGINE = "engine";
    public static final String EXTRA_IGNORE_RULES = "ignore_rules";

    public static final String CHANNEL_ID = "pdf_audio_export_v119";
    public static final int NOTIFICATION_ID = 7714;

    /** Trozos que el motor tiene en cola a la vez. Con esto nunca queda parado. */
    private static final int MAX_IN_FLIGHT = 3;
    /** Paginas cuyo texto se extrae por adelantado. */
    private static final int TEXT_LOOKAHEAD_PAGES = 3;
    /** Trozos grandes = menos idas y vueltas con el motor. */
    private static final int MAX_CHUNK_CHARS = 1800;
    private static final int GAP_BETWEEN_CHUNKS_MS = 230;
    private static final int GAP_BETWEEN_PAGES_MS = 520;
    private static final long WAKELOCK_MS = 30L * 60L * 1000L;
    private static final long WAKELOCK_RENEW_MS = 20L * 60L * 1000L;

    /**
     * Quien entrega el texto de cada pagina. Lo registra MainActivity con el
     * mismo repositorio que usa la lectura (respeta reglas y modo OCR). No
     * guarda la Activity, solo el repositorio, asi que sigue funcionando aunque
     * la pantalla se cierre.
     */
    public interface PageTextSource {
        void getPageText(int page, boolean ignoreRules, TextRepository.TextCallback callback);
    }

    private static volatile PageTextSource textSource;
    private static volatile boolean exportRunning;

    public static void setTextSource(PageTextSource source) {
        textSource = source;
    }

    public static boolean isExportRunning() {
        return exportRunning;
    }

    private static final class Segment {
        int page;
        String text;        // null = pagina sin texto (no se sintetiza)
        boolean pageEnd;
        File file;
        String utteranceId;
        boolean finished;
        boolean failed;
        int retries;
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ExecutorService writerExecutor;
    private PowerManager.WakeLock wakeLock;
    private boolean foregroundStarted;

    // Estado del trabajo (solo en el hilo principal)
    private int jobToken;
    private TextToSpeech tts;
    private boolean ttsReady;
    private int startPage;
    private int endPage;
    private int totalPages;
    private boolean ignoreRules;
    private String language = "";
    private String region = "";
    private String enginePackage = "";
    private float rate = 1.0f;
    private File outputDir;
    private String baseName = "pdf";
    private File partialFile;
    private AudioExportWriter writer;
    private boolean finishing;
    private boolean timedOut;

    private int nextFetchPage;
    private int fetchesInProgress;
    private int nextSegmentPage;
    private final Map<Integer, String> pageTexts = new HashMap<>();
    private final ArrayDeque<Segment> pending = new ArrayDeque<>();
    private final ArrayDeque<Segment> inFlight = new ArrayDeque<>();
    private final Map<String, Segment> byUtterance = new HashMap<>();
    /** Caracteres de cada pagina, para que la barra avance dentro de la pagina. */
    private final Map<Integer, Integer> pageChars = new HashMap<>();
    /** Paginas completas ya enviadas al archivo (en orden). */
    private int pagesDelivered;

    // Progreso
    private int pagesWritten;
    private int currentPageChars;
    private int currentPageWrittenChars;
    private int lastPageNotified = -1;
    private long startedAtMs;
    private int lastPercentShown = -1;
    private long lastNotifyMs;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_START_EXPORT.equals(action)) {
            // Primero la notificacion: Android exige primer plano en segundos.
            startForegroundSafely(buildProgressNotification(
                    t("Creando audio") + "  0%", t("Preparando voz..."), 0));
            if (exportRunning) {
                // Ya hay una creacion en marcha: no se pisan.
                return START_NOT_STICKY;
            }
            startJob(intent);
            return START_NOT_STICKY;
        }
        if (ACTION_CANCEL_EXPORT.equals(action)) {
            cancelJob(true);
            return START_NOT_STICKY;
        }
        // ACTION_DISMISS o una orden vacia.
        if (!exportRunning) stopEverything(true);
        return START_NOT_STICKY;
    }

    // ------------------------------------------------------------------
    // Arranque
    // ------------------------------------------------------------------

    private void startJob(Intent intent) {
        jobToken++;
        exportRunning = true;
        finishing = false;
        timedOut = false;
        startPage = Math.max(0, intent.getIntExtra(EXTRA_START_PAGE, 0));
        endPage = Math.max(startPage, intent.getIntExtra(EXTRA_END_PAGE, startPage));
        totalPages = endPage - startPage + 1;
        ignoreRules = intent.getBooleanExtra(EXTRA_IGNORE_RULES, false);
        language = safe(intent.getStringExtra(EXTRA_LANGUAGE));
        region = safe(intent.getStringExtra(EXTRA_REGION));
        enginePackage = safe(intent.getStringExtra(EXTRA_ENGINE));
        rate = intent.getFloatExtra(EXTRA_RATE, 1.0f);
        String dir = safe(intent.getStringExtra(EXTRA_OUTPUT_DIR));
        outputDir = dir.length() > 0 ? new File(dir) : getFilesDir();
        if (!outputDir.exists()) outputDir.mkdirs();
        baseName = safe(intent.getStringExtra(EXTRA_BASE_NAME));
        if (baseName.length() == 0) baseName = "pdf";

        nextFetchPage = startPage;
        nextSegmentPage = startPage;
        fetchesInProgress = 0;
        pageTexts.clear();
        pending.clear();
        inFlight.clear();
        byUtterance.clear();
        pageChars.clear();
        pagesDelivered = 0;
        pagesWritten = 0;
        currentPageChars = 0;
        currentPageWrittenChars = 0;
        lastPageNotified = -1;
        lastPercentShown = -1;
        lastNotifyMs = 0L;
        startedAtMs = SystemClock.elapsedRealtime();

        clearChunkDirectory();
        partialFile = new File(outputDir, "." + baseName + "_" + System.currentTimeMillis() + ".part");
        writer = new AudioExportWriter(partialFile, true);
        if (writerExecutor == null || writerExecutor.isShutdown()) {
            writerExecutor = Executors.newSingleThreadExecutor(r -> {
                Thread thread = new Thread(() -> {
                    // Fondo: el motor de voz (el cuello de botella) va primero.
                    android.os.Process.setThreadPriority(
                            android.os.Process.THREAD_PRIORITY_BACKGROUND);
                    r.run();
                }, "GeoZetaAudioWriter");
                return thread;
            });
        }
        acquireWakeLock();
        broadcastStatus(STATUS_RUNNING, 0, null, false);

        if (textSource == null) {
            failJob();
            return;
        }
        pumpTextFetch();
        createEngine();
    }

    private void createEngine() {
        final int token = jobToken;
        releaseEngine();
        TextToSpeech.OnInitListener listener = status -> handler.post(() -> {
            if (token != jobToken || !exportRunning) return;
            if (status != TextToSpeech.SUCCESS || tts == null) {
                failJob();
                return;
            }
            configureVoice();
            ttsReady = true;
            pump();
        });
        try {
            tts = enginePackage.length() > 0
                    ? new TextToSpeech(getApplicationContext(), listener, enginePackage)
                    : new TextToSpeech(getApplicationContext(), listener);
        } catch (Exception e) {
            tts = new TextToSpeech(getApplicationContext(), listener);
        }
    }

    /**
     * Mismo idioma y misma voz sin conexion que la lectura, con la velocidad
     * elegida. Una voz por internet haria cada trozo en un servidor: lentisimo.
     */
    private void configureVoice() {
        if (tts == null) return;
        String lang = language.length() > 0 ? language : "es";
        try {
            int result = tts.setLanguage(TtsEngineManager.localeForLanguage(lang, region));
            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(TtsEngineManager.localeForLanguage(lang, ""));
            }
        } catch (Exception ignored) {
        }
        try {
            TtsEngineManager.getInstance(this).applyOfflineVoice(tts, lang, region);
        } catch (Exception ignored) {
        }
        try { tts.setSpeechRate(rate); } catch (Exception ignored) { }

        final int token = jobToken;
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) { }

            @Override
            public void onDone(final String utteranceId) {
                handler.post(() -> {
                    if (token == jobToken) onSegmentFinished(utteranceId, true);
                });
            }

            @Override
            public void onError(final String utteranceId) {
                handler.post(() -> {
                    if (token == jobToken) onSegmentFinished(utteranceId, false);
                });
            }

            @Override
            public void onError(final String utteranceId, int errorCode) {
                handler.post(() -> {
                    if (token == jobToken) onSegmentFinished(utteranceId, false);
                });
            }
        });
    }

    // ------------------------------------------------------------------
    // Motor de la cola
    // ------------------------------------------------------------------

    private void pump() {
        if (!exportRunning || finishing) return;
        pumpTextFetch();

        // Texto listo -> trozos, siempre en el orden de las paginas.
        while (nextSegmentPage <= endPage && pageTexts.containsKey(nextSegmentPage)) {
            String raw = pageTexts.remove(nextSegmentPage);
            addSegmentsForPage(nextSegmentPage, raw);
            nextSegmentPage++;
            pumpTextFetch();
        }

        // El motor siempre con trabajo en cola.
        while (ttsReady && inFlight.size() < MAX_IN_FLIGHT && !pending.isEmpty()) {
            submit(pending.poll());
        }

        // Lo terminado se escribe en orden.
        deliverFinished();

        if (nextSegmentPage > endPage && pending.isEmpty() && inFlight.isEmpty()) {
            finishJob();
        }
    }

    private void pumpTextFetch() {
        final PageTextSource source = textSource;
        if (source == null) return;
        while (nextFetchPage <= endPage
                && nextFetchPage < nextSegmentPage + TEXT_LOOKAHEAD_PAGES
                && fetchesInProgress < 2) {
            final int page = nextFetchPage++;
            final int token = jobToken;
            fetchesInProgress++;
            try {
                source.getPageText(page, ignoreRules, text -> handler.post(() -> {
                    if (token != jobToken) return;
                    fetchesInProgress = Math.max(0, fetchesInProgress - 1);
                    pageTexts.put(page, text == null ? "" : text);
                    pump();
                }));
            } catch (Exception e) {
                fetchesInProgress = Math.max(0, fetchesInProgress - 1);
                pageTexts.put(page, "");
            }
        }
    }

    private void addSegmentsForPage(int page, String raw) {
        String clean = TtsForegroundService.cleanForTts(raw);
        ArrayList<String> chunks = splitText(clean);
        int total = 0;
        for (String chunk : chunks) total += chunk.length();
        pageChars.put(page, total);
        if (chunks.isEmpty()) {
            Segment empty = new Segment();
            empty.page = page;
            empty.text = null;
            empty.pageEnd = true;
            empty.finished = true;
            pending.add(empty);
            return;
        }
        for (int i = 0; i < chunks.size(); i++) {
            Segment segment = new Segment();
            segment.page = page;
            segment.text = chunks.get(i);
            segment.pageEnd = i == chunks.size() - 1;
            pending.add(segment);
        }
    }

    private void submit(Segment segment) {
        inFlight.add(segment);
        if (segment.text == null) {
            segment.finished = true;
            return;
        }
        synthesize(segment);
    }

    private void synthesize(Segment segment) {
        File dir = new File(getCacheDir(), "tts_export_chunks");
        if (!dir.exists()) dir.mkdirs();
        segment.file = new File(dir, "part_" + jobToken + "_" + segment.page + "_"
                + System.nanoTime() + ".wav");
        segment.utteranceId = "EXP_" + jobToken + "_" + segment.page + "_" + System.nanoTime();
        byUtterance.put(segment.utteranceId, segment);
        int result;
        try {
            result = tts.synthesizeToFile(segment.text, new Bundle(), segment.file,
                    segment.utteranceId);
        } catch (Exception e) {
            result = TextToSpeech.ERROR;
        }
        if (result != TextToSpeech.SUCCESS) {
            byUtterance.remove(segment.utteranceId);
            segment.failed = true;
            segment.finished = true;
        }
    }

    private void onSegmentFinished(String utteranceId, boolean success) {
        if (utteranceId == null) return;
        Segment segment = byUtterance.remove(utteranceId);
        if (segment == null || !exportRunning) return;
        if (!success) {
            deleteQuietly(segment.file);
            if (segment.retries < 1) {
                // Un reintento: el trozo vuelve a la cola del motor. El orden del
                // archivo final no cambia porque se escribe por orden de lista.
                segment.retries++;
                synthesize(segment);
                pump();
                return;
            }
            segment.failed = true;
        }
        segment.finished = true;
        pump();
    }

    private void deliverFinished() {
        while (!inFlight.isEmpty() && inFlight.peek().finished) {
            final Segment segment = inFlight.poll();
            if (segment.pageEnd) pagesDelivered++;
            final int token = jobToken;
            final AudioExportWriter target = writer;
            final int gap = segment.pageEnd ? GAP_BETWEEN_PAGES_MS : GAP_BETWEEN_CHUNKS_MS;
            final int chars = segment.text == null ? 0 : segment.text.length();
            final boolean usable = !segment.failed && segment.file != null;
            writerExecutor.execute(() -> {
                boolean writeError = false;
                try {
                    if (usable) target.appendWavPart(segment.file, gap);
                } catch (Exception e) {
                    writeError = true;
                }
                deleteQuietly(segment.file);
                final boolean error = writeError;
                handler.post(() -> {
                    if (token != jobToken) return;
                    if (error) {
                        failJob();
                        return;
                    }
                    onSegmentWritten(segment, chars);
                });
            });
        }
    }

    private void onSegmentWritten(Segment segment, int chars) {
        if (segment.page != lastPageNotified) {
            lastPageNotified = segment.page;
            currentPageWrittenChars = 0;
            Integer total = pageChars.get(segment.page);
            currentPageChars = total == null ? 0 : total;
        }
        currentPageWrittenChars += chars;
        if (segment.pageEnd) {
            pagesWritten++;
            pageChars.remove(segment.page);
            lastPageNotified = -1;
            currentPageWrittenChars = 0;
            currentPageChars = 0;
        }
        updateProgressNotification(false);
    }

    // ------------------------------------------------------------------
    // Final
    // ------------------------------------------------------------------

    private void finishJob() {
        if (finishing) return;
        finishing = true;
        final int token = jobToken;
        final AudioExportWriter target = writer;
        final File partial = partialFile;
        final boolean partialResult = timedOut;
        final int donePages = pagesDelivered;
        showNotification(buildProgressNotification(t("Creando audio") + "  100%",
                t("Guardando archivo..."), 100), true);
        writerExecutor.execute(() -> {
            File saved = null;
            try {
                if (target.finish()) {
                    String extension = target.isAac() ? ".m4a" : ".wav";
                    String suffix = startPage == endPage
                            ? "_pagina_" + (startPage + 1)
                            : "_P" + (startPage + 1) + "_a_"
                            + (partialResult ? (startPage + donePages) : (endPage + 1));
                    File finalFile = uniqueFile(outputDir, baseName + suffix, extension);
                    if (partial.renameTo(finalFile)) {
                        saved = finalFile;
                        publishAudioToDevice(finalFile, target.isAac()
                                ? "audio/mp4" : "audio/x-wav");
                    }
                }
            } catch (Exception ignored) {
            }
            if (saved == null) deleteQuietly(partial);
            final File result = saved;
            handler.post(() -> {
                if (token != jobToken) return;
                if (result == null) {
                    failJob();
                    return;
                }
                completeJob(result, partialResult);
            });
        });
    }

    private void completeJob(File saved, boolean partialResult) {
        exportRunning = false;
        releaseEngine();
        clearChunkDirectory();
        releaseWakeLock();
        detachForeground(false);
        String text = partialResult
                ? t("Guardado hasta la página") + " " + (startPage + pagesDelivered)
                : saved.getName();
        showNotification(buildFinishedNotification(t("Audio guardado"), text), false);
        broadcastStatus(STATUS_DONE, 100, saved.getAbsolutePath(), partialResult);
        stopSelf();
    }

    private void failJob() {
        if (!exportRunning) return;
        jobToken++;
        exportRunning = false;
        final AudioExportWriter target = writer;
        writer = null;
        stopEngineQuietly();
        releaseEngine();
        if (target != null && writerExecutor != null) writerExecutor.execute(target::abort);
        clearChunkDirectory();
        releaseWakeLock();
        detachForeground(true);
        showNotification(buildFinishedNotification(t("No se pudo crear el audio"), ""), false);
        broadcastStatus(STATUS_FAILED, 0, null, false);
        stopSelf();
    }

    private void cancelJob(boolean notifyScreen) {
        if (!exportRunning) {
            stopEverything(true);
            return;
        }
        jobToken++;
        exportRunning = false;
        final AudioExportWriter target = writer;
        writer = null;
        stopEngineQuietly();
        releaseEngine();
        if (target != null && writerExecutor != null) writerExecutor.execute(target::abort);
        clearChunkDirectory();
        if (notifyScreen) broadcastStatus(STATUS_CANCELED, 0, null, false);
        stopEverything(true);
    }

    /**
     * Android 15: un servicio de este tipo puede trabajar como mucho 6 horas
     * por dia en segundo plano. Si se llega al tope, se guarda lo que ya esta
     * hecho (no se pierde nada) y se cierra a tiempo.
     */
    @Override
    public void onTimeout(int startId, int fgsType) {
        if (!exportRunning || finishing) {
            stopEverything(false);
            return;
        }
        timedOut = true;
        stopEngineQuietly();
        pending.clear();
        // Lo ya terminado se escribe; lo que el motor tenia a medias se descarta.
        Iterator<Segment> it = inFlight.iterator();
        boolean keep = true;
        while (it.hasNext()) {
            Segment s = it.next();
            if (!keep || !s.finished) {
                keep = false;
                deleteQuietly(s.file);
                it.remove();
            }
        }
        nextSegmentPage = endPage + 1;
        nextFetchPage = endPage + 1;
        deliverFinished();
        finishJob();
    }

    // ------------------------------------------------------------------
    // Texto
    // ------------------------------------------------------------------

    private ArrayList<String> splitText(String source) {
        ArrayList<String> chunks = new ArrayList<>();
        if (source == null) return chunks;
        source = source.trim();
        if (source.length() == 0) return chunks;
        int engineLimit;
        try {
            engineLimit = TextToSpeech.getMaxSpeechInputLength();
        } catch (Exception e) {
            engineLimit = 4000;
        }
        int limit = Math.max(300, Math.min(MAX_CHUNK_CHARS, engineLimit - 64));
        int start = 0;
        while (start < source.length()) {
            int end = Math.min(source.length(), start + limit);
            if (end < source.length()) {
                int minimum = start + Math.max(80, limit / 2);
                int sentence = findBreak(source, minimum, end, true);
                int space = findBreak(source, minimum, end, false);
                if (sentence > start) end = sentence;
                else if (space > start) end = space;
            }
            if (end <= start) end = Math.min(source.length(), start + limit);
            String chunk = source.substring(start, end).trim();
            if (chunk.length() > 0) chunks.add(chunk);
            start = end;
            while (start < source.length() && Character.isWhitespace(source.charAt(start))) start++;
        }
        return chunks;
    }

    private int findBreak(String text, int minimum, int end, boolean sentenceOnly) {
        int lower = Math.max(0, minimum);
        for (int i = end - 1; i >= lower; i--) {
            char c = text.charAt(i);
            if (sentenceOnly) {
                if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':' || c == '\n') return i + 1;
            } else if (Character.isWhitespace(c) || c == ',') {
                return i + 1;
            }
        }
        return -1;
    }

    // ------------------------------------------------------------------
    // Notificacion y avisos
    // ------------------------------------------------------------------

    private int currentPercent() {
        if (totalPages <= 0) return 0;
        float within = currentPageChars > 0
                ? Math.min(1f, currentPageWrittenChars / (float) currentPageChars) : 0f;
        int percent = Math.round(100f * (pagesWritten + within) / totalPages);
        return Math.max(0, Math.min(99, percent));
    }

    private void updateProgressNotification(boolean force) {
        int percent = currentPercent();
        long now = SystemClock.elapsedRealtime();
        if (!force && percent == lastPercentShown && now - lastNotifyMs < 15000L) return;
        lastPercentShown = percent;
        lastNotifyMs = now;
        int pageNumber = Math.max(1, Math.min(totalPages, pagesWritten + 1));
        String detail = t("Página") + " " + pageNumber + " " + t("de") + " " + totalPages;
        String remaining = formatRemaining(percent, now);
        if (remaining.length() > 0) detail = detail + "  ·  " + remaining;
        showNotification(buildProgressNotification(
                t("Creando audio") + "  " + percent + "%", detail, percent), true);
        broadcastStatus(STATUS_RUNNING, percent, null, false);
        acquireWakeLock();
    }

    /** Tiempo restante aproximado, a partir de lo que tardo lo ya hecho. */
    private String formatRemaining(int percent, long now) {
        long elapsed = now - startedAtMs;
        if (percent < 2 || elapsed < 20000L) return "";
        long total = elapsed * 100L / Math.max(1, percent);
        long left = Math.max(0L, total - elapsed);
        long minutes = Math.max(1L, (left + 59999L) / 60000L);
        String value;
        if (minutes >= 60L) {
            value = (minutes / 60L) + " h " + (minutes % 60L) + " min";
        } else {
            value = minutes + " min";
        }
        return t("quedan") + " ~" + value;
    }

    private void broadcastStatus(int status, int percent, String path, boolean partial) {
        try {
            Intent update = new Intent(ACTION_EXPORT_STATUS);
            update.setPackage(getPackageName());
            update.putExtra(EXTRA_STATUS, status);
            update.putExtra(EXTRA_PERCENT, percent);
            update.putExtra(EXTRA_PARTIAL, partial);
            if (path != null) update.putExtra(EXTRA_FILE_PATH, path);
            sendBroadcast(update);
        } catch (Exception ignored) {
        }
    }

    private void startForegroundSafely(Notification notification) {
        if (foregroundStarted) {
            showNotification(notification, true);
            return;
        }
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification,
                    Build.VERSION.SDK_INT >= 29 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC : 0);
            foregroundStarted = true;
        } catch (Exception e) {
            // Si el sistema no deja pasar a primer plano, se sigue trabajando
            // mientras la app este abierta.
            showNotification(notification, true);
        }
    }

    private void showNotification(Notification notification, boolean ongoing) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        try { manager.notify(NOTIFICATION_ID, notification); } catch (Exception ignored) { }
    }

    private Notification buildProgressNotification(String title, String text, int percent) {
        Notification.Builder builder = baseBuilder(title, text);
        builder.setOngoing(true).setProgress(100, Math.max(0, Math.min(100, percent)), false);
        Intent cancelIntent = new Intent(this, ExportKeepAliveService.class);
        cancelIntent.setAction(ACTION_CANCEL_EXPORT);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent cancelPending = PendingIntent.getService(this, NOTIFICATION_ID,
                cancelIntent, flags);
        builder.addAction(R.drawable.ic_notification_close, t("Cancelar"), cancelPending);
        return builder.build();
    }

    private Notification buildFinishedNotification(String title, String text) {
        Notification.Builder builder = baseBuilder(title, text);
        builder.setOngoing(false).setAutoCancel(true);
        return builder.build();
    }

    private Notification.Builder baseBuilder(String title, String text) {
        createChannel();
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int openFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) openFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent openPending = PendingIntent.getActivity(this, 0, openIntent, openFlags);
        builder.setSmallIcon(R.drawable.ic_notification_blank)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(openPending)
                .setOnlyAlertOnce(true)
                .setShowWhen(false);
        if (Build.VERSION.SDK_INT >= 21) {
            builder.setVisibility(Notification.VISIBILITY_PUBLIC).setColor(0xFF08283A);
        }
        if (Build.VERSION.SDK_INT < 26) builder.setPriority(Notification.PRIORITY_LOW);
        return builder;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                t("Creación de audio"), NotificationManager.IMPORTANCE_LOW);
        channel.setDescription(t("Progreso al guardar el audio del PDF"));
        channel.setShowBadge(false);
        channel.enableVibration(false);
        channel.setSound(null, null);
        try { manager.createNotificationChannel(channel); } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------------
    // Recursos
    // ------------------------------------------------------------------

    private void stopEngineQuietly() {
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) { }
        }
    }

    private void releaseEngine() {
        ttsReady = false;
        if (tts != null) {
            try { tts.setOnUtteranceProgressListener(null); } catch (Exception ignored) { }
            try { tts.shutdown(); } catch (Exception ignored) { }
            tts = null;
        }
    }

    private void acquireWakeLock() {
        try {
            if (wakeLock == null) {
                PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
                if (power == null) return;
                wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoZeta:crearAudio");
                wakeLock.setReferenceCounted(false);
            }
            // Renovable: un PDF largo dura mas que cualquier tope fijo.
            wakeLock.acquire(WAKELOCK_MS);
            handler.removeCallbacks(wakeLockRenewal);
            handler.postDelayed(wakeLockRenewal, WAKELOCK_RENEW_MS);
        } catch (Exception ignored) {
        }
    }

    private final Runnable wakeLockRenewal = new Runnable() {
        @Override
        public void run() {
            if (exportRunning) acquireWakeLock();
        }
    };

    private void releaseWakeLock() {
        handler.removeCallbacks(wakeLockRenewal);
        if (wakeLock == null) return;
        try {
            if (wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {
        }
    }

    private void stopEverything(boolean removeNotification) {
        releaseWakeLock();
        detachForeground(removeNotification);
        if (removeNotification) {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) {
                try { manager.cancel(NOTIFICATION_ID); } catch (Exception ignored) { }
            }
        }
        stopSelf();
    }

    private void detachForeground(boolean removeNotification) {
        if (!foregroundStarted) return;
        foregroundStarted = false;
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                stopForeground(removeNotification
                        ? Service.STOP_FOREGROUND_REMOVE : Service.STOP_FOREGROUND_DETACH);
            } else {
                stopForeground(removeNotification);
            }
        } catch (Exception ignored) {
        }
    }

    private void clearChunkDirectory() {
        File dir = new File(getCacheDir(), "tts_export_chunks");
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File file : files) deleteQuietly(file);
    }

    private static void deleteQuietly(File file) {
        if (file == null) return;
        try { if (file.exists()) file.delete(); } catch (Exception ignored) { }
    }

    private static File uniqueFile(File dir, String baseName, String extension) {
        File candidate = new File(dir, baseName + extension);
        int counter = 2;
        while (candidate.exists() && counter < 999) {
            candidate = new File(dir, baseName + "_" + counter + extension);
            counter++;
        }
        return candidate;
    }

    /** Copia el audio a Musica / Geo Zeta para que lo vean otras apps. */
    private void publishAudioToDevice(File source, String mimeType) {
        if (source == null || !source.exists() || Build.VERSION.SDK_INT < 29) return;
        java.io.OutputStream output = null;
        java.io.InputStream input = null;
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, source.getName());
            values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_MUSIC + "/Geo Zeta");
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return;
            output = getContentResolver().openOutputStream(uri);
            if (output == null) return;
            input = new java.io.FileInputStream(source);
            byte[] buffer = new byte[65536];
            int read;
            while ((read = input.read(buffer)) > 0) output.write(buffer, 0, read);
            output.flush();
            output.close();
            output = null;
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, done, null, null);
        } catch (Exception ignored) {
        } finally {
            try { if (output != null) output.close(); } catch (Exception ignored) { }
            try { if (input != null) input.close(); } catch (Exception ignored) { }
        }
    }

    private String t(String text) {
        return UiStrings.translate(this, text);
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }

    @Override
    public void onDestroy() {
        if (exportRunning) {
            // Android cerro el servicio a mitad: se descarta el archivo a medias.
            jobToken++;
            exportRunning = false;
            final AudioExportWriter target = writer;
            writer = null;
            releaseEngine();
            if (target != null && writerExecutor != null) {
                try { writerExecutor.execute(target::abort); } catch (Exception ignored) { }
            }
        }
        releaseWakeLock();
        if (writerExecutor != null) writerExecutor.shutdown();
        super.onDestroy();
    }
}
