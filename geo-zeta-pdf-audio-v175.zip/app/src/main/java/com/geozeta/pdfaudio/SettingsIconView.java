package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/** Small consistent line icons for the Settings cards. */
public class SettingsIconView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private String iconType = "files";
    private int iconColor = Color.rgb(59, 130, 246);

    public SettingsIconView(Context context) {
        this(context, null);
    }

    public SettingsIconView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint.setColor(iconColor);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(dp(1.8f));
    }

    public void setIconType(String type) {
        iconType = type == null ? "files" : type;
        invalidate();
    }

    public void setIconColor(int color) {
        iconColor = color;
        paint.setColor(iconColor);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float s = Math.min(w, h) * 0.34f;
        paint.setStrokeWidth(Math.max(dp(1.5f), s * 0.11f));
        path.reset();
        paint.setColor(iconColor);

        if ("back".equals(iconType) || "left".equals(iconType)) {
            float nav = Math.min(w, h) * 0.48f;
            paint.setStrokeWidth(Math.max(dp(2.2f), nav * 0.13f));
            path.moveTo(cx + nav * 0.34f, cy - nav * 0.70f);
            path.lineTo(cx - nav * 0.36f, cy);
            path.lineTo(cx + nav * 0.34f, cy + nav * 0.70f);
            canvas.drawPath(path, paint);
            return;
        }

        if ("right".equals(iconType)) {
            float nav = Math.min(w, h) * 0.48f;
            paint.setStrokeWidth(Math.max(dp(2.2f), nav * 0.13f));
            path.moveTo(cx - nav * 0.34f, cy - nav * 0.70f);
            path.lineTo(cx + nav * 0.36f, cy);
            path.lineTo(cx - nav * 0.34f, cy + nav * 0.70f);
            canvas.drawPath(path, paint);
            return;
        }

        if ("undo".equals(iconType) || "redo".equals(iconType)) {
            // Simple history arrows: long straight shaft + clear arrow head.
            // Deliberately avoid circular arcs so they cannot look like rings.
            boolean redo = "redo".equals(iconType);
            float r = Math.min(w, h) * 0.34f;
            paint.setStrokeWidth(Math.max(dp(2.0f), r * 0.16f));

            if (redo) {
                canvas.drawLine(cx - r * 0.90f, cy, cx + r * 0.72f, cy, paint);
                path.reset();
                path.moveTo(cx + r * 0.72f, cy);
                path.lineTo(cx + r * 0.28f, cy - r * 0.42f);
                path.moveTo(cx + r * 0.72f, cy);
                path.lineTo(cx + r * 0.28f, cy + r * 0.42f);
                canvas.drawPath(path, paint);
            } else {
                canvas.drawLine(cx + r * 0.90f, cy, cx - r * 0.72f, cy, paint);
                path.reset();
                path.moveTo(cx - r * 0.72f, cy);
                path.lineTo(cx - r * 0.28f, cy - r * 0.42f);
                path.moveTo(cx - r * 0.72f, cy);
                path.lineTo(cx - r * 0.28f, cy + r * 0.42f);
                canvas.drawPath(path, paint);
            }
            return;
        }

        if ("tracking".equals(iconType)) {
            // Tres renglones con la linea del medio resaltada: es exactamente lo
            // que hace "Seguir lectura", y se lee mucho mejor que el ojo que
            // habia antes, que a tamano pequeno quedaba raro.
            Paint solid = new Paint(Paint.ANTI_ALIAS_FLAG);
            solid.setStyle(Paint.Style.FILL);
            solid.setColor(iconColor);

            float left = cx - s * 0.86f;
            paint.setStrokeWidth(Math.max(dp(1.4f), s * 0.11f));
            canvas.drawLine(left, cy - s * 0.66f, cx + s * 0.60f, cy - s * 0.66f, paint);
            canvas.drawLine(left, cy + s * 0.66f, cx + s * 0.34f, cy + s * 0.66f, paint);

            // Renglon activo: barra rellena, como el resaltado de la lectura.
            RectF active = new RectF(left, cy - s * 0.22f, cx + s * 0.86f, cy + s * 0.22f);
            canvas.drawRoundRect(active, s * 0.11f, s * 0.11f, solid);
            return;
        }

        if ("mark".equals(iconType)) {
            // Lapiz de verdad: cuerpo, banda de la contera y punta afilada que
            // acaba en pico. Antes era un simple paralelogramo con una raya
            // debajo y parecia una regla, no un lapiz.
            float ux = 0.70f, uy = -0.70f;   // eje del lapiz (hacia arriba-derecha)
            float vx = 0.70f, vy = 0.70f;    // ancho del lapiz
            float half = 0.26f;              // medio grosor
            float tailD = -0.86f;            // extremo de atras
            float bandD = -0.52f;            // banda de la contera
            float neckD = 0.34f;             // donde empieza la punta
            float tipD = 0.88f;              // pico

            float tailLX = cx + s * (ux * tailD - vx * half);
            float tailLY = cy + s * (uy * tailD - vy * half);
            float tailRX = cx + s * (ux * tailD + vx * half);
            float tailRY = cy + s * (uy * tailD + vy * half);
            float neckLX = cx + s * (ux * neckD - vx * half);
            float neckLY = cy + s * (uy * neckD - vy * half);
            float neckRX = cx + s * (ux * neckD + vx * half);
            float neckRY = cy + s * (uy * neckD + vy * half);
            float tipX = cx + s * ux * tipD;
            float tipY = cy + s * uy * tipD;

            path.reset();
            path.moveTo(tailLX, tailLY);
            path.lineTo(neckLX, neckLY);
            path.lineTo(tipX, tipY);
            path.lineTo(neckRX, neckRY);
            path.lineTo(tailRX, tailRY);
            path.close();
            canvas.drawPath(path, paint);

            // Banda de la contera y arranque de la punta.
            canvas.drawLine(cx + s * (ux * bandD - vx * half), cy + s * (uy * bandD - vy * half),
                    cx + s * (ux * bandD + vx * half), cy + s * (uy * bandD + vy * half), paint);
            canvas.drawLine(neckLX, neckLY, neckRX, neckRY, paint);

            // Trazo que va dejando el lapiz.
            canvas.drawLine(cx - s * 0.86f, cy + s * 0.88f, cx + s * 0.70f, cy + s * 0.88f, paint);
            return;
        }

        if ("thickness".equals(iconType)) {
            float left = cx - s * 0.78f;
            float right = cx + s * 0.78f;
            paint.setStrokeWidth(Math.max(dp(1.2f), s * 0.08f));
            canvas.drawLine(left, cy - s * 0.55f, right, cy - s * 0.55f, paint);
            paint.setStrokeWidth(Math.max(dp(2f), s * 0.16f));
            canvas.drawLine(left, cy, right, cy, paint);
            paint.setStrokeWidth(Math.max(dp(3f), s * 0.25f));
            canvas.drawLine(left, cy + s * 0.58f, right, cy + s * 0.58f, paint);
            return;
        }

        if ("voices".equals(iconType)) {
            // Cabeza de nota + ondas de sonido: pantalla "Voces".
            canvas.drawCircle(cx - s * 0.34f, cy + s * 0.46f, s * 0.30f, paint);
            canvas.drawLine(cx - s * 0.05f, cy + s * 0.46f, cx - s * 0.05f, cy - s * 0.72f, paint);
            canvas.drawLine(cx - s * 0.05f, cy - s * 0.72f, cx + s * 0.30f, cy - s * 0.56f, paint);
            RectF wave1 = new RectF(cx + s * 0.18f, cy - s * 0.46f, cx + s * 0.72f, cy + s * 0.30f);
            canvas.drawArc(wave1, -62f, 124f, false, paint);
            RectF wave2 = new RectF(cx + s * 0.34f, cy - s * 0.74f, cx + s * 1.06f, cy + s * 0.58f);
            canvas.drawArc(wave2, -58f, 116f, false, paint);
            return;
        }

        if ("engine".equals(iconType)) {
            // Altavoz: pantalla "Motor de voz".
            path.moveTo(cx - s * 0.20f, cy - s * 0.34f);
            path.lineTo(cx - s * 0.68f, cy - s * 0.34f);
            path.lineTo(cx - s * 0.68f, cy + s * 0.34f);
            path.lineTo(cx - s * 0.20f, cy + s * 0.34f);
            path.lineTo(cx + s * 0.24f, cy + s * 0.76f);
            path.lineTo(cx + s * 0.24f, cy - s * 0.76f);
            path.close();
            canvas.drawPath(path, paint);
            RectF sound1 = new RectF(cx + s * 0.18f, cy - s * 0.42f, cx + s * 0.66f, cy + s * 0.42f);
            canvas.drawArc(sound1, -64f, 128f, false, paint);
            RectF sound2 = new RectF(cx + s * 0.30f, cy - s * 0.70f, cx + s * 1.00f, cy + s * 0.70f);
            canvas.drawArc(sound2, -60f, 120f, false, paint);
            return;
        }

        if ("testvoice".equals(iconType)) {
            // Nota musical simple: "Probar voz".
            canvas.drawCircle(cx - s * 0.30f, cy + s * 0.50f, s * 0.31f, paint);
            canvas.drawLine(cx + s * 0.01f, cy + s * 0.50f, cx + s * 0.01f, cy - s * 0.76f, paint);
            path.moveTo(cx + s * 0.01f, cy - s * 0.76f);
            path.lineTo(cx + s * 0.62f, cy - s * 0.52f);
            path.lineTo(cx + s * 0.62f, cy - s * 0.16f);
            path.lineTo(cx + s * 0.01f, cy - s * 0.40f);
            canvas.drawPath(path, paint);
            return;
        }

        if ("speed".equals(iconType)) {
            // Reloj: "Velocidad".
            canvas.drawCircle(cx, cy, s * 0.80f, paint);
            canvas.drawLine(cx, cy - s * 0.44f, cx, cy, paint);
            canvas.drawLine(cx, cy, cx + s * 0.38f, cy + s * 0.20f, paint);
            return;
        }

        if ("colordot".equals(iconType)) {
            // Circulo con relleno suave: "Color del seguimiento".
            canvas.drawCircle(cx, cy, s * 0.74f, paint);
            Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(iconColor);
            canvas.drawCircle(cx, cy, s * 0.40f, fill);
            return;
        }

        if ("bookmark".equals(iconType)) {
            // Cinta de marcador: rectangulo con una muesca en V abajo.
            path.moveTo(cx - s * 0.58f, cy - s * 0.86f);
            path.lineTo(cx + s * 0.58f, cy - s * 0.86f);
            path.lineTo(cx + s * 0.58f, cy + s * 0.86f);
            path.lineTo(cx, cy + s * 0.34f);
            path.lineTo(cx - s * 0.58f, cy + s * 0.86f);
            path.close();
            canvas.drawPath(path, paint);
            return;
        }

        if ("files".equals(iconType)) {
            path.moveTo(cx - s * 0.88f, cy - s * 0.44f);
            path.lineTo(cx - s * 0.25f, cy - s * 0.44f);
            path.lineTo(cx - s * 0.03f, cy - s * 0.72f);
            path.lineTo(cx + s * 0.84f, cy - s * 0.72f);
            path.lineTo(cx + s * 0.84f, cy + s * 0.66f);
            path.lineTo(cx - s * 0.88f, cy + s * 0.66f);
            path.close();
            canvas.drawPath(path, paint);
            return;
        }

        if ("audio".equals(iconType)) {
            // Microfono centrado: representa mejor "Crear audio" que la nota
            // musical anterior, que quedaba descentrada y con dos circulos sueltos.
            float capsuleHalfWidth = s * 0.30f;
            RectF capsule = new RectF(cx - capsuleHalfWidth, cy - s * 0.86f,
                    cx + capsuleHalfWidth, cy + s * 0.16f);
            canvas.drawRoundRect(capsule, capsuleHalfWidth, capsuleHalfWidth, paint);

            RectF cradle = new RectF(cx - s * 0.58f, cy - s * 0.34f,
                    cx + s * 0.58f, cy + s * 0.50f);
            canvas.drawArc(cradle, 15f, 150f, false, paint);

            canvas.drawLine(cx, cy + s * 0.50f, cx, cy + s * 0.82f, paint);
            canvas.drawLine(cx - s * 0.34f, cy + s * 0.82f, cx + s * 0.34f, cy + s * 0.82f, paint);
            return;
        }

        if ("image".equals(iconType)) {
            RectF frame = new RectF(cx - s * 0.82f, cy - s * 0.66f, cx + s * 0.82f, cy + s * 0.66f);
            canvas.drawRoundRect(frame, s * 0.12f, s * 0.12f, paint);
            canvas.drawCircle(cx + s * 0.42f, cy - s * 0.30f, s * 0.13f, paint);
            path.moveTo(frame.left + s * 0.16f, frame.bottom - s * 0.12f);
            path.lineTo(cx - s * 0.20f, cy + s * 0.02f);
            path.lineTo(cx + s * 0.05f, cy + s * 0.28f);
            path.lineTo(cx + s * 0.28f, cy + s * 0.02f);
            path.lineTo(frame.right - s * 0.12f, frame.bottom - s * 0.12f);
            canvas.drawPath(path, paint);
            return;
        }

        if ("pdf".equals(iconType)) {
            RectF doc = new RectF(cx - s * 0.63f, cy - s * 0.82f, cx + s * 0.63f, cy + s * 0.82f);
            canvas.drawRoundRect(doc, s * 0.1f, s * 0.1f, paint);
            canvas.drawLine(cx - s * 0.36f, cy - s * 0.18f, cx + s * 0.36f, cy - s * 0.18f, paint);
            canvas.drawLine(cx - s * 0.36f, cy + s * 0.12f, cx + s * 0.36f, cy + s * 0.12f, paint);
            canvas.drawLine(cx - s * 0.36f, cy + s * 0.42f, cx + s * 0.16f, cy + s * 0.42f, paint);
            return;
        }

        if ("unlock".equals(iconType)) {
            // Candado abierto: es la imagen del cuadro de desbloqueo.
            RectF body = new RectF(cx - s * 0.58f, cy - s * 0.10f, cx + s * 0.58f, cy + s * 0.82f);
            canvas.drawRoundRect(body, s * 0.16f, s * 0.16f, paint);
            // Arco abierto hacia la derecha, levantado sobre el cuerpo.
            RectF shackle = new RectF(cx - s * 0.14f, cy - s * 0.86f, cx + s * 0.72f, cy - s * 0.06f);
            canvas.drawArc(shackle, 160f, 200f, false, paint);
            Paint solid = new Paint(Paint.ANTI_ALIAS_FLAG);
            solid.setStyle(Paint.Style.FILL);
            solid.setColor(iconColor);
            canvas.drawCircle(cx, cy + s * 0.32f, s * 0.13f, solid);
            return;
        }

        if ("rules".equals(iconType)) {
            // Dos guias horizontales con la pagina entre medias: "Color de las
            // reglas". Se distingue del icono de grosor, que son tres lineas.
            RectF page = new RectF(cx - s * 0.80f, cy - s * 0.88f, cx + s * 0.80f, cy + s * 0.88f);
            paint.setStrokeWidth(Math.max(dp(1.2f), s * 0.08f));
            canvas.drawRoundRect(page, s * 0.12f, s * 0.12f, paint);
            paint.setStrokeWidth(Math.max(dp(2.2f), s * 0.20f));
            canvas.drawLine(cx - s * 0.56f, cy - s * 0.40f, cx + s * 0.56f, cy - s * 0.40f, paint);
            canvas.drawLine(cx - s * 0.56f, cy + s * 0.40f, cx + s * 0.56f, cy + s * 0.40f, paint);
            return;
        }

        if ("gear".equals(iconType)) {
            // Rueda dentada real: un contorno cerrado que sube y baja entre el
            // radio del diente y el del valle. La version anterior era un
            // circulo con ocho rayos sueltos alrededor, que parecia un sol.
            int teeth = 8;
            float outer = s * 0.92f;
            float inner = s * 0.68f;
            float toothHalf = (float) (Math.PI / teeth) * 0.34f;
            float valleyHalf = (float) (Math.PI / teeth) * 0.62f;
            path.reset();
            for (int i = 0; i < teeth; i++) {
                double center = 2.0 * Math.PI * i / teeth;
                double a1 = center - toothHalf;
                double a2 = center + toothHalf;
                double a3 = center + valleyHalf;
                double a4 = center + 2.0 * Math.PI / teeth - valleyHalf;
                if (i == 0) {
                    path.moveTo(cx + (float) Math.cos(a1) * outer,
                            cy + (float) Math.sin(a1) * outer);
                } else {
                    path.lineTo(cx + (float) Math.cos(a1) * outer,
                            cy + (float) Math.sin(a1) * outer);
                }
                path.lineTo(cx + (float) Math.cos(a2) * outer,
                        cy + (float) Math.sin(a2) * outer);
                path.lineTo(cx + (float) Math.cos(a3) * inner,
                        cy + (float) Math.sin(a3) * inner);
                path.lineTo(cx + (float) Math.cos(a4) * inner,
                        cy + (float) Math.sin(a4) * inner);
            }
            path.close();
            canvas.drawPath(path, paint);
            // Agujero central, que es lo que remata la lectura de "engranaje".
            canvas.drawCircle(cx, cy, s * 0.30f, paint);
            return;
        }

        if ("eraser".equals(iconType)) {
            // Goma de borrar inclinada, con la banda que separa el bloque de
            // caucho del cuerpo y apoyada sobre la linea del papel. La version
            // anterior era un simple rombo y no se leia como goma.
            float ux = 0.80f, uy = -0.56f;   // eje largo de la goma
            float vx = 0.46f, vy = 0.66f;    // eje corto (grosor)
            float ox = cx - s * 0.34f, oy = cy + s * 0.06f;

            float aX = ox - s * ux * 0.62f - s * vx * 0.42f;
            float aY = oy - s * uy * 0.62f - s * vy * 0.42f;
            float bX = ox + s * ux * 0.98f - s * vx * 0.42f;
            float bY = oy + s * uy * 0.98f - s * vy * 0.42f;
            float cX = ox + s * ux * 0.98f + s * vx * 0.42f;
            float cY = oy + s * uy * 0.98f + s * vy * 0.42f;
            float dX = ox - s * ux * 0.62f + s * vx * 0.42f;
            float dY = oy - s * uy * 0.62f + s * vy * 0.42f;

            path.reset();
            path.moveTo(aX, aY);
            path.lineTo(bX, bY);
            path.lineTo(cX, cY);
            path.lineTo(dX, dY);
            path.close();
            canvas.drawPath(path, paint);

            // Banda entre el caucho (la punta que borra) y el resto del cuerpo.
            float tX = ox + s * ux * 0.16f, tY = oy + s * uy * 0.16f;
            canvas.drawLine(tX - s * vx * 0.42f, tY - s * vy * 0.42f,
                    tX + s * vx * 0.42f, tY + s * vy * 0.42f, paint);

            // Linea del papel debajo, para que se entienda que esta borrando.
            canvas.drawLine(cx - s * 0.88f, cy + s * 0.86f,
                    cx + s * 0.88f, cy + s * 0.86f, paint);
            return;
        }

        if ("play".equals(iconType)) {
            // Triangulo relleno: estado "reproducir".
            Paint solid = new Paint(Paint.ANTI_ALIAS_FLAG);
            solid.setStyle(Paint.Style.FILL);
            solid.setColor(iconColor);
            path.moveTo(cx - s * 0.52f, cy - s * 0.80f);
            path.lineTo(cx + s * 0.80f, cy);
            path.lineTo(cx - s * 0.52f, cy + s * 0.80f);
            path.close();
            canvas.drawPath(path, solid);
            return;
        }

        if ("pause".equals(iconType)) {
            // Dos barras rellenas: estado "pausar".
            Paint solid = new Paint(Paint.ANTI_ALIAS_FLAG);
            solid.setStyle(Paint.Style.FILL);
            solid.setColor(iconColor);
            RectF barA = new RectF(cx - s * 0.62f, cy - s * 0.78f, cx - s * 0.16f, cy + s * 0.78f);
            RectF barB = new RectF(cx + s * 0.16f, cy - s * 0.78f, cx + s * 0.62f, cy + s * 0.78f);
            canvas.drawRoundRect(barA, s * 0.10f, s * 0.10f, solid);
            canvas.drawRoundRect(barB, s * 0.10f, s * 0.10f, solid);
            return;
        }

        if ("star".equals(iconType) || "starfilled".equals(iconType)) {
            // Estrella de cinco puntas: "Guardar pagina".
            boolean filled = "starfilled".equals(iconType);
            path.reset();
            for (int i = 0; i < 10; i++) {
                double angle = -Math.PI / 2.0 + Math.PI * i / 5.0;
                float radius = (i % 2 == 0) ? s * 0.90f : s * 0.40f;
                float px = cx + (float) Math.cos(angle) * radius;
                float py = cy + (float) Math.sin(angle) * radius;
                if (i == 0) path.moveTo(px, py);
                else path.lineTo(px, py);
            }
            path.close();
            if (filled) {
                Paint solid = new Paint(Paint.ANTI_ALIAS_FLAG);
                solid.setStyle(Paint.Style.FILL);
                solid.setColor(iconColor);
                canvas.drawPath(path, solid);
            } else {
                canvas.drawPath(path, paint);
            }
            return;
        }

        canvas.drawCircle(cx, cy, s * 0.55f, paint);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
