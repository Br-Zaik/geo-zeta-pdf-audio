# Geo Zeta PDF a Audio V34 ZOOM SEGURO

Base:
- Hecha desde V33 SEGURA.
- No se toca motor de audio ni carga de PDF.

Cambio principal:
- Zoom con dos dedos usa vista previa ligera mientras acercas.
- Al soltar, renderiza una sola vez con más nitidez.
- Se evita que varios renderizados peleen entre sí.
- El subrayado ignora gestos de 2 dedos para evitar lag.
- Botón Nítido para re-renderizar.
- Botón Ajustar para volver al zoom normal.

Objetivo:
- Menos lag al acercar.
- Menos borrosidad después de soltar el zoom.
