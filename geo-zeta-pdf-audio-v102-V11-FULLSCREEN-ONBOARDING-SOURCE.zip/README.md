Geo Zeta PDF a Audio - V102

Cambios V102:
- Notificación siempre compacta: sin vista expandida grande.
- Caché persistente: el indexado completo se pausa durante interacción y continúa solo.
- Prioridad a página visible + anterior y 3 siguientes.
- Preferencia por voz española local/offline si el motor instalado ofrece una.
- Iconos deshacer/rehacer más claros.
