package com.geozeta.pdfaudio;

import android.app.Application;

/**
 * Starts the process-wide TTS engine as early as possible.
 *
 * TtsEngineManager performs one silent pipeline prime when the selected engine
 * becomes ready. Keeping the warm-up in one place avoids two QUEUE_FLUSH primes
 * competing with the first real Play request.
 */
public class GeoZetaApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        TtsEngineManager.getInstance(this).initialize(null);
    }
}
