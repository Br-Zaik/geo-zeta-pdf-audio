package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Horizontal hue selector used by the custom color dialog. */
public class HueSliderView extends View {
    public interface OnHueChangedListener {
        void onHueChanged(float hue);
    }

    private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indicatorOuterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indicatorInnerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Bitmap hueBitmap;
    private float hue = 0f;
    private OnHueChangedListener listener;

    public HueSliderView(Context context) {
        this(context, null);
    }

    public HueSliderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setClickable(true);

        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(1));
        borderPaint.setColor(Color.rgb(148, 163, 184));

        indicatorOuterPaint.setStyle(Paint.Style.STROKE);
        indicatorOuterPaint.setStrokeWidth(dp(3));
        indicatorOuterPaint.setColor(Color.WHITE);
        indicatorOuterPaint.setShadowLayer(dp(2), 0f, dp(1), 0x88000000);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        indicatorInnerPaint.setStyle(Paint.Style.STROKE);
        indicatorInnerPaint.setStrokeWidth(dp(1));
        indicatorInnerPaint.setColor(Color.rgb(15, 23, 42));
    }

    public void setOnHueChangedListener(OnHueChangedListener listener) {
        this.listener = listener;
    }

    public void setHue(float hueValue) {
        hue = normalizeHue(hueValue);
        invalidate();
    }

    public float getHue() {
        return hue;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        rebuildBitmap(w, h);
    }

    private void rebuildBitmap(int width, int height) {
        if (width <= 0 || height <= 0) return;
        if (hueBitmap != null && !hueBitmap.isRecycled()) hueBitmap.recycle();
        int bw = Math.max(180, Math.min(width, 720));
        int bh = Math.max(16, Math.min(height, 60));
        hueBitmap = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        int[] pixels = new int[bw * bh];
        for (int x = 0; x < bw; x++) {
            float hx = bw <= 1 ? 0f : (x / (float) (bw - 1)) * 360f;
            int color = Color.HSVToColor(new float[]{hx, 1f, 1f});
            for (int y = 0; y < bh; y++) pixels[y * bw + x] = color;
        }
        hueBitmap.setPixels(pixels, 0, bw, 0, 0, bw, bh);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        RectF dst = new RectF(0f, 0f, getWidth(), getHeight());
        if (hueBitmap != null && !hueBitmap.isRecycled()) {
            canvas.drawBitmap(hueBitmap, null, dst, bitmapPaint);
        }
        RectF border = new RectF(dp(0.5f), dp(0.5f), getWidth() - dp(0.5f), getHeight() - dp(0.5f));
        canvas.drawRoundRect(border, getHeight() / 2f, getHeight() / 2f, borderPaint);

        float x = (hue / 360f) * Math.max(1f, getWidth() - 1f);
        float radius = Math.max(dp(8), getHeight() * 0.38f);
        canvas.drawCircle(x, getHeight() / 2f, radius, indicatorOuterPaint);
        canvas.drawCircle(x, getHeight() / 2f, Math.max(dp(4), radius - dp(2)), indicatorInnerPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            float x = Math.max(0f, Math.min(event.getX(), Math.max(1f, getWidth() - 1f)));
            hue = (x / Math.max(1f, getWidth() - 1f)) * 360f;
            if (listener != null) listener.onHueChanged(hue);
            invalidate();
            return true;
        }
        return action == MotionEvent.ACTION_UP || super.onTouchEvent(event);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (hueBitmap != null && !hueBitmap.isRecycled()) {
            hueBitmap.recycle();
            hueBitmap = null;
        }
        super.onDetachedFromWindow();
    }

    private float normalizeHue(float value) {
        float result = value % 360f;
        if (result < 0f) result += 360f;
        return result;
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
