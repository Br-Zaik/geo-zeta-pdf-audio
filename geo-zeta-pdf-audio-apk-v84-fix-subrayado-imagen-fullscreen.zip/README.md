# Geo Zeta PDF a Audio - V94

Cambios de esta revision:
- Nombre del PDF desplazable manualmente en la barra superior.
- Eliminado el check redundante de Ajustes.
- Iconografia consistente en Seguimiento, Marcado y Archivos/Exportacion.
- Inicio de lectura prioriza solo la pagina visible; se elimino el indexado completo automatico.
- Precarga ligera de paginas cercanas en segundo plano.
- Selector de subrayado 4x4 con 4 espacios personalizados.
- Selector personalizado profesional: saturacion/brillo + barra de tono + muestra HEX.
- Mantiene las correcciones anteriores de navegacion de audio e imagen HD.
