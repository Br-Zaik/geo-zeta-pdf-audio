package com.geozeta.pdfaudio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.Settings;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import android.util.LruCache;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.GridLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.graphics.Typeface;
import android.widget.Toast;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.content.DialogInterface;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.text.TextUtils;
import android.text.Editable;
import android.text.TextWatcher;
import android.webkit.MimeTypeMap;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.text.SimpleDateFormat;
import java.text.Normalizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ConcurrentHashMap;

public class MainActivity extends Activity {
    private static final int REQ_OPEN_PDF = 1001;
    private static final String PREF_TTS_ACTIVE = "tts_service_active";
    private static final String PREF_TTS_PAUSED = "tts_service_paused";
    private static final String PREF_TTS_CURRENT_PAGE = "tts_current_page";
    private static final String PREF_TTS_STATE = "tts_service_state";
    private static final String PREF_TTS_MESSAGE = "tts_service_message";
    private static final String PREF_AUDIO_STATE_REPAIRED_V69 = "audio_state_repaired_v69";
    private static final String PREF_FAST_RESUME_DOC = "fast_resume_doc_v7";
    private static final String PREF_FAST_RESUME_PAGE = "fast_resume_page_v7";
    private static final String PREF_FAST_RESUME_TEXT = "fast_resume_text_v7";
    private static final String PREF_FAST_RESUME_RATE = "fast_resume_rate_v7";
    private static final String PREF_FAST_RESUME_ENGINE = "fast_resume_engine_v7";
    private static final String PREF_FAST_RESUME_LANGUAGE = "fast_resume_language_v28";
    private static final String PREF_PDF_LANGUAGE_PREFIX = "pdf_language_v28_";
    private static final String FAST_RESUME_FILE_NAME = "fast_resume_bridge.wav";
    private static final int FAST_RESUME_MIN_CHARS = 50;
    private static final int FAST_RESUME_TARGET_CHARS = 80;
    private static final String PREF_MARK_STYLE = "mark_style";
    private static final String PREF_MARK_STYLE_V72_MIGRATED = "mark_style_v72_migrated";
    private static final String PREF_MARK_COLORS_V72_MIGRATED = "mark_colors_v72_migrated";
    private static final String PREF_MARK_THICKNESS = "mark_thickness_level";
    private static final String PREF_UNDERLINE_COLOR = "underline_color_index";
    private static final String PREF_HIGHLIGHT_COLOR = "highlight_color_index";
    private static final String PREF_CUSTOM_UNDERLINE_COLOR = "custom_underline_color";
    private static final String PREF_CUSTOM_HIGHLIGHT_COLOR = "custom_highlight_color";
    private static final String PREF_USE_CUSTOM_UNDERLINE_COLOR = "use_custom_underline_color";
    private static final String PREF_USE_CUSTOM_HIGHLIGHT_COLOR = "use_custom_highlight_color";
    private static final String PREF_RULE_COLOR = "rule_color_index";
    private static final String PREF_CUSTOM_RULE_COLOR = "custom_rule_color";
    private static final String PREF_USE_CUSTOM_RULE_COLOR = "use_custom_rule_color";
    private static final String PREF_READING_MARKER_ENABLED = "reading_marker_enabled";
    private static final String PREF_READING_MARKER_COLOR = "reading_marker_color_index";
    private static final String PREF_CUSTOM_READING_MARKER_COLOR = "custom_reading_marker_color";
    private static final String PREF_USE_CUSTOM_READING_MARKER_COLOR = "use_custom_reading_marker_color";
    private static final String PREF_READING_MARKER_V81_RESET = "reading_marker_v81_reset";
    private static final String PREF_READING_BRIGHTNESS = "reading_brightness";
    private static final String PREF_IMAGE_LIBRARY_GRID = "image_library_grid";
    // Clave antigua (v156-v159). Se conserva solo para migrar desbloqueos existentes.
    private static final String PREF_ADVANCED_UNLOCK_UNTIL = "advanced_unlock_until_v156";
    // v160: reloj monotónico + respaldo de pared para que cambiar la hora manualmente
    // no regale tiempo extra. El BOOT_COUNT permite detectar reinicios reales.
    private static final String PREF_ADVANCED_UNLOCK_REMAINING_MS = "advanced_unlock_remaining_v160";
    private static final String PREF_ADVANCED_UNLOCK_ELAPSED_BASE_MS = "advanced_unlock_elapsed_base_v160";
    private static final String PREF_ADVANCED_UNLOCK_WALL_BASE_MS = "advanced_unlock_wall_base_v160";
    private static final String PREF_ADVANCED_UNLOCK_BOOT_COUNT = "advanced_unlock_boot_count_v160";
    private static final String PREF_LAST_READER_OCR_MODE = "last_reader_ocr_mode_v156";
    private static final String PREF_LAST_FILE_PATH = "last_file_path_v157";
    private static final String PREF_LAST_SOURCE_KEY = "last_source_key_v157";
    private static final String PREF_SOURCE_PAGE_PREFIX = "pdf_source_page_v157_";
    private static final String PDF_CACHE_DIR = "opened_pdf_cache";
    private static final int MAX_CACHED_PDFS = 6;
    private static final long ADVANCED_UNLOCK_DURATION_MS = 8L * 60L * 60L * 1000L;
    private static final int QUICK_MARK_SLOT_COUNT = 4;

    private static final int MARK_STYLE_UNDERLINE_FINE = 0;
    private static final int MARK_STYLE_UNDERLINE_DOUBLE = 1;
    private static final int MARK_STYLE_UNDERLINE_WAVY = 2;
    private static final int MARK_STYLE_UNDERLINE_DOTTED = 3;
    private static final int MARK_STYLE_HIGHLIGHT_SOFT = 4;
    private static final int MARK_STYLE_HIGHLIGHT_INTENSE = 5;
    private static final int MARK_STYLE_TEXT_BOX = 6;

    private static final int COLOR_TARGET_UNDERLINE = 0;
    private static final int COLOR_TARGET_HIGHLIGHT = 1;
    private static final int COLOR_TARGET_RULE = 2;
    private static final int COLOR_TARGET_READING_MARKER = 3;

    private static final int LIBRARY_AUDIO = 0;
    private static final int LIBRARY_IMAGE = 1;
    private static final int LIBRARY_PDF = 2;

    // Colores mostrados como muestras reales. Sus nombres no aparecen en la interfaz.
    private static final int[] MARK_COLOR_RGB = new int[]{
            0x00FFD400, 0x00EF4444, 0x00EC4899, 0x003B82F6,
            0x0022C55E, 0x00F97316, 0x00A855F7, 0x0006B6D4,
            0x0084CC16, 0x0092400E, 0x00111111, 0x00FFFFFF
    };

    private PdfPageView pdfView;
    private TextRepository textRepository;
    private TextRepository normalTextRepository;
    private OcrTextRepository ocrTextRepository;
    private boolean currentOcrMode;
    private SelectionTextRepository selectionRepository;
    private TextView titleView;
    private HorizontalScrollView titleScroller;
    private TextView pageView;
    private Button bookmarkButton;
    private Button playButton;
    private File currentFile;
    private String currentBookmarkKey;
    private String currentSourceKey = "";
    private String currentTitle;
    private int currentPage;
    private int pageCount;
    private boolean audioStarted;
    private boolean audioPaused;
    private boolean audioPreparing;
    private boolean markMode;
    private int markStyle;
    private int underlineColorIndex;
    private int highlightColorIndex;
    private int customUnderlineRgb;
    private int customHighlightRgb;
    private boolean useCustomUnderlineColor;
    private boolean useCustomHighlightColor;
    private int markThicknessLevel;
    private float readingBrightness;
    private LinearLayout markButton;
    private SettingsIconView markButtonIcon;
    private TextView markButtonLabel;
    private Button colorButton;
    private Button rulesButton;
    private TextView readingMarkerSettingsSwatch;
    private TextView ruleColorSettingsSwatch;
    private boolean rulesEnabled;
    private int ruleColorIndex;
    private int customRuleRgb;
    private boolean useCustomRuleColor;
    private boolean readingMarkerEnabled;
    private int readingMarkerColorIndex;
    private int customReadingMarkerRgb;
    private boolean useCustomReadingMarkerColor;
    private int pendingReadingPage = -1;
    private String pendingReadingChunk = "";
    private int pendingReadingChunkIndex = -1;
    private int pendingReadingRangeStart;
    private int pendingReadingRangeEnd;
    private int loadedSelectionPage = -1;
    private int loadingSelectionPage = -1;
    private float ruleTop;
    private float ruleBottom;
    private boolean restartAudioAfterRender;
    private int requestedAudioPage;
    private boolean requestedAudioPageConfirmed;
    private int audioRequestToken;
    private boolean darkTheme;
    private float speechRate;
    private boolean settingsMode;
    private int settingsSubscreen;
    private boolean settingsNeedsMainRebuild;
    private LinearLayout root;
    private FrameLayout screenHost;
    private View settingsOverlay;
    private View libraryOverlay;
    private View imageViewerOverlay;
    private View startupCoverView;
    /** Momento en que arranco la pantalla, para medir el tiempo de apertura. */
    private long startupClockStart;
    private boolean startupClockReported;
    /**
     * El cronometro solo vale si la app reabrio sola el ultimo PDF. En cuanto el
     * usuario interviene (abre el selector, elige otro archivo, cambia de
     * pagina) el numero deja de medir la app y pasa a medir cuanto tarda la
     * persona, que fue lo que dio aquel 113 s sin sentido.
     */
    private boolean startupClockValid;
    private Runnable startupCoverTimeout;
    /**
     * Trabajo pesado de un documento recien abierto (extraccion de texto con
     * PDFBox, coordenadas y encendido del motor de voz). Espera guardado aqui
     * hasta que la primera pagina este dibujada.
     */
    private Runnable deferredDocumentWork;
    private TextToSpeech exportTts;
    private boolean exportTtsReady;
    private SharedPreferences prefs;
    private ScrollView settingsScrollView;
    private int settingsScrollY;
    private int exportStartPage = -1;
    private int exportEndPage = -1;
    private int exportCurrentPage = -1;
    private int exportSavedCount;
    private File exportAudioDir;
    private String exportAudioBase;
    private File lastExportedAudioFile;
    private final ArrayList<String> activeExportChunks = new ArrayList<>();
    private final ArrayList<File> activeExportChunkFiles = new ArrayList<>();
    private int activeExportChunkIndex = -1;
    private int activeExportPage = -1;
    private File activeExportOutputFile;
    private String activeExportUtteranceId;
    private int audioExportSessionToken;
    private boolean libraryMode;
    private boolean imageLibraryGridMode;
    private boolean libraryReturnToSettings;
    private int libraryShowingType = LIBRARY_AUDIO;
    private boolean imageViewerMode;
    private Bitmap imageViewerBitmap;
    private ViewPager2 imagePager;
    private ImagePagerAdapter imagePagerAdapter;
    private MediaPlayer previewPlayer;
    private Handler previewHandler = new Handler(Looper.getMainLooper());
    private Runnable previewProgressTask;
    private final Handler readingMarkerHandler = new Handler(Looper.getMainLooper());
    private Runnable readingMarkerUpdateTask;
    private boolean readingMarkerUpdateScheduled;
    private Handler pageSyncHandler;
    private Runnable pageSyncRunnable;
    private BroadcastReceiver playbackReceiver;
    private boolean receiverRegistered;
    private BroadcastReceiver exportCancelReceiver;
    private boolean exportCancelReceiverRegistered;
    private boolean notificationWarningShown;
    /** El usuario cambio de pagina a mano estando en pausa. */
    private boolean userBrowsedAwayWhilePaused;
    private boolean notificationPermissionAsked;
    private boolean notificationPermissionDeniedForever;
    private boolean notificationSettingsDialogShown;
    private final Handler audioStartHandler = new Handler(Looper.getMainLooper());
    private final Handler advancedAccessHandler = new Handler(Looper.getMainLooper());
    private Runnable advancedAccessExpiryRunnable;
    private Runnable audioNeighborPreloadRunnable;
    private Runnable audioIdleIndexRunnable;
    private Runnable ttsWarmupRunnable;
    private final Handler pageWorkHandler = new Handler(Looper.getMainLooper());
    private Runnable pageWorkRunnable;
    private int pageWorkToken;
    private final ExecutorService imageExportExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService audioExportExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService imageDecodeExecutor = Executors.newFixedThreadPool(2);
    private final ExecutorService libraryScanExecutor = Executors.newSingleThreadExecutor();
    private int libraryLoadToken;
    // Resultado del ultimo escaneo de carpetas. Cambiar de pestana
    // (Audios/Imagenes/PDF) reutiliza esto y pinta al instante, sin volver a
    // recorrer el disco ni mostrar el aviso de "Buscando archivos...".
    private ArrayList<File> cachedLibraryAudio;
    private ArrayList<File> cachedLibraryImages;
    private ArrayList<File> cachedLibraryPdf;
    private boolean libraryCacheValid;
    // Mis archivos se mantiene como una sola capa viva. Cambiar de pestana solo
    // reemplaza el contenido interno; nunca se quita la capa entre dos toques.
    private LinearLayout libraryScreenView;
    private LinearLayout libraryListView;
    private ScrollView libraryScrollView;
    private Button libraryAudioTab;
    private Button libraryImageTab;
    private Button libraryPdfTab;
    private Button libraryActionButton;
    private boolean libraryScanInFlight;
    private final ExecutorService audioMetadataExecutor = Executors.newFixedThreadPool(2);
    private final ConcurrentHashMap<String, String> audioDurationCache = new ConcurrentHashMap<String, String>();
    // Las miniaturas de la pestaña Imágenes se decodifican fuera del hilo UI.
    // Antes cada PNG/JPG se abría de forma síncrona al tocar la pestaña y eso
    // provocaba el tirón brusco que no existía en Audios/PDF.
    private final HashSet<String> libraryThumbnailDecodeInFlight = new HashSet<String>();
    private Runnable playPreparingDotsRunnable;
    private final ExecutorService languageDetectionExecutor = Executors.newFixedThreadPool(2);
    private final LruCache<String, Bitmap> imageViewerCache = new LruCache<String, Bitmap>(48 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            if (value == null) return 0;
            return Math.max(1, value.getByteCount() / 1024);
        }
    };
    private final LruCache<String, Bitmap> imagePreviewCache = new LruCache<String, Bitmap>(12 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            if (value == null) return 0;
            return Math.max(1, value.getByteCount() / 1024);
        }
    };
    private final HashSet<String> imageDecodeInFlight = new HashSet<String>();
    private Runnable audioStartTimeout;
    private int playbackState = TtsForegroundService.STATE_STOPPED;
    private String lastPlaybackError = "";
    private boolean fullIndexRequested;
    private String appLanguage;
    private String appRegion;
    private String currentPdfLanguage = "";
    private boolean provisionalPdfLanguageActive = false;

    /** Alto estandar de un banner de AdMob. */
    private static final int BANNER_HEIGHT_DP = 50;
    private FrameLayout bannerSlot;
    private LinearLayout readerTopBar;
    private LinearLayout readerControls;
    private LinearLayout readerMarkControls;
    private boolean bannerVisible = true;
    private float currentPdfLanguageConfidence;
    private int languageDetectionToken;
    private int languageSamplingToken = -1;
    private boolean pdfLanguageDialogVisible;
    private boolean waitingForTtsDataInstall;
    private String pendingVoiceInstallLanguage = "";
    private boolean voicesInventoryLoading;
    private boolean initialLanguagePending;
    private boolean startupCompleted;
    private int pdfOpenRequestToken;
    private boolean skipNextStartupCover;
    private boolean onboardingMode;
    private int onboardingStep;
    private int fastResumeSynthesisToken;
    private boolean fastResumeWaitingForEngine;
    private Runnable fastResumePrepareRunnable;

    private static final class FastResumeBridge {
        final File file;
        final String text;

        FastResumeBridge(File file, String text) {
            this.file = file;
            this.text = text;
        }
    }

    /**
     * Android 15/16 enforce edge-to-edge for modern target SDKs. Keep the existing
     * programmatic UI inside the status/navigation bar safe area without changing
     * any of the reader layouts or controls.
     */
    private void installAndroid16SystemBarInsets() {
        if (Build.VERSION.SDK_INT < 35) return;

        final View content = findViewById(android.R.id.content);
        if (content == null) return;

        content.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets bars = insets.getInsets(
                            WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                    v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                }
                return insets;
            }
        });
        content.requestApplyInsets();
    }

    /**
     * Tarjeta seleccionable usada por Tipo de PDF, Crear audio y Guardar PDF.
     * Tocar la tarjeta solo cambia la seleccion; la flecha es el unico control
     * que ejecuta la accion.
     */
    private static final class SelectableOptionCard {
        final LinearLayout root;
        final TextView arrow;
        final int accent;

        SelectableOptionCard(LinearLayout root, TextView arrow, int accent) {
            this.root = root;
            this.arrow = arrow;
            this.accent = accent;
        }
    }

    /**
     * Primera superficie visible del proceso. Android puede recrear la Activity
     * despues de haberla cerrado por memoria; esta vista se dibuja antes de OCR,
     * PDF, TTS o publicidad para que nunca exista un rectangulo negro vacio.
     */
    private void showImmediateLaunchSurface() {
        try {
            FrameLayout launch = new FrameLayout(this);
            launch.setBackgroundColor(Color.rgb(8, 40, 58));
            launch.setClickable(true);

            LinearLayout center = new LinearLayout(this);
            center.setOrientation(LinearLayout.VERTICAL);
            center.setGravity(Gravity.CENTER);

            ImageView logo = new ImageView(this);
            logo.setImageResource(R.drawable.ic_splash_icon);
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(uiDp(76), uiDp(76));
            logoLp.bottomMargin = uiDp(14);
            center.addView(logo, logoLp);

            TextView name = new TextView(this);
            name.setText("PDF a Voz");
            name.setTextColor(Color.WHITE);
            name.setTextSize(uiSp(18));
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setGravity(Gravity.CENTER);
            center.addView(name);

            ProgressBar spinner = new ProgressBar(this);
            spinner.setIndeterminate(true);
            LinearLayout.LayoutParams spinnerLp = new LinearLayout.LayoutParams(uiDp(28), uiDp(28));
            spinnerLp.topMargin = uiDp(14);
            center.addView(spinner, spinnerLp);

            FrameLayout.LayoutParams centerLp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            centerLp.gravity = Gravity.CENTER;
            launch.addView(center, centerLp);
            setContentView(launch);
        } catch (Throwable ignored) {
            // El windowBackground del tema sigue cubriendo el arranque incluso
            // si un fabricante no permite construir esta superficie.
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startupClockStart = SystemClock.elapsedRealtime();
        // El consentimiento de anuncios se consulta con Google por internet y
        // tarda un momento. Antes solo arrancaba al crearse el banner, asi que
        // un usuario que entraba directo a Ajustes se encontraba con que el
        // tramite ni siquiera habia empezado. Se lanza al abrir, con un respiro
        // para no competir con el primer dibujado de la pantalla.
        audioStartHandler.postDelayed(new Runnable() {
            @Override public void run() {
                if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                startConsentFlowIfNeeded();
            }
        }, 1200L);
        installAndroid16SystemBarInsets();
        showImmediateLaunchSurface();
        currentTitle = "PDF a Audio";
        prefs = getSharedPreferences("pdf_audio_prefs", MODE_PRIVATE);
        appLanguage = UiStrings.normalize(prefs.getString(UiStrings.PREF_LANGUAGE, UiStrings.detectDeviceLanguage()));
        initialLanguagePending = !prefs.getBoolean(UiStrings.PREF_ONBOARDING_COMPLETE, false);
        // En una instalación nueva la bienvenida nace en el idioma del teléfono.
        // Si el usuario ya había elegido un idioma en una versión anterior, se
        // respeta esa preferencia al mostrar una sola vez el nuevo onboarding.
        if (initialLanguagePending && !prefs.getBoolean(UiStrings.PREF_LANGUAGE_CHOSEN, false)) {
            appLanguage = UiStrings.detectDeviceLanguage();
        }
        appRegion = UiStrings.normalizeRegion(
                prefs.getString(UiStrings.PREF_REGION,
                        UiStrings.detectDeviceRegion(this, appLanguage)),
                appLanguage, this);
        if (!prefs.contains(UiStrings.PREF_REGION)) {
            prefs.edit().putString(UiStrings.PREF_REGION, appRegion).apply();
        }
        // Tema oscuro fijo: la opcion se retiro de Ajustes, asi que se ignora
        // cualquier preferencia guardada de tema claro y se normaliza el valor.
        darkTheme = true;
        if (!prefs.getBoolean("dark_theme", true)) {
            prefs.edit().putBoolean("dark_theme", true).apply();
        }
        speechRate = prefs.getFloat("speech_rate", 1.0f);
        int storedMarkStyle = prefs.getInt(PREF_MARK_STYLE, MARK_STYLE_UNDERLINE_FINE);
        if (!prefs.getBoolean(PREF_MARK_STYLE_V72_MIGRATED, false)) {
            // V71 usaba 0=subrayado y 1=resaltado. Se conserva la eleccion al migrar.
            storedMarkStyle = storedMarkStyle == 1 ? MARK_STYLE_HIGHLIGHT_SOFT : MARK_STYLE_UNDERLINE_FINE;
            prefs.edit()
                    .putInt(PREF_MARK_STYLE, storedMarkStyle)
                    .putBoolean(PREF_MARK_STYLE_V72_MIGRATED, true)
                    .apply();
        }
        markStyle = safeMarkStyle(storedMarkStyle);
        if (storedMarkStyle == MARK_STYLE_TEXT_BOX) {
            markStyle = MARK_STYLE_UNDERLINE_FINE;
            prefs.edit().putInt(PREF_MARK_STYLE, markStyle).apply();
        }
        markThicknessLevel = safeThicknessLevel(prefs.getInt(PREF_MARK_THICKNESS, 1));

        int storedUnderlineColor = prefs.getInt(PREF_UNDERLINE_COLOR, 0);
        int storedHighlightColor = prefs.getInt(PREF_HIGHLIGHT_COLOR, 0);
        if (!prefs.getBoolean(PREF_MARK_COLORS_V72_MIGRATED, false)) {
            storedUnderlineColor = migrateV71ColorIndex(storedUnderlineColor);
            storedHighlightColor = migrateV71ColorIndex(storedHighlightColor);
            prefs.edit()
                    .putInt(PREF_UNDERLINE_COLOR, storedUnderlineColor)
                    .putInt(PREF_HIGHLIGHT_COLOR, storedHighlightColor)
                    .putBoolean(PREF_MARK_COLORS_V72_MIGRATED, true)
                    .apply();
        }
        underlineColorIndex = safeMarkColorIndex(storedUnderlineColor);
        highlightColorIndex = safeMarkColorIndex(storedHighlightColor);
        customUnderlineRgb = prefs.getInt(PREF_CUSTOM_UNDERLINE_COLOR, 0x00FFD400) & 0x00FFFFFF;
        customHighlightRgb = prefs.getInt(PREF_CUSTOM_HIGHLIGHT_COLOR, 0x00FFD400) & 0x00FFFFFF;
        useCustomUnderlineColor = prefs.getBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, false);
        useCustomHighlightColor = prefs.getBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, false);
        ruleColorIndex = safeMarkColorIndex(prefs.getInt(PREF_RULE_COLOR, 3));
        customRuleRgb = prefs.getInt(PREF_CUSTOM_RULE_COLOR, 0x003B82F6) & 0x00FFFFFF;
        useCustomRuleColor = prefs.getBoolean(PREF_USE_CUSTOM_RULE_COLOR, false);
        readingMarkerEnabled = prefs.getBoolean(PREF_READING_MARKER_ENABLED, false);
        if (!prefs.getBoolean(PREF_READING_MARKER_V81_RESET, false)) {
            readingMarkerEnabled = false;
            prefs.edit().putBoolean(PREF_READING_MARKER_ENABLED, false)
                    .putBoolean(PREF_READING_MARKER_V81_RESET, true).apply();
        }
        readingMarkerColorIndex = safeMarkColorIndex(prefs.getInt(PREF_READING_MARKER_COLOR, 3));
        customReadingMarkerRgb = prefs.getInt(PREF_CUSTOM_READING_MARKER_COLOR, 0x003B82F6) & 0x00FFFFFF;
        useCustomReadingMarkerColor = prefs.getBoolean(PREF_USE_CUSTOM_READING_MARKER_COLOR, false);
        readingBrightness = prefs.getFloat(PREF_READING_BRIGHTNESS, -1f);
        imageLibraryGridMode = prefs.getBoolean(PREF_IMAGE_LIBRARY_GRID, true);
        applyReadingBrightness();
        repairBrokenPlaybackStateOnce();
        setupPlaybackSync();
        setupExportCancelReceiver();
        normalTextRepository = new TextRepository(this);
        ocrTextRepository = new OcrTextRepository(this);
        ocrTextRepository.setPreferDevanagari("hi".equals(appLanguage));
        currentOcrMode = prefs.getBoolean(PREF_LAST_READER_OCR_MODE, false) && hasAdvancedAccess();
        if (!currentOcrMode && prefs.getBoolean(PREF_LAST_READER_OCR_MODE, false)) {
            prefs.edit().putBoolean(PREF_LAST_READER_OCR_MODE, false).apply();
        }
        textRepository = currentOcrMode ? ocrTextRepository : normalTextRepository;
        selectionRepository = new SelectionTextRepository(this);
        TtsForegroundService.setPageProvider(new TtsForegroundService.PageProvider() {
            @Override
            public void requestPageText(final int page, final TtsForegroundService.PageTextCallback callback) {
                if (currentOcrMode && !hasAdvancedAccess()) {
                    callback.onFastText("");
                    callback.onText("");
                    return;
                }
                // Entrega un prefijo audible tan pronto como sea posible y sigue
                // extrayendo la pagina completa en la misma solicitud. El servicio
                // elimina ese prefijo al continuar, por lo que no repite texto. Esto
                // evita que Play quede varios segundos en "..." al abrir un PDF o
                // saltar a una pagina que todavia no estaba en cache.
                textRepository.getPageTextFastStart(page,
                        new TextRepository.TextCallback() {
                            @Override
                            public void onText(String text) {
                                callback.onFastText(text);
                            }
                        },
                        new TextRepository.TextCallback() {
                            @Override
                            public void onText(String text) {
                                callback.onText(text);
                            }
                        });
            }
        });
        if (initialLanguagePending) {
            showInitialRegionSelectionScreen();
        } else {
            buildUi();
            finishStartupAfterLanguageSelection();
        }
    }

    private String t(String text) {
        return UiStrings.translate(appLanguage, text);
    }

    private void finishStartupAfterLanguageSelection() {
        if (startupCompleted) return;
        startupCompleted = true;
        initialLanguagePending = false;

        String storedPath = prefs.getString(PREF_LAST_FILE_PATH, "");
        File restored = storedPath == null || storedPath.trim().length() == 0
                ? null : new File(storedPath);
        if (restored == null || !restored.exists()) {
            File legacy = new File(getFilesDir(), "last.pdf");
            if (legacy.exists()) restored = legacy;
        }
        final File last = restored;
        // Solo se cronometra cuando la app reabre sola el ultimo documento.
        startupClockValid = last != null && last.exists();
        currentSourceKey = prefs.getString(PREF_LAST_SOURCE_KEY, "");
        String storedTitle = prefs.getString("last_title", t("PDF guardado"));
        // Blindaje: si por una sesion anterior quedo guardado el titulo por
        // defecto ("PDF a Audio"/"PDF"), no se muestra ese marcador de posicion.
        // Se usa un nombre de respaldo legible en su lugar.
        if (storedTitle == null || storedTitle.trim().length() == 0
                || "PDF a Audio".equals(storedTitle) || "PDF".equals(storedTitle)) {
            storedTitle = t("PDF guardado");
        }
        final String lastTitle = storedTitle;

        // Si hay un PDF que reabrir, se oculta el cartel "Abrir un PDF" desde
        // ya: la interfaz dibuja primero y el documento se restaura unos
        // milisegundos despues, y en ese hueco se veia el cartel de estado
        // vacio aunque hubiera un documento en camino.
        if (last != null && last.exists()) {
            if (pdfView != null) pdfView.setSuppressEmptyLabel(true);
            if (titleView != null) titleView.setText(lastTitle);
            // Se tapa el armado de la interfaz hasta que la pagina este lista.
            showStartupCover();
        }

        final Runnable afterFirstFrame = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                ensureNotificationPermission();
                if (last != null && last.exists()) {
                    openLocalPdf(last, lastTitle, true);
                } else {
                    scheduleTtsWarmup(700L);
                }
            }
        };

        // Deja que la interfaz dibuje primero. Restaurar PdfRenderer, caché y
        // marcados en el mismo onCreate hacía que el arranque pareciera congelado.
        if (root != null) root.postDelayed(afterFirstFrame, 48L);
        else new Handler(Looper.getMainLooper()).postDelayed(afterFirstFrame, 48L);
    }

    /**
     * First launch onboarding. It is deliberately a full-screen surface so the
     * reader UI never appears behind the language choice.
     */
    private void showOnboardingWelcome() {
        // Legacy entry point retained only for compatibility with old internal paths.
        // The welcome screen itself no longer exists; first run goes straight to region.
        showInitialRegionSelectionScreen();
    }

    /**
     * First launch is intentionally reduced to one decision: country / region.
     * The interface language is detected from Android and can still be changed
     * later from Settings. Selecting a country completes first-run setup.
     */
    private void showInitialRegionSelectionScreen() {
        onboardingMode = true;
        onboardingStep = 3;
        settingsMode = false;
        settingsSubscreen = 0;

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));
        screen.setClickable(true);
        screen.setFocusable(true);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(18), uiDp(10), uiDp(18), uiDp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        TextView title = new TextView(this);
        title.setText(t("País / Región"));
        title.setTextSize(uiSp(22));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(46)));
        screen.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(62)));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(uiDp(16), uiDp(10), uiDp(16), uiDp(16));

        final EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("🔎  " + t("Buscar país..."));
        search.setTextSize(uiSp(16));
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.rgb(148, 163, 184));
        search.setPadding(uiDp(16), 0, uiDp(16), 0);
        GradientDrawable searchBg = new GradientDrawable();
        searchBg.setCornerRadius(uiDp(18));
        searchBg.setColor(Color.rgb(8, 31, 51));
        searchBg.setStroke(uiDp(1), Color.rgb(37, 84, 120));
        search.setBackground(searchBg);
        body.addView(search, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(52)));

        LinearLayout regionStatus = new LinearLayout(this);
        regionStatus.setOrientation(LinearLayout.HORIZONTAL);
        regionStatus.setGravity(Gravity.CENTER_VERTICAL);
        regionStatus.setPadding(uiDp(4), 0, uiDp(4), 0);

        TextView currentPrefix = new TextView(this);
        currentPrefix.setText(t("Región actual") + ":");
        currentPrefix.setTextColor(Color.WHITE);
        currentPrefix.setTextSize(uiSp(14));
        currentPrefix.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        currentPrefix.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams currentPrefixLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        currentPrefixLp.gravity = Gravity.CENTER_VERTICAL;
        regionStatus.addView(currentPrefix, currentPrefixLp);

        ImageView currentFlag = makeFlagImageView(appRegion);
        LinearLayout.LayoutParams currentFlagLp = new LinearLayout.LayoutParams(uiDp(28), uiDp(19));
        currentFlagLp.leftMargin = uiDp(6);
        currentFlagLp.rightMargin = uiDp(6);
        currentFlagLp.gravity = Gravity.CENTER_VERTICAL;
        regionStatus.addView(currentFlag, currentFlagLp);

        TextView currentName = new TextView(this);
        currentName.setText(UiStrings.regionName(appRegion, appLanguage));
        currentName.setTextColor(Color.WHITE);
        currentName.setTextSize(uiSp(14));
        currentName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        currentName.setSingleLine(true);
        currentName.setEllipsize(TextUtils.TruncateAt.END);
        currentName.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams currentNameLp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        currentNameLp.gravity = Gravity.CENTER_VERTICAL;
        regionStatus.addView(currentName, currentNameLp);

        TextView total = new TextView(this);
        total.setText(t("28 países"));
        total.setTextColor(Color.rgb(96, 165, 250));
        total.setTextSize(uiSp(13));
        total.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        total.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        regionStatus.addView(total, new LinearLayout.LayoutParams(uiDp(92), uiDp(42)));
        body.addView(regionStatus, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(42)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        body.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        populateRegionRows(list, "", true);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                populateRegionRows(list, s == null ? "" : s.toString(), true);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        screen.addView(body, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(screen);
    }

    private void completeInitialRegionAndEnterApp(String regionCode) {
        appRegion = UiStrings.normalizeRegion(regionCode, appLanguage);
        prefs.edit()
                .putString(UiStrings.PREF_LANGUAGE, UiStrings.normalize(appLanguage))
                .putString(UiStrings.PREF_REGION, appRegion)
                .putBoolean(UiStrings.PREF_ONBOARDING_COMPLETE, true)
                .apply();
        onboardingMode = false;
        initialLanguagePending = false;
        buildUi();
        finishStartupAfterLanguageSelection();
    }

    private void showOnboardingLanguageSelection() {
        onboardingMode = true;
        onboardingStep = 2;

        final int accent = Color.rgb(37, 99, 235);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(uiDp(22), uiDp(10), uiDp(22), uiDp(14));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(3, 17, 31), Color.rgb(3, 37, 64)});
        page.setBackground(bg);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(Color.WHITE);
        back.setTextSize(uiSp(38));
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showOnboardingWelcome(); }
        });
        top.addView(back, new LinearLayout.LayoutParams(uiDp(44), uiDp(44)));
        View topSpacer = new View(this);
        top.addView(topSpacer, new LinearLayout.LayoutParams(0, uiDp(44), 1));
        TextView globe = makeRoundHeaderIcon("🌐");
        top.addView(globe, new LinearLayout.LayoutParams(uiDp(44), uiDp(44)));
        page.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(44)));

        TextView title = new TextView(this);
        title.setText(t("Elige tu idioma"));
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setTextSize(uiSp(25));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleLp.topMargin = uiDp(5);
        page.addView(title, titleLp);

        TextView info = new TextView(this);
        info.setText(t("Selecciona el idioma que deseas usar en la aplicación."));
        info.setTextColor(Color.rgb(203, 213, 225));
        info.setTextSize(uiSp(14));
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        infoLp.topMargin = uiDp(4);
        infoLp.bottomMargin = uiDp(10);
        page.addView(info, infoLp);

        final String[] codes = new String[]{UiStrings.ES, UiStrings.EN, UiStrings.PT, UiStrings.HI, UiStrings.ID};
        final String[] flagCodes = new String[]{"ES", "US", "BR", "IN", "ID"};
        final String[] names = new String[]{"Español", "English", "Português (Brasil)", "हिन्दी — Hindi", "Bahasa Indonesia"};
        final String deviceLanguage = UiStrings.detectDeviceLanguage();

        for (int i = 0; i < codes.length; i++) {
            final String code = codes[i];
            boolean selected = code.equals(UiStrings.normalize(appLanguage));
            String note = code.equals(deviceLanguage) ? t("Idioma del dispositivo") : "";
            View option = makeDesign3SelectionRow(flagCodes[i], names[i], note, selected);
            option.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    appLanguage = code;
                    if (ocrTextRepository != null) ocrTextRepository.setPreferDevanagari("hi".equals(appLanguage));
                    showOnboardingLanguageSelection();
                }
            });
            LinearLayout.LayoutParams optionLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, uiDp(54));
            optionLp.bottomMargin = uiDp(7);
            page.addView(option, optionLp);
        }

        View stretch = new View(this);
        page.addView(stretch, new LinearLayout.LayoutParams(1, 0, 0.08f));

        Button continueButton = makeOnboardingPrimaryButton(t("Continuar"), accent);
        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                prefs.edit()
                        .putString(UiStrings.PREF_LANGUAGE, UiStrings.normalize(appLanguage))
                        .putString(UiStrings.PREF_REGION, UiStrings.normalizeRegion(appRegion, appLanguage))
                        .putBoolean(UiStrings.PREF_LANGUAGE_CHOSEN, true)
                        .apply();
                showOnboardingWelcome();
            }
        });
        page.addView(continueButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(58)));

        setContentView(page);
    }

    private Button makeOnboardingPrimaryButton(String label, int accent) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(uiSp(16));
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(accent);
        bg.setCornerRadius(uiDp(16));
        button.setBackground(bg);
        return button;
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Mantener el receptor activo mientras la Activity siga visible/arrancada.
        // Al bajar el panel de notificaciones Android puede pausar la Activity,
        // pero no debe perder los cambios Play/Pausa/Siguiente del servicio.
        registerPlaybackReceiver();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Recalcula el desbloqueo al volver a primer plano. Si las 8 horas
        // vencieron mientras la app estaba en segundo plano, Ajustes vuelve a
        // mostrar candados inmediatamente.
        if (settingsMode && settingsSubscreen == 0) buildSettingsScreen();
        scheduleAdvancedAccessExpiryRefresh();
        resumeBannerAd();
        startPageSyncLoop();
        syncVisiblePageWithReader(true);
        // Volver a la app es el tercer momento tipico antes de tocar Play.
        if (currentFile != null) warmTtsEngineNow();

        // Con la pantalla apagada la vista no recibe los avisos de "voy leyendo
        // esta frase", asi que al volver el resaltado no aparecia hasta la
        // frase siguiente (o nunca, si quedo en pausa). Se le pide al servicio
        // la posicion actual para pintarlo enseguida.
        if (readingMarkerEnabled && currentFile != null
                && (playbackState == TtsForegroundService.STATE_PLAYING
                || playbackState == TtsForegroundService.STATE_PAUSED
                || playbackState == TtsForegroundService.STATE_PREPARING)) {
            try {
                Intent report = new Intent(this, TtsForegroundService.class);
                report.setAction(TtsForegroundService.ACTION_REPORT_RANGE);
                startService(report);
            } catch (Exception ignored) {
            }
            schedulePendingReadingMarker();
        }
        if (waitingForTtsDataInstall) {
            waitingForTtsDataInstall = false;
            final String installedLanguage = pendingVoiceInstallLanguage;
            pendingVoiceInstallLanguage = "";
            audioStartHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                    TtsEngineManager manager = TtsEngineManager.getInstance(MainActivity.this);
                    // El motor tiene que releer sus voces: las recien bajadas no
                    // aparecen en la lista que ya tenia en memoria.
                    manager.refreshVoiceCache();
                    if (currentPdfLanguage.length() > 0) {
                        manager.ensureLanguage(currentPdfLanguage, appRegion, null);
                    } else {
                        manager.retryInitialization();
                    }
                    if (installedLanguage.length() > 0) {
                        confirmVoiceInstallResult(installedLanguage, 0);
                    } else if (settingsMode && settingsSubscreen == 4) {
                        showVoicesScreen();
                    }
                }
            }, 450L);
        }
    }

    @Override
    protected void onPause() {
        checkpointAdvancedAccessState();
        cancelAdvancedAccessExpiryRefresh();
        pauseBannerAd();
        stopPageSyncLoop();
        cancelPendingReadingMarker();
        super.onPause();
    }

    @Override
    protected void onStop() {
        unregisterPlaybackReceiver();
        super.onStop();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        syncVisiblePageWithReader(true);
    }

    private void setupPlaybackSync() {
        pageSyncHandler = new Handler(Looper.getMainLooper());
        pageSyncRunnable = new Runnable() {
            @Override
            public void run() {
                syncVisiblePageWithReader();
                if (pageSyncHandler != null) {
                    pageSyncHandler.postDelayed(this, 700);
                }
            }
        };
        playbackReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !TtsForegroundService.ACTION_PAGE_CHANGED.equals(intent.getAction())) return;
                int state = intent.getIntExtra(TtsForegroundService.EXTRA_STATE,
                        TtsForegroundService.STATE_STOPPED);
                int page = intent.getIntExtra(TtsForegroundService.EXTRA_PAGE, -1);
                String message = intent.getStringExtra(TtsForegroundService.EXTRA_MESSAGE);
                String chunk = intent.getStringExtra(TtsForegroundService.EXTRA_CHUNK_TEXT);
                boolean rangeOnlyUpdate = chunk != null && chunk.length() > 0
                        && state == playbackState && (page < 0 || page == currentPage);
                if (!rangeOnlyUpdate) {
                    applyPlaybackState(state, page, message, true);
                }
                if (readingMarkerEnabled && chunk != null && chunk.length() > 0) {
                    pendingReadingPage = page;
                    pendingReadingChunk = chunk;
                    pendingReadingChunkIndex = intent.getIntExtra(TtsForegroundService.EXTRA_CHUNK_INDEX, 0);
                    pendingReadingRangeStart = intent.getIntExtra(TtsForegroundService.EXTRA_RANGE_START, 0);
                    pendingReadingRangeEnd = intent.getIntExtra(TtsForegroundService.EXTRA_RANGE_END, 1);
                    schedulePendingReadingMarker();
                }
            }
        };
    }

    private void registerPlaybackReceiver() {
        if (receiverRegistered || playbackReceiver == null) return;
        IntentFilter filter = new IntentFilter(TtsForegroundService.ACTION_PAGE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(playbackReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(playbackReceiver, filter);
        }
        receiverRegistered = true;
    }

    private void unregisterPlaybackReceiver() {
        if (!receiverRegistered || playbackReceiver == null) return;
        try {
            unregisterReceiver(playbackReceiver);
        } catch (Exception ignored) {
        }
        receiverRegistered = false;
    }

    private void setupExportCancelReceiver() {
        exportCancelReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !ACTION_CANCEL_AUDIO_EXPORT.equals(intent.getAction())) return;
                cancelActiveAudioExport(true);
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_CANCEL_AUDIO_EXPORT);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(exportCancelReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(exportCancelReceiver, filter);
            }
            exportCancelReceiverRegistered = true;
        } catch (Exception ignored) {
            exportCancelReceiverRegistered = false;
        }
    }

    private void unregisterExportCancelReceiver() {
        if (!exportCancelReceiverRegistered || exportCancelReceiver == null) return;
        try {
            unregisterReceiver(exportCancelReceiver);
        } catch (Exception ignored) {
        }
        exportCancelReceiverRegistered = false;
    }

    private void startPageSyncLoop() {
        if (pageSyncHandler == null || pageSyncRunnable == null) return;
        pageSyncHandler.removeCallbacks(pageSyncRunnable);
        pageSyncHandler.postDelayed(pageSyncRunnable, 700);
    }

    private void stopPageSyncLoop() {
        if (pageSyncHandler != null && pageSyncRunnable != null) {
            pageSyncHandler.removeCallbacks(pageSyncRunnable);
        }
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33) return;
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return;

        // Android deja de mostrar el dialogo tras dos rechazos. En ese caso pedir
        // el permiso otra vez no hace nada, asi que se ofrece abrir los ajustes
        // del sistema, que es el unico camino que le queda al usuario.
        if (notificationPermissionAsked
                && !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
            showNotificationPermissionSettingsDialog();
            return;
        }

        notificationPermissionAsked = true;
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 33);
        if (!notificationWarningShown) {
            notificationWarningShown = true;
            Toast.makeText(this, t("Acepta el permiso de notificaciones para ver los controles del audio"), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != 33 || Build.VERSION.SDK_INT < 33) return;
        boolean granted = results != null && results.length > 0
                && results[0] == PackageManager.PERMISSION_GRANTED;
        if (granted) {
            notificationPermissionDeniedForever = false;
            return;
        }
        // Rechazado y sin posibilidad de volver a preguntar: se recuerda para
        // ofrecer los ajustes del sistema la proxima vez que haga falta.
        if (!shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
            notificationPermissionDeniedForever = true;
        }
    }

    /** Explica por que hace falta el permiso y abre la ficha de la app. */
    private void showNotificationPermissionSettingsDialog() {
        if (notificationSettingsDialogShown || isFinishing()
                || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        notificationSettingsDialogShown = true;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Permiso de notificaciones"))
                .setMessage(t("Sin este permiso no se ven los controles del audio. Puedes activarlo desde los ajustes de la aplicación."))
                .setPositiveButton(t("Abrir ajustes"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        openApplicationSettings();
                    }
                })
                .setNegativeButton(t("Ahora no"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void openApplicationSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.fromParts("package", getPackageName(), null));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, t("No se pudieron abrir los ajustes"), Toast.LENGTH_LONG).show();
        }
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.WHITE);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(8), uiDp(8), uiDp(8), uiDp(6));
        top.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.WHITE);

        Button openButton = makeTopBarButton("Abrir");
        openButton.setTextSize(uiSp(12.0f));
        openButton.setSingleLine(true);
        openButton.setPadding(uiDp(2), 0, uiDp(2), 0);
        
openButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        choosePdf();
    }
});

        titleScroller = null;

        titleView = new TextView(this);
        titleView.setText("PDF a Audio");
        titleView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        titleView.setTextSize(uiSp(15.5f));
        titleView.setSingleLine(true);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        titleView.setPadding(0, 0, uiDp(8), 0);
        // Desplazamiento automatico tipo cartel cuando el nombre del PDF no entra
        // en el ancho disponible. Con setSelected(true) siempre activo, el texto
        // largo se mueve solo y en loop; el corto queda quieto y centrado a la
        // izquierda. Reemplaza al scroll manual anterior que no se movia solo.
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
        titleView.setMarqueeRepeatLimit(-1);
        titleView.setHorizontalFadingEdgeEnabled(true);
        titleView.setSelected(true);

        pageView = new TextView(this);
        pageView.setText(t("0/0"));
        pageView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        pageView.setTextSize(uiSp(13.5f));
        pageView.setSingleLine(true);
        pageView.setGravity(Gravity.CENTER);
        pageView.setClickable(true);
        pageView.setFocusable(true);
        pageView.setContentDescription(t("Ir a página"));
        pageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showGoto();
            }
        });

        bookmarkButton = makeButton("☆");
        bookmarkButton.setTextSize(uiSp(20));
        bookmarkButton.setContentDescription(t("Guardar pagina"));
        // Guardar/quitar al instante. Antes abria un cuadro con un boton que
        // habia que volver a tocar; ahora la estrella es la accion en si misma
        // y la lista de paginas guardadas vive en Ajustes.
        bookmarkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleCurrentPageBookmark();
            }
        });

        Button filesButton = makeButton("📁");
        filesButton.setTextSize(uiSp(20));
        filesButton.setContentDescription(t("Mis archivos"));
        filesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(true);
            }
        });

        rulesButton = makeTopBarButton("Reglas");
        rulesButton.setTextSize(uiSp(8.9f));
        rulesButton.setSingleLine(false);
        rulesButton.setPadding(uiDp(2), 0, uiDp(2), 0);
        rulesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleRules();
            }
        });
        rulesButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showUtilityColorDialog(COLOR_TARGET_RULE, "Color de las reglas");
                return true;
            }
        });

        top.addView(openButton, new LinearLayout.LayoutParams(uiDp(58), uiDp(44)));
        top.addView(titleView, new LinearLayout.LayoutParams(0, uiDp(44), 1));
        // Ancho fijo de 50 cortaba "173/369". Ahora crece lo necesario y se
        // conserva un minimo para que no baile al cambiar de pagina.
        pageView.setMinWidth(uiDp(50));
        pageView.setPadding(uiDp(4), 0, uiDp(4), 0);
        top.addView(pageView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, uiDp(44)));
        top.addView(rulesButton, new LinearLayout.LayoutParams(uiDp(62), uiDp(44)));
        top.addView(filesButton, new LinearLayout.LayoutParams(uiDp(42), uiDp(44)));

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(getPdfWorkspaceColor());
        // La vista anterior queda descartada al reconstruir la interfaz (por
        // ejemplo al cambiar de tema). Se libera su hilo de renderizado para que
        // no se acumulen hilos vivos sin dueno.
        if (pdfView != null) pdfView.release();
        pdfView = new PdfPageView(this);
        pdfView.setPageChangeListener(new PdfPageView.PageChangeListener() {
            @Override
            public void onPageRendered(final int pageIndex, int total) {
                currentPage = pageIndex;
                pageCount = total;
                updatePageLabel();
                saveProgress();
                // Ya hay algo real en pantalla: se puede quitar la tapa de
                // arranque sin que se vea la interfaz a medio armar.
                hideStartupCover();
                // Ya hay pagina dibujada: el cartel de estado vacio vuelve a
                // estar disponible para cuando se cierre el documento.
                if (pdfView != null) pdfView.setSuppressEmptyLabel(false);

                // Recien ahora arrancan la extraccion de texto y el motor de
                // voz. Hacerlo antes le robaba procesador al dibujado y era lo
                // que estiraba el "Cargando" y la apertura de un PDF.
                runDeferredDocumentWork();

                // El render visible termina primero. El texto, las coordenadas y
                // la precarga se agrupan y se retrasan unos milisegundos para que
                // varios toques seguidos no bloqueen ni hagan regresar páginas.
                scheduleVisiblePageWork(pageIndex, true);
                if (readingMarkerEnabled && pendingReadingPage == pageIndex) {
                    schedulePendingReadingMarker();
                }
                if (!TtsEngineManager.getInstance(MainActivity.this).isReady()) {
                    scheduleTtsWarmup(220L);
                }
                if (restartAudioAfterRender) {
                    restartAudioAfterRender = false;
                    startAudioFromPage(currentPage);
                }
            }

            @Override
            public void onError(String message) {
                hideStartupCover();
                Toast.makeText(MainActivity.this, t(message), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onHighlightsChanged(String serialized) {
                saveHighlights(serialized);
            }

            @Override
            public void onRulesChanged(boolean enabled, float top, float bottom) {
                saveRules(enabled, top, bottom);
                textRepository.setRules(enabled, top, bottom);
                refreshTextCacheForRules();
            }
        });
        pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
        pdfView.setReadingMarkerEnabled(!currentOcrMode && readingMarkerEnabled);
        pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
        pdfView.setWorkspaceColor(getPdfWorkspaceColor());
        frame.addView(pdfView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(uiDp(6), uiDp(5), uiDp(6), uiDp(5));
        controls.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        View prevButton = makeNavigationButton("left", true);
        
prevButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) requestManualPageChange(currentPage - 1);
    }
});

        playButton = makeButton("▶");
        playButton.setTextSize(uiSp(21));
        
playButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        toggleAudio();
    }
});

        View nextButton = makeNavigationButton("right", true);
        
nextButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) requestManualPageChange(currentPage + 1);
    }
});

        View fitButton = makeIconBarButton("gear", "Ajustes");
        
fitButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        showSettings();
    }
});

        // Cinco celdas identicas: la fila queda centrada exactamente igual en
        // espanol, ingles, portugues, hindi e indonesio.
        controls.addView(prevButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        controls.addView(playButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        controls.addView(nextButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        controls.addView(bookmarkButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        controls.addView(fitButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));

        LinearLayout markControls = new LinearLayout(this);
        markControls.setOrientation(LinearLayout.HORIZONTAL);
        markControls.setGravity(Gravity.CENTER);
        markControls.setPadding(uiDp(8), uiDp(2), uiDp(8), uiDp(2));
        markControls.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        markButton = makeIconStateButton("mark", "Subrayar OFF");
        markButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleMarkMode();
            }
        });

        colorButton = makeButton("●");
        colorButton.setTextSize(uiSp(22));
        colorButton.setContentDescription(t("Elegir color del marcado"));
        colorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkColorDialog(isHighlightStyle(markStyle) ? COLOR_TARGET_HIGHLIGHT : COLOR_TARGET_UNDERLINE);
            }
        });

        View undoButton = makeMarkHistoryButton("undo", "Deshacer marca");
        undoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.undoLastHighlight();
            }
        });

        View redoButton = makeMarkHistoryButton("redo", "Rehacer marca");
        redoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.redoLastHighlight();
            }
        });

        View clearButton = makeIconBarButton("eraser", "Limpiar");
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.clearPageHighlights();
            }
        });

        markControls.addView(markButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        markControls.addView(colorButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        markControls.addView(undoButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        markControls.addView(redoButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        markControls.addView(clearButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.addView(controls, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(54)));
        bottom.addView(markControls, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(46)));

        // Se guardan para poder ajustar sus alturas al girar el telefono sin
        // reconstruir nada.
        readerTopBar = top;
        readerControls = controls;
        readerMarkControls = markControls;

        root.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(62)));
        root.addView(frame, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        // Espacio del banner. Debajo esta la etiqueta "Anuncio" como fondo; el
        // banner real se coloca encima y, cuando carga, tapa la etiqueta. Si no
        // hay anuncio disponible se sigue viendo el hueco de siempre, sin saltos
        // en la distribucion de la pantalla.
        bannerSlot = new FrameLayout(this);
        bannerSlot.setBackgroundColor(darkTheme ? Color.rgb(10, 46, 66) : Color.rgb(226, 235, 245));
        bannerStatusLabel = new TextView(this);
        bannerStatusLabel.setText("");
        bannerStatusLabel.setTextSize(uiSp(12));
        bannerStatusLabel.setGravity(Gravity.CENTER);
        bannerStatusLabel.setTextColor(darkTheme ? Color.rgb(120, 150, 175) : Color.rgb(71, 85, 105));
        bannerStatusLabel.setVisibility(View.GONE);
        bannerSlot.addView(bannerStatusLabel, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        attachBannerAd();
        root.addView(bannerSlot, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(BANNER_HEIGHT_DP)));
        applyBannerVisibility();

        root.addView(bottom, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(100)));

        // Si la app arranca ya de costado, se aplica de una.
        applyOrientationLayout();

        // Si el contenedor ya esta puesto en la ventana se reutiliza y solo se
        // cambia lo de adentro. Cambiar la vista raiz de la ventana entera es lo
        // que provocaba el parpadeo negro al volver de Ajustes con otro idioma:
        // habia un instante sin nada que dibujar. Reusando el contenedor, el
        // recambio ocurre en un solo pase de dibujado y no se ve ningun hueco.
        if (screenHost != null && screenHost.getParent() != null) {
            hideStartupCover();
            screenHost.removeAllViews();
            screenHost.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
            screenHost.addView(root, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        } else {
            screenHost = new FrameLayout(this);
            screenHost.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
            screenHost.addView(root, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            setContentView(screenHost);
        }
        settingsOverlay = null;
        libraryOverlay = null;
        imageViewerOverlay = null;

        pdfView.setMarkStyle(markStyle);
        pdfView.setMarkThickness(markThicknessLevel);
        pdfView.setMarkColor(getCurrentMarkColor());
        pdfView.setMarkMode(markMode);
        updateMarkControls();
        loadRules();
        updateBookmarkButton();
    }

    /**
     * Muestra u oculta el espacio del banner y ajusta como se alinea la pagina:
     * con banner la pagina se pega arriba (el sobrante queda abajo, detras del
     * anuncio); sin banner vuelve a quedar centrada como siempre.
     */
    /**
     * MIENTRAS PRUEBAS: dejar en true. Muestra el banner de prueba de Google,
     * que siempre carga y dice "Test Ad". Sirve para comprobar que el codigo
     * esta bien sin depender de que AdMob ya tenga anuncios para esta app.
     *
     * ANTES DE PUBLICAR: cambiar a false para usar el banner real.
     *
     * Importante: nunca toques tus propios anuncios reales mientras pruebas.
     * Google lo detecta como trafico invalido y puede cerrar la cuenta.
     */
    private static final boolean USAR_ANUNCIOS_DE_PRUEBA = true;

    /** Banner de prueba oficial de Google. Siempre devuelve un anuncio. */
    private static final String BANNER_DE_PRUEBA = "ca-app-pub-3940256099942544/6300978111";

    /** Identificador del banner creado en AdMob para esta app. */
    private static final String BANNER_AD_UNIT_ID = "ca-app-pub-1608518646683505/2998230204";

    /** Rewarded de prueba oficial de Google. Se usa mientras USAR_ANUNCIOS_DE_PRUEBA=true. */
    private static final String REWARDED_DE_PRUEBA = "ca-app-pub-3940256099942544/5224354917";

    /** Rewarded real creado en AdMob para OCR + guardado avanzado. */
    private static final String REWARDED_AD_UNIT_ID = "ca-app-pub-1608518646683505/7565597963";

    private com.google.android.gms.ads.AdView bannerAdView;
    private com.google.android.gms.ads.rewarded.RewardedAd rewardedAd;
    private boolean rewardedLoading;
    private boolean rewardEarnedThisAd;
    private Runnable pendingAdvancedAction;
    private TextView bannerStatusLabel;
    private boolean adsInitialized;
    private String bannerStatusText;

    // --- Consentimiento de privacidad (UMP / GDPR) ---
    private com.google.android.ump.ConsentInformation consentInformation;
    private boolean consentFlowStarted;
    private boolean consentFlowFinished;
    /** Hay un toque de "ver anuncio" esperando a que acabe el consentimiento. */
    private boolean resumeAdWhenConsentReady;
    /** Reintentos del tramite de consentimiento, para no entrar en bucle. */
    private int consentRetryCount;
    private boolean bannerRequested;

    /**
     * Coloca el banner dentro del hueco reservado, pero NO pide el anuncio
     * todavia. Primero hay que resolver el consentimiento: en Espana, el resto
     * del Espacio Economico Europeo, Reino Unido y Suiza la ley exige preguntar
     * antes de mostrar publicidad. Solo cuando el consentimiento lo permite se
     * arranca el SDK de anuncios y se pide el banner.
     *
     * Todo va dentro de try/catch a proposito: un fallo de publicidad nunca
     * debe impedir leer un PDF, que es lo que la app tiene que hacer.
     */
    private void attachBannerAd() {
        if (bannerSlot == null) return;
        try {
            if (bannerAdView != null) {
                if (bannerAdView.getParent() instanceof android.view.ViewGroup) {
                    ((android.view.ViewGroup) bannerAdView.getParent()).removeView(bannerAdView);
                }
            } else {
                bannerAdView = new com.google.android.gms.ads.AdView(this);
                bannerAdView.setAdUnitId(USAR_ANUNCIOS_DE_PRUEBA
                        ? BANNER_DE_PRUEBA : BANNER_AD_UNIT_ID);
                bannerAdView.setAdSize(com.google.android.gms.ads.AdSize.BANNER);
                bannerAdView.setAdListener(new com.google.android.gms.ads.AdListener() {
                    @Override
                    public void onAdLoaded() {
                        bannerStatusText = null;
                        updateBannerStatusLabel();
                    }

                    @Override
                    public void onAdFailedToLoad(com.google.android.gms.ads.LoadAdError error) {
                        // El codigo 3 significa "sin anuncios disponibles": la
                        // integracion esta bien, pero AdMob no tiene que servir.
                        // Es lo normal en apps recien creadas o sin publicar.
                        bannerStatusText = "Sin anuncio (" + error.getCode() + ") "
                                + error.getMessage();
                        updateBannerStatusLabel();
                    }
                });
            }

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.CENTER;
            bannerSlot.addView(bannerAdView, lp);
            updateBannerStatusLabel();

            startConsentFlowIfNeeded();
        } catch (Throwable t) {
            bannerAdView = null;
            bannerStatusText = "Error de publicidad: " + t.getClass().getSimpleName();
            updateBannerStatusLabel();
        }
    }

    /**
     * Pregunta a Google si este usuario necesita dar consentimiento segun donde
     * esta, y si hace falta muestra el formulario. Fuera de Europa no aparece
     * nada y la publicidad sigue como siempre.
     */
    private void startConsentFlowIfNeeded() {
        if (consentFlowStarted) {
            if (consentFlowFinished) loadBannerIfAllowed();
            return;
        }
        consentFlowStarted = true;
        try {
            // La app no solicita ni almacena la edad del usuario. Por eso no
            // afirmamos aqui que sea mayor de la edad de consentimiento. Las
            // solicitudes de anuncios se envian con UAC=UNSPECIFIED y contenido
            // maximo T en RequestConfiguration (ver configureAdRequests...).
            com.google.android.ump.ConsentRequestParameters params =
                    new com.google.android.ump.ConsentRequestParameters.Builder()
                            .build();

            consentInformation = com.google.android.ump.UserMessagingPlatform
                    .getConsentInformation(this);

            consentInformation.requestConsentInfoUpdate(this, params,
                    new com.google.android.ump.ConsentInformation.OnConsentInfoUpdateSuccessListener() {
                        @Override
                        public void onConsentInfoUpdateSuccess() {
                            showConsentFormIfRequired();
                        }
                    },
                    new com.google.android.ump.ConsentInformation.OnConsentInfoUpdateFailureListener() {
                        @Override
                        public void onConsentInfoUpdateFailure(
                                com.google.android.ump.FormError formError) {
                            // Si no se pudo consultar (por ejemplo, sin internet),
                            // canRequestAds decide si existe un consentimiento previo valido.
                            consentFlowFinished = true;
                            loadBannerIfAllowed();
                            resumePendingAdAfterConsent();
                        }
                    });
        } catch (Throwable t) {
            // Fallo cerrado: si UMP no pudo inicializarse, no pedimos anuncios.
            // El lector continua funcionando y se evita servir publicidad sin
            // haber podido resolver primero la privacidad.
            consentFlowFinished = true;
            resumeAdWhenConsentReady = false;
            bannerStatusText = null;
            updateBannerStatusLabel();
            if (pendingAdvancedAction != null) {
                pendingAdvancedAction = null;
                Toast.makeText(this, t("No se pudo preparar la privacidad para anuncios."),
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * Retoma el "ver anuncio" que el usuario ya habia tocado mientras el
     * consentimiento seguia resolviendose. Se llama en todos los finales del
     * tramite: exito, fallo de red y excepcion.
     */
    private void resumePendingAdAfterConsent() {
        if (!resumeAdWhenConsentReady) return;
        resumeAdWhenConsentReady = false;
        if (pendingAdvancedAction == null) return;
        if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        showOrLoadRewardedAd();
    }

    private void showConsentFormIfRequired() {
        try {
            com.google.android.ump.UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                    this,
                    new com.google.android.ump.ConsentForm.OnConsentFormDismissedListener() {
                        @Override
                        public void onConsentFormDismissed(
                                com.google.android.ump.FormError formError) {
                            // Haya aceptado, rechazado o fallado el formulario,
                            // canRequestAds dice si se puede pedir publicidad.
                            consentFlowFinished = true;
                            loadBannerIfAllowed();
                            resumePendingAdAfterConsent();
                        }
                    });
        } catch (Throwable t) {
            consentFlowFinished = true;
            loadBannerIfAllowed();
            resumePendingAdAfterConsent();
        }
    }

    /**
     * Arranca el SDK de anuncios y pide el banner, pero solo si el
     * consentimiento lo permite. Si el usuario rechazo, no se pide nada y el
     * hueco queda como estaba.
     */
    private void loadBannerIfAllowed() {
        try {
            boolean allowed = consentInformation == null || consentInformation.canRequestAds();
            if (!allowed) {
                // Todavia no se pueden pedir anuncios (consentimiento pendiente
                // o eleccion que no permite solicitudes). El lector sigue normal.
                bannerStatusText = null;
                updateBannerStatusLabel();
                if (consentFlowFinished && pendingAdvancedAction != null) {
                    // No mostrar un aviso automático aquí. Sin conexión, UMP puede
                    // quedar temporalmente sin autorizar solicitudes y ese Toast
                    // parecía un error de configuración. La lógica de anuncios y
                    // consentimiento se mantiene exactamente igual.
                    pendingAdvancedAction = null;
                }
                return;
            }
            if (!adsInitialized) {
                adsInitialized = true;
                configureAdRequestsFor13PlusAudience();
                com.google.android.gms.ads.MobileAds.initialize(getApplicationContext());
            }
            if (bannerAdView != null && !bannerRequested) {
                bannerRequested = true;
                bannerAdView.loadAd(new com.google.android.gms.ads.AdRequest.Builder().build());
            }
            loadRewardedAdIfNeeded();
        } catch (Throwable t) {
            bannerStatusText = "Error de publicidad: " + t.getClass().getSimpleName();
            updateBannerStatusLabel();
        }
    }

    /**
     * La ficha de Play declara audiencia 13+. No tratamos a todos como menores,
     * pero limitamos el contenido publicitario a una clasificacion apta para
     * adolescentes y dejamos "under age of consent" sin asumir, porque la app
     * no pide fecha de nacimiento ni crea cuentas.
     */
    private void configureAdRequestsFor13PlusAudience() {
        try {
            com.google.android.gms.ads.RequestConfiguration configuration =
                    new com.google.android.gms.ads.RequestConfiguration.Builder()
                            .setMaxAdContentRating(
                                    com.google.android.gms.ads.RequestConfiguration.MAX_AD_CONTENT_RATING_T)
                            .setTagForChildDirectedTreatment(
                                    com.google.android.gms.ads.RequestConfiguration
                                            .TAG_FOR_CHILD_DIRECTED_TREATMENT_FALSE)
                            .setTagForUnderAgeOfConsent(
                                    com.google.android.gms.ads.RequestConfiguration
                                            .TAG_FOR_UNDER_AGE_OF_CONSENT_UNSPECIFIED)
                            .build();
            com.google.android.gms.ads.MobileAds.setRequestConfiguration(configuration);
        } catch (Throwable ignored) {
            // La publicidad nunca debe bloquear el lector.
        }
    }

    private int currentBootCount() {
        if (Build.VERSION.SDK_INT < 24) return -1;
        try {
            return Settings.Global.getInt(getContentResolver(), Settings.Global.BOOT_COUNT, -1);
        } catch (Throwable ignored) {
            return -1;
        }
    }

    private void saveAdvancedAccessState(long remainingMs) {
        if (prefs == null) return;
        long safeRemaining = Math.max(0L, Math.min(ADVANCED_UNLOCK_DURATION_MS, remainingMs));
        prefs.edit()
                .putLong(PREF_ADVANCED_UNLOCK_REMAINING_MS, safeRemaining)
                .putLong(PREF_ADVANCED_UNLOCK_ELAPSED_BASE_MS, SystemClock.elapsedRealtime())
                .putLong(PREF_ADVANCED_UNLOCK_WALL_BASE_MS, System.currentTimeMillis())
                .putInt(PREF_ADVANCED_UNLOCK_BOOT_COUNT, currentBootCount())
                .remove(PREF_ADVANCED_UNLOCK_UNTIL)
                .apply();
    }

    /**
     * Migra un posible desbloqueo de v159. Si quedaban mas de 8 horas, se limita
     * al nuevo maximo de 8 horas para que toda la app use una sola regla.
     */
    private void migrateLegacyAdvancedAccessIfNeeded() {
        if (prefs == null || prefs.contains(PREF_ADVANCED_UNLOCK_REMAINING_MS)) return;
        long legacyUntil = prefs.getLong(PREF_ADVANCED_UNLOCK_UNTIL, 0L);
        long remaining = Math.max(0L, legacyUntil - System.currentTimeMillis());
        saveAdvancedAccessState(Math.min(ADVANCED_UNLOCK_DURATION_MS, remaining));
    }

    private boolean hasAdvancedAccess() {
        return advancedAccessRemainingMs() > 0L;
    }

    /**
     * Calcula el tiempo restante sin depender solo de la hora visible del telefono.
     * En el mismo arranque usa elapsedRealtime(), que no cambia aunque el usuario
     * adelante o atrase el reloj. Tras un reinicio usa la hora de pared solo para
     * descontar el tiempo transcurrido y nunca permite aumentar la recompensa.
     */
    private long advancedAccessRemainingMs() {
        if (prefs == null) return 0L;
        migrateLegacyAdvancedAccessIfNeeded();

        long savedRemaining = prefs.getLong(PREF_ADVANCED_UNLOCK_REMAINING_MS, 0L);
        if (savedRemaining <= 0L) return 0L;

        final long nowElapsed = SystemClock.elapsedRealtime();
        final long nowWall = System.currentTimeMillis();
        final long savedElapsed = prefs.getLong(PREF_ADVANCED_UNLOCK_ELAPSED_BASE_MS, -1L);
        final long savedWall = prefs.getLong(PREF_ADVANCED_UNLOCK_WALL_BASE_MS, -1L);
        final int savedBoot = prefs.getInt(PREF_ADVANCED_UNLOCK_BOOT_COUNT, -1);
        final int nowBoot = currentBootCount();

        boolean sameBoot;
        if (savedBoot >= 0 && nowBoot >= 0) {
            sameBoot = savedBoot == nowBoot;
        } else {
            // Android 6 no expone BOOT_COUNT. Se compara la hora aproximada de
            // arranque; si la hora manual cambio mucho se toma el camino seguro.
            long savedBootWall = (savedWall >= 0L && savedElapsed >= 0L)
                    ? savedWall - savedElapsed : Long.MIN_VALUE;
            long nowBootWall = nowWall - nowElapsed;
            sameBoot = savedElapsed >= 0L && nowElapsed >= savedElapsed
                    && savedBootWall != Long.MIN_VALUE
                    && Math.abs(nowBootWall - savedBootWall) <= 2L * 60L * 1000L;
        }

        long remaining;
        if (sameBoot && savedElapsed >= 0L && nowElapsed >= savedElapsed) {
            long passed = nowElapsed - savedElapsed;
            remaining = Math.max(0L, savedRemaining - passed);
        } else {
            // Reinicio o cambio de reloj sospechoso. Un atraso fuerte nunca da
            // tiempo extra: se invalida el desbloqueo. Pequenas correcciones de
            // red (hasta 2 min) se toleran sin aumentar savedRemaining.
            if (savedWall < 0L || nowWall + 2L * 60L * 1000L < savedWall) {
                remaining = 0L;
            } else {
                long passed = Math.max(0L, nowWall - savedWall);
                remaining = Math.max(0L, savedRemaining - passed);
            }
            // Normaliza las bases al nuevo arranque para las siguientes consultas.
            saveAdvancedAccessState(remaining);
        }

        if (remaining <= 0L) {
            saveAdvancedAccessState(0L);
            return 0L;
        }
        return Math.min(ADVANCED_UNLOCK_DURATION_MS, remaining);
    }

    private void grantAdvancedAccess() {
        saveAdvancedAccessState(ADVANCED_UNLOCK_DURATION_MS);
        scheduleAdvancedAccessExpiryRefresh();
        if (settingsMode && settingsSubscreen == 0) buildSettingsScreen();
    }

    private void checkpointAdvancedAccessState() {
        if (prefs == null) return;
        long remaining = advancedAccessRemainingMs();
        if (remaining > 0L) saveAdvancedAccessState(remaining);
    }

    private void cancelAdvancedAccessExpiryRefresh() {
        if (advancedAccessExpiryRunnable != null) {
            advancedAccessHandler.removeCallbacks(advancedAccessExpiryRunnable);
            advancedAccessExpiryRunnable = null;
        }
    }

    private void scheduleAdvancedAccessExpiryRefresh() {
        cancelAdvancedAccessExpiryRefresh();
        final long remaining = advancedAccessRemainingMs();
        if (remaining <= 0L) return;
        advancedAccessExpiryRunnable = new Runnable() {
            @Override
            public void run() {
                advancedAccessExpiryRunnable = null;
                if (advancedAccessRemainingMs() <= 0L
                        && settingsMode && settingsSubscreen == 0) {
                    buildSettingsScreen();
                }
            }
        };
        advancedAccessHandler.postDelayed(advancedAccessExpiryRunnable, remaining + 250L);
    }

    private String advancedAccessStatusText() {
        long remaining = advancedAccessRemainingMs();
        if (remaining <= 0L) return t("Bloqueado");
        long totalMinutes = Math.max(1L, (remaining + 59999L) / 60000L);
        long hours = totalMinutes / 60L;
        long minutes = totalMinutes % 60L;
        if (hours > 0L && minutes > 0L) {
            return t("Desbloqueado") + " · " + hours + " h " + minutes + " min";
        }
        if (hours > 0L) return t("Desbloqueado") + " · " + hours + " h";
        return t("Desbloqueado") + " · " + minutes + " min";
    }

    /**
     * Un solo anuncio recompensado desbloquea durante 8 horas:
     * - OCR para PDFs escaneados
     * - guardar audio
     * - guardar pagina como imagen
     * - exportar/guardar PDF
     * El resto del lector sigue gratis y nunca abre anuncios por sorpresa.
     */
    private void requireAdvancedAccess(final String feature, final Runnable action) {
        if (hasAdvancedAccess()) {
            if (action != null) action.run();
            return;
        }

        // Cuadro de desbloqueo completo: se dibuja entero aqui, titulo y botones
        // incluidos, para que no haya la franja de otro color que dejaba el
        // titulo del sistema ni los botones planos de AlertDialog.
        final int accent = Color.rgb(96, 165, 250);
        final int panelColor = darkTheme ? Color.rgb(10, 24, 38) : Color.WHITE;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(uiDp(22), uiDp(24), uiDp(22), uiDp(16));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setCornerRadius(uiDp(18));
        panelBg.setColor(panelColor);
        box.setBackground(panelBg);

        // Emblema: dos anillos concentricos y el candado abierto en el centro.
        FrameLayout emblemWrap = new FrameLayout(this);
        GradientDrawable outerRing = new GradientDrawable();
        outerRing.setShape(GradientDrawable.OVAL);
        outerRing.setColor(Color.argb(22, Color.red(accent), Color.green(accent), Color.blue(accent)));
        outerRing.setStroke(uiDp(1), Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent)));
        emblemWrap.setBackground(outerRing);

        FrameLayout innerWrap = new FrameLayout(this);
        GradientDrawable innerRing = new GradientDrawable();
        innerRing.setShape(GradientDrawable.OVAL);
        innerRing.setColor(Color.argb(46, Color.red(accent), Color.green(accent), Color.blue(accent)));
        innerRing.setStroke(uiDp(1), Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent)));
        innerWrap.setBackground(innerRing);
        SettingsIconView lock = new SettingsIconView(this);
        lock.setIconType("unlock");
        lock.setIconColor(accent);
        FrameLayout.LayoutParams lockLp = new FrameLayout.LayoutParams(uiDp(30), uiDp(30));
        lockLp.gravity = Gravity.CENTER;
        innerWrap.addView(lock, lockLp);
        FrameLayout.LayoutParams innerLp = new FrameLayout.LayoutParams(uiDp(58), uiDp(58));
        innerLp.gravity = Gravity.CENTER;
        emblemWrap.addView(innerWrap, innerLp);

        LinearLayout.LayoutParams emblemLp = new LinearLayout.LayoutParams(uiDp(84), uiDp(84));
        emblemLp.gravity = Gravity.CENTER_HORIZONTAL;
        emblemLp.bottomMargin = uiDp(14);
        box.addView(emblemWrap, emblemLp);

        TextView heading = new TextView(this);
        heading.setText(t(feature == null || feature.length() == 0
                ? "Desbloquear funciones avanzadas" : feature));
        heading.setTextSize(uiSp(20));
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setGravity(Gravity.CENTER);
        heading.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        box.addView(heading);

        TextView explanation = new TextView(this);
        explanation.setText(t("Mira un anuncio y desbloquea 8 horas."));
        explanation.setTextSize(uiSp(15));
        explanation.setGravity(Gravity.CENTER);
        explanation.setTextColor(darkTheme ? Color.rgb(178, 196, 214) : Color.rgb(71, 85, 105));
        explanation.setPadding(0, uiDp(6), 0, uiDp(14));
        box.addView(explanation);

        // Las cuatro funciones como chips, no como una lista de vinetas.
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setGravity(Gravity.CENTER);
        String[] names = new String[]{"OCR", "Audio", "Imagen", "PDF"};
        for (String name : names) {
            TextView chip = new TextView(this);
            chip.setText(t(name));
            chip.setTextSize(uiSp(12));
            chip.setTypeface(Typeface.DEFAULT_BOLD);
            chip.setTextColor(accent);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(uiDp(10), uiDp(6), uiDp(10), uiDp(6));
            GradientDrawable chipBg = new GradientDrawable();
            chipBg.setCornerRadius(uiDp(20));
            chipBg.setColor(Color.argb(28, Color.red(accent), Color.green(accent), Color.blue(accent)));
            chipBg.setStroke(uiDp(1), Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent)));
            chip.setBackground(chipBg);
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            chipLp.leftMargin = uiDp(3);
            chipLp.rightMargin = uiDp(3);
            chips.addView(chip, chipLp);
        }
        box.addView(chips, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView freeNote = new TextView(this);
        freeNote.setText(t("El resto sigue gratis."));
        freeNote.setTextSize(uiSp(12));
        freeNote.setGravity(Gravity.CENTER);
        freeNote.setTextColor(darkTheme ? Color.rgb(120, 142, 162) : Color.rgb(100, 116, 139));
        freeNote.setPadding(0, uiDp(14), 0, uiDp(18));
        box.addView(freeNote);

        // Botones propios: los de AlertDialog salen planos, en mayusculas y
        // pegados a la esquina. Aqui el principal es un boton relleno y el
        // secundario queda discreto, como en el resto de la app.
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER_VERTICAL);

        final TextView later = new TextView(this);
        later.setText(t("Ahora no"));
        later.setTextSize(uiSp(15));
        later.setGravity(Gravity.CENTER);
        later.setClickable(true);
        later.setFocusable(true);
        later.setTextColor(darkTheme ? Color.rgb(140, 160, 180) : Color.rgb(100, 116, 139));
        later.setPadding(uiDp(12), uiDp(12), uiDp(12), uiDp(12));

        final TextView watch = new TextView(this);
        watch.setText(t("Ver anuncio"));
        watch.setTextSize(uiSp(15));
        watch.setTypeface(Typeface.DEFAULT_BOLD);
        watch.setGravity(Gravity.CENTER);
        watch.setClickable(true);
        watch.setFocusable(true);
        watch.setTextColor(Color.WHITE);
        watch.setPadding(uiDp(18), uiDp(12), uiDp(18), uiDp(12));
        GradientDrawable watchBg = new GradientDrawable();
        watchBg.setCornerRadius(uiDp(24));
        watchBg.setColor(accent);
        watch.setBackground(watchBg);

        LinearLayout.LayoutParams laterLp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        buttons.addView(later, laterLp);
        buttons.addView(watch, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        box.addView(buttons, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(box)
                .create();
        try {
            if (dialog.getWindow() != null) {
                dialog.getWindow().clearFlags(
                        WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            }
        } catch (Exception ignored) {
        }
        watch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                pendingAdvancedAction = action;
                showOrLoadRewardedAd();
            }
        });
        later.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { dialog.dismiss(); }
        });
        dialog.show();
        styleDialog(dialog);
    }

    private void showOrLoadRewardedAd() {
        if (hasAdvancedAccess()) {
            Runnable action = pendingAdvancedAction;
            pendingAdvancedAction = null;
            if (action != null) action.run();
            return;
        }
        try {
            if (!consentFlowFinished) {
                // El toque no se tira: queda guardado y el anuncio se abre solo
                // en cuanto el tramite termine. Antes se perdia y el usuario se
                // quedaba mirando sin que pasara nada.
                resumeAdWhenConsentReady = true;
                Toast.makeText(this, t("Preparando el anuncio, un momento..."),
                        Toast.LENGTH_SHORT).show();
                startConsentFlowIfNeeded();
                return;
            }
            boolean allowed = consentInformation == null || consentInformation.canRequestAds();
            if (!allowed) {
                // En una instalacion nueva esto suele significar que la consulta
                // a Google no llego a completarse (por ejemplo, la red tardo un
                // instante), no que el usuario haya rechazado nada. Antes se
                // tiraba el toque y se soltaba un mensaje sobre "opciones de
                // privacidad" que nadie entiende. Ahora se rehace el tramite una
                // vez, conservando la accion, y el anuncio se abre solo.
                if (consentRetryCount < 1) {
                    consentRetryCount++;
                    resumeAdWhenConsentReady = true;
                    consentFlowStarted = false;
                    consentFlowFinished = false;
                    Toast.makeText(this, t("Preparando el anuncio, un momento..."),
                            Toast.LENGTH_SHORT).show();
                    startConsentFlowIfNeeded();
                    return;
                }
                pendingAdvancedAction = null;
                if (privacyOptionsRequired()) {
                    Toast.makeText(this,
                            t("Revisa tus opciones de anuncios para poder desbloquear."),
                            Toast.LENGTH_LONG).show();
                    showPrivacyOptionsForm();
                } else {
                    Toast.makeText(this,
                            t("No se pudo preparar el anuncio. Revisa tu conexión."),
                            Toast.LENGTH_LONG).show();
                }
                return;
            }
            consentRetryCount = 0;
            if (!adsInitialized) {
                adsInitialized = true;
                configureAdRequestsFor13PlusAudience();
                com.google.android.gms.ads.MobileAds.initialize(getApplicationContext());
            }
            if (rewardedAd != null) {
                showRewardedAdNow();
                return;
            }
            Toast.makeText(this, t("Preparando anuncio..."), Toast.LENGTH_SHORT).show();
            loadRewardedAdIfNeeded();
        } catch (Throwable e) {
            pendingAdvancedAction = null;
            Toast.makeText(this, t("No se pudo preparar el anuncio"), Toast.LENGTH_SHORT).show();
        }
    }

    private void loadRewardedAdIfNeeded() {
        if (!consentFlowFinished) return;
        if (hasAdvancedAccess() || rewardedAd != null || rewardedLoading || isFinishing()) return;
        try {
            boolean allowed = consentInformation == null || consentInformation.canRequestAds();
            if (!allowed) return;
            rewardedLoading = true;
            String unitId = USAR_ANUNCIOS_DE_PRUEBA ? REWARDED_DE_PRUEBA : REWARDED_AD_UNIT_ID;
            com.google.android.gms.ads.rewarded.RewardedAd.load(
                    this,
                    unitId,
                    new com.google.android.gms.ads.AdRequest.Builder().build(),
                    new com.google.android.gms.ads.rewarded.RewardedAdLoadCallback() {
                        @Override
                        public void onAdLoaded(com.google.android.gms.ads.rewarded.RewardedAd ad) {
                            rewardedLoading = false;
                            rewardedAd = ad;
                            if (pendingAdvancedAction != null && !hasAdvancedAccess()) {
                                showRewardedAdNow();
                            }
                        }

                        @Override
                        public void onAdFailedToLoad(com.google.android.gms.ads.LoadAdError error) {
                            rewardedLoading = false;
                            rewardedAd = null;
                            if (pendingAdvancedAction != null) {
                                pendingAdvancedAction = null;
                                Toast.makeText(MainActivity.this,
                                        t("No hay un anuncio disponible ahora. Inténtalo de nuevo."),
                                        Toast.LENGTH_LONG).show();
                            }
                        }
                    });
        } catch (Throwable e) {
            rewardedLoading = false;
            rewardedAd = null;
            if (pendingAdvancedAction != null) {
                pendingAdvancedAction = null;
                Toast.makeText(this, t("No se pudo preparar el anuncio"), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showRewardedAdNow() {
        final com.google.android.gms.ads.rewarded.RewardedAd ad = rewardedAd;
        if (ad == null || isFinishing()) {
            loadRewardedAdIfNeeded();
            return;
        }
        rewardedAd = null;
        rewardEarnedThisAd = false;
        ad.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                Runnable action = null;
                if (rewardEarnedThisAd && hasAdvancedAccess()) {
                    action = pendingAdvancedAction;
                }
                pendingAdvancedAction = null;
                rewardEarnedThisAd = false;
                loadRewardedAdIfNeeded();
                // Se deja un respiro para que la ventana del anuncio termine de
                // cerrarse antes de arrancar el guardado. Encadenarlos hacia que
                // la sombra del cierre cayera sobre la pantalla nueva.
                if (action != null) {
                    final Runnable pending = action;
                    audioStartHandler.postDelayed(new Runnable() {
                        @Override public void run() { pending.run(); }
                    }, 260L);
                }
            }

            @Override
            public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                pendingAdvancedAction = null;
                rewardEarnedThisAd = false;
                Toast.makeText(MainActivity.this,
                        t("No se pudo mostrar el anuncio. Inténtalo de nuevo."),
                        Toast.LENGTH_SHORT).show();
                loadRewardedAdIfNeeded();
            }
        });
        try {
            ad.show(this, new com.google.android.gms.ads.OnUserEarnedRewardListener() {
                @Override
                public void onUserEarnedReward(com.google.android.gms.ads.rewarded.RewardItem rewardItem) {
                    rewardEarnedThisAd = true;
                    grantAdvancedAccess();
                    Toast.makeText(MainActivity.this,
                            t("Funciones avanzadas desbloqueadas durante 8 horas"),
                            Toast.LENGTH_LONG).show();
                }
            });
        } catch (Throwable e) {
            pendingAdvancedAction = null;
            rewardEarnedThisAd = false;
            Toast.makeText(this, t("No se pudo mostrar el anuncio. Inténtalo de nuevo."),
                    Toast.LENGTH_SHORT).show();
            loadRewardedAdIfNeeded();
        }
    }

    /**
     * Vuelve a abrir el formulario de privacidad. La normativa exige que el
     * usuario pueda cambiar de opinion despues, asi que en Ajustes aparece esta
     * opcion cuando corresponde.
     */
    private void showPrivacyOptionsForm() {
        try {
            com.google.android.ump.UserMessagingPlatform.showPrivacyOptionsForm(this,
                    new com.google.android.ump.ConsentForm.OnConsentFormDismissedListener() {
                        @Override
                        public void onConsentFormDismissed(
                                com.google.android.ump.FormError formError) {
                            if (formError != null) {
                                Toast.makeText(MainActivity.this,
                                        t("No se pudo abrir el formulario"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        } catch (Throwable t) {
            Toast.makeText(this, t("No se pudo abrir el formulario"), Toast.LENGTH_SHORT).show();
        }
    }

    /** true solo donde la ley exige poder cambiar la eleccion de privacidad. */
    private boolean privacyOptionsRequired() {
        try {
            return consentInformation != null
                    && consentInformation.getPrivacyOptionsRequirementStatus()
                    == com.google.android.ump.ConsentInformation
                            .PrivacyOptionsRequirementStatus.REQUIRED;
        } catch (Throwable t) {
            return false;
        }
    }

    private void updateBannerStatusLabel() {
        if (bannerStatusLabel == null) return;
        // El hueco del banner queda SIEMPRE limpio: cuando hay anuncio, el AdView
        // lo tapa; cuando no hay (sin internet, sin anuncio disponible, sin
        // consentimiento o error), no se muestra ningun texto. Antes se veian
        // mensajes tecnicos feos como "Sin anuncio (0) Error while connecting to
        // ad server..." que no aportan nada al usuario. La carga del anuncio y el
        // flujo de consentimiento siguen funcionando igual; solo se oculta el
        // cartel de estado.
        bannerStatusLabel.setText("");
        bannerStatusLabel.setVisibility(View.GONE);
    }

    private void resumeBannerAd() {
        try { if (bannerAdView != null) bannerAdView.resume(); } catch (Throwable ignored) { }
    }

    private void pauseBannerAd() {
        try { if (bannerAdView != null) bannerAdView.pause(); } catch (Throwable ignored) { }
    }

    private void destroyBannerAd() {
        try {
            if (bannerAdView != null) {
                if (bannerAdView.getParent() instanceof android.view.ViewGroup) {
                    ((android.view.ViewGroup) bannerAdView.getParent()).removeView(bannerAdView);
                }
                bannerAdView.destroy();
            }
        } catch (Throwable ignored) {
        } finally {
            bannerAdView = null;
        }
    }

    private void applyBannerVisibility() {
        if (bannerSlot != null) {
            // En horizontal el banner se esconde: la altura de pantalla es corta
            // y ese espacio le hace mucha mas falta a la pagina.
            boolean show = bannerVisible && !isLandscape();
            bannerSlot.setVisibility(show ? View.VISIBLE : View.GONE);
        }
        // La pagina se mantiene centrada tenga o no banner. Alinearla arriba
        // dejaba las paginas anchas (portadas e ilustraciones) pegadas al techo
        // con un hueco blanco enorme debajo.
        if (pdfView != null) {
            pdfView.setAlignPageTop(false);
        }
    }


    private int getPdfWorkspaceColor() {
        // El espacio libre del visor usa el mismo fondo que el resto de la app.
        // Asi, cuando una pagina es solo una ilustracion que no llena la hoja,
        // lo que sobra se funde con la interfaz en vez de mostrar una plancha
        // blanca.
        return darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248);
    }

    private Button makeButton(String text) {
        Button button = new Button(this);
        button.setText(t(text));
        button.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        button.setTextSize(uiSp(16));
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setPadding(uiDp(4), 0, uiDp(4), 0);
        if (darkTheme) {
            button.setBackgroundColor(Color.rgb(11, 60, 88));
        } else {
            GradientDrawable lightBg = new GradientDrawable();
            lightBg.setCornerRadius(uiDp(8));
            lightBg.setColor(Color.rgb(226, 239, 255));
            lightBg.setStroke(uiDp(1), Color.rgb(147, 178, 240));
            button.setBackground(lightBg);
        }
        return button;
    }

    /**
     * Boton de la barra superior ("Abrir", "Reglas ON/OFF"): texto plano, sin
     * bloque de color de fondo, del mismo color que el titulo del PDF y el
     * numero de pagina para que no se note como un color aparte pegado en la
     * barra. El resto de los botones de la app siguen usando makeButton().
     */
    private Button makeTopBarButton(String text) {
        Button button = new Button(this);
        button.setText(t(text));
        button.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        button.setTextSize(uiSp(16));
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setPadding(uiDp(4), 0, uiDp(4), 0);
        button.setBackgroundColor(Color.TRANSPARENT);
        return button;
    }



    private void showSettings() {
        // Un segundo toque en menos de 400 ms no abre otra copia de esta pantalla.
        if (!acceptTap("showSettings")) return;
        settingsMode = true;
        settingsSubscreen = 0;
        settingsNeedsMainRebuild = false;
        buildSettingsScreen();
    }

    private String formatSpeed() {
        return String.format(Locale.US, "%.2fx", speechRate);
    }


    private String getVoiceSummary() {
        TtsEngineManager manager = TtsEngineManager.getInstance(this);
        String engine = manager.getActiveEnginePackage();
        if (engine != null && engine.length() > 0 && manager.isReady()) {
            return "Listo: " + engine;
        }
        String status = manager.getStatusText();
        if (status != null && status.startsWith(TtsForegroundService.ERROR_MISSING_VOICE_PREFIX)) {
            return t("Falta una voz");
        }
        return status == null || status.length() == 0 ? "Preparando motor" : status;
    }

    private void showVoicesScreen() {
        settingsMode = true;
        settingsSubscreen = 4;
        // Al entrar a Voces se vuelve a preguntar al motor una sola vez, por si
        // el usuario instalo voces nuevas. Dentro de la pantalla ya se reutiliza
        // ese listado para que tocar una voz responda al instante.
        TtsEngineManager.getInstance(this).refreshVoiceCache();

        final LinearLayout screen = makeSettingsSubscreenBase(t("Voces"), new View.OnClickListener() {
            @Override public void onClick(View v) { buildSettingsScreen(); }
        });
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(uiDp(16), uiDp(12), uiDp(16), uiDp(20));

        TextView info = new TextView(this);
        info.setText(t("Comprueba qué voces están listas para leer PDFs."));
        info.setTextColor(darkTheme ? Color.rgb(191, 205, 220) : Color.rgb(71, 85, 105));
        info.setTextSize(uiSp(14));
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        infoLp.bottomMargin = uiDp(14);
        content.addView(info, infoLp);

        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        final String[] codes = new String[]{UiStrings.ES, UiStrings.EN, UiStrings.PT, UiStrings.HI, UiStrings.ID};
        final String[] flags = new String[]{"ES", "US", "BR", "IN", "ID"};
        final String[] names = new String[]{"Español", "English", "Português (Brasil)",
                "हिन्दी — Hindi", "Bahasa Indonesia"};
        boolean managerReady = manager.isReady();
        boolean needsDownload = false;

        for (int i = 0; i < codes.length; i++) {
            final String code = codes[i];
            TtsEngineManager.VoiceAvailability availability = manager.getVoiceAvailability(code, appRegion);
            String status;
            boolean canDownload;
            if (!managerReady) {
                status = t("Comprobando voces...");
                canDownload = false;
            } else if (availability.offlineVoice) {
                status = t("Instalada");
                canDownload = false;
            } else if (availability.networkOnly) {
                status = t("Solo en línea");
                canDownload = true;
                needsDownload = true;
            } else {
                status = t("Falta descargar");
                canDownload = true;
                needsDownload = true;
            }

            final boolean voiceInstalled = managerReady && availability.offlineVoice;
            LinearLayout row = makeDesign3MenuCard("flag:" + flags[i], names[i], status,
                    canDownload || voiceInstalled);
            if (canDownload) {
                final String downloadLanguage = code;
                row.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        launchTtsVoiceInstaller(downloadLanguage);
                    }
                });
            } else if (voiceInstalled) {
                final String voiceLanguageCode = code;
                final String voiceLanguageName = names[i];
                row.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        showVoiceChoiceScreen(voiceLanguageCode, voiceLanguageName);
                    }
                });
            }
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, uiDp(64));
            rowLp.bottomMargin = uiDp(8);
            content.addView(row, rowLp);
        }

        if (managerReady && needsDownload) {
            Button download = makeButton("Descargar voces faltantes");
            download.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { launchTtsVoiceInstaller(); }
            });
            LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, uiDp(52));
            buttonLp.topMargin = uiDp(8);
            content.addView(download, buttonLp);
        }

        scroll.addView(content, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        screen.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        presentSettingsSubscreen(screen);

        if (!managerReady && !voicesInventoryLoading) {
            voicesInventoryLoading = true;
            final String languageToRestore = currentPdfLanguage;
            manager.setPreferredLanguage("", appRegion);
            manager.initialize(new TtsEngineManager.ReadyCallback() {
                @Override
                public void onReady(String enginePackage) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            voicesInventoryLoading = false;
                            if (languageToRestore.length() > 0) {
                                manager.setPreferredLanguage(languageToRestore, appRegion);
                            }
                            if (settingsMode && settingsSubscreen == 4) showVoicesScreen();
                        }
                    });
                }

                @Override
                public void onError(String message) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            voicesInventoryLoading = false;
                            if (languageToRestore.length() > 0) {
                                manager.setPreferredLanguage(languageToRestore, appRegion);
                            }
                            if (settingsMode && settingsSubscreen == 4) showVoicesScreen();
                        }
                    });
                }
            });
        }
    }

    private void showVoiceChoiceScreen(final String languageCode, final String languageName) {
        settingsMode = true;
        settingsSubscreen = 8;

        final LinearLayout screen = makeSettingsSubscreenBase(languageName, new View.OnClickListener() {
            @Override public void onClick(View v) { showVoicesScreen(); }
        });
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(uiDp(16), uiDp(12), uiDp(16), uiDp(20));

        // Aviso honesto: la primera reproduccion de cada voz la carga el motor
        // de Android, no la app. Antes era un texto gris chico que casi no se
        // veia; ahora es una tarjeta de alerta con el mismo cuerpo que las
        // opciones de voz, para que se lea de una.
        TextView firstTapNote = new TextView(this);
        firstTapNote.setText("⚠  " + t("La primera voz tarda unos segundos en sonar. Después suena al instante."));
        firstTapNote.setTextColor(darkTheme ? Color.rgb(254, 226, 226) : Color.rgb(127, 29, 29));
        firstTapNote.setTextSize(uiSp(14));
        firstTapNote.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        firstTapNote.setGravity(Gravity.CENTER);
        firstTapNote.setPadding(uiDp(14), uiDp(12), uiDp(14), uiDp(12));
        GradientDrawable noteBg = new GradientDrawable();
        noteBg.setCornerRadius(uiDp(16));
        noteBg.setColor(darkTheme ? Color.rgb(74, 22, 22) : Color.rgb(254, 226, 226));
        noteBg.setStroke(uiDp(2), Color.rgb(220, 38, 38));
        firstTapNote.setBackground(noteBg);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        noteLp.bottomMargin = uiDp(14);
        content.addView(firstTapNote, noteLp);

        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        // Las filas se guardan para poder mover la marca de seleccion sin
        // reconstruir la pantalla entera en cada toque. Rearmar veinte tarjetas
        // en el hilo de interfaz justo cuando el motor arranca la muestra era lo
        // que hacia sentir lenta y dura la eleccion de voz.
        final java.util.ArrayList<View> voiceRows = new java.util.ArrayList<View>();
        final java.util.ArrayList<String> voiceRowNames = new java.util.ArrayList<String>();
        String manualName = manager.getManualVoiceName(languageCode);
        boolean isAutomatic = manualName == null || manualName.length() == 0;
        java.util.List<TtsEngineManager.VoiceOption> options =
                manager.getVoiceOptionsForLanguage(languageCode, appRegion);

        View autoRow = makeVoiceOptionRow(t("Automática (recomendada)"),
                t("La app elige la mejor disponible"), isAutomatic);
        voiceRows.add(autoRow);
        voiceRowNames.add("");
        autoRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                manager.setManualVoice(languageCode, "");
                markSelectedVoiceRow(voiceRows, voiceRowNames, "");
            }
        });
        LinearLayout.LayoutParams autoLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(64));
        autoLp.bottomMargin = uiDp(8);
        content.addView(autoRow, autoLp);

        if (options.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(t("No hay más de una voz instalada para este idioma en el teléfono."));
            empty.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
            empty.setTextSize(uiSp(13));
            empty.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams emptyLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            emptyLp.topMargin = uiDp(18);
            content.addView(empty, emptyLp);
        } else {
            // Cuenta repeticiones del mismo pais para numerarlas cuando el
            // telefono tiene mas de una voz de esa misma variante.
            java.util.Map<String, Integer> total = new java.util.HashMap<String, Integer>();
            for (TtsEngineManager.VoiceOption option : options) {
                String base = option.countryLabel != null && option.countryLabel.length() > 0
                        ? option.countryLabel : t("Voz del sistema");
                Integer count = total.get(base);
                total.put(base, count == null ? 1 : count + 1);
            }
            java.util.Map<String, Integer> seen = new java.util.HashMap<String, Integer>();
            for (final TtsEngineManager.VoiceOption option : options) {
                String base = option.countryLabel != null && option.countryLabel.length() > 0
                        ? option.countryLabel : t("Voz del sistema");
                String label = base;
                if (total.get(base) != null && total.get(base) > 1) {
                    int index = seen.containsKey(base) ? seen.get(base) + 1 : 1;
                    seen.put(base, index);
                    label = base + " " + index;
                }
                View row = makeVoiceOptionRow(label, null, option.selected);
                voiceRows.add(row);
                voiceRowNames.add(option.voiceName);
                row.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        // Primero la marca, que es instantanea y le da respuesta
                        // inmediata al dedo. Despues la muestra.
                        markSelectedVoiceRow(voiceRows, voiceRowNames, option.voiceName);
                        manager.selectAndTestVoice(languageCode, option.voiceName,
                                voiceTestText(languageCode),
                                new TtsEngineManager.TestCallback() {
                                    @Override public void onStarted() { }

                                    @Override public void onCompleted() { }

                                    @Override public void onError(final String message) {
                                        // Sin avisos: cambiar de voz rapido corta
                                        // la muestra anterior y eso es normal.
                                    }
                                });
                    }
                });
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, uiDp(64));
                rowLp.bottomMargin = uiDp(8);
                content.addView(row, rowLp);
            }
        }

        scroll.addView(content, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        screen.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        presentSettingsSubscreen(screen);
    }

    /**
     * Mueve la marca de seleccion entre las filas de voces sin volver a crear la
     * pantalla. Solo cambia el fondo y el circulo de cada tarjeta, que es un
     * repintado barato: el dedo recibe respuesta en el mismo instante y el motor
     * de voz se queda con todo el hilo para arrancar la muestra.
     */
    private void markSelectedVoiceRow(java.util.List<View> rows,
                                      java.util.List<String> names, String selectedName) {
        if (rows == null || names == null) return;
        String target = selectedName == null ? "" : selectedName;
        int count = Math.min(rows.size(), names.size());
        for (int i = 0; i < count; i++) {
            String name = names.get(i) == null ? "" : names.get(i);
            applyVoiceRowSelection(rows.get(i), target.equals(name));
        }
    }

    private void applyVoiceRowSelection(View rowView, boolean selected) {
        if (!(rowView instanceof LinearLayout)) return;
        LinearLayout row = (LinearLayout) rowView;

        GradientDrawable bg;
        if (selected) {
            bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.rgb(37, 99, 235), Color.rgb(29, 78, 216)});
            bg.setCornerRadius(uiDp(16));
            bg.setStroke(uiDp(1), Color.rgb(96, 165, 250));
        } else {
            bg = new GradientDrawable();
            bg.setCornerRadius(uiDp(16));
            bg.setColor(Color.rgb(8, 31, 51));
            bg.setStroke(uiDp(1), Color.rgb(31, 65, 88));
        }
        row.setBackground(bg);

        int childCount = row.getChildCount();
        if (childCount > 0) {
            View words = row.getChildAt(0);
            if (words instanceof LinearLayout && ((LinearLayout) words).getChildCount() > 1) {
                View note = ((LinearLayout) words).getChildAt(1);
                if (note instanceof TextView) {
                    ((TextView) note).setTextColor(
                            selected ? Color.WHITE : Color.rgb(203, 213, 225));
                }
            }
            View last = row.getChildAt(childCount - 1);
            if (last instanceof TextView) {
                TextView marker = (TextView) last;
                marker.setText(selected ? "✓" : "○");
                marker.setTextColor(selected ? Color.WHITE : Color.rgb(148, 163, 184));
                marker.setTextSize(uiSp(selected ? 20f : 24f));
                if (selected) {
                    GradientDrawable markerBg = new GradientDrawable();
                    markerBg.setShape(GradientDrawable.OVAL);
                    markerBg.setColor(Color.rgb(59, 130, 246));
                    marker.setBackground(markerBg);
                } else {
                    marker.setBackground(null);
                }
            }
        }
    }

    private View makeVoiceOptionRow(String name, String note, boolean selected) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(16), 0, uiDp(12), 0);
        row.setClickable(true);
        row.setFocusable(true);

        GradientDrawable bg;
        if (selected) {
            bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.rgb(37, 99, 235), Color.rgb(29, 78, 216)});
            bg.setCornerRadius(uiDp(16));
            bg.setStroke(uiDp(1), Color.rgb(96, 165, 250));
        } else {
            bg = new GradientDrawable();
            bg.setCornerRadius(uiDp(16));
            bg.setColor(Color.rgb(8, 31, 51));
            bg.setStroke(uiDp(1), Color.rgb(31, 65, 88));
        }
        row.setBackground(bg);

        LinearLayout words = new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams wordsLp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        row.addView(words, wordsLp);

        TextView nameView = new TextView(this);
        nameView.setText(name);
        nameView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        nameView.setTextSize(uiSp(16));
        nameView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        nameView.setMaxLines(1);
        nameView.setEllipsize(TextUtils.TruncateAt.END);
        words.addView(nameView);

        if (note != null && note.length() > 0) {
            TextView noteView = new TextView(this);
            noteView.setText(note);
            noteView.setTextColor(selected ? Color.WHITE : Color.rgb(203, 213, 225));
            noteView.setTextSize(uiSp(11));
            noteView.setMaxLines(1);
            words.addView(noteView);
        }

        TextView marker = new TextView(this);
        marker.setText(selected ? "✓" : "○");
        marker.setTextColor(selected ? Color.WHITE : Color.rgb(148, 163, 184));
        marker.setTextSize(uiSp(selected ? 20f : 24f));
        marker.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        marker.setGravity(Gravity.CENTER);
        if (selected) {
            GradientDrawable markerBg = new GradientDrawable();
            markerBg.setShape(GradientDrawable.OVAL);
            markerBg.setColor(Color.rgb(59, 130, 246));
            marker.setBackground(markerBg);
        }
        row.addView(marker, new LinearLayout.LayoutParams(uiDp(32), uiDp(32)));
        return row;
    }

    private void launchTtsVoiceInstaller() {
        openTtsVoiceInstaller("");
    }

    /**
     * Android no deja que una app descargue voces por su cuenta ni permite
     * pedirle al instalador un idioma concreto: siempre abre su lista completa.
     * Lo unico que podemos hacer para que no sea una busqueda a ciegas es decir
     * antes, con el nombre exacto que va a aparecer, que hay que tocar.
     */
    private void launchTtsVoiceInstaller(String languageCode) {
        final String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (language.length() == 0 || isFinishing()
                || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) {
            openTtsVoiceInstaller(language);
            return;
        }
        String message = t("Se abrirá la lista de voces de Android. Busca esta y tócala:")
                + "\n\n" + TtsEngineManager.systemVoiceLabel(language) + "\n\n"
                + t("Cuando termine la descarga, vuelve aquí con el botón atrás.");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Descargar voz"))
                .setMessage(message)
                .setPositiveButton(t("Abrir la lista"), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        openTtsVoiceInstaller(language);
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void openTtsVoiceInstaller(String languageCode) {
        try {
            pendingVoiceInstallLanguage = PdfLanguageDetector.normalizeCode(languageCode);
            waitingForTtsDataInstall = true;
            Intent intent = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
            startActivity(intent);
        } catch (Exception e) {
            waitingForTtsDataInstall = false;
            pendingVoiceInstallLanguage = "";
            Toast.makeText(this, t("No se encontró el instalador de voces"), Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Al volver del instalador se comprueba si la voz llego de verdad, para no
     * dejar al usuario adivinando. Se intenta dos veces porque el motor tarda un
     * momento en publicar las voces recien descargadas.
     */
    private void confirmVoiceInstallResult(final String languageCode, final int attempt) {
        if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        final String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (language.length() == 0) return;

        TtsEngineManager manager = TtsEngineManager.getInstance(this);
        manager.refreshVoiceCache();
        TtsEngineManager.VoiceAvailability availability =
                manager.getVoiceAvailability(language, appRegion);

        if (availability.engineReady && availability.offlineVoice) {
            Toast.makeText(this,
                    t("Voz instalada") + ": " + UiStrings.languageName(language),
                    Toast.LENGTH_LONG).show();
            if (settingsMode && settingsSubscreen == 4) showVoicesScreen();
            return;
        }

        if (attempt < 1) {
            audioStartHandler.postDelayed(new Runnable() {
                @Override public void run() { confirmVoiceInstallResult(language, attempt + 1); }
            }, 2000L);
            return;
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("La voz sigue sin aparecer"))
                .setMessage(t("No se descargó la voz de") + " "
                        + UiStrings.languageName(language) + ". "
                        + t("Busca en la lista el nombre") + " \"" 
                        + TtsEngineManager.systemVoiceLabel(language) + "\". "
                        + t("Si tu motor de voz no la tiene, prueba con otro motor desde Ajustes."))
                .setPositiveButton(t("Abrir la lista"), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        openTtsVoiceInstaller(language);
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
        if (settingsMode && settingsSubscreen == 4) showVoicesScreen();
    }

    private void showMissingVoiceDialog(String languageCode) {
        final String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (!PdfLanguageDetector.isSupported(language) || isFinishing()
                || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        // Mensaje compacto en una sola linea: el cuadro tapa mucho menos del PDF.
        String message = t("Falta la voz para leer este PDF.")
                + " (" + UiStrings.languageName(language) + ")\n\n"
                + t("Se abrirá la lista de voces de Android. Busca esta y tócala:")
                + "\n" + TtsEngineManager.systemVoiceLabel(language);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Falta una voz"))
                .setMessage(message)
                .setPositiveButton(t("Descargar voz"), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialogInterface, int which) {
                        openTtsVoiceInstaller(language);
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void showVoiceEngineDialog() {
        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        final java.util.List<TtsEngineManager.EngineChoice> engines = manager.getInstalledEngines();
        final String[] labels = new String[engines.size() + 1];
        final String[] packages = new String[engines.size() + 1];
        labels[0] = t("Automatico (recomendado)");
        packages[0] = "";
        for (int i = 0; i < engines.size(); i++) {
            TtsEngineManager.EngineChoice item = engines.get(i);
            labels[i + 1] = t(item.label) + "\n" + item.packageName;
            packages[i + 1] = item.packageName;
        }

        String selectedPackage = prefs.getString(TtsEngineManager.PREF_ENGINE_PACKAGE, "");
        int selected = 0;
        for (int i = 1; i < packages.length; i++) {
            if (packages[i].equals(selectedPackage)) {
                selected = i;
                break;
            }
        }

        new AlertDialog.Builder(this)
                .setTitle(t("Motor de voz"))
                .setSingleChoiceItems(labels, selected, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        manager.selectEngine(packages[which]);
                        Toast.makeText(MainActivity.this,
                                t("Preparando " + labels[which].replace("\n", " ")),
                                Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                })
                .setNeutralButton(t("Reintentar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        manager.retryInitialization();
                        Toast.makeText(MainActivity.this,
                                t("Reiniciando el motor de voz"), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .show();
    }

    private String voiceTestText(String languageCode) {
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        // Frase unica y corta: la muestra tiene que sonar y terminar rapido para
        // poder saltar de una voz a otra sin esperar.
        if (UiStrings.EN.equals(language)) {
            return "This is a voice test.";
        }
        if (UiStrings.PT.equals(language)) {
            return "Este é um teste de voz.";
        }
        if (UiStrings.HI.equals(language)) {
            return "यह आवाज़ की जाँच है।";
        }
        if (UiStrings.ID.equals(language)) {
            return "Ini adalah uji suara.";
        }
        return "Esta es una prueba de voz.";
    }

    private void showSpeedDialog() {
        final String[] labels = new String[]{"0.75x", "1.0x", "1.25x", "1.5x", "1.75x", "2.0x"};
        final float[] values = new float[]{0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f};

        int selected = 1;
        for (int i = 0; i < values.length; i++) {
            if (Math.abs(values[i] - speechRate) < 0.01f) {
                selected = i;
                break;
            }
        }

        new AlertDialog.Builder(this)
                .setTitle(t("Velocidad de lectura"))
                .setSingleChoiceItems(labels, selected, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        speechRate = values[which];
                        prefs.edit().putFloat("speech_rate", speechRate).apply();
                        Toast.makeText(MainActivity.this, t("Velocidad: " + labels[which]), Toast.LENGTH_SHORT).show();

                        if (audioStarted && !audioPaused) {
                            startAudioFromPage(currentPage);
                        }

                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .show();
    }

    private void closeSettings() {
        settingsMode = false;
        settingsSubscreen = 0;

        if (!settingsNeedsMainRebuild && screenHost != null) {
            if (settingsOverlay != null && settingsOverlay.getParent() == screenHost) {
                screenHost.removeView(settingsOverlay);
            }
            settingsOverlay = null;
            if (screenHost.getParent() == null) {
                setContentView(screenHost);
            }
            if (pdfView != null) {
                pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
                pdfView.setReadingMarkerEnabled(!currentOcrMode && readingMarkerEnabled);
                pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
                pdfView.setWorkspaceColor(getPdfWorkspaceColor());
                pdfView.setMarkStyle(markStyle);
                pdfView.setMarkThickness(markThicknessLevel);
                pdfView.setMarkColor(getCurrentMarkColor());
                pdfView.setMarkMode(!currentOcrMode && markMode);
                pdfView.invalidate();
            }
            updatePageLabel();
            updateMarkControls();
            applyReadingBrightness();
            return;
        }

        settingsNeedsMainRebuild = false;
        File file = currentFile;
        String title = currentTitle;
        int page = currentPage;
        boolean hadDocument = file != null && file.exists();
        buildUi();
        if (hadDocument) {
            // Mismo caso que el cambio de tema: la vista recien creada no tiene
            // nada dibujado todavia, asi que se oculta el cartel vacio para que
            // no aparezca "Abrir un PDF" mientras se reabre el documento (por
            // ejemplo, al volver de cambiar el idioma en Ajustes).
            if (pdfView != null) {
                pdfView.setSuppressEmptyLabel(true);
                if (titleView != null) titleView.setText(title == null ? "PDF" : title);
            }
            openLocalPdfAtPage(file, title, page);
        }
    }

    private void showLanguageRegionSettingsScreen() {
        settingsMode = true;
        settingsSubscreen = 1;

        LinearLayout screen = makeSettingsSubscreenBase(t("Idioma y región"), new View.OnClickListener() {
            @Override public void onClick(View v) { buildSettingsScreen(); }
        });

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(uiDp(16), uiDp(14), uiDp(16), uiDp(22));

        TextView intro = new TextView(this);
        intro.setText(t("Idioma y región"));
        intro.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        intro.setTextSize(uiSp(22));
        intro.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        content.addView(intro);

        TextView description = new TextView(this);
        description.setText(t("Configura el idioma de la interfaz y tu país o región."));
        description.setTextColor(darkTheme ? Color.rgb(191, 205, 220) : Color.rgb(71, 85, 105));
        description.setTextSize(uiSp(13));
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        descLp.topMargin = uiDp(5);
        descLp.bottomMargin = uiDp(18);
        content.addView(description, descLp);

        LinearLayout languageCard = makeDesign3MenuCard("flag:" + languageFlagCode(appLanguage),
                t("Idioma de la aplicación"), UiStrings.languageName(appLanguage), true);
        languageCard.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSettingsLanguageScreen(); }
        });
        content.addView(languageCard, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(66)));

        LinearLayout regionCard = makeDesign3MenuCard("flag:" + appRegion,
                t("País / Región"), UiStrings.regionName(appRegion, appLanguage), true);
        regionCard.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSettingsRegionScreen(); }
        });
        LinearLayout.LayoutParams regionLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(66));
        regionLp.topMargin = uiDp(10);
        content.addView(regionCard, regionLp);

        TextView ready = new TextView(this);
        ready.setText(t("La región ayuda a elegir el acento de voz cuando está disponible."));
        ready.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        ready.setTextSize(uiSp(12));
        ready.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams readyLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        readyLp.topMargin = uiDp(16);
        content.addView(ready, readyLp);

        screen.addView(content, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        presentSettingsSubscreen(screen);
    }

    private void showSettingsLanguageScreen() {
        // Un segundo toque en menos de 400 ms no abre otra copia de esta pantalla.
        if (!acceptTap("showSettingsLanguageScreen")) return;
        settingsMode = true;
        settingsSubscreen = 2;

        LinearLayout screen = makeSettingsSubscreenBase(t("Idioma de la aplicación"), new View.OnClickListener() {
            @Override public void onClick(View v) { showLanguageRegionSettingsScreen(); }
        });

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(uiDp(16), uiDp(12), uiDp(16), uiDp(18));

        TextView globe = makeRoundHeaderIcon("🌐");
        content.addView(globe, new LinearLayout.LayoutParams(uiDp(54), uiDp(54)));

        TextView title = new TextView(this);
        title.setText(t("Elige tu idioma"));
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setTextSize(uiSp(25));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleLp.topMargin = uiDp(8);
        content.addView(title, titleLp);

        TextView info = new TextView(this);
        info.setText(t("Puedes cambiarlo cuando quieras desde Ajustes."));
        info.setTextColor(darkTheme ? Color.rgb(191, 205, 220) : Color.rgb(71, 85, 105));
        info.setTextSize(uiSp(14));
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        infoLp.topMargin = uiDp(5);
        infoLp.bottomMargin = uiDp(16);
        content.addView(info, infoLp);

        final String[] codes = new String[]{UiStrings.ES, UiStrings.EN, UiStrings.PT, UiStrings.HI, UiStrings.ID};
        final String[] flagCodes = new String[]{"ES", "US", "BR", "IN", "ID"};
        final String[] names = new String[]{"Español", "English", "Português (Brasil)", "हिन्दी — Hindi", "Bahasa Indonesia"};
        final String deviceLanguage = UiStrings.detectDeviceLanguage();

        for (int i = 0; i < codes.length; i++) {
            final String code = codes[i];
            String note = code.equals(deviceLanguage) ? t("Idioma del dispositivo") : "";
            View option = makeDesign3SelectionRow(flagCodes[i], names[i], note,
                    code.equals(UiStrings.normalize(appLanguage)));
            option.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!code.equals(UiStrings.normalize(appLanguage))) {
                        appLanguage = code;
                        if (ocrTextRepository != null) ocrTextRepository.setPreferDevanagari("hi".equals(appLanguage));
                        prefs.edit()
                                .putString(UiStrings.PREF_LANGUAGE, code)
                                .putBoolean(UiStrings.PREF_LANGUAGE_CHOSEN, true)
                                .apply();
                        settingsNeedsMainRebuild = true;
                    }
                    showSettingsLanguageScreen();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, uiDp(58));
            lp.bottomMargin = uiDp(8);
            content.addView(option, lp);
        }

        screen.addView(content, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        presentSettingsSubscreen(screen);
    }

    private void showSettingsRegionScreen() {
        // Un segundo toque en menos de 400 ms no abre otra copia de esta pantalla.
        if (!acceptTap("showSettingsRegionScreen")) return;
        settingsMode = true;
        settingsSubscreen = 3;

        final LinearLayout screen = makeSettingsSubscreenBase(t("País / Región"), new View.OnClickListener() {
            @Override public void onClick(View v) { showLanguageRegionSettingsScreen(); }
        });
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(uiDp(16), uiDp(10), uiDp(16), uiDp(16));

        final EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("🔎  " + t("Buscar país..."));
        search.setTextSize(uiSp(16));
        search.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        search.setHintTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        search.setPadding(uiDp(16), 0, uiDp(16), 0);
        GradientDrawable searchBg = new GradientDrawable();
        searchBg.setCornerRadius(uiDp(18));
        searchBg.setColor(Color.rgb(8, 31, 51));
        searchBg.setStroke(uiDp(1), Color.rgb(37, 84, 120));
        search.setBackground(searchBg);
        body.addView(search, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(52)));

        LinearLayout regionStatus = new LinearLayout(this);
        regionStatus.setOrientation(LinearLayout.HORIZONTAL);
        regionStatus.setGravity(Gravity.CENTER_VERTICAL);
        regionStatus.setPadding(uiDp(4), 0, uiDp(4), 0);
        LinearLayout currentBox = new LinearLayout(this);
        currentBox.setOrientation(LinearLayout.HORIZONTAL);
        currentBox.setGravity(Gravity.CENTER_VERTICAL);

        TextView currentPrefix = new TextView(this);
        currentPrefix.setText(t("Región actual") + ":");
        currentPrefix.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        currentPrefix.setTextSize(uiSp(14));
        currentPrefix.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        currentPrefix.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams currentPrefixLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        currentPrefixLp.gravity = Gravity.CENTER_VERTICAL;
        currentBox.addView(currentPrefix, currentPrefixLp);

        ImageView currentFlag = makeFlagImageView(appRegion);
        LinearLayout.LayoutParams currentFlagLp = new LinearLayout.LayoutParams(uiDp(28), uiDp(19));
        currentFlagLp.leftMargin = uiDp(6);
        currentFlagLp.rightMargin = uiDp(6);
        currentFlagLp.gravity = Gravity.CENTER_VERTICAL;
        currentBox.addView(currentFlag, currentFlagLp);

        TextView currentName = new TextView(this);
        currentName.setText(UiStrings.regionName(appRegion, appLanguage));
        currentName.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        currentName.setTextSize(uiSp(14));
        currentName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        currentName.setSingleLine(true);
        currentName.setEllipsize(TextUtils.TruncateAt.END);
        currentName.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams currentNameLp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        currentNameLp.gravity = Gravity.CENTER_VERTICAL;
        currentBox.addView(currentName, currentNameLp);

        regionStatus.addView(currentBox, new LinearLayout.LayoutParams(0, uiDp(42), 1));
        TextView total = new TextView(this);
        total.setText(t("28 países"));
        total.setTextColor(darkTheme ? Color.rgb(96, 165, 250) : Color.rgb(29, 78, 216));
        total.setTextSize(uiSp(13));
        total.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        total.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        regionStatus.addView(total, new LinearLayout.LayoutParams(uiDp(100), uiDp(42)));
        body.addView(regionStatus, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(42)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        body.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        populateRegionRows(list, "");
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                populateRegionRows(list, s == null ? "" : s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        screen.addView(body, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        presentSettingsSubscreen(screen);
    }

    private void populateRegionRows(LinearLayout list, String query) {
        populateRegionRows(list, query, false);
    }

    private void populateRegionRows(LinearLayout list, String query, final boolean finishInitialSelection) {
        list.removeAllViews();
        String normalizedQuery = normalizeSearchText(query);
        int matches = 0;
        for (String code : UiStrings.regionCodes()) {
            final String regionCode = code;
            String name = UiStrings.regionName(code, appLanguage);
            String searchable = normalizeSearchText(name + " " + code);
            if (normalizedQuery.length() > 0 && !searchable.contains(normalizedQuery)) continue;

            View row = makeSettingsSelectionRow(code, name, code.equals(appRegion));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    appRegion = regionCode;
                    prefs.edit().putString(UiStrings.PREF_REGION, appRegion).apply();
                    if (currentPdfLanguage.length() > 0) {
                        TtsEngineManager.getInstance(MainActivity.this)
                                .setPreferredLanguage(currentPdfLanguage, appRegion);
                    }
                    if (finishInitialSelection) {
                        completeInitialRegionAndEnterApp(regionCode);
                    } else {
                        showSettingsRegionScreen();
                    }
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, uiDp(58));
            lp.bottomMargin = uiDp(7);
            list.addView(row, lp);
            matches++;
        }
        if (matches == 0) {
            TextView empty = new TextView(this);
            empty.setText(t("No se encontraron países"));
            empty.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
            empty.setTextSize(uiSp(16));
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(uiDp(12), uiDp(36), uiDp(12), uiDp(36));
            list.addView(empty, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
    }

    private View makeSettingsSelectionRow(String flagCode, String name, boolean selected) {
        return makeDesign3SelectionRow(flagCode, name, "", selected);
    }

    private TextView makeRoundHeaderIcon(String symbol) {
        TextView icon = new TextView(this);
        icon.setText(symbol);
        icon.setTextSize(uiSp(22));
        icon.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.rgb(11, 54, 91));
        bg.setStroke(uiDp(1), Color.rgb(37, 99, 235));
        icon.setBackground(bg);
        return icon;
    }

    private LinearLayout makeDesign3MenuCard(String iconText, String titleText, String subtitleText, boolean arrowVisible) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(12), 0, uiDp(12), 0);
        row.setClickable(true);
        row.setFocusable(true);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(18));
        bg.setColor(darkTheme ? Color.rgb(8, 34, 55) : Color.WHITE);
        bg.setStroke(uiDp(1), darkTheme ? Color.rgb(30, 76, 109) : Color.rgb(203, 213, 225));
        row.setBackground(bg);

        View icon;
        if (iconText != null && iconText.startsWith("flag:")) {
            FrameLayout holder = new FrameLayout(this);
            GradientDrawable iconBg = new GradientDrawable();
            iconBg.setCornerRadius(uiDp(13));
            iconBg.setColor(darkTheme ? Color.rgb(10, 49, 82) : Color.rgb(232, 240, 254));
            iconBg.setStroke(uiDp(1), darkTheme ? Color.rgb(37, 99, 235) : Color.rgb(147, 178, 240));
            holder.setBackground(iconBg);

            ImageView flagIcon = makeFlagImageView(iconText.substring(5));
            FrameLayout.LayoutParams flagLp = new FrameLayout.LayoutParams(uiDp(36), uiDp(24), Gravity.CENTER);
            holder.addView(flagIcon, flagLp);
            icon = holder;
        } else {
            TextView textIcon = new TextView(this);
            textIcon.setText(iconText);
            textIcon.setTextSize(uiSp(25));
            textIcon.setGravity(Gravity.CENTER);
            textIcon.setAlpha(1f);
            GradientDrawable iconBg = new GradientDrawable();
            iconBg.setCornerRadius(uiDp(13));
            iconBg.setColor(darkTheme ? Color.rgb(10, 49, 82) : Color.rgb(232, 240, 254));
            iconBg.setStroke(uiDp(1), darkTheme ? Color.rgb(37, 99, 235) : Color.rgb(147, 178, 240));
            textIcon.setBackground(iconBg);
            icon = textIcon;
        }
        row.addView(icon, new LinearLayout.LayoutParams(uiDp(46), uiDp(42)));

        LinearLayout words = new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams wordsLp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        wordsLp.leftMargin = uiDp(12);
        row.addView(words, wordsLp);

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setTextSize(uiSp(15));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        words.addView(title);

        // Sin subtitulo no se anade nada: el titulo queda centrado solo en la
        // fila, sin el hueco vacio que dejaba un TextView en blanco.
        if (subtitleText != null && subtitleText.length() > 0) {
            TextView subtitle = new TextView(this);
            subtitle.setText(subtitleText);
            subtitle.setTextColor(darkTheme ? Color.rgb(191, 205, 220) : Color.rgb(71, 85, 105));
            subtitle.setTextSize(uiSp(12));
            subtitle.setMaxLines(1);
            subtitle.setEllipsize(TextUtils.TruncateAt.END);
            words.addView(subtitle);
        }

        if (arrowVisible) {
            TextView arrow = new TextView(this);
            arrow.setText("›");
            arrow.setTextColor(darkTheme ? Color.rgb(59, 130, 246) : Color.rgb(29, 78, 216));
            arrow.setTextSize(uiSp(30));
            arrow.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            arrow.setGravity(Gravity.CENTER);
            row.addView(arrow, new LinearLayout.LayoutParams(uiDp(28), uiDp(48)));
        }
        return row;
    }

    private int flagDrawableRes(String countryCode) {
        if (countryCode == null) return 0;
        switch (countryCode.toUpperCase(Locale.ROOT)) {
            case "PE": return R.drawable.flag_pe;
            case "MX": return R.drawable.flag_mx;
            case "CO": return R.drawable.flag_co;
            case "AR": return R.drawable.flag_ar;
            case "CL": return R.drawable.flag_cl;
            case "EC": return R.drawable.flag_ec;
            case "BO": return R.drawable.flag_bo;
            case "PY": return R.drawable.flag_py;
            case "UY": return R.drawable.flag_uy;
            case "VE": return R.drawable.flag_ve;
            case "GT": return R.drawable.flag_gt;
            case "HN": return R.drawable.flag_hn;
            case "SV": return R.drawable.flag_sv;
            case "NI": return R.drawable.flag_ni;
            case "CR": return R.drawable.flag_cr;
            case "PA": return R.drawable.flag_pa;
            case "CU": return R.drawable.flag_cu;
            case "DO": return R.drawable.flag_do;
            case "ES": return R.drawable.flag_es;
            case "BR": return R.drawable.flag_br;
            case "PT": return R.drawable.flag_pt;
            case "IN": return R.drawable.flag_in;
            case "ID": return R.drawable.flag_id;
            case "PH": return R.drawable.flag_ph;
            case "US": return R.drawable.flag_us;
            case "GB": return R.drawable.flag_gb;
            case "CA": return R.drawable.flag_ca;
            case "AU": return R.drawable.flag_au;
            default: return 0;
        }
    }

    private static final java.util.HashMap<Integer, Bitmap> FLAG_BITMAP_CACHE =
            new java.util.HashMap<Integer, Bitmap>();

    /**
     * Los PNG de banderas traen un margen blanco/transparente de ~2-3% pegado a los
     * bordes. Recortamos el mismo porcentaje en los cuatro lados para eliminarlo sin
     * descentrar ni deformar la bandera.
     */
    private Bitmap croppedFlagBitmap(int resId) {
        if (resId == 0) return null;
        Bitmap cached = FLAG_BITMAP_CACHE.get(Integer.valueOf(resId));
        if (cached != null && !cached.isRecycled()) return cached;
        try {
            Bitmap source = BitmapFactory.decodeResource(getResources(), resId);
            if (source == null) return null;
            int w = source.getWidth();
            int h = source.getHeight();
            int insetX = Math.round(w * 0.03f);
            int insetY = Math.round(h * 0.03f);
            if (w - 2 * insetX < 8 || h - 2 * insetY < 8) return source;
            Bitmap cropped = Bitmap.createBitmap(source, insetX, insetY,
                    w - 2 * insetX, h - 2 * insetY);
            if (cropped != source) source.recycle();
            FLAG_BITMAP_CACHE.put(Integer.valueOf(resId), cropped);
            return cropped;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private ImageView makeFlagImageView(String countryCode) {
        ImageView flag = new ImageView(this);
        int resId = flagDrawableRes(countryCode);
        if (resId != 0) {
            Bitmap cropped = croppedFlagBitmap(resId);
            if (cropped != null) flag.setImageBitmap(cropped);
            else flag.setImageResource(resId);
        }
        flag.setScaleType(ImageView.ScaleType.CENTER_CROP);
        flag.setAdjustViewBounds(false);
        flag.setCropToPadding(true);

        GradientDrawable clip = new GradientDrawable();
        clip.setColor(Color.TRANSPARENT);
        clip.setCornerRadius(uiDp(4));
        flag.setBackground(clip);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            flag.setClipToOutline(true);
        }
        return flag;
    }

    private View makeDesign3SelectionRow(String flagCode, String name, String note, boolean selected) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(12), 0, uiDp(12), 0);
        row.setClickable(true);
        row.setFocusable(true);

        GradientDrawable bg;
        if (selected) {
            bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.rgb(37, 99, 235), Color.rgb(29, 78, 216)});
            bg.setCornerRadius(uiDp(16));
            bg.setStroke(uiDp(1), Color.rgb(96, 165, 250));
        } else {
            bg = new GradientDrawable();
            bg.setCornerRadius(uiDp(16));
            bg.setColor(Color.rgb(8, 31, 51));
            bg.setStroke(uiDp(1), Color.rgb(31, 65, 88));
        }
        row.setBackground(bg);

        ImageView flagView = makeFlagImageView(flagCode);
        row.addView(flagView, new LinearLayout.LayoutParams(uiDp(46), uiDp(31)));

        LinearLayout words = new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams wordsLp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        wordsLp.leftMargin = uiDp(12);
        row.addView(words, wordsLp);

        TextView nameView = new TextView(this);
        nameView.setText(name);
        nameView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        nameView.setTextSize(uiSp(17));
        nameView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        nameView.setMaxLines(1);
        nameView.setEllipsize(TextUtils.TruncateAt.END);
        words.addView(nameView);

        if (note != null && note.length() > 0) {
            TextView noteView = new TextView(this);
            noteView.setText(note);
            noteView.setTextColor(selected ? Color.WHITE : Color.rgb(203, 213, 225));
            noteView.setTextSize(uiSp(11));
            noteView.setMaxLines(1);
            words.addView(noteView);
        }

        TextView marker = new TextView(this);
        marker.setText(selected ? "✓" : "○");
        marker.setTextColor(selected ? Color.WHITE : Color.rgb(148, 163, 184));
        marker.setTextSize(uiSp(selected ? 20f : 24f));
        marker.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        marker.setGravity(Gravity.CENTER);
        if (selected) {
            GradientDrawable markerBg = new GradientDrawable();
            markerBg.setShape(GradientDrawable.OVAL);
            markerBg.setColor(Color.rgb(59, 130, 246));
            marker.setBackground(markerBg);
        }
        row.addView(marker, new LinearLayout.LayoutParams(uiDp(32), uiDp(32)));
        return row;
    }

    private LinearLayout makeSettingsSubscreenBase(String titleText, View.OnClickListener backListener) {
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));
        screen.setClickable(true);
        screen.setFocusable(true);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        View back = makeNavigationButton("back", false);
        back.setOnClickListener(backListener);
        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextSize(uiSp(22));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);
        View spacer = new View(this);
        top.addView(back, new LinearLayout.LayoutParams(uiDp(42), uiDp(46)));
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(title, new LinearLayout.LayoutParams(0, uiDp(46), 1));
        top.addView(spacer, new LinearLayout.LayoutParams(uiDp(42), uiDp(46)));
        screen.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(62)));
        return screen;
    }

    private void presentSettingsSubscreen(View screen) {
        if (screenHost == null) {
            screenHost = new FrameLayout(this);
            if (root != null) {
                screenHost.addView(root, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
        }
        if (screenHost.getParent() == null) setContentView(screenHost);
        if (settingsOverlay != null && settingsOverlay.getParent() == screenHost) {
            screenHost.removeView(settingsOverlay);
        }
        settingsOverlay = screen;
        screenHost.addView(settingsOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private String languageFlagCode(String language) {
        language = UiStrings.normalize(language);
        if (UiStrings.ES.equals(language)) return "ES";
        if (UiStrings.PT.equals(language)) return "BR";
        if (UiStrings.HI.equals(language)) return "IN";
        if (UiStrings.ID.equals(language)) return "ID";
        return "US";
    }

    private String normalizeSearchText(String value) {
        if (value == null) return "";
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        return normalized.toLowerCase(Locale.ROOT).trim();
    }

    private void showPrivacyPolicyScreen() {
        // Un segundo toque en menos de 400 ms no abre otra copia de esta pantalla.
        if (!acceptTap("showPrivacyPolicyScreen")) return;
        settingsMode = true;
        settingsSubscreen = 9;

        LinearLayout screen = makeSettingsSubscreenBase(t("Política de privacidad"), new View.OnClickListener() {
            @Override public void onClick(View v) { buildSettingsScreen(); }
        });

        ScrollView scroll = new ScrollView(this);
        TextView body = new TextView(this);
        body.setText(
                t("Última actualización: 3 de septiembre de 2026\n\n") +
                t("Geo Zeta: PDF a Voz y Audio respeta la privacidad de sus usuarios.\n\n") +
                t("1. Datos personales\n") +
                t("La aplicación no requiere crear una cuenta ni iniciar sesión. El desarrollador no recopila, almacena ni vende información personal del usuario en servidores propios.\n\n") +
                t("2. Archivos PDF y OCR\n") +
                t("La aplicación accede únicamente a los archivos PDF que el usuario selecciona de forma explícita. Los documentos se procesan localmente en el dispositivo y pueden copiarse temporalmente al almacenamiento privado de la aplicación para permitir su lectura. El modo OCR para PDF escaneados usa modelos de reconocimiento incluidos en la aplicación y procesa las páginas en el propio dispositivo. El PDF, las imágenes de sus páginas y el texto reconocido no se envían a servidores del desarrollador para realizar el OCR.\n\n") +
                t("3. Texto a voz\n") +
                t("Para leer los documentos en voz alta, Geo Zeta utiliza el motor de texto a voz (TTS) instalado o seleccionado en Android. Dependiendo del motor elegido, el procesamiento puede realizarse localmente o mediante servicios del proveedor de ese motor, sujetos a sus propias políticas de privacidad.\n\n") +
                t("4. Archivos creados y compartidos\n") +
                t("Los audios, imágenes y PDF generados por la aplicación se guardan localmente. Solo se entregan a otra aplicación o servicio cuando el usuario utiliza voluntariamente una función de compartir o abrir.\n\n") +
                t("5. Publicidad\n") +
                t("La aplicación muestra un banner y puede ofrecer anuncios recompensados proporcionados por Google AdMob. Los anuncios recompensados solo se muestran cuando el usuario elige voluntariamente ver uno para desbloquear temporalmente OCR y funciones de guardado. Para mostrar publicidad, Google y sus socios publicitarios pueden recoger información técnica del dispositivo, como el identificador de publicidad, la dirección IP aproximada y datos de interacción con los anuncios. Esa información la recoge y trata Google conforme a sus propias políticas: https://policies.google.com/technologies/ads\n\n") +
                t("La aplicación no incluye servicios de analítica propios ni compras dentro de la aplicación.\n\n") +
                t("6. Permisos y ubicación\n") +
                t("La versión actual no solicita ubicación, cámara, micrófono ni contactos. Utiliza notificaciones y un servicio de reproducción multimedia en primer plano para mantener los controles de audio cuando corresponde.\n\n") +
                t("7. Conservación y eliminación\n") +
                t("Los datos de funcionamiento y archivos de trabajo permanecen en el dispositivo según corresponda. El usuario puede borrar los archivos creados, eliminar los datos de la aplicación desde los ajustes de Android o desinstalar la aplicación.\n\n") +
                t("8. Contacto\n") +
                t("Para consultas sobre privacidad: Zxmnxzxmnx@gmail.com")
        );
        body.setTextSize(uiSp(15));
        body.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(30, 41, 59));
        body.setLineSpacing(0, 1.18f);
        body.setPadding(uiDp(18), uiDp(18), uiDp(18), uiDp(28));

        scroll.addView(body, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        screen.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        presentSettingsSubscreen(screen);
    }

    private void buildSettingsScreen() {
        settingsSubscreen = 0;
        if (settingsScrollView != null) {
            settingsScrollY = settingsScrollView.getScrollY();
        }

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));
        // Consume taps on empty settings areas so they never fall through to
        // the page selector or controls in the reader underneath.
        screen.setClickable(true);
        screen.setFocusable(true);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        View back = makeNavigationButton("back", false);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeSettings();
            }
        });

        TextView title = new TextView(this);
        title.setText(t("Ajustes"));
        // Mismo tamano que los encabezados de las subpantallas (Voces,
        // Velocidad, etc) para que todos los titulos se vean parejos.
        title.setTextSize(uiSp(22));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);

        View topSpacer = new View(this);
        topSpacer.setClickable(true);
        top.setClickable(true);

        top.addView(back, new LinearLayout.LayoutParams(uiDp(42), uiDp(46)));
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(title, new LinearLayout.LayoutParams(0, uiDp(46), 1));
        top.addView(topSpacer, new LinearLayout.LayoutParams(uiDp(42), uiDp(46)));

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(uiDp(14), uiDp(8), uiDp(14), uiDp(22));

        addSettingsSection(content, "IDIOMA Y REGIÓN");
        LinearLayout languageRegionEntry = makeDesign3MenuCard("🌐", t("Idioma y región"),
                UiStrings.languageName(appLanguage) + " · " + UiStrings.regionName(appRegion, appLanguage), true);
        languageRegionEntry.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showLanguageRegionSettingsScreen(); }
        });
        LinearLayout.LayoutParams languageRegionEntryLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(66));
        languageRegionEntryLp.bottomMargin = uiDp(6);
        content.addView(languageRegionEntry, languageRegionEntryLp);

        // La seccion APARIENCIA se retiro: la app usa siempre el tema oscuro.
        addSettingsSection(content, "LECTURA Y AUDIO");
        addActionRow(content, "icon:voices", "Voces", "", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showVoicesScreen();
            }
        });
        addActionRow(content, "icon:engine", "Motor de voz", getVoiceSummary(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showVoiceEngineDialog();
            }
        });
        addActionRow(content, "icon:speed", "Velocidad", formatSpeed(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSpeedDialog();
            }
        });
        addSettingsSection(content, "SEGUIMIENTO VISUAL");
        final Switch[] trackingSwitchHolder = new Switch[1];
        View.OnClickListener trackingToggle = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleReadingMarker();
                if (trackingSwitchHolder[0] != null) {
                    trackingSwitchHolder[0].setChecked(readingMarkerEnabled);
                }
            }
        };
        trackingSwitchHolder[0] = addSwitchRow(content, "icon:tracking", "Seguir lectura",
                "", readingMarkerEnabled, trackingToggle);
        readingMarkerSettingsSwatch = addColorRow(content, "icon:colordot", "Color del seguimiento",
                getUtilityColorRgb(COLOR_TARGET_READING_MARKER), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showUtilityColorDialog(COLOR_TARGET_READING_MARKER, "Color del seguimiento");
                    }
                });

        // Mismo tipo de fila con muestra de color que "Color del seguimiento":
        // antes el color de las reglas solo se podia cambiar manteniendo pulsado
        // el boton "Reglas" de la barra de arriba, que no lo encontraba nadie.
        ruleColorSettingsSwatch = addColorRow(content, "icon:rules", "Color de las reglas",
                getUtilityColorRgb(COLOR_TARGET_RULE), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showUtilityColorDialog(COLOR_TARGET_RULE, "Color de las reglas");
                    }
                });

        addSettingsSection(content, "MARCADO");
        addMarkStyleRow(content, "icon:mark", "Tipo de marcado", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkStyleDialog();
            }
        });
        addMarkThicknessRow(content, "icon:thickness", "Grosor del subrayado", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkThicknessDialog();
            }
        });
        addSettingsSection(content, t("PÁGINAS GUARDADAS"));
        addActionRow(content, "icon:bookmark", "Páginas guardadas",
                "", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBookmarksScreen();
            }
        });

        addSettingsSection(content, "ARCHIVOS Y EXPORTACIÓN");
        addActionRow(content, "icon:files", "Mis archivos", "Audios, imágenes y PDF", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(LIBRARY_AUDIO);
            }
        });
        addAdvancedActionRow(content, "icon:audio", "Crear audio", "Página, rango o todo", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAudioExportDialog();
            }
        });
        addAdvancedActionRow(content, "icon:image", "Guardar página marcada", "PNG sin reglas", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCurrentPageImage();
            }
        });
        addAdvancedActionRow(content, "icon:pdf", "Guardar PDF", "Página, rango o todo", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPdfExportDialog();
            }
        });
        addSettingsSection(content, "INFORMACIÓN");
        addActionRow(content, "🔒", "Política de privacidad",
                "", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPrivacyPolicyScreen();
            }
        });
        // Solo aparece donde la ley obliga a poder cambiar la eleccion
        // (Espana y resto del EEE, Reino Unido y Suiza). En el resto del mundo
        // esta fila no se muestra.
        if (privacyOptionsRequired()) {
            addActionRow(content, "🔒", "Opciones de privacidad",
                    "Cambiar tu elección sobre los anuncios", "›", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showPrivacyOptionsForm();
                }
            });
        }
        scroll.addView(content);
        settingsScrollView = scroll;
        screen.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(62)));
        screen.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        if (screenHost == null) {
            screenHost = new FrameLayout(this);
            if (root != null) {
                screenHost.addView(root, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
        }
        if (screenHost.getParent() == null) {
            setContentView(screenHost);
        }
        if (settingsOverlay != null && settingsOverlay.getParent() == screenHost) {
            screenHost.removeView(settingsOverlay);
        }
        settingsOverlay = screen;
        screenHost.addView(settingsOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        if (settingsScrollView != null) {
            final int restoreY = settingsScrollY;
            settingsScrollView.post(new Runnable() {
                @Override
                public void run() {
                    settingsScrollView.scrollTo(0, restoreY);
                }
            });
        }
    }

    private Button makeFlatIconButton(String text) {
        Button b = new Button(this);
        b.setText(t(text));
        b.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        b.setTextSize(uiSp(24));
        b.setAllCaps(false);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private View makeNavigationButton(String direction, boolean filled) {
        FrameLayout button = new FrameLayout(this);
        button.setClickable(true);
        button.setFocusable(true);
        button.setContentDescription(t("left".equals(direction) || "back".equals(direction)
                ? "Regresar" : "Siguiente"));
        button.setBackgroundColor(filled
                ? (darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255))
                : Color.TRANSPARENT);

        SettingsIconView icon = new SettingsIconView(this);
        icon.setIconType(direction);
        icon.setIconColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        int navIconSize = filled ? 28 : 26;
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(uiDp(navIconSize), uiDp(navIconSize));
        iconLp.gravity = Gravity.CENTER;
        button.addView(icon, iconLp);
        return button;
    }


    /**
     * Boton de la barra inferior dibujado como icono. Antes estos botones eran
     * texto ("Ajustes", "Limpiar", "Subrayar OFF") y su ancho cambiaba mucho
     * entre idiomas: en portugues "Configuracoes" desbordaba y descuadraba toda
     * la fila. Con icono todos los botones miden igual en los cinco idiomas.
     */
    private View makeIconBarButton(String iconType, String description) {
        FrameLayout button = new FrameLayout(this);
        button.setClickable(true);
        button.setFocusable(true);
        button.setContentDescription(t(description));
        button.setBackgroundColor(darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255));

        SettingsIconView icon = new SettingsIconView(this);
        icon.setIconType(iconType);
        icon.setIconColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(uiDp(26), uiDp(26));
        iconLp.gravity = Gravity.CENTER;
        button.addView(icon, iconLp);
        return button;
    }

    /**
     * Boton de icono con una etiqueta minima debajo ("ON" / "OFF"), igual en los
     * cinco idiomas. Se usa para el interruptor de subrayado, que necesita
     * mostrar su estado sin depender de una palabra traducida.
     */
    private LinearLayout makeIconStateButton(String iconType, String description) {
        LinearLayout button = new LinearLayout(this);
        button.setOrientation(LinearLayout.VERTICAL);
        button.setGravity(Gravity.CENTER);
        button.setClickable(true);
        button.setFocusable(true);
        button.setContentDescription(t(description));
        button.setBackgroundColor(darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255));

        SettingsIconView icon = new SettingsIconView(this);
        icon.setIconType(iconType);
        icon.setIconColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(uiDp(20), uiDp(20));
        button.addView(icon, iconLp);

        TextView label = new TextView(this);
        label.setText("OFF");
        label.setTextSize(uiSp(9));
        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setIncludeFontPadding(false);
        label.setGravity(Gravity.CENTER);
        label.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        labelLp.topMargin = uiDp(2);
        button.addView(label, labelLp);

        markButtonIcon = icon;
        markButtonLabel = label;
        return button;
    }

    private View makeMarkHistoryButton(String type, String description) {
        FrameLayout button = new FrameLayout(this);
        button.setClickable(true);
        button.setFocusable(true);
        button.setContentDescription(t(description));
        button.setBackgroundColor(darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255));

        ImageView icon = new ImageView(this);
        icon.setImageResource("redo".equals(type) ? R.drawable.ic_mark_redo : R.drawable.ic_mark_undo);
        icon.setColorFilter(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(30, 41, 59));
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(uiDp(25), uiDp(25));
        iconLp.gravity = Gravity.CENTER;
        button.addView(icon, iconLp);
        return button;
    }

    private TextView makeDialogTitleView(String text) {
        TextView tv = new TextView(this);
        tv.setText(t(text));
        tv.setTextSize(22);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        tv.setPadding(dp(22), dp(18), dp(22), dp(10));
        tv.setBackgroundColor(darkTheme ? Color.rgb(7, 28, 42) : Color.WHITE);
        return tv;
    }

    private LinearLayout makeDialogContainer() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(14), dp(18), dp(16));
        box.setBackgroundColor(darkTheme ? Color.rgb(10, 24, 38) : Color.WHITE);
        return box;
    }

    private void styleDialog(AlertDialog dialog) {
        if (dialog == null) return;
        if (dialog.getWindow() != null) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(18));
            bg.setColor(darkTheme ? Color.rgb(10, 24, 38) : Color.WHITE);
            dialog.getWindow().setBackgroundDrawable(bg);
        }
        // El titulo y el mensaje que crea Android no traen color propio: sobre el
        // fondo oscuro del dialogo quedaban casi invisibles. Se pintan aqui.
        applyDialogTextColors(dialog);
        int accent = getSettingsAccentColor();
        Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        Button negative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        Button neutral = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
        if (positive != null) positive.setTextColor(accent);
        if (negative != null) negative.setTextColor(accent);
        if (neutral != null) neutral.setTextColor(accent);
    }

    /**
     * Pinta el titulo y el mensaje por defecto de un AlertDialog. Sin esto
     * heredan el gris de Android y se pierden sobre el fondo del dialogo.
     */
    private void applyDialogTextColors(AlertDialog dialog) {
        if (dialog == null) return;
        int titleColor = darkTheme ? Color.WHITE : Color.rgb(15, 23, 42);
        int messageColor = darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(51, 65, 85);
        try {
            View titleView = dialog.findViewById(
                    getResources().getIdentifier("alertTitle", "id", "android"));
            if (titleView instanceof TextView) {
                ((TextView) titleView).setTextColor(titleColor);
            }
        } catch (Exception ignored) {
        }
        try {
            View messageView = dialog.findViewById(android.R.id.message);
            if (messageView instanceof TextView) {
                ((TextView) messageView).setTextColor(messageColor);
            }
        } catch (Exception ignored) {
        }
    }

    private void addSettingsSection(LinearLayout parent, String title) {
        TextView tv = new TextView(this);
        tv.setText(t(title));
        tv.setTextSize(uiSp(13));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(getSettingsAccentColor());
        tv.setPadding(uiDp(4), uiDp(15), uiDp(4), uiDp(6));
        parent.addView(tv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private File getAudioSaveDir() {
        return ensureDirectory(new File(new File(getStorageBase(Environment.DIRECTORY_MUSIC), "Geo_Zeta"), "Audios"));
    }

    private File getImageSaveDir() {
        return ensureDirectory(new File(new File(getStorageBase(Environment.DIRECTORY_PICTURES), "Geo_Zeta"), "Imagenes"));
    }

    private File getPdfSaveDir() {
        return ensureDirectory(new File(new File(getStorageBase(Environment.DIRECTORY_DOCUMENTS), "Geo_Zeta"), "PDF_Marcados"));
    }

    private File getStorageBase(String type) {
        File base = getExternalFilesDir(type);
        return base == null ? getFilesDir() : base;
    }

    private File ensureDirectory(File directory) {
        if (directory != null && !directory.exists()) directory.mkdirs();
        return directory;
    }

    private void showStorageFoldersDialog() {
        LinearLayout box = makeDialogContainer();
        box.setPadding(dp(12), dp(10), dp(12), dp(10));

        TextView info = new TextView(this);
        info.setText(t("Cada formato se guarda en su propia carpeta y también aparece en Mis archivos."));
        info.setTextSize(13);
        info.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
        info.setPadding(dp(4), 0, dp(4), dp(8));
        box.addView(info);

        final AlertDialog[] dialogHolder = new AlertDialog[1];
        addStorageFolderRow(box, "♫", "Audios", "Geo Zeta / Audios", LIBRARY_AUDIO, dialogHolder);
        addStorageFolderRow(box, "📁", "Imágenes", "Geo Zeta / Imágenes", LIBRARY_IMAGE, dialogHolder);
        addStorageFolderRow(box, "PDF", "PDF marcados", "Geo Zeta / PDF marcados", LIBRARY_PDF, dialogHolder);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Carpetas de guardado"))
                .setView(box)
                .setNegativeButton(t("Cerrar"), null)
                .create();
        dialogHolder[0] = dialog;
        dialog.show();
        styleDialog(dialog);
    }

    private void addStorageFolderRow(LinearLayout parent, String iconText, String titleText, String pathText, final int libraryType, final AlertDialog[] dialogHolder) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(10), dp(10));

        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(dp(14));
        background.setColor(darkTheme ? Color.rgb(12, 35, 54) : Color.rgb(248, 250, 252));
        row.setBackground(background);

        TextView icon = new TextView(this);
        icon.setText(iconText);
        icon.setTextSize(iconText.equals("PDF") ? 16 : 24);
        icon.setTypeface(Typeface.DEFAULT_BOLD);
        icon.setGravity(Gravity.CENTER);
        icon.setTextColor(Color.WHITE);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(Color.rgb(37, 99, 235));
        icon.setBackground(iconBg);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(12), 0, dp(8), 0);

        TextView title = new TextView(this);
        title.setText(t(titleText));
        title.setTextSize(15);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView path = new TextView(this);
        path.setText(pathText);
        path.setTextSize(12);
        path.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        texts.addView(title);
        texts.addView(path);

        TextView arrow = new TextView(this);
        arrow.setText(t("›"));
        arrow.setTextSize(26);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.WHITE : Color.rgb(71, 85, 105));

        row.addView(icon, new LinearLayout.LayoutParams(dp(52), dp(52)));
        row.addView(texts, new LinearLayout.LayoutParams(0, dp(54), 1));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(32), dp(54)));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dialogHolder != null && dialogHolder.length > 0 && dialogHolder[0] != null) {
                    dialogHolder[0].dismiss();
                }
                showFileLibrary(libraryType);
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(4));
        parent.addView(row, lp);
    }

    private LinearLayout makeCardRow(String icon, String title, String sub) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(12), uiDp(8), uiDp(10), uiDp(8));
        row.setBackgroundColor(darkTheme ? Color.rgb(12, 35, 54) : Color.WHITE);

        View iconView;
        if (icon != null && icon.startsWith("icon:")) {
            SettingsIconView customIcon = new SettingsIconView(this);
            customIcon.setIconType(icon.substring(5));
            // En claro el azul por defecto casi no se ve sobre blanco: se usa un
            // azul mas oscuro para que el icono quede legible.
            customIcon.setIconColor(getSettingsAccentColor());
            iconView = customIcon;
        } else {
            TextView textIcon = new TextView(this);
            textIcon.setText(icon);
            textIcon.setTextSize(uiSp(24));
            textIcon.setGravity(Gravity.CENTER);
            textIcon.setTextColor(getSettingsAccentColor());
            iconView = textIcon;
        }

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);

        TextView titleView = new TextView(this);
        titleView.setText(t(title));
        titleView.setTextSize(uiSp(16));
        titleView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView subView = new TextView(this);
        subView.setText(sub == null ? "" : t(sub));
        subView.setTextSize(uiSp(11));
        subView.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        texts.addView(titleView);
        if (sub != null && sub.length() > 0) texts.addView(subView);

        row.addView(iconView, new LinearLayout.LayoutParams(uiDp(44), uiDp(48)));
        row.addView(texts, new LinearLayout.LayoutParams(0, uiDp(50), 1));
        return row;
    }

    private Switch addSwitchRow(LinearLayout parent, String icon, String title, String sub, boolean checked, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        Switch sw = new Switch(this);
        sw.setChecked(checked);
        sw.setEnabled(listener != null);
        if (listener != null) {
            sw.setOnClickListener(listener);
            row.setOnClickListener(listener);
        }
        row.addView(sw, new LinearLayout.LayoutParams(uiDp(64), uiDp(56)));
        addRowWithMargin(parent, row);
        return sw;
    }

    private LinearLayout addActionRow(LinearLayout parent, String icon, String title, String sub, String right, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        TextView arrow = new TextView(this);
        arrow.setText(right == null ? "" : right);
        arrow.setTextSize(uiSp(25));
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(uiDp(38), uiDp(56)));
        if (listener != null) row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
        return row;
    }

    /**
     * Fila de una funcion financiada por Rewarded. Bloqueada sigue siendo
     * pulsable para poder explicar la recompensa, pero se ve atenuada y con
     * candado. Al desbloquear recupera exactamente el aspecto normal.
     */
    private void addAdvancedActionRow(LinearLayout parent, String icon, String title, String sub,
                                      View.OnClickListener listener) {
        boolean locked = !hasAdvancedAccess();
        LinearLayout row = addActionRow(parent, icon, title, sub, locked ? "🔒" : "›", listener);
        // El candado ya comunica el bloqueo. Atenuar toda la tarjeta ensuciaba
        // los colores (especialmente amarillos y azules) y parecia un fallo de
        // pantalla. Se conserva el diseño normal y solo cambia el indicador.
        row.setAlpha(1f);
    }

    private void addMarkStyleRow(LinearLayout parent, String icon, String title, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, "");
        View sample = createInlineMarkStylePreview(markStyle);
        row.addView(sample, new LinearLayout.LayoutParams(uiDp(92), uiDp(56)));
        TextView arrow = new TextView(this);
        arrow.setText(t("›"));
        arrow.setTextSize(uiSp(25));
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(uiDp(32), uiDp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private void addMarkThicknessRow(LinearLayout parent, String icon, String title, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, "");
        View sample = createInlineThicknessPreview(markThicknessLevel);
        row.addView(sample, new LinearLayout.LayoutParams(uiDp(92), uiDp(56)));
        TextView arrow = new TextView(this);
        arrow.setText(t("›"));
        arrow.setTextSize(uiSp(25));
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(uiDp(32), uiDp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private View createInlineThicknessPreview(int level) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(6), 0, dp(6), 0);
        int thickness = getPreviewLineThickness(level);
        int color = darkTheme ? Color.WHITE : Color.rgb(15, 23, 42);
        View line = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(3));
        line.setBackground(d);
        box.addView(line, new LinearLayout.LayoutParams(dp(54), thickness));
        return box;
    }

    private View createInlineMarkStylePreview(int style) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(4), dp(2), dp(4), dp(2));
        View line = createPreviewUnderlineView(style, markThicknessLevel, getCurrentMarkColor(), dp(58));
        box.addView(line);
        return box;
    }

    private int getPreviewLineThickness(int level) {
        if (level <= 0) return dp(2);
        if (level >= 2) return dp(6);
        return dp(4);
    }

    private int getPreviewLineColor(int color) {
        return 0xFF000000 | (color & 0x00FFFFFF);
    }

    private void applySampleDecoration(TextView sample, int style, int color) {
        sample.setBackground(null);
        sample.setPadding(dp(6), dp(2), dp(6), dp(2));
        int lineColor = getPreviewLineColor(color);

        if (style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(4));
            int alpha = style == MARK_STYLE_HIGHLIGHT_INTENSE ? 0xA8 : 0x62;
            bg.setColor((alpha << 24) | (lineColor & 0x00FFFFFF));
            sample.setBackground(bg);
        }
    }

    private View createPreviewUnderlineView(int style, int thicknessLevel, int color, int width) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        int lineColor = getPreviewLineColor(color);
        int thickness = getPreviewLineThickness(thicknessLevel);

        if (style == MARK_STYLE_UNDERLINE_DOUBLE) {
            for (int i = 0; i < 2; i++) {
                View line = new View(this);
                GradientDrawable d = new GradientDrawable();
                d.setColor(lineColor);
                d.setCornerRadius(dp(3));
                line.setBackground(d);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, Math.max(dp(2), thickness - dp(1)));
                lp.setMargins(0, i == 0 ? 0 : dp(3), 0, 0);
                box.addView(line, lp);
            }
            return box;
        }

        if (style == MARK_STYLE_UNDERLINE_DOTTED) {
            LinearLayout dots = new LinearLayout(this);
            dots.setOrientation(LinearLayout.HORIZONTAL);
            dots.setGravity(Gravity.CENTER);
            int dot = Math.max(dp(3), thickness);
            for (int i = 0; i < 7; i++) {
                View v = new View(this);
                GradientDrawable d = new GradientDrawable();
                d.setShape(GradientDrawable.OVAL);
                d.setColor(lineColor);
                v.setBackground(d);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dot, dot);
                lp.setMargins(dp(1), 0, dp(1), 0);
                dots.addView(v, lp);
            }
            box.addView(dots);
            return box;
        }

        if (style == MARK_STYLE_UNDERLINE_WAVY) {
            TextView wave = new TextView(this);
            wave.setText(t("﹏﹏﹏﹏"));
            wave.setTextSize(16);
            wave.setTextColor(lineColor);
            wave.setGravity(Gravity.CENTER);
            box.addView(wave, new LinearLayout.LayoutParams(width, LinearLayout.LayoutParams.WRAP_CONTENT));
            return box;
        }

        View line = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(lineColor);
        d.setCornerRadius(dp(3));
        line.setBackground(d);
        box.addView(line, new LinearLayout.LayoutParams(width, thickness));
        return box;
    }

    private TextView addColorRow(LinearLayout parent, String icon, String title, int color, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, "");

        TextView swatch = new TextView(this);
        swatch.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF000000 | (color & 0x00FFFFFF));
        circle.setStroke(uiDp(2), darkTheme ? Color.WHITE : Color.rgb(71, 85, 105));
        swatch.setBackground(circle);
        swatch.setContentDescription(t("Color seleccionado"));

        LinearLayout.LayoutParams swatchParams = new LinearLayout.LayoutParams(uiDp(30), uiDp(30));
        swatchParams.setMargins(uiDp(4), uiDp(13), uiDp(6), uiDp(13));
        row.addView(swatch, swatchParams);

        TextView arrow = new TextView(this);
        arrow.setText(t("›"));
        arrow.setTextSize(uiSp(25));
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(uiDp(32), uiDp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
        return swatch;
    }

    private void updateRuleColorSettingsSwatch() {
        if (ruleColorSettingsSwatch == null) return;
        int color = getUtilityColorRgb(COLOR_TARGET_RULE);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF000000 | (color & 0x00FFFFFF));
        circle.setStroke(dp(2), darkTheme ? Color.WHITE : Color.rgb(71, 85, 105));
        ruleColorSettingsSwatch.setBackground(circle);
    }

    private void updateReadingMarkerSettingsSwatch() {
        if (readingMarkerSettingsSwatch == null) return;
        int color = getUtilityColorRgb(COLOR_TARGET_READING_MARKER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF000000 | (color & 0x00FFFFFF));
        circle.setStroke(dp(2), darkTheme ? Color.WHITE : Color.rgb(71, 85, 105));
        readingMarkerSettingsSwatch.setBackground(circle);
    }

    private void addRowWithMargin(LinearLayout parent, View row) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(58));
        lp.setMargins(0, uiDp(3), 0, uiDp(3));
        parent.addView(row, lp);
    }

    /**
     * Candado global contra el doble toque. La app no tenia ninguna proteccion:
     * dos toques rapidos en el mismo boton ejecutaban la accion dos veces y
     * abrian dos pantallas de Ajustes apiladas, dos dialogos o dos guardados del
     * mismo archivo. Se instala una vez sobre la ventana y protege todos los
     * botones a la vez, sin tocar ninguna funcion.
     */
    private String lastAcceptedTapKey = "";
    private long lastAcceptedTapAt;

    private boolean acceptTap(String action) {
        long now = SystemClock.elapsedRealtime();
        if (action.equals(lastAcceptedTapKey) && now - lastAcceptedTapAt < 400L) {
            return false;
        }
        lastAcceptedTapKey = action;
        lastAcceptedTapAt = now;
        return true;
    }

    private void applyReadingBrightness() {
        try {
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.screenBrightness = readingBrightness < 0f ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE : readingBrightness;
            getWindow().setAttributes(params);
        } catch (Exception ignored) {
        }
    }

    private void showFileLibrary(boolean showAudio) {
        showFileLibrary(showAudio ? LIBRARY_AUDIO : LIBRARY_IMAGE);
    }

    /**
     * Monta "Mis archivos" como una capa encima de la interfaz que ya esta viva,
     * igual que Ajustes. Antes se reemplazaba la vista raiz de la ventana entera
     * y por eso se veia un parpadeo negro al entrar y al salir; ademas obligaba a
     * reconstruir el lector y a reabrir el PDF al volver.
     */
    private void presentLibraryScreen(View screen) {
        if (screenHost == null) {
            screenHost = new FrameLayout(this);
            screenHost.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
            if (root != null) {
                screenHost.addView(root, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
        }
        if (screenHost.getParent() == null) setContentView(screenHost);
        if (libraryOverlay != null && libraryOverlay.getParent() == screenHost) {
            screenHost.removeView(libraryOverlay);
        }
        libraryOverlay = screen;
        screenHost.addView(libraryOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        // El visor de imagen a pantalla completa siempre va por encima de la
        // lista, nunca por debajo.
        if (imageViewerOverlay != null && imageViewerOverlay.getParent() == screenHost) {
            imageViewerOverlay.bringToFront();
        }
    }

    /**
     * Tapa de arranque. Cuando Android tuvo que cerrar la app por falta de
     * memoria, al volver a entrar todo se arma de cero y se alcanzaba a ver la
     * interfaz montandose por partes. Con esta tapa el usuario ve una pantalla
     * con los colores de la app y recien se destapa cuando la primera pagina del
     * PDF ya esta dibujada. Si algo tardara demasiado, se destapa igual a los
     * pocos segundos para que nunca quede trabada.
     */
    private void showStartupCover() {
        if (startupCoverView != null) return;
        if (pdfView == null || !(pdfView.getParent() instanceof ViewGroup)) return;
        final ViewGroup coverHost = (ViewGroup) pdfView.getParent();

        FrameLayout cover = new FrameLayout(this);
        cover.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
        cover.setClickable(true);
        cover.setFocusable(true);

        LinearLayout coverContent = new LinearLayout(this);
        coverContent.setOrientation(LinearLayout.VERTICAL);
        coverContent.setGravity(Gravity.CENTER);

        ProgressBar spinner = new ProgressBar(this);
        spinner.setIndeterminate(true);
        LinearLayout.LayoutParams spinnerLp = new LinearLayout.LayoutParams(uiDp(40), uiDp(40));
        spinnerLp.bottomMargin = uiDp(14);
        coverContent.addView(spinner, spinnerLp);

        TextView label = new TextView(this);
        label.setText(t("Cargando"));
        label.setTextSize(uiSp(16));
        label.setGravity(Gravity.CENTER);
        label.setTextColor(darkTheme ? Color.rgb(191, 205, 220) : Color.rgb(71, 85, 105));
        coverContent.addView(label, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        FrameLayout.LayoutParams labelLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        labelLp.gravity = Gravity.CENTER;
        cover.addView(coverContent, labelLp);

        startupCoverView = cover;
        coverHost.addView(cover, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        startupCoverTimeout = new Runnable() {
            @Override
            public void run() {
                hideStartupCover();
            }
        };
        cover.postDelayed(startupCoverTimeout, 6000L);
    }

    /**
     * Deja en el log cuanto se tardo desde que arranco la pantalla hasta que hay
     * una pagina dibujada. Sirve para saber si la demora esta en el arranque de
     * la app o en la apertura del PDF, en vez de suponerlo.
     * Se lee con:  adb logcat -s GeoZetaArranque
     */
    private void reportStartupTiming(String phase) {
        if (startupClockStart <= 0L) return;
        long elapsed = SystemClock.elapsedRealtime() - startupClockStart;
        Log.i("GeoZetaArranque", phase + ": " + elapsed + " ms");
        // Ademas del log, se muestra en pantalla cuando la apertura ha sido
        // lenta. Trabajando solo desde el movil no hay forma de leer el log, y
        // sin el numero no se puede saber si la demora esta en abrir el PDF o en
        // arrancar la app. Solo aparece por encima de dos segundos, para no
        // molestar cuando todo va bien.
        if (elapsed >= 2000L) {
            try {
                Toast.makeText(this, phase + ": " + (elapsed / 1000f) + " s",
                        Toast.LENGTH_LONG).show();
            } catch (Exception ignored) {
            }
        }
    }

    private void hideStartupCover() {
        if (!startupClockReported) {
            startupClockReported = true;
            if (startupClockValid) reportStartupTiming("Apertura automática");
        }
        if (startupCoverView == null) return;
        View cover = startupCoverView;
        startupCoverView = null;
        if (startupCoverTimeout != null) {
            cover.removeCallbacks(startupCoverTimeout);
        }
        startupCoverTimeout = null;
        if (cover.getParent() instanceof ViewGroup) {
            ((ViewGroup) cover.getParent()).removeView(cover);
        }
    }

    /** Quita la capa de "Mis archivos" si esta puesta. */
    private void removeLibraryOverlay() {
        if (libraryOverlay != null && screenHost != null
                && libraryOverlay.getParent() == screenHost) {
            screenHost.removeView(libraryOverlay);
        }
        libraryOverlay = null;
        libraryScreenView = null;
        libraryListView = null;
        libraryScrollView = null;
        libraryAudioTab = null;
        libraryImageTab = null;
        libraryPdfTab = null;
        libraryActionButton = null;
    }

    private void showFileLibrary(int libraryType) {
        // Un segundo toque en menos de 400 ms no abre otra copia de esta pantalla.
        if (!acceptTap("showFileLibrary")) return;
        final int requestedType = Math.max(LIBRARY_AUDIO, Math.min(libraryType, LIBRARY_PDF));

        // Si Mis archivos ya esta visible NO se destruye ni se vuelve a montar.
        // Esto elimina tirones y, sobre todo, evita el instante en que un segundo
        // toque podia atravesar la capa y activar "Tipo de marcado" de Ajustes.
        if (libraryMode && screenHost != null && libraryScreenView != null
                && libraryOverlay == libraryScreenView && libraryOverlay.getParent() == screenHost) {
            switchLibraryTab(requestedType, !libraryCacheValid);
            return;
        }

        if (!libraryMode) libraryReturnToSettings = settingsMode;
        libraryMode = true;
        settingsMode = false;
        libraryShowingType = requestedType;
        stopFilePreview();

        libraryScreenView = new LinearLayout(this);
        libraryScreenView.setOrientation(LinearLayout.VERTICAL);
        libraryScreenView.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));
        libraryScreenView.setClickable(true);
        libraryScreenView.setFocusable(true);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        View back = makeNavigationButton("back", false);
        back.setOnClickListener(v -> closeFileLibrary());

        TextView title = new TextView(this);
        title.setText(t("Mis archivos"));
        title.setTextSize(uiSp(22));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);

        libraryActionButton = makeFlatIconButton("↻");
        libraryActionButton.setOnClickListener(v -> {
            if (libraryShowingType == LIBRARY_IMAGE) {
                imageLibraryGridMode = !imageLibraryGridMode;
                prefs.edit().putBoolean(PREF_IMAGE_LIBRARY_GRID, imageLibraryGridMode).apply();
                refreshLibraryContent(false);
            } else {
                refreshLibraryContent(true);
            }
        });

        top.addView(back, new LinearLayout.LayoutParams(uiDp(52), uiDp(56)));
        top.addView(title, new LinearLayout.LayoutParams(0, uiDp(56), 1));
        top.addView(libraryActionButton, new LinearLayout.LayoutParams(uiDp(52), uiDp(56)));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(uiDp(10), uiDp(6), uiDp(10), uiDp(8));
        tabs.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));

        libraryAudioTab = makeButton("Audios\n…");
        libraryImageTab = makeButton("Imágenes\n…");
        libraryPdfTab = makeButton("PDF\n…");
        libraryAudioTab.setTextSize(uiSp(12));
        libraryImageTab.setTextSize(uiSp(12));
        libraryPdfTab.setTextSize(uiSp(12));
        libraryAudioTab.setOnClickListener(v -> switchLibraryTab(LIBRARY_AUDIO, false));
        libraryImageTab.setOnClickListener(v -> switchLibraryTab(LIBRARY_IMAGE, false));
        libraryPdfTab.setOnClickListener(v -> switchLibraryTab(LIBRARY_PDF, false));
        tabs.addView(libraryAudioTab, new LinearLayout.LayoutParams(0, uiDp(54), 1));
        tabs.addView(libraryImageTab, new LinearLayout.LayoutParams(0, uiDp(54), 1));
        tabs.addView(libraryPdfTab, new LinearLayout.LayoutParams(0, uiDp(54), 1));

        libraryScrollView = new ScrollView(this);
        libraryListView = new LinearLayout(this);
        libraryListView.setOrientation(LinearLayout.VERTICAL);
        libraryListView.setPadding(uiDp(12), uiDp(6), uiDp(12), uiDp(24));
        libraryScrollView.addView(libraryListView);

        libraryScreenView.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(78)));
        libraryScreenView.addView(tabs, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(68)));
        libraryScreenView.addView(libraryScrollView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        presentLibraryScreen(libraryScreenView);
        updateLibraryChrome();
        refreshLibraryContent(false);
    }

    private void switchLibraryTab(int type, boolean forceReload) {
        int requested = Math.max(LIBRARY_AUDIO, Math.min(type, LIBRARY_PDF));
        if (!libraryMode || libraryListView == null) {
            showFileLibrary(requested);
            return;
        }
        // Un doble toque sobre la pestana ya activa no hace absolutamente nada.
        // La capa nunca se desmonta, por lo que el toque no puede llegar a Ajustes.
        if (requested == libraryShowingType && !forceReload) {
            updateLibraryChrome();
            return;
        }
        stopFilePreview();
        libraryShowingType = requested;
        updateLibraryChrome();
        refreshLibraryContent(forceReload);
        if (libraryScrollView != null) libraryScrollView.scrollTo(0, 0);
    }

    private void updateLibraryChrome() {
        int audioCount = libraryCacheValid && cachedLibraryAudio != null ? cachedLibraryAudio.size() : -1;
        int imageCount = libraryCacheValid && cachedLibraryImages != null ? cachedLibraryImages.size() : -1;
        int pdfCount = libraryCacheValid && cachedLibraryPdf != null ? cachedLibraryPdf.size() : -1;
        if (libraryAudioTab != null) {
            libraryAudioTab.setText(t("Audios") + "\n" + (audioCount >= 0 ? audioCount : "…"));
            libraryAudioTab.setAlpha(libraryShowingType == LIBRARY_AUDIO ? 1f : 0.52f);
        }
        if (libraryImageTab != null) {
            libraryImageTab.setText(t("Imágenes") + "\n" + (imageCount >= 0 ? imageCount : "…"));
            libraryImageTab.setAlpha(libraryShowingType == LIBRARY_IMAGE ? 1f : 0.52f);
        }
        if (libraryPdfTab != null) {
            libraryPdfTab.setText(t("PDF") + "\n" + (pdfCount >= 0 ? pdfCount : "…"));
            libraryPdfTab.setAlpha(libraryShowingType == LIBRARY_PDF ? 1f : 0.52f);
        }
        if (libraryActionButton != null) {
            boolean images = libraryShowingType == LIBRARY_IMAGE;
            libraryActionButton.setText(images ? (imageLibraryGridMode ? "☰" : "▦") : "↻");
            libraryActionButton.setTextSize(uiSp(images ? 22 : 26));
            libraryActionButton.setContentDescription(t(images
                    ? (imageLibraryGridMode ? "Ver imágenes en lista" : "Ver imágenes en cuadrícula")
                    : "Actualizar archivos"));
        }
    }

    private void refreshLibraryContent(boolean forceReload) {
        if (!libraryMode || libraryListView == null) return;
        if (forceReload) invalidateLibraryCache();

        libraryListView.removeAllViews();
        addLibraryFoldersRow(libraryListView);
        if (libraryCacheValid && cachedLibraryAudio != null
                && cachedLibraryImages != null && cachedLibraryPdf != null) {
            populateLibraryList(libraryListView, libraryShowingType,
                    cachedLibraryAudio, cachedLibraryImages, cachedLibraryPdf);
            updateLibraryChrome();
            return;
        }

        final TextView loading = new TextView(this);
        loading.setText(t("Buscando archivos..."));
        loading.setTextSize(uiSp(16));
        loading.setGravity(Gravity.CENTER);
        loading.setPadding(uiDp(20), uiDp(70), uiDp(20), uiDp(40));
        loading.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
        loading.setVisibility(View.GONE);
        libraryListView.addView(loading, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        loading.postDelayed(new Runnable() {
            @Override public void run() {
                if (libraryMode && !libraryCacheValid && loading.getParent() != null) {
                    loading.setVisibility(View.VISIBLE);
                }
            }
        }, 400L);
        startLibraryScanIfNeeded();
    }

    private void startLibraryScanIfNeeded() {
        if (libraryScanInFlight) return;
        libraryScanInFlight = true;
        final int requestToken = ++libraryLoadToken;
        libraryScanExecutor.execute(new Runnable() {
            @Override public void run() {
                final ArrayList<File> foundAudio = getLibraryFiles(LIBRARY_AUDIO);
                final ArrayList<File> foundImages = getLibraryFiles(LIBRARY_IMAGE);
                final ArrayList<File> foundPdf = getLibraryFiles(LIBRARY_PDF);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (requestToken != libraryLoadToken || isFinishing()
                                || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                        libraryScanInFlight = false;
                        cachedLibraryAudio = foundAudio;
                        cachedLibraryImages = foundImages;
                        cachedLibraryPdf = foundPdf;
                        libraryCacheValid = true;
                        updateLibraryChrome();
                        if (libraryMode && libraryListView != null) refreshLibraryContent(false);
                    }
                });
            }
        });
    }

    /** Rellena la lista de Mis archivos una vez que el escaneo termino. */
    private void populateLibraryList(LinearLayout list, int type,
                                     ArrayList<File> audioFiles,
                                     ArrayList<File> imageFiles,
                                     ArrayList<File> pdfFiles) {
        ArrayList<File> files = type == LIBRARY_AUDIO
                ? audioFiles
                : (type == LIBRARY_IMAGE ? imageFiles : pdfFiles);
        if (files.isEmpty()) {
            TextView empty = new TextView(this);
            String message;
            if (type == LIBRARY_AUDIO) {
                message = "Todavía no hay audios guardados.\nCrea uno desde Ajustes > Crear audio.";
            } else if (type == LIBRARY_IMAGE) {
                message = "Todavía no hay imágenes guardadas.\nGuarda una página marcada desde Ajustes.";
            } else {
                message = "Todavía no hay PDF guardados aquí.";
            }
            empty.setText(t(message));
            empty.setTextSize(uiSp(17));
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(uiDp(20), uiDp(80), uiDp(20), uiDp(40));
            empty.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
            list.addView(empty, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        } else if (type == LIBRARY_IMAGE) {
            if (imageLibraryGridMode) addImageGallery(list, imageFiles);
            else addImageList(list, imageFiles);
        } else {
            for (File file : files) {
                addLibraryFileRow(list, file, type);
            }
        }
    }

    private void addLibraryFoldersRow(LinearLayout parent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(12), uiDp(8), uiDp(10), uiDp(8));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(14));
        bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
        bg.setStroke(uiDp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
        row.setBackground(bg);

        TextView icon = new TextView(this);
        icon.setText(t("📁"));
        icon.setTextSize(uiSp(21));
        icon.setGravity(Gravity.CENTER);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(uiDp(12), 0, uiDp(8), 0);

        TextView title = new TextView(this);
        title.setText(t("Ver carpetas de guardado"));
        title.setTextSize(uiSp(15));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView subtitle = new TextView(this);
        subtitle.setText(t("Audios · Imágenes · PDF"));
        subtitle.setTextSize(uiSp(11));
        subtitle.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));

        texts.addView(title);
        texts.addView(subtitle);

        TextView arrow = new TextView(this);
        arrow.setText(t("›"));
        arrow.setTextSize(uiSp(25));
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));

        row.addView(icon, new LinearLayout.LayoutParams(uiDp(42), uiDp(48)));
        row.addView(texts, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row.addView(arrow, new LinearLayout.LayoutParams(uiDp(36), uiDp(48)));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStorageFoldersDialog();
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, uiDp(8));
        parent.addView(row, lp);
    }

    /**
     * Descarta el escaneo guardado. Se llama cuando la lista de archivos pudo
     * cambiar (se guardo o borro algo) o cuando el usuario pide actualizar.
     */
    private void invalidateLibraryCache() {
        libraryCacheValid = false;
        cachedLibraryAudio = null;
        cachedLibraryImages = null;
        cachedLibraryPdf = null;
        libraryLoadToken++;
        libraryScanInFlight = false;
    }

    private void closeFileLibrary() {
        stopFilePreview();
        libraryMode = false;
        removeLibraryOverlay();

        if (libraryReturnToSettings) {
            libraryReturnToSettings = false;
            settingsMode = true;
            buildSettingsScreen();
            return;
        }

        settingsMode = false;
        // La interfaz de lectura nunca se desarmo: estaba tapada por la capa de
        // "Mis archivos". Al quitarla vuelve tal cual estaba, con el PDF abierto
        // y en la misma pagina, sin reconstruir nada y sin parpadeo.
        if (settingsOverlay != null && screenHost != null
                && settingsOverlay.getParent() == screenHost) {
            screenHost.removeView(settingsOverlay);
        }
        settingsOverlay = null;

        if (screenHost != null && screenHost.getParent() == null) {
            setContentView(screenHost);
        }
        if (root == null || screenHost == null || root.getParent() != screenHost) {
            // Caso extremo: no quedo interfaz viva que destapar.
            final File file = currentFile;
            final String title = currentTitle;
            final int page = currentPage;
            final boolean hadDocument = file != null && file.exists();
            buildUi();
            if (hadDocument) {
                if (pdfView != null) {
                    pdfView.setSuppressEmptyLabel(true);
                    if (titleView != null) titleView.setText(title == null ? "PDF" : title);
                }
                openLocalPdfAtPage(file, title, page);
            }
            return;
        }

        updatePageLabel();
        updateMarkControls();
        applyReadingBrightness();
        if (pdfView != null) pdfView.invalidate();
    }

    private ArrayList<File> getLibraryFiles(boolean audio) {
        return getLibraryFiles(audio ? LIBRARY_AUDIO : LIBRARY_IMAGE);
    }

    private ArrayList<File> getLibraryFiles(int type) {
        ArrayList<File> result = new ArrayList<File>();
        if (type == LIBRARY_AUDIO) {
            collectLibraryFiles(getAudioSaveDir(), LIBRARY_AUDIO, result);
            collectLibraryFiles(new File(getStorageBase(Environment.DIRECTORY_MUSIC), "PDF_Audio"), LIBRARY_AUDIO, result);
        } else if (type == LIBRARY_IMAGE) {
            collectLibraryFiles(getImageSaveDir(), LIBRARY_IMAGE, result);
            collectLibraryFiles(new File(getStorageBase(Environment.DIRECTORY_PICTURES), "PDF_Audio"), LIBRARY_IMAGE, result);
        } else {
            collectLibraryFiles(getPdfSaveDir(), LIBRARY_PDF, result);
            collectLibraryFiles(new File(getStorageBase(Environment.DIRECTORY_DOCUMENTS), "PDF_Audio"), LIBRARY_PDF, result);
        }
        Collections.sort(result, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        return result;
    }

    private void collectLibraryFiles(File directory, int type, ArrayList<File> output) {
        if (directory == null || !directory.exists()) return;
        File[] children = directory.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.isDirectory()) {
                collectLibraryFiles(child, type, output);
                continue;
            }
            String name = child.getName().toLowerCase(Locale.US);
            boolean matches;
            if (type == LIBRARY_AUDIO) {
                matches = name.endsWith(".wav") || name.endsWith(".mp3") || name.endsWith(".m4a") || name.endsWith(".ogg");
            } else if (type == LIBRARY_IMAGE) {
                matches = name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".webp");
            } else {
                matches = name.endsWith(".pdf");
            }
            if (matches && !output.contains(child)) output.add(child);
        }
    }

    private void addImageGallery(LinearLayout parent, final ArrayList<File> imageFiles) {
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setUseDefaultMargins(false);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setPadding(0, uiDp(4), 0, uiDp(12));

        for (final File file : imageFiles) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setPadding(uiDp(6), uiDp(6), uiDp(6), uiDp(8));

            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(uiDp(14));
            bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
            bg.setStroke(uiDp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
            card.setBackground(bg);

            ImageView thumb = new ImageView(this);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumb.setAdjustViewBounds(false);
            bindLibraryImageThumbnail(thumb, file, 420, 560);
            GradientDrawable thumbBg = new GradientDrawable();
            thumbBg.setCornerRadius(uiDp(10));
            thumbBg.setColor(Color.WHITE);
            thumb.setBackground(thumbBg);
            card.addView(thumb, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(180)));

            TextView name = new TextView(this);
            name.setText(file.getName());
            name.setTextSize(uiSp(12));
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setGravity(Gravity.CENTER);
            name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
            name.setPadding(uiDp(4), uiDp(7), uiDp(4), 0);
            card.addView(name, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(32)));

            TextView details = new TextView(this);
            details.setText(formatFileDate(file.lastModified()));
            details.setTextSize(uiSp(10));
            details.setGravity(Gravity.CENTER);
            details.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));
            card.addView(details, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(24)));

            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showImagePreview(file);
                }
            });
            card.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showFileActions(file, LIBRARY_IMAGE);
                    return true;
                }
            });

            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.height = GridLayout.LayoutParams.WRAP_CONTENT;
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            lp.setMargins(uiDp(4), uiDp(4), uiDp(4), uiDp(4));
            grid.addView(card, lp);
        }

        parent.addView(grid, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void addImageList(LinearLayout parent, final ArrayList<File> imageFiles) {
        for (final File file : imageFiles) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(uiDp(10), uiDp(8), uiDp(10), uiDp(8));

            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(uiDp(14));
            bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
            bg.setStroke(uiDp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
            row.setBackground(bg);

            ImageView thumb = new ImageView(this);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            bindLibraryImageThumbnail(thumb, file, 320, 420);
            GradientDrawable thumbBg = new GradientDrawable();
            thumbBg.setCornerRadius(uiDp(10));
            thumbBg.setColor(Color.WHITE);
            thumb.setBackground(thumbBg);
            row.addView(thumb, new LinearLayout.LayoutParams(uiDp(70), uiDp(92)));

            LinearLayout textBox = new LinearLayout(this);
            textBox.setOrientation(LinearLayout.VERTICAL);
            textBox.setGravity(Gravity.CENTER_VERTICAL);
            textBox.setPadding(uiDp(12), 0, uiDp(8), 0);

            TextView name = new TextView(this);
            name.setText(file.getName());
            name.setTextSize(uiSp(14));
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

            TextView details = new TextView(this);
            details.setText(formatFileSizePretty(file.length()) + "   " + formatFileDate(file.lastModified()));
            details.setTextSize(uiSp(11));
            details.setSingleLine(true);
            details.setEllipsize(TextUtils.TruncateAt.END);
            details.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));
            details.setPadding(0, uiDp(3), 0, 0);

            textBox.addView(name);
            textBox.addView(details);
            row.addView(textBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

            Button menu = makeFlatIconButton("⋮");
            menu.setTextSize(uiSp(24));
            menu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showFileActions(file, LIBRARY_IMAGE);
                }
            });
            row.addView(menu, new LinearLayout.LayoutParams(uiDp(40), uiDp(52)));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showImagePreview(file);
                }
            });
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showFileActions(file, LIBRARY_IMAGE);
                    return true;
                }
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, uiDp(5), 0, uiDp(5));
            parent.addView(row, lp);
        }
    }

    private void addLibraryFileRow(LinearLayout parent, final File file, final int type) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(12), uiDp(10), uiDp(6), uiDp(10));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(14));
        bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
        bg.setStroke(uiDp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
        row.setBackground(bg);

        TextView icon = new TextView(this);
        icon.setText(type == LIBRARY_AUDIO ? "♫" : "PDF");
        icon.setTextSize(type == LIBRARY_AUDIO ? 26 : 15);
        icon.setTypeface(Typeface.DEFAULT_BOLD);
        icon.setTextColor(Color.WHITE);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setCornerRadius(uiDp(12));
        iconBg.setColor(type == LIBRARY_AUDIO ? Color.rgb(37, 99, 235) : Color.rgb(220, 38, 38));
        icon.setBackground(iconBg);
        row.addView(icon, new LinearLayout.LayoutParams(uiDp(50), uiDp(50)));

        LinearLayout textBox = new LinearLayout(this);
        textBox.setOrientation(LinearLayout.VERTICAL);
        textBox.setGravity(Gravity.CENTER_VERTICAL);
        textBox.setPadding(uiDp(10), 0, uiDp(8), 0);

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextSize(uiSp(14));
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        final TextView details = new TextView(this);
        final String staticDetails = formatFileSizePretty(file.length()) + "   " + formatFileDate(file.lastModified());
        if (type == LIBRARY_AUDIO) {
            String key = audioDurationCacheKey(file);
            String cachedDuration = audioDurationCache.get(key);
            details.setText((cachedDuration == null ? "…" : cachedDuration) + "   " + staticDetails);
            details.setTag(key);
            if (cachedDuration == null) loadAudioDurationAsync(file, details, staticDetails);
        } else {
            details.setText(staticDetails);
        }
        details.setTextSize(uiSp(11));
        details.setSingleLine(true);
        details.setEllipsize(TextUtils.TruncateAt.END);
        details.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));
        details.setPadding(0, uiDp(2), 0, 0);

        textBox.addView(name);
        textBox.addView(details);
        row.addView(textBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button menu = makeFlatIconButton("⋮");
        menu.setTextSize(uiSp(26));
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileActions(file, type);
            }
        });
        row.addView(menu, new LinearLayout.LayoutParams(uiDp(42), uiDp(54)));

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (type == LIBRARY_AUDIO) showAudioPreview(file);
                else openFileExternally(file);
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, uiDp(5), 0, uiDp(5));
        parent.addView(row, lp);
    }

    /**
     * Carga una miniatura de Mis archivos sin bloquear la interfaz. La tarjeta
     * aparece al instante y la imagen entra con una transición corta cuando la
     * decodificación termina.
     */
    private void bindLibraryImageThumbnail(final ImageView target, final File file,
                                           final int reqWidth, final int reqHeight) {
        if (target == null || file == null) return;
        final String path = file.getAbsolutePath();
        target.setTag(path);
        target.setImageBitmap(null);
        target.setAlpha(1f);

        Bitmap cached = imagePreviewCache.get(path);
        if (cached != null && !cached.isRecycled()) {
            target.setImageBitmap(cached);
            return;
        }

        synchronized (libraryThumbnailDecodeInFlight) {
            if (libraryThumbnailDecodeInFlight.contains(path)) {
                // Si otra tarjeta ya está decodificando este mismo archivo, esta
                // vista espera el resultado de caché en vez de quedar vacía.
                target.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (target.getTag() == null
                                || !path.equals(String.valueOf(target.getTag()))) return;
                        Bitmap ready = imagePreviewCache.get(path);
                        if (ready != null && !ready.isRecycled()) {
                            target.setImageBitmap(ready);
                        } else {
                            bindLibraryImageThumbnail(target, file, reqWidth, reqHeight);
                        }
                    }
                }, 120L);
                return;
            }
            libraryThumbnailDecodeInFlight.add(path);
        }
        imageDecodeExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final Bitmap preview = decodePreviewBitmap(file, reqWidth, reqHeight);
                synchronized (libraryThumbnailDecodeInFlight) {
                    libraryThumbnailDecodeInFlight.remove(path);
                }
                if (preview != null) imagePreviewCache.put(path, preview);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (preview == null || target.getTag() == null
                                || !path.equals(String.valueOf(target.getTag()))) return;
                        // Antes la miniatura entraba atenuada y se aclaraba en
                        // 110 ms. Ese aclarado se percibe como un parpadeo en la
                        // lista. Se pone ya a plena opacidad.
                        target.setAlpha(1f);
                        target.setImageBitmap(preview);
                    }
                });
            }
        });
    }

    private Bitmap decodePreviewBitmap(File file, int reqWidth, int reqHeight) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            int sample = 1;
            while (bounds.outWidth / sample > reqWidth * 2 || bounds.outHeight / sample > reqHeight * 2) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = Math.max(1, sample);
            return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        } catch (Exception ignored) {
            return null;
        }
    }

    private Bitmap decodeViewerBitmap(File file, int reqWidth, int reqHeight) {
        Bitmap decoded = null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= reqWidth
                    && bounds.outHeight / (sample * 2) >= reqHeight) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = Math.max(1, sample);
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            decoded = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
            if (decoded == null) return null;

            float scale = Math.min(1f, Math.min(reqWidth / (float) decoded.getWidth(),
                    reqHeight / (float) decoded.getHeight()));
            if (scale < 0.999f) {
                int width = Math.max(1, Math.round(decoded.getWidth() * scale));
                int height = Math.max(1, Math.round(decoded.getHeight() * scale));
                Bitmap scaled = Bitmap.createScaledBitmap(decoded, width, height, true);
                if (scaled != decoded && !decoded.isRecycled()) decoded.recycle();
                decoded = scaled;
            }
            return decoded;
        } catch (Throwable ignored) {
            if (decoded != null && !decoded.isRecycled()) decoded.recycle();
            return null;
        }
    }

    private class ImagePagerAdapter extends RecyclerView.Adapter<ImagePagerAdapter.ImageHolder> {
        private final ArrayList<File> files;
        private final ZoomImageView.OnSingleTapListener tapListener;
        private final ArrayList<ImageHolder> holders = new ArrayList<ImageHolder>();
        private boolean released;

        ImagePagerAdapter(ArrayList<File> files, ZoomImageView.OnSingleTapListener tapListener) {
            this.files = files;
            this.tapListener = tapListener;
        }

        class ImageHolder extends RecyclerView.ViewHolder {
            final ZoomImageView image;
            String boundPath;

            ImageHolder(FrameLayout page, ZoomImageView image) {
                super(page);
                this.image = image;
            }

            void bindPlaceholder(String path) {
                boundPath = path;
                // decodePreviewBitmap conserva la proporcion original; CENTER_CROP
                // solo recorta la VISTA de la grilla, no el bitmap guardado. Por
                // eso esta miniatura sirve como puente correcto hasta que llegue
                // la version HD y evita el flash oscuro entre paginas.
                Bitmap hd = imageViewerCache.get(path);
                Bitmap preview = hd != null ? hd : imagePreviewCache.get(path);
                image.setImageBitmapImmediate(preview);
                image.resetZoom();
            }

            void applyBitmap(String path, Bitmap bitmap) {
                if (released || bitmap == null || boundPath == null || !boundPath.equals(path)) return;
                image.setImageBitmapImmediate(bitmap);
                image.resetZoom();
            }
        }

        @Override
        public ImageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            FrameLayout page = new FrameLayout(MainActivity.this);
            page.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
            page.setLayoutParams(new RecyclerView.LayoutParams(
                    RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));

            ZoomImageView image = new ZoomImageView(MainActivity.this);
            image.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
            image.setPadding(0, 0, 0, 0);
            image.setOnSingleTapListener(tapListener);
            page.addView(image, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

            ImageHolder holder = new ImageHolder(page, image);
            holders.add(holder);
            return holder;
        }

        @Override
        public void onBindViewHolder(final ImageHolder holder, int position) {
            final File file = files.get(position);
            final String path = file.getAbsolutePath();
            holder.bindPlaceholder(path);
            requestHighQualityImage(file, holder);
        }

        private void requestHighQualityImage(final File file, final ImageHolder holder) {
            final String path = file.getAbsolutePath();
            Bitmap cached = imageViewerCache.get(path);
            if (cached != null) {
                holder.applyBitmap(path, cached);
                return;
            }
            synchronized (imageDecodeInFlight) {
                if (imageDecodeInFlight.contains(path)) return;
                imageDecodeInFlight.add(path);
            }
            imageDecodeExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    if (imagePreviewCache.get(path) == null) {
                        final Bitmap preview = decodePreviewBitmap(file, 720, 1120);
                        if (preview != null) {
                            imagePreviewCache.put(path, preview);
                            runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    if (!released && imageViewerCache.get(path) == null) {
                                        holder.applyBitmap(path, preview);
                                    }
                                }
                            });
                        }
                    }
                    final Bitmap decoded = decodeViewerBitmap(file, 1800, 2800);
                    synchronized (imageDecodeInFlight) {
                        imageDecodeInFlight.remove(path);
                    }
                    if (decoded != null) imageViewerCache.put(path, decoded);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!released && decoded != null) holder.applyBitmap(path, decoded);
                        }
                    });
                }
            });
        }

        void preload(int center) {
            int from = Math.max(0, center - 2);
            int to = Math.min(files.size() - 1, center + 2);
            for (int i = from; i <= to; i++) {
                final File file = files.get(i);
                final String path = file.getAbsolutePath();
                if (imageViewerCache.get(path) != null) continue;
                synchronized (imageDecodeInFlight) {
                    if (imageDecodeInFlight.contains(path)) continue;
                    imageDecodeInFlight.add(path);
                }
                imageDecodeExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        if (imagePreviewCache.get(path) == null) {
                            Bitmap preview = decodePreviewBitmap(file, 720, 1120);
                            if (preview != null) imagePreviewCache.put(path, preview);
                        }
                        Bitmap decoded = decodeViewerBitmap(file, 1800, 2800);
                        synchronized (imageDecodeInFlight) {
                            imageDecodeInFlight.remove(path);
                        }
                        if (decoded != null) imageViewerCache.put(path, decoded);
                        final Bitmap readyBitmap = decoded != null ? decoded : imagePreviewCache.get(path);
                        if (readyBitmap != null) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (released) return;
                                    // No se fuerza un rebind con notifyItemChanged(): en ViewPager2
                                    // ese rebind podia dejar un frame vacio o reiniciar la imagen
                                    // visible. Si la pagina ya esta enlazada, se actualiza el mismo
                                    // holder; si todavia no lo esta, tomara el bitmap del cache al
                                    // enlazarse mas adelante.
                                    for (ImageHolder holder : holders) {
                                        if (holder != null && path.equals(holder.boundPath)) {
                                            holder.applyBitmap(path, readyBitmap);
                                        }
                                    }
                                }
                            });
                        }
                    }
                });
            }
        }

        void runWhenImageIsDrawn(final String path, final Runnable callback) {
            if (path == null || callback == null || released) {
                if (callback != null) callback.run();
                return;
            }
            final boolean[] delivered = new boolean[]{false};
            final Runnable arm = new Runnable() {
                @Override
                public void run() {
                    if (released || delivered[0]) return;
                    for (final ImageHolder holder : holders) {
                        if (holder == null || !path.equals(holder.boundPath)
                                || holder.image.getDrawable() == null
                                || holder.image.getWidth() <= 0 || holder.image.getHeight() <= 0) {
                            continue;
                        }
                        final android.view.ViewTreeObserver observer = holder.image.getViewTreeObserver();
                        if (!observer.isAlive()) continue;
                        observer.addOnPreDrawListener(new android.view.ViewTreeObserver.OnPreDrawListener() {
                            @Override
                            public boolean onPreDraw() {
                                if (delivered[0] || released || !path.equals(holder.boundPath)
                                        || holder.image.getDrawable() == null) {
                                    try {
                                        if (holder.image.getViewTreeObserver().isAlive()) {
                                            holder.image.getViewTreeObserver().removeOnPreDrawListener(this);
                                        }
                                    } catch (Throwable ignored) { }
                                    return true;
                                }
                                delivered[0] = true;
                                try {
                                    if (holder.image.getViewTreeObserver().isAlive()) {
                                        holder.image.getViewTreeObserver().removeOnPreDrawListener(this);
                                    }
                                } catch (Throwable ignored) { }
                                // Se ejecuta despues de que este frame ya fue enviado a dibujo.
                                // Asi la imagen puente nunca se retira antes que la real exista.
                                holder.image.post(new Runnable() {
                                    @Override public void run() { callback.run(); }
                                });
                                return true;
                            }
                        });
                        holder.image.invalidate();
                        return;
                    }
                    // El ViewHolder puede crearse en el siguiente ciclo de layout.
                    if (imagePager != null) imagePager.postOnAnimation(this);
                }
            };
            if (imagePager != null) imagePager.postOnAnimation(arm);
            else arm.run();
        }

        @Override
        public int getItemCount() {
            return files.size();
        }

        @Override
        public void onViewRecycled(ImageHolder holder) {
            holder.boundPath = null;
            holder.image.setImageBitmap(null);
            super.onViewRecycled(holder);
        }

        void release() {
            released = true;
            for (ImageHolder holder : holders) {
                if (holder != null) {
                    holder.boundPath = null;
                    holder.image.setImageBitmap(null);
                }
            }
            holders.clear();
        }
    }

    private void showImagePreview(final File file) {
        showFullscreenImageViewer(file);
    }

    private void showFullscreenImageViewer(final File startFile) {
        showFullscreenImageViewer(startFile, null);
    }

    private ViewGroup getOverlayHost() {
        if (screenHost != null && screenHost.getParent() != null) {
            return screenHost;
        }
        View content = findViewById(android.R.id.content);
        if (content instanceof ViewGroup) {
            return (ViewGroup) content;
        }
        return null;
    }

    private void showFullscreenImageViewer(final File startFile, final Runnable onReady) {
        final ArrayList<File> images = getLibraryFiles(LIBRARY_IMAGE);
        if (images.isEmpty()) {
            Toast.makeText(this, t("No hay imágenes guardadas"), Toast.LENGTH_SHORT).show();
            if (onReady != null) onReady.run();
            return;
        }

        stopFilePreview();
        imageViewerMode = true;

        int startIndex = images.indexOf(startFile);
        if (startIndex < 0) startIndex = 0;
        final String initialImagePath = images.get(startIndex).getAbsolutePath();
        final Bitmap transitionPreview = imagePreviewCache.get(initialImagePath);

        final FrameLayout screen = new FrameLayout(this);
        screen.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
        screen.setClickable(true);
        screen.setFocusable(true);
        // El visor se monta siempre opaco. Antes se montaba transparente y se
        // le subia el alpha al revelarlo; cualquier frame intermedio dejaba ver
        // el lector oscuro por debajo y la imagen aparecia como con un velo.
        // Ahora no se toca el alpha en ningun momento: quien cubre la espera es
        // la imagen puente, que ya lleva la miniatura recien guardada.

        final LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(8), uiDp(8), uiDp(8), uiDp(8));
        top.setBackgroundColor(darkTheme ? 0xCC08283A : 0xDDEAF2F8);

        View close = makeNavigationButton("back", false);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setGravity(Gravity.CENTER_VERTICAL);

        final TextView counter = new TextView(this);
        counter.setTextSize(uiSp(15));
        counter.setTypeface(Typeface.DEFAULT_BOLD);
        counter.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        final TextView fileName = new TextView(this);
        fileName.setTextSize(uiSp(12));
        fileName.setSingleLine(true);
        fileName.setEllipsize(TextUtils.TruncateAt.END);
        fileName.setTextColor(darkTheme ? Color.rgb(215, 227, 244) : Color.rgb(71, 85, 105));

        titleBox.addView(counter);
        titleBox.addView(fileName);

        Button share = makeFlatIconButton("Compartir");
        share.setTextSize(uiSp(13));
        share.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        top.addView(close, new LinearLayout.LayoutParams(uiDp(52), uiDp(52)));
        top.addView(titleBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        top.addView(share, new LinearLayout.LayoutParams(uiDp(100), uiDp(52)));

        final Handler chromeHandler = new Handler(Looper.getMainLooper());
        final boolean[] chromeVisible = new boolean[]{true};
        final Runnable hideChrome = new Runnable() {
            @Override
            public void run() {
                chromeVisible[0] = false;
                top.animate().alpha(0f).setDuration(140L).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        if (!chromeVisible[0]) top.setVisibility(View.GONE);
                    }
                }).start();
            }
        };
        final Runnable showChromeNow = new Runnable() {
            @Override
            public void run() {
                chromeVisible[0] = true;
                top.setVisibility(View.VISIBLE);
                top.animate().cancel();
                top.setAlpha(1f);
                chromeHandler.removeCallbacks(hideChrome);
                chromeHandler.postDelayed(hideChrome, 2400L);
            }
        };

        imagePager = new ViewPager2(this);
        imagePager.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);
        imagePager.setOffscreenPageLimit(2);
        imagePager.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
        imagePagerAdapter = new ImagePagerAdapter(images, new ZoomImageView.OnSingleTapListener() {
            @Override
            public void onSingleTap() {
                if (chromeVisible[0]) {
                    chromeHandler.removeCallbacks(hideChrome);
                    hideChrome.run();
                } else {
                    showChromeNow.run();
                }
            }
        });
        imagePager.setAdapter(imagePagerAdapter);
        screen.addView(imagePager, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // Para la transicion de "Guardar imagen" usamos el bitmap que acabamos
        // de generar como primer frame garantizado. Asi, aunque ViewPager2 tarde
        // uno o dos frames en enlazar su ViewHolder, nunca se ve un fondo vacio.
        final ImageView transitionImage;
        if (transitionPreview != null && !transitionPreview.isRecycled()) {
            transitionImage = new ImageView(this);
            transitionImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
            transitionImage.setBackgroundColor(darkTheme
                    ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
            transitionImage.setImageBitmap(transitionPreview);
            screen.addView(transitionImage, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        } else {
            transitionImage = null;
        }

        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        topLp.gravity = Gravity.TOP;
        screen.addView(top, topLp);

        final Runnable updateHeader = new Runnable() {
            @Override
            public void run() {
                int position = imagePager == null ? 0 : imagePager.getCurrentItem();
                position = Math.max(0, Math.min(position, images.size() - 1));
                counter.setText((position + 1) + " / " + images.size());
                fileName.setText(images.get(position).getName());
            }
        };

        imagePager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                updateHeader.run();
                showChromeNow.run();
                if (imagePagerAdapter != null) imagePagerAdapter.preload(position);
            }
        });
        imagePager.setCurrentItem(startIndex, false);
        if (imagePagerAdapter != null) imagePagerAdapter.preload(startIndex);
        updateHeader.run();

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chromeHandler.removeCallbacks(hideChrome);
                closeFullscreenImageViewer();
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChromeNow.run();
                int position = imagePager == null ? 0 : imagePager.getCurrentItem();
                position = Math.max(0, Math.min(position, images.size() - 1));
                shareFile(images.get(position));
            }
        });

        ViewGroup host = getOverlayHost();
        if (host == null) {
            Toast.makeText(this, t("No se pudo abrir la imagen"), Toast.LENGTH_SHORT).show();
            if (onReady != null) onReady.run();
            return;
        }
        if (imageViewerOverlay != null && imageViewerOverlay.getParent() == host) {
            host.removeView(imageViewerOverlay);
        }
        imageViewerOverlay = screen;
        host.addView(imageViewerOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        showChromeNow.run();

        // La imagen puente ya contiene exactamente la PNG recien guardada.
        // No se retira por un tiempo fijo: esperamos a que el ZoomImageView real
        // confirme un pre-draw con bitmap. Solo despues de ese frame quitamos el
        // puente. De esta forma no existe un intervalo donde pueda verse el fondo.
        final Runnable finishImageTransition = new Runnable() {
            private boolean done;
            @Override
            public void run() {
                if (done) return;
                done = true;
                try {
                    if (transitionImage != null && transitionImage.getParent() == screen) {
                        screen.removeView(transitionImage);
                    }
                } catch (Throwable ignored) { }
                if (onReady != null) onReady.run();
            }
        };
        if (imagePagerAdapter != null && (transitionImage != null || onReady != null)) {
            imagePagerAdapter.runWhenImageIsDrawn(initialImagePath, finishImageTransition);
        } else {
            finishImageTransition.run();
        }
    }

    private void closeFullscreenImageViewer() {
        if (!imageViewerMode) return;
        imageViewerMode = false;
        if (imagePager != null) {
            imagePager.setAdapter(null);
            imagePager = null;
        }
        if (imagePagerAdapter != null) {
            imagePagerAdapter.release();
            imagePagerAdapter = null;
        }
        if (imageViewerBitmap != null && !imageViewerBitmap.isRecycled()) {
            imageViewerBitmap.recycle();
            imageViewerBitmap = null;
        }
        ViewGroup host = getOverlayHost();
        if (host != null && imageViewerOverlay != null && imageViewerOverlay.getParent() == host) {
            host.removeView(imageViewerOverlay);
        }
        imageViewerOverlay = null;
    }

    private void showAudioPreview(final File file) {


        stopFilePreview();

        LinearLayout box = makeDialogContainer();

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextSize(uiSp(18));
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        name.setPadding(0, 0, 0, uiDp(10));
        box.addView(name);

        final TextView time = new TextView(this);
        time.setText(t("00:00 / 00:00"));
        time.setGravity(Gravity.CENTER);
        time.setTextSize(uiSp(14));
        time.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(15, 23, 42));

        final SeekBar seek = new SeekBar(this);
        seek.setMax(1000);

        final Button play = makeButton("▶ Reproducir");
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (previewPlayer == null) return;
                if (previewPlayer.isPlaying()) {
                    previewPlayer.pause();
                    play.setText(t("▶ Reproducir"));
                } else {
                    previewPlayer.start();
                    play.setText(t("Ⅱ Pausar"));
                    startPreviewProgress(seek, time, play);
                }
            }
        });

        box.addView(time, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(34)));
        box.addView(seek, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(48)));
        box.addView(play, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(52)));

        try {
            previewPlayer = new MediaPlayer();
            previewPlayer.setDataSource(file.getAbsolutePath());
            previewPlayer.prepare();
            updatePreviewTime(seek, time);
            previewPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    play.setText(t("▶ Reproducir"));
                    updatePreviewTime(seek, time);
                }
            });
        } catch (Exception e) {
            stopFilePreview();
            Toast.makeText(this, t("No se pudo abrir el audio"), Toast.LENGTH_LONG).show();
            return;
        }

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && previewPlayer != null) {
                    int duration = previewPlayer.getDuration();
                    previewPlayer.seekTo((int) (duration * (progress / 1000f)));
                    updatePreviewTime(seek, time);
                }
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(box)
                .setPositiveButton(t("Compartir"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        shareFile(file);
                    }
                })
                .setNegativeButton(t("Cerrar"), null)
                .create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                stopFilePreview();
            }
        });
        dialog.show();
        styleDialog(dialog);
    }

    private void startPreviewProgress(final SeekBar seek, final TextView time, final Button play) {
        if (previewProgressTask != null) previewHandler.removeCallbacks(previewProgressTask);
        previewProgressTask = new Runnable() {
            @Override
            public void run() {
                if (previewPlayer == null) return;
                updatePreviewTime(seek, time);
                if (previewPlayer.isPlaying()) {
                    play.setText(t("Ⅱ Pausar"));
                    previewHandler.postDelayed(this, 400L);
                }
            }
        };
        previewHandler.post(previewProgressTask);
    }

    private void updatePreviewTime(SeekBar seek, TextView time) {
        if (previewPlayer == null) return;
        int duration = Math.max(0, previewPlayer.getDuration());
        int position = Math.max(0, previewPlayer.getCurrentPosition());
        seek.setProgress(duration == 0 ? 0 : Math.min(1000, Math.round(position * 1000f / duration)));
        time.setText(formatDuration(position) + " / " + formatDuration(duration));
    }

    private void stopFilePreview() {
        if (previewProgressTask != null) {
            previewHandler.removeCallbacks(previewProgressTask);
            previewProgressTask = null;
        }
        if (previewPlayer != null) {
            try { previewPlayer.stop(); } catch (Exception ignored) { }
            try { previewPlayer.release(); } catch (Exception ignored) { }
            previewPlayer = null;
        }
    }

    private void showFileActions(final File file, final int type) {
        final String[] actions = new String[]{t("Abrir"), t("Compartir"), t("Cambiar nombre"), t("Eliminar")};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(file.getName())
                .setItems(actions, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            if (type == LIBRARY_AUDIO) showAudioPreview(file);
                            else if (type == LIBRARY_IMAGE) showImagePreview(file);
                            else openFileExternally(file);
                        } else if (which == 1) {
                            shareFile(file);
                        } else if (which == 2) {
                            renameLibraryFile(file);
                        } else {
                            deleteLibraryFile(file);
                        }
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void shareFile(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(getMimeType(file));
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, t("Compartir archivo")));
        } catch (Exception e) {
            Toast.makeText(this, t("No se pudo compartir el archivo"), Toast.LENGTH_LONG).show();
        }
    }

    private String getMimeType(File file) {
        String name = file.getName();
        int dot = name.lastIndexOf('.');
        String extension = dot >= 0 ? name.substring(dot + 1).toLowerCase(Locale.US) : "";
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        if (mime != null) return mime;
        if (extension.equals("wav") || extension.equals("mp3") || extension.equals("m4a") || extension.equals("ogg")) return "audio/*";
        if (extension.equals("pdf")) return "application/pdf";
        return "image/*";
    }

    private void openFileExternally(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, getMimeType(file));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Abrir archivo"));
        } catch (Exception e) {
            Toast.makeText(this, t("No se pudo abrir el archivo"), Toast.LENGTH_LONG).show();
        }
    }

    private void renameLibraryFile(final File file) {
        final EditText input = new EditText(this);
        String name = file.getName();
        final int dot = name.lastIndexOf('.');
        final String extension = dot >= 0 ? name.substring(dot) : "";
        input.setText(dot >= 0 ? name.substring(0, dot) : name);
        input.setSelection(input.getText().length());

        new AlertDialog.Builder(this)
                .setTitle(t("Cambiar nombre"))
                .setView(input)
                .setNegativeButton(t("Cancelar"), null)
                .setPositiveButton(t("Guardar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String clean = input.getText().toString().trim().replaceAll("[\\/:*?\"<>|]", "_");
                        if (clean.length() == 0) {
                            Toast.makeText(MainActivity.this, t("Nombre inválido"), Toast.LENGTH_SHORT).show();
                            return;
                        }
                        File renamed = new File(file.getParentFile(), clean + extension);
                        if (renamed.exists()) {
                            Toast.makeText(MainActivity.this, t("Ya existe un archivo con ese nombre"), Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (file.renameTo(renamed)) {
                            Toast.makeText(MainActivity.this, t("Nombre actualizado"), Toast.LENGTH_SHORT).show();
                            showFileLibrary(libraryShowingType);
                        } else {
                            Toast.makeText(MainActivity.this, t("No se pudo cambiar el nombre"), Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .show();
    }

    private void deleteLibraryFile(final File file) {
        AlertDialog deleteDialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Eliminar archivo"))
                .setMessage(t("¿Eliminar " + file.getName() + "?"))
                .setNegativeButton(t("Cancelar"), null)
                .setPositiveButton(t("Eliminar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        stopFilePreview();
                        if (file.delete()) {
                            removeEmptyParentFolders(file.getParentFile());
                            // La lista guardada ya no coincide con el disco:
                            // se invalida para que el borrado se refleje ya.
                            invalidateLibraryCache();
                            Toast.makeText(MainActivity.this, t("Archivo eliminado"), Toast.LENGTH_SHORT).show();
                            showFileLibrary(libraryShowingType);
                        } else {
                            Toast.makeText(MainActivity.this, t("No se pudo eliminar"), Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .create();
        deleteDialog.show();
        styleDialog(deleteDialog);
    }

    private void removeEmptyParentFolders(File folder) {
        if (folder == null) return;
        File audioRoot = getAudioSaveDir();
        File imageRoot = getImageSaveDir();
        File pdfRoot = getPdfSaveDir();
        File legacyAudioRoot = new File(getStorageBase(Environment.DIRECTORY_MUSIC), "PDF_Audio");
        File legacyImageRoot = new File(getStorageBase(Environment.DIRECTORY_PICTURES), "PDF_Audio");
        File legacyPdfRoot = new File(getStorageBase(Environment.DIRECTORY_DOCUMENTS), "PDF_Audio");
        if (folder.equals(audioRoot) || folder.equals(imageRoot) || folder.equals(pdfRoot)
                || folder.equals(legacyAudioRoot) || folder.equals(legacyImageRoot) || folder.equals(legacyPdfRoot)) return;
        File[] children = folder.listFiles();
        if (children != null && children.length == 0) {
            File parent = folder.getParentFile();
            folder.delete();
            removeEmptyParentFolders(parent);
        }
    }

    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L * 1024L) return String.format(Locale.US, "%.1f KB", bytes / 1024f);
        return String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f));
    }

    private String formatFileSizePretty(long bytes) {
        if (bytes <= 0) return t("Tamaño pendiente");
        return formatFileSize(bytes);
    }

    private String formatFileDate(long time) {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date(time));
    }

    private String audioDurationCacheKey(File file) {
        if (file == null) return "";
        return file.getAbsolutePath() + "#" + file.length() + "#" + file.lastModified();
    }

    private void loadAudioDurationAsync(final File file, final TextView target, final String staticDetails) {
        if (file == null || target == null) return;
        final String key = audioDurationCacheKey(file);
        audioMetadataExecutor.execute(new Runnable() {
            @Override public void run() {
                final String duration = getAudioDurationText(file);
                audioDurationCache.put(key, duration);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Object tag = target.getTag();
                        if (tag != null && key.equals(tag.toString())) {
                            target.setText(duration + "   " + staticDetails);
                        }
                    }
                });
            }
        });
    }

    private String getAudioDurationText(File file) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(file.getAbsolutePath());
            String duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (duration != null) return formatDuration(Integer.parseInt(duration));
        } catch (Exception ignored) {
        } finally {
            try { retriever.release(); } catch (Exception ignored) { }
        }
        return "--:--";
    }

    private String formatDuration(int milliseconds) {
        int totalSeconds = Math.max(0, milliseconds / 1000);
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;
        if (hours > 0) return String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds);
        return String.format(Locale.US, "%02d:%02d", minutes, seconds);
    }

    private void showSavedFileActions(final File file, final boolean audio) {
        // Se guardo un archivo nuevo: la lista de "Mis archivos" ya no
        // coincide con el disco.
        invalidateLibraryCache();
        LinearLayout box = makeDialogContainer();

        TextView title = new TextView(this);
        title.setText(audio ? t("Audio guardado") : t("Imagen guardada"));
        title.setTextSize(uiSp(20));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        box.addView(title);

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextSize(uiSp(14));
        name.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(71, 85, 105));
        name.setPadding(0, uiDp(6), 0, 0);
        box.addView(name);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(box)
                .setPositiveButton(audio ? t("Reproducir") : t("Galería"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (audio) showAudioPreview(file);
                        else showFileLibrary(false);
                    }
                })
                .setNeutralButton(t("Compartir"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        shareFile(file);
                    }
                })
                .setNegativeButton(t("Cerrar"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }


    private void showAudioExportCompleted() {
        showExportFinishedNotification(exportSavedCount > 0);
        // Cubre tambien el caso de varios audios guardados de una
        // (showSavedFileActions ya invalida el caso de uno solo).
        invalidateLibraryCache();
        if (exportSavedCount == 1 && lastExportedAudioFile != null && lastExportedAudioFile.exists()) {
            showSavedFileActions(lastExportedAudioFile, true);
            return;
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Audio terminado"))
                .setMessage(t(exportSavedCount + " archivo(s) guardado(s) en Mis archivos"))
                .setPositiveButton(t("Ver audios"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showFileLibrary(true);
                    }
                })
                .setNegativeButton(t("Cerrar"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void saveCurrentPageImage() {
        // Un segundo toque en menos de 400 ms no abre otra copia de esta pantalla.
        if (!acceptTap("saveCurrentPageImage")) return;
        if (currentFile == null || pdfView == null || pageCount <= 0) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }
        if (!hasAdvancedAccess()) {
            requireAdvancedAccess("Guardar imagen", new Runnable() {
                @Override
                public void run() { saveCurrentPageImage(); }
            });
            return;
        }

        final int pageToSave = currentPage;
        final String titleToSave = currentTitle;
        final File dir = getImageSaveDir();
        final String clean = titleToSave == null ? "pdf"
                : titleToSave.replaceAll("[^a-zA-Z0-9._-]", "_");
        final File out = new File(dir, clean + "_pagina_" + (pageToSave + 1) + ".png");

        // Indicador de progreso: generar la imagen en alta definicion de una
        // pagina densa puede tardar un par de segundos, y sin nada en pantalla
        // parecia que la app se habia colgado. Se muestra una rueda mientras se
        // guarda y se cierra al abrir la imagen o si algo falla.
        final View progress = showInlineBusyOverlay(false);

        imageExportExecutor.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = null;
                try {
                    bitmap = pdfView.exportPageBitmapHd(pageToSave, false);
                    if (bitmap == null) throw new IllegalStateException("bitmap null");

                    try (FileOutputStream fos = new FileOutputStream(out)) {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                        fos.flush();
                    }
                    // Deja una vista previa con la proporcion real ya preparada.
                    // Al abrir o deslizar hacia esta imagen el visor nunca queda
                    // un frame sin bitmap mientras decodifica la version HD.
                    try {
                        int maxEdge = Math.max(bitmap.getWidth(), bitmap.getHeight());
                        float scale = maxEdge > 1200 ? 1200f / maxEdge : 1f;
                        int pw = Math.max(1, Math.round(bitmap.getWidth() * scale));
                        int ph = Math.max(1, Math.round(bitmap.getHeight() * scale));
                        Bitmap preview = Bitmap.createScaledBitmap(bitmap, pw, ph, true);
                        if (preview == bitmap) preview = bitmap.copy(Bitmap.Config.ARGB_8888, false);
                        if (preview != null) imagePreviewCache.put(out.getAbsolutePath(), preview);
                    } catch (Throwable ignored) { }
                    bitmap.recycle();
                    bitmap = null;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // v164: la imagen se abre directamente, pero por la via
                            // sin parpadeo. El visor se monta transparente sobre la
                            // pantalla actual y solo se hace visible cuando ya tiene
                            // dibujada la imagen real; la rueda de progreso se retira
                            // en ese mismo frame. Asi no queda ningun frame vacio en
                            // medio, que era el "tick" negro que se veia al guardar.
                            invalidateLibraryCache();
                            showFullscreenImageViewer(out, new Runnable() {
                                @Override public void run() {
                                    dismissInlineBusyOverlay(progress);
                                }
                            });
                        }
                    });
                } catch (Exception e) {
                    if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            dismissInlineBusyOverlay(progress);
                            Toast.makeText(MainActivity.this,
                                    t("No se pudo guardar la imagen"), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }

    /**
     * Indicador dentro de la misma Activity. A diferencia de AlertDialog no crea
     * una segunda ventana ni cambia el dim del sistema, evitando flashes negros
     * al pasar del PDF al visor o entre pasos de exportacion.
     */
    private View showInlineBusyOverlay(boolean dimBackground) {
        try {
            ViewGroup host = getOverlayHost();
            if (host == null) return null;
            FrameLayout overlay = new FrameLayout(this);
            overlay.setClickable(true);
            overlay.setFocusable(true);
            overlay.setBackgroundColor(dimBackground ? 0x33000000 : Color.TRANSPARENT);

            ProgressBar spinner = new ProgressBar(this);
            spinner.setIndeterminate(true);
            FrameLayout.LayoutParams spLp = new FrameLayout.LayoutParams(uiDp(48), uiDp(48));
            spLp.gravity = Gravity.CENTER;
            overlay.addView(spinner, spLp);

            host.addView(overlay, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));
            return overlay;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private void dismissInlineBusyOverlay(View overlay) {
        if (overlay == null) return;
        try {
            if (overlay.getParent() instanceof ViewGroup) {
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            }
        } catch (Throwable ignored) { }
    }

    /**
     * Aviso de guardado dentro de la misma Activity. No crea Dialog, Toast de
     * sistema ni otra ventana, por lo que no puede introducir un frame negro.
     */
    private void showInlineSavedNotice(String message, String actionLabel,
                                       final View.OnClickListener action) {
        try {
            final ViewGroup host = getOverlayHost();
            if (host == null) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                return;
            }

            final LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(uiDp(16), uiDp(10), uiDp(10), uiDp(10));
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(uiDp(14));
            bg.setColor(darkTheme ? Color.rgb(17, 48, 68) : Color.WHITE);
            bg.setStroke(uiDp(1), darkTheme ? Color.rgb(55, 91, 116) : Color.rgb(203, 213, 225));
            card.setBackground(bg);
            card.setElevation(uiDp(8));

            TextView text = new TextView(this);
            text.setText("✓  " + message);
            text.setTextSize(uiSp(14));
            text.setTypeface(Typeface.DEFAULT_BOLD);
            text.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
            card.addView(text, new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            if (action != null && actionLabel != null && actionLabel.length() > 0) {
                TextView actionView = new TextView(this);
                actionView.setText(actionLabel.toUpperCase(Locale.ROOT));
                actionView.setGravity(Gravity.CENTER);
                actionView.setTypeface(Typeface.DEFAULT_BOLD);
                actionView.setTextSize(uiSp(13));
                actionView.setTextColor(Color.rgb(96, 165, 250));
                actionView.setPadding(uiDp(14), uiDp(8), uiDp(10), uiDp(8));
                actionView.setClickable(true);
                actionView.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        try {
                            if (card.getParent() instanceof ViewGroup) {
                                ((ViewGroup) card.getParent()).removeView(card);
                            }
                        } catch (Throwable ignored) { }
                        action.onClick(v);
                    }
                });
                card.addView(actionView, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
            }

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.BOTTOM;
            lp.leftMargin = uiDp(14);
            lp.rightMargin = uiDp(14);
            // Lo mantenemos por encima de los controles inferiores del lector.
            lp.bottomMargin = uiDp(118);
            host.addView(card, lp);
            card.setAlpha(0f);
            card.setTranslationY(uiDp(12));
            card.animate().alpha(1f).translationY(0f).setDuration(140L).start();

            card.postDelayed(new Runnable() {
                @Override public void run() {
                    if (!(card.getParent() instanceof ViewGroup)) return;
                    card.animate().alpha(0f).translationY(uiDp(8)).setDuration(140L)
                            .withEndAction(new Runnable() {
                                @Override public void run() {
                                    try {
                                        if (card.getParent() instanceof ViewGroup) {
                                            ((ViewGroup) card.getParent()).removeView(card);
                                        }
                                    } catch (Throwable ignored) { }
                                }
                            }).start();
                }
            }, 4200L);
        } catch (Throwable ignored) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Indicador modal heredado para otros flujos. Las rutas sensibles al flash
     * usan showInlineBusyOverlay y no cambian de ventana.
     */
    private AlertDialog showBusyDialog(String message) {
        return showBusyDialog(message, true);
    }

    private AlertDialog showBusyDialog(String message, boolean dimBackground) {
        try {
            FrameLayout box = new FrameLayout(this);
            box.setPadding(uiDp(18), uiDp(18), uiDp(18), uiDp(18));

            ProgressBar spinner = new ProgressBar(this);
            spinner.setIndeterminate(true);
            FrameLayout.LayoutParams spLp = new FrameLayout.LayoutParams(uiDp(44), uiDp(44));
            spLp.gravity = Gravity.CENTER;
            box.addView(spinner, spLp);

            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setView(box)
                    .setCancelable(false)
                    .create();
            dialog.show();
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
                params.dimAmount = dimBackground ? 0.20f : 0f;
                dialog.getWindow().setAttributes(params);
                if (dimBackground) {
                    dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                } else {
                    // Guardar imagen: no oscurecer la Activity. El antiguo dim de
                    // una segunda ventana podia producir un frame negro al pasar
                    // del PDF al visor en algunos telefonos.
                    dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                }
            }
            return dialog;
        } catch (Exception e) {
            return null;
        }
    }

    private void dismissBusyDialog(AlertDialog dialog) {
        if (dialog == null) return;
        try {
            if (dialog.isShowing()) dialog.dismiss();
        } catch (Exception ignored) {
        }
    }


    /**
     * Guardar PDF: elige que paginas y luego si se guarda igual que el original
     * o con las marcas hechas encima.
     */
    private void showPdfExportDialog() {
        // Un segundo toque en menos de 400 ms no abre otra copia de este cuadro.
        if (!acceptTap("showPdfExportDialog")) return;
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }
        if (!hasAdvancedAccess()) {
            requireAdvancedAccess("Guardar PDF", new Runnable() {
                @Override public void run() { showPdfExportDialog(); }
            });
            return;
        }

        // v162: Guardar PDF deja de usar AlertDialog por completo. Todo vive
        // dentro del mismo FrameLayout de la Activity, asi el sistema nunca
        // cambia de Window ni de capa de dim entre "paginas" y "como guardarlo".
        final ViewGroup host = getOverlayHost();
        if (host == null) return;

        final FrameLayout overlay = new FrameLayout(this);
        overlay.setClickable(true);
        overlay.setFocusable(true);
        overlay.setBackgroundColor(0x66000000);

        final LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(makeRoundedPanelBackground());
        panel.setPadding(0, uiDp(4), 0, uiDp(4));

        final TextView dialogTitle = new TextView(this);
        dialogTitle.setText(t("Guardar PDF"));
        dialogTitle.setTextSize(uiSp(22));
        dialogTitle.setTypeface(Typeface.DEFAULT_BOLD);
        dialogTitle.setTextColor(Color.WHITE);
        dialogTitle.setPadding(uiDp(20), uiDp(16), uiDp(20), uiDp(12));
        panel.addView(dialogTitle, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // El panel ahora se ajusta a su contenido. Para que un paso largo no
        // empuje el titulo ni la fila de Cancelar fuera de la pantalla, esta
        // lista nunca pasa de la altura disponible y a partir de ahi se desliza.
        final ScrollView scroll = new ScrollView(this) {
            @Override
            protected void onMeasure(int widthSpec, int heightSpec) {
                int reserved = uiDp(96 + 54 + 56);
                int available = getResources().getDisplayMetrics().heightPixels - reserved;
                int limit = Math.max(uiDp(140), available);
                super.onMeasure(widthSpec,
                        MeasureSpec.makeMeasureSpec(limit, MeasureSpec.AT_MOST));
            }
        };
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(uiDp(20), uiDp(8), uiDp(20), uiDp(14));
        // Mismo color de siempre pero con esquinas redondeadas. Antes era un
        // rectangulo recto y sus cuatro puntas sobresalian por encima del borde
        // curvo del dialogo: esas puntas eran los "ticks" feos de los bordes.
        box.setBackground(makeRoundedContentBackground());
        scroll.addView(box, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT));
        panel.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        final TextView cancel = new TextView(this);
        cancel.setText(t("Cancelar"));
        cancel.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        cancel.setTextSize(uiSp(14));
        cancel.setTypeface(Typeface.DEFAULT_BOLD);
        cancel.setTextColor(Color.rgb(96, 165, 250));
        cancel.setPadding(uiDp(20), uiDp(10), uiDp(22), uiDp(14));
        cancel.setClickable(true);
        panel.addView(cancel, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(54)));

        // El panel crece solo lo que necesita su contenido y nunca mas alla del
        // hueco disponible (el ScrollView se encarga si un paso es largo). Antes
        // era MATCH_PARENT y el paso corto dejaba media pantalla vacia.
        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        panelLp.gravity = Gravity.CENTER;
        panelLp.leftMargin = uiDp(18);
        panelLp.rightMargin = uiDp(18);
        panelLp.topMargin = uiDp(48);
        panelLp.bottomMargin = uiDp(48);
        overlay.addView(panel, panelLp);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                removeInlineOverlay(overlay);
            }
        });

        showPdfScopeStep(overlay, dialogTitle, box, cancel);
        host.addView(overlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
    }

    /**
     * Fondo del contenido de los cuadros de herramientas. Conserva el color de
     * siempre y solo redondea las esquinas para que encajen dentro del borde
     * curvo del dialogo que lo contiene.
     */
    private GradientDrawable makeRoundedContentBackground() {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(18));
        bg.setColor(Color.rgb(9, 20, 34));
        return bg;
    }

    private GradientDrawable makeRoundedPanelBackground() {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(18));
        bg.setColor(Color.rgb(9, 20, 34));
        bg.setStroke(uiDp(1), Color.rgb(24, 52, 72));
        return bg;
    }

    private void removeInlineOverlay(View overlay) {
        if (overlay == null) return;
        try {
            if (overlay.getParent() instanceof ViewGroup) {
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            }
        } catch (Throwable ignored) { }
    }

    private void resetPdfExportStep(LinearLayout box) {
        if (box == null) return;
        box.removeAllViews();
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(uiDp(20), uiDp(8), uiDp(20), uiDp(14));
        // Mismo color de siempre pero con esquinas redondeadas. Antes era un
        // rectangulo recto y sus cuatro puntas sobresalian por encima del borde
        // curvo del dialogo: esas puntas eran los "ticks" feos de los bordes.
        box.setBackground(makeRoundedContentBackground());
    }

    private void showPdfScopeStep(final FrameLayout overlay, final TextView dialogTitle,
                                  final LinearLayout box, final TextView cancel) {
        if (overlay == null || box == null) return;
        dialogTitle.setText(t("Guardar PDF"));
        cancel.setText(t("Cancelar"));
        cancel.setEnabled(true);
        cancel.setAlpha(1f);
        resetPdfExportStep(box);

        PdfEmblemView emblem = new PdfEmblemView(this);
        LinearLayout.LayoutParams emblemLp = new LinearLayout.LayoutParams(uiDp(104), uiDp(104));
        emblemLp.topMargin = uiDp(6);
        emblemLp.bottomMargin = uiDp(10);
        box.addView(emblem, emblemLp);

        TextView info = new TextView(this);
        info.setText(t("Elige una opción"));
        info.setTextSize(uiSp(16));
        info.setTypeface(Typeface.DEFAULT_BOLD);
        info.setGravity(Gravity.CENTER);
        info.setTextColor(Color.rgb(226, 240, 245));
        info.setPadding(0, 0, 0, uiDp(4));
        box.addView(info);

        TextView folder = new TextView(this);
        folder.setText(t("Se guardará en  Geo Zeta / PDF marcados"));
        folder.setTextSize(uiSp(13));
        folder.setGravity(Gravity.CENTER);
        folder.setTextColor(Color.rgb(120, 145, 165));
        folder.setPadding(0, 0, 0, uiDp(14));
        box.addView(folder);

        final SelectableOptionCard current = makeSelectableAudioOptionCard(
                "icon:doc", Color.rgb(96, 165, 250),
                "Página actual", "", true);
        final SelectableOptionCard range = makeSelectableAudioOptionCard(
                "icon:range", Color.rgb(129, 140, 248),
                "Elegir rango", "", false);
        final SelectableOptionCard full = makeSelectableAudioOptionCard(
                "icon:book", Color.rgb(96, 130, 240),
                "Todo el PDF", "", false);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(68));
        cardLp.setMargins(0, uiDp(4), 0, uiDp(4));
        box.addView(current.root, cardLp);
        box.addView(range.root, cardLp);
        box.addView(full.root, cardLp);

        current.root.setOnClickListener(v -> selectOnly(current, current, range, full));
        range.root.setOnClickListener(v -> selectOnly(range, current, range, full));
        full.root.setOnClickListener(v -> selectOnly(full, current, range, full));
        current.arrow.setOnClickListener(v ->
                showPdfModeStep(overlay, dialogTitle, box, cancel, currentPage, currentPage));
        range.arrow.setOnClickListener(v ->
                showPdfRangeStep(overlay, dialogTitle, box, cancel));
        full.arrow.setOnClickListener(v ->
                showPdfModeStep(overlay, dialogTitle, box, cancel, 0, pageCount - 1));
    }

    private void showPdfRangeStep(final FrameLayout overlay, final TextView dialogTitle,
                                  final LinearLayout box, final TextView cancel) {
        dialogTitle.setText(t("Elegir rango"));
        resetPdfExportStep(box);

        final EditText startInput = new EditText(this);
        startInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        startInput.setHint(t("Desde (1 - " + pageCount + ")"));
        startInput.setText(String.valueOf(currentPage + 1));
        startInput.setTextColor(Color.WHITE);
        startInput.setHintTextColor(Color.rgb(148, 163, 184));

        final EditText endInput = new EditText(this);
        endInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        endInput.setHint(t("Hasta (1 - " + pageCount + ")"));
        endInput.setText(String.valueOf(currentPage + 1));
        endInput.setTextColor(Color.WHITE);
        endInput.setHintTextColor(Color.rgb(148, 163, 184));

        box.addView(startInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        box.addView(endInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        Button continueButton = makeButton("Continuar");
        continueButton.setTextSize(uiSp(14));
        LinearLayout.LayoutParams continueLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(52));
        continueLp.topMargin = uiDp(14);
        box.addView(continueButton, continueLp);

        TextView back = new TextView(this);
        back.setText("‹ " + t("Volver"));
        back.setTextSize(uiSp(14));
        back.setGravity(Gravity.CENTER);
        back.setTextColor(Color.rgb(96, 165, 250));
        back.setPadding(0, uiDp(12), 0, uiDp(4));
        back.setClickable(true);
        box.addView(back, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(48)));

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int start;
                int end;
                try {
                    start = Integer.parseInt(startInput.getText().toString().trim()) - 1;
                    end = Integer.parseInt(endInput.getText().toString().trim()) - 1;
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, t("Rango inválido"), Toast.LENGTH_SHORT).show();
                    return;
                }
                if (start < 0 || end < 0 || start >= pageCount || end >= pageCount) {
                    Toast.makeText(MainActivity.this, t("Rango inválido"), Toast.LENGTH_SHORT).show();
                    return;
                }
                showPdfModeStep(overlay, dialogTitle, box, cancel, start, end);
            }
        });
        back.setOnClickListener(v -> showPdfScopeStep(overlay, dialogTitle, box, cancel));
    }

    private void showPdfModeStep(final FrameLayout overlay, final TextView dialogTitle,
                                 final LinearLayout box, final TextView cancel,
                                 final int startPage, final int endPage) {
        dialogTitle.setText(t("¿Cómo guardarlo?"));
        resetPdfExportStep(box);
        box.setPadding(uiDp(20), uiDp(6), uiDp(20), uiDp(14));

        View clean = makeAudioOptionCard("icon:doc", Color.rgb(96, 165, 250),
                "Original sin marcas",
                "Igual que el PDF original, el texto se puede leer en voz alta", true);
        View marked = makeAudioOptionCard("icon:mark", Color.rgb(250, 204, 21),
                "Con mis marcas",
                "Incluye subrayados y resaltados; queda como imágenes", false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(86));
        lp.setMargins(0, uiDp(6), 0, uiDp(6));
        box.addView(clean, lp);
        box.addView(marked, lp);

        TextView back = new TextView(this);
        back.setText("‹ " + t("Volver"));
        back.setTextSize(uiSp(14));
        back.setGravity(Gravity.CENTER);
        back.setTextColor(Color.rgb(96, 165, 250));
        back.setPadding(0, uiDp(10), 0, 0);
        back.setClickable(true);
        box.addView(back, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(44)));

        clean.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startPdfExportInline(overlay, dialogTitle, box, cancel,
                        startPage, endPage, false);
            }
        });
        marked.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startPdfExportInline(overlay, dialogTitle, box, cancel,
                        startPage, endPage, true);
            }
        });
        back.setOnClickListener(v -> showPdfScopeStep(overlay, dialogTitle, box, cancel));
    }

    private void startPdfExportInline(final FrameLayout overlay,
                                      final TextView dialogTitle,
                                      final LinearLayout box,
                                      final TextView cancel,
                                      int startPage, int endPage,
                                      final boolean withMarks) {
        if (currentFile == null || pageCount <= 0 || overlay == null || box == null) return;

        int a = Math.max(0, Math.min(startPage, pageCount - 1));
        int b = Math.max(0, Math.min(endPage, pageCount - 1));
        final int first = Math.min(a, b);
        final int last = Math.max(a, b);

        final File source = currentFile;
        final File dir = getPdfSaveDir();
        final String clean = currentTitle == null ? "pdf"
                : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_").replaceAll("\\.pdf$", "");
        final String suffix = (first == last)
                ? ("_pagina_" + (first + 1))
                : ("_" + (first + 1) + "-" + (last + 1));
        final File out = new File(dir, clean + suffix + (withMarks ? "_marcado" : "") + ".pdf");

        dialogTitle.setText(t("Guardando PDF..."));
        resetPdfExportStep(box);
        box.setGravity(Gravity.CENTER);
        cancel.setEnabled(false);
        cancel.setAlpha(0.35f);

        ProgressBar spinner = new ProgressBar(this);
        spinner.setIndeterminate(true);
        box.addView(spinner, new LinearLayout.LayoutParams(uiDp(52), uiDp(52)));
        TextView wait = new TextView(this);
        wait.setText(t("Guardando PDF..."));
        wait.setTextSize(uiSp(15));
        wait.setGravity(Gravity.CENTER);
        wait.setTextColor(Color.rgb(200, 215, 228));
        LinearLayout.LayoutParams waitLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        waitLp.topMargin = uiDp(14);
        box.addView(wait, waitLp);

        imageExportExecutor.execute(new Runnable() {
            @Override
            public void run() {
                boolean ok = withMarks
                        ? writeMarkedPdf(out, first, last)
                        : writeCleanPdf(source, out, first, last);
                final boolean success = ok;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (overlay.getParent() == null) return;
                        resetPdfExportStep(box);
                        box.setGravity(Gravity.CENTER_HORIZONTAL);
                        cancel.setEnabled(true);
                        cancel.setAlpha(1f);
                        cancel.setText(t("Cerrar"));
                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override public void onClick(View v) {
                                removeInlineOverlay(overlay);
                            }
                        });

                        if (success) {
                            invalidateLibraryCache();
                            dialogTitle.setText(t("PDF guardado"));
                            TextView check = new TextView(MainActivity.this);
                            check.setText("✓");
                            check.setTextSize(uiSp(42));
                            check.setGravity(Gravity.CENTER);
                            check.setTextColor(Color.rgb(45, 212, 191));
                            box.addView(check, new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT, uiDp(72)));

                            TextView saved = new TextView(MainActivity.this);
                            saved.setText(t("PDF guardado en Geo Zeta / PDF marcados"));
                            saved.setTextSize(uiSp(15));
                            saved.setGravity(Gravity.CENTER);
                            saved.setTextColor(Color.rgb(226, 240, 245));
                            saved.setPadding(uiDp(8), uiDp(8), uiDp(8), 0);
                            box.addView(saved, new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT));
                        } else {
                            dialogTitle.setText(t("No se pudo guardar el PDF"));
                            TextView error = new TextView(MainActivity.this);
                            error.setText(t("No se pudo guardar el PDF"));
                            error.setTextSize(uiSp(15));
                            error.setGravity(Gravity.CENTER);
                            error.setTextColor(Color.rgb(248, 113, 113));
                            box.addView(error, new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT));
                        }
                    }
                });
            }
        });
    }

    /**
     * Copia las paginas pedidas tal cual estan en el archivo original. Se usa
     * PDFBox y no imagenes para que el texto siga siendo texto: asi el PDF
     * guardado se puede volver a leer en voz alta.
     */
    private boolean writeCleanPdf(File source, File out, int first, int last) {
        com.tom_roush.pdfbox.pdmodel.PDDocument src = null;
        com.tom_roush.pdfbox.pdmodel.PDDocument dst = null;
        try {
            if (out.getParentFile() != null) out.getParentFile().mkdirs();
            src = com.tom_roush.pdfbox.pdmodel.PDDocument.load(source);
            dst = new com.tom_roush.pdfbox.pdmodel.PDDocument();
            int total = src.getNumberOfPages();
            for (int i = first; i <= last && i < total; i++) {
                dst.addPage(src.getPage(i));
            }
            if (dst.getNumberOfPages() == 0) return false;
            dst.save(out);
            return true;
        } catch (Exception e) {
            return false;
        } catch (OutOfMemoryError e) {
            return false;
        } finally {
            try { if (dst != null) dst.close(); } catch (Exception ignored) { }
            try { if (src != null) src.close(); } catch (Exception ignored) { }
        }
    }

    /**
     * Genera un PDF con las paginas dibujadas como imagen, para que se vean los
     * subrayados y resaltados. Las reglas de lectura no se incluyen.
     */
    private boolean writeMarkedPdf(File out, int first, int last) {
        if (pdfView == null) return false;
        android.graphics.pdf.PdfDocument doc = new android.graphics.pdf.PdfDocument();
        FileOutputStream fos = null;
        boolean wrote = false;
        try {
            if (out.getParentFile() != null) out.getParentFile().mkdirs();
            for (int i = first; i <= last; i++) {
                Bitmap bitmap = pdfView.exportPageBitmapHd(i, false);
                if (bitmap == null) continue;
                try {
                    // Se limita el lado mayor para no agotar la memoria en
                    // rangos largos; sigue siendo mas que suficiente para leer.
                    int w = bitmap.getWidth();
                    int h = bitmap.getHeight();
                    int maxSide = 2000;
                    if (Math.max(w, h) > maxSide) {
                        float scale = maxSide / (float) Math.max(w, h);
                        w = Math.max(1, Math.round(w * scale));
                        h = Math.max(1, Math.round(h * scale));
                    }
                    android.graphics.pdf.PdfDocument.PageInfo info =
                            new android.graphics.pdf.PdfDocument.PageInfo.Builder(w, h, i + 1).create();
                    android.graphics.pdf.PdfDocument.Page page = doc.startPage(info);
                    Canvas canvas = page.getCanvas();
                    canvas.drawColor(Color.WHITE);
                    canvas.drawBitmap(bitmap, null, new RectF(0f, 0f, w, h), null);
                    doc.finishPage(page);
                    wrote = true;
                } finally {
                    if (!bitmap.isRecycled()) bitmap.recycle();
                }
            }
            if (!wrote) return false;
            fos = new FileOutputStream(out);
            doc.writeTo(fos);
            fos.flush();
            return true;
        } catch (Exception e) {
            return false;
        } catch (OutOfMemoryError e) {
            return false;
        } finally {
            try { if (fos != null) fos.close(); } catch (Exception ignored) { }
            doc.close();
        }
    }

    private void cancelTtsWarmup() {
        if (ttsWarmupRunnable != null) {
            audioStartHandler.removeCallbacks(ttsWarmupRunnable);
            ttsWarmupRunnable = null;
        }
    }

    /**
     * Enciende el motor de voz ya mismo, sin esperas. Se llama en los tres
     * momentos en que el usuario puede pedir Play a continuación: al abrir un
     * PDF, al volver a la app y al saltar de pagina. Si el motor ya esta listo
     * con el idioma correcto no hace nada, asi que es barato repetirla.
     */
    private void warmTtsEngineNow() {
        cancelTtsWarmup();
        TtsEngineManager manager = TtsEngineManager.getInstance(this);
        if (manager.isReady() && (currentPdfLanguage.length() == 0
                || (currentPdfLanguage.equals(manager.getPreferredLanguage())
                && manager.isPreferredLanguageAvailable()))) {
            return;
        }
        if (currentPdfLanguage.length() > 0) {
            manager.ensureLanguage(currentPdfLanguage, appRegion, null);
        } else if (PdfLanguageDetector.isSupported(appLanguage)) {
            // Todavia no se detecto el idioma del PDF: se adelanta con el idioma
            // de la app, que es el candidato mas probable. Si luego se detecta
            // otro, saveCurrentPdfLanguage vuelve a preparar el correcto.
            manager.ensureLanguage(appLanguage, appRegion, null);
        } else {
            manager.initialize(null);
        }
    }

    private void scheduleTtsWarmup(long delayMs) {
        cancelTtsWarmup();
        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        if (manager.isReady() && (currentPdfLanguage.length() == 0
                || (currentPdfLanguage.equals(manager.getPreferredLanguage())
                && manager.isPreferredLanguageAvailable()))) return;
        // Do not warm an arbitrary language while a PDF is still being detected.
        // That only creates work that may have to be discarded a moment later.
        if (currentFile != null && currentPdfLanguage.length() == 0) return;
        ttsWarmupRunnable = new Runnable() {
            @Override
            public void run() {
                ttsWarmupRunnable = null;
                if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                if (currentPdfLanguage.length() > 0) {
                    manager.ensureLanguage(currentPdfLanguage, appRegion, null);
                } else if (PdfLanguageDetector.isSupported(appLanguage)) {
                    // Se adelanta con el idioma de la app: es el candidato mas
                    // probable y asi el arranque frio del motor ocurre antes de
                    // que el usuario llegue al boton de Play.
                    manager.ensureLanguage(appLanguage, appRegion, null);
                } else {
                    manager.initialize(null);
                }
            }
        };
        audioStartHandler.postDelayed(ttsWarmupRunnable, Math.max(0L, delayMs));
    }

    private void choosePdf() {
        // A partir de aqui el tiempo lo marca la persona buscando su archivo, no
        // la app: la medida de arranque queda anulada.
        startupClockValid = false;
        startupClockReported = true;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        startActivityForResult(intent, REQ_OPEN_PDF);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OPEN_PDF && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            showPdfModeDialog(uri);
        }
    }

    private void showPdfModeDialog(final Uri uri) {
        if (uri == null) return;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(uiDp(20), uiDp(8), uiDp(20), uiDp(14));
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        // Mismo color de siempre pero con esquinas redondeadas. Antes era un
        // rectangulo recto y sus cuatro puntas sobresalian por encima del borde
        // curvo del dialogo: esas puntas eran los "ticks" feos de los bordes.
        box.setBackground(makeRoundedContentBackground());

        PdfModeEmblemView emblem = new PdfModeEmblemView(this);
        LinearLayout.LayoutParams emblemLp = new LinearLayout.LayoutParams(uiDp(96), uiDp(96));
        emblemLp.topMargin = uiDp(4);
        emblemLp.bottomMargin = uiDp(8);
        box.addView(emblem, emblemLp);

        TextView info = new TextView(this);
        info.setText(t("Elige cómo quieres leer este documento"));
        info.setTextSize(uiSp(16));
        info.setTypeface(Typeface.DEFAULT_BOLD);
        info.setGravity(Gravity.CENTER);
        info.setTextColor(Color.rgb(226, 240, 245));
        info.setPadding(0, 0, 0, uiDp(3));
        box.addView(info);

        // Se quita la linea "Elige una opción": el titulo de arriba ya dice
        // "Elige cómo quieres leer este documento" y repetirlo solo alargaba el
        // cuadro. Los subtitulos de las dos tarjetas tambien sobran: se cortaban
        // a media palabra y sus titulos ya se entienden solos.
        final boolean ocrLocked = !hasAdvancedAccess();
        final SelectableOptionCard textMode = makeSelectableModeOptionCard(
                "PDF con texto", "", false, true, false);
        final SelectableOptionCard ocrMode = makeSelectableModeOptionCard(
                "PDF escaneado (OCR)", "", true, false, ocrLocked);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(68));
        lp.setMargins(0, uiDp(5), 0, uiDp(5));
        box.addView(textMode.root, lp);
        box.addView(ocrMode.root, lp);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Tipo de PDF"))
                .setView(box)
                .setNegativeButton(t("Cancelar"), null)
                .create();

        textMode.root.setOnClickListener(v -> selectOnly(textMode, textMode, ocrMode));
        ocrMode.root.setOnClickListener(v -> {
            if (ocrLocked) {
                dialog.dismiss();
                requireAdvancedAccess("Lectura OCR", new Runnable() {
                    @Override public void run() {
                        switchTextMode(true);
                        copyAndOpen(uri);
                    }
                });
            } else {
                selectOnly(ocrMode, textMode, ocrMode);
            }
        });

        textMode.arrow.setOnClickListener(v -> {
            dialog.dismiss();
            switchTextMode(false);
            copyAndOpen(uri);
        });
        ocrMode.arrow.setOnClickListener(v -> {
            dialog.dismiss();
            requireAdvancedAccess("Lectura OCR", new Runnable() {
                @Override public void run() {
                    switchTextMode(true);
                    copyAndOpen(uri);
                }
            });
        });

        dialog.show();
        if (dialog.getWindow() != null) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(18));
            bg.setColor(Color.rgb(9, 20, 34));
            dialog.getWindow().setBackgroundDrawable(bg);
        }
        applyDialogTextColors(dialog);
    }

    private View makeModeOptionCard(String title, String subtitle, boolean ocr) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(uiDp(14), uiDp(10), uiDp(14), uiDp(10));
        card.setClickable(true);
        card.setFocusable(true);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(16));
        bg.setColor(darkTheme ? Color.rgb(16, 30, 48) : Color.WHITE);
        int accent = ocr ? Color.rgb(45, 212, 191) : Color.rgb(96, 130, 240);
        bg.setStroke(uiDp(1), accent);
        card.setBackground(bg);

        TextView icon = new TextView(this);
        icon.setText(ocr ? "OCR" : "Aa");
        icon.setGravity(Gravity.CENTER);
        icon.setTextSize(uiSp(14));
        icon.setTypeface(Typeface.DEFAULT_BOLD);
        icon.setTextColor(accent);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(Color.argb(34, Color.red(accent), Color.green(accent), Color.blue(accent)));
        iconBg.setStroke(uiDp(1), Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent)));
        icon.setBackground(iconBg);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(uiDp(50), uiDp(50));
        iconLp.rightMargin = uiDp(14);
        card.addView(icon, iconLp);

        LinearLayout textBox = new LinearLayout(this);
        textBox.setOrientation(LinearLayout.VERTICAL);
        TextView titleView = new TextView(this);
        titleView.setText(t(title));
        titleView.setTextSize(uiSp(16));
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setTextColor(darkTheme ? Color.rgb(240, 248, 252) : Color.rgb(15, 23, 42));
        textBox.addView(titleView);
        TextView subView = new TextView(this);
        subView.setText(subtitle);
        subView.setTextSize(uiSp(12));
        subView.setTextColor(darkTheme ? Color.rgb(135, 155, 175) : Color.rgb(100, 116, 139));
        subView.setPadding(0, uiDp(2), 0, 0);
        textBox.addView(subView);
        card.addView(textBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(uiSp(24));
        arrow.setTextColor(accent);
        card.addView(arrow);
        return card;
    }

    private void switchTextMode(boolean useOcr) {
        stopAudioOnly();
        TtsForegroundService.clearPages();
        if (textRepository != null) textRepository.close();
        currentOcrMode = useOcr;
        textRepository = useOcr ? ocrTextRepository : normalTextRepository;
        if (ocrTextRepository != null) {
            ocrTextRepository.setPreferDevanagari("hi".equals(appLanguage));
        }
        prefs.edit().putBoolean(PREF_LAST_READER_OCR_MODE, useOcr).apply();
        if (useOcr && selectionRepository != null) {
            selectionRepository.close();
            loadedSelectionPage = -1;
            loadingSelectionPage = -1;
            if (markMode) {
                markMode = false;
                updateMarkControls();
            }
            if (pdfView != null) {
                pdfView.setMarkMode(false);
                pdfView.setReadingMarkerEnabled(false);
                pdfView.clearReadingMarker();
                pdfView.setSelectionChars(new ArrayList<CharBox>());
            }
        }
    }

    private void copyAndOpen(final Uri uri) {
        if (uri == null) return;

        // Guarda el progreso del documento que se deja antes de soltarlo.
        saveProgress();
        stopAudioOnly();
        TtsForegroundService.clearPages();
        final int requestToken = ++pdfOpenRequestToken;
        final String name = getDisplayName(uri);
        final String sourceKey = buildSourceKey(uri);
        final File target = getCachedPdfFile(sourceKey);
        final long sourceSize = queryUriSize(uri);
        final int rememberedPage = getRememberedPageForSource(sourceKey);

        // Si este mismo PDF ya fue copiado antes y sigue teniendo el mismo tamano,
        // se abre desde la copia local inmediatamente: no vuelve a copiarse.
        if (isReusablePdfCache(target, sourceSize)) {
            currentSourceKey = sourceKey;
            if (pdfView != null) {
                pdfView.setSuppressEmptyLabel(true);
                pdfView.closeDocument();
            }
            skipNextStartupCover = true;
            prefs.edit()
                    .putString(PREF_LAST_SOURCE_KEY, sourceKey)
                    .putString(PREF_LAST_FILE_PATH, target.getAbsolutePath())
                    .putString("last_title", name)
                    .apply();
            openLocalPdfAtPage(target, name, rememberedPage);
            touchFile(target);
            return;
        }

        // Un PDF NUEVO se muestra primero directamente desde el Uri. Asi PdfRenderer
        // puede dibujar la primera pagina mientras, en paralelo, se crea la copia
        // local que necesitan PDFBox, OCR, exportaciones y la restauracion posterior.
        beginIncomingDocumentPreview(uri, name, rememberedPage, requestToken);

        new Thread(new Runnable() {
            @Override
            public void run() {
                File cacheDir = target.getParentFile();
                if (cacheDir != null && !cacheDir.exists()) cacheDir.mkdirs();
                final File temp = new File(target.getParentFile(), target.getName() + ".tmp");
                try {
                    try (InputStream input = getContentResolver().openInputStream(uri);
                         FileOutputStream output = new FileOutputStream(temp, false)) {
                        if (input == null) throw new IOException("No se pudo abrir el PDF");
                        byte[] buffer = new byte[262144];
                        int read;
                        while ((read = input.read(buffer)) != -1) {
                            if (requestToken != pdfOpenRequestToken) {
                                temp.delete();
                                return;
                            }
                            output.write(buffer, 0, read);
                        }
                        output.flush();
                    }

                    if (requestToken != pdfOpenRequestToken) {
                        temp.delete();
                        return;
                    }

                    if (target.exists() && !target.delete()) {
                        throw new IOException("No se pudo reemplazar la copia local");
                    }
                    if (!temp.renameTo(target)) {
                        try (InputStream input = new FileInputStream(temp);
                             FileOutputStream output = new FileOutputStream(target, false)) {
                            byte[] buffer = new byte[262144];
                            int read;
                            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                            output.flush();
                        }
                        temp.delete();
                    }
                    touchFile(target);
                    pruneOpenedPdfCache(target);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (requestToken != pdfOpenRequestToken
                                    || isFinishing()
                                    || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                            currentSourceKey = sourceKey;
                            prefs.edit()
                                    .putString(PREF_LAST_SOURCE_KEY, sourceKey)
                                    .putString(PREF_LAST_FILE_PATH, target.getAbsolutePath())
                                    .putString("last_title", name)
                                    .apply();
                            // La vista ya tiene la misma pagina visible desde el Uri.
                            // Se enlaza ahora con la copia local sin mostrar una tapa de
                            // carga ni volver a la pagina 1.
                            openLocalPdfAtPage(target, name, Math.max(0, currentPage));
                        }
                    });
                } catch (final Exception e) {
                    temp.delete();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (requestToken != pdfOpenRequestToken) return;
                            Toast.makeText(MainActivity.this, t("No se pudo abrir el PDF"), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }, "PdfOpenCache").start();
    }

    private void beginIncomingDocumentPreview(final Uri uri, final String name,
                                              final int preferredPage, final int requestToken) {
        if (pdfView == null) return;
        cancelTtsWarmup();
        if (textRepository != null) textRepository.close();
        if (selectionRepository != null) selectionRepository.close();
        deferredDocumentWork = null;
        currentFile = null;
        currentBookmarkKey = null;
        currentSourceKey = buildSourceKey(uri);
        currentTitle = name == null ? "PDF" : name;
        currentPage = Math.max(0, preferredPage);
        pageCount = 0;
        titleView.setText(currentTitle);
        updatePageLabel();
        pdfView.setSuppressEmptyLabel(true);
        // El PDF anterior se libera por completo antes de abrir el nuevo.
        pdfView.closeDocument();

        pdfView.openUriAsync(uri, new PdfPageView.DocumentOpenCallback() {
            @Override
            public void onOpened(int totalPages) {
                if (requestToken != pdfOpenRequestToken) return;
                pageCount = Math.max(0, totalPages);
                if (pageCount <= 0) return;
                currentPage = Math.max(0, Math.min(preferredPage, pageCount - 1));
                pdfView.showPage(currentPage);
                updatePageLabel();
            }

            @Override
            public void onError(Exception error) {
                if (requestToken != pdfOpenRequestToken) return;
                pageCount = 0;
                updatePageLabel();
            }
        });
    }

    private String buildSourceKey(Uri uri) {
        if (uri == null) return "unknown";
        String value = uri.toString();
        long hash = 1469598103934665603L;
        for (int i = 0; i < value.length(); i++) {
            hash ^= value.charAt(i);
            hash *= 1099511628211L;
        }
        return Long.toHexString(hash);
    }

    private File getCachedPdfFile(String sourceKey) {
        File dir = new File(getFilesDir(), PDF_CACHE_DIR);
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "pdf_" + sourceKey + ".pdf");
    }

    private long queryUriSize(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (index >= 0 && !cursor.isNull(index)) return cursor.getLong(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return -1L;
    }

    private boolean isReusablePdfCache(File target, long sourceSize) {
        if (target == null || !target.exists() || target.length() <= 0L) return false;
        return sourceSize <= 0L || target.length() == sourceSize;
    }

    private void touchFile(File file) {
        if (file == null) return;
        try { file.setLastModified(System.currentTimeMillis()); } catch (Exception ignored) { }
    }

    private void pruneOpenedPdfCache(File keep) {
        try {
            File dir = new File(getFilesDir(), PDF_CACHE_DIR);
            File[] files = dir.listFiles();
            if (files == null || files.length <= MAX_CACHED_PDFS) return;
            Arrays.sort(files, new Comparator<File>() {
                @Override
                public int compare(File a, File b) {
                    return Long.compare(a.lastModified(), b.lastModified());
                }
            });
            int remove = files.length - MAX_CACHED_PDFS;
            for (File file : files) {
                if (remove <= 0) break;
                if (keep != null && keep.equals(file)) continue;
                if (file.getName().endsWith(".tmp") || file.delete()) remove--;
            }
        } catch (Exception ignored) { }
    }

    private int getRememberedPageForSource(String sourceKey) {
        if (sourceKey == null || sourceKey.length() == 0) return 0;
        return Math.max(0, prefs.getInt(PREF_SOURCE_PAGE_PREFIX + sourceKey, 0));
    }

    private void openLocalPdf(final File file, String title, boolean restore) {
        int page = 0;
        if (restore) {
            page = prefs.getInt("last_page", 0);
            // Si la voz quedo activa (por ejemplo sonando con la pantalla apagada
            // y el proceso reciclado por el sistema), la pagina real la tiene el
            // servicio en "tts_current_page", que se actualiza en vivo aunque la
            // Activity no exista. "last_page" solo se guarda mientras la pantalla
            // dibuja, asi que puede haber quedado atrasado. Se prefiere la del
            // servicio para no reabrir en la pagina equivocada ni en el inicio.
            boolean ttsActive = prefs.getBoolean(PREF_TTS_ACTIVE, false);
            int readerPage = prefs.getInt(PREF_TTS_CURRENT_PAGE, -1);
            if (ttsActive && readerPage >= 0) {
                page = readerPage;
            }
        }
        final int preferredPage = Math.max(0, page);
        openLocalPdfAtPage(file, title, preferredPage);
    }

    private void openLocalPdfAtPage(final File file, String title, final int preferredPage) {
        if (file == null || pdfView == null) return;
        cancelTtsWarmup();
        // Se recuerda el documento que estaba en pantalla antes de cambiar de
        // archivo, para decidir si hay que tapar la vista con la pantalla de
        // carga mientras aparece el PDF nuevo (ver mas abajo).
        final File previousFile = currentFile;
        try {
            currentFile = file;
            currentTitle = title == null ? "PDF" : title;
            currentBookmarkKey = buildBookmarkKey(file);
            languageDetectionToken++;
            languageSamplingToken = -1;
            provisionalPdfLanguageActive = false;
            currentPdfLanguage = PdfLanguageDetector.normalizeCode(
                    prefs.getString(pdfLanguagePreferenceKey(currentBookmarkKey), ""));
            currentPdfLanguageConfidence = currentPdfLanguage.length() > 0 ? 1.0f : 0f;
            TtsEngineManager.getInstance(this).setPreferredLanguage(currentPdfLanguage, appRegion);
            titleView.setText(currentTitle);
            // Reinicia el desplazamiento del cartel al abrir un PDF: al volver a
            // seleccionar la vista, el marquee arranca de nuevo desde el principio.
            if (titleView != null) {
                titleView.setSelected(false);
                titleView.post(new Runnable() {
                    @Override
                    public void run() {
                        if (titleView != null) titleView.setSelected(true);
                    }
                });
            }
            fullIndexRequested = false;
            pageCount = 0;
            currentPage = Math.max(0, preferredPage);
            updatePageLabel();

            TtsForegroundService.clearPages();

            // La extraccion de texto (PDFBox) y el encendido del motor de voz ya
            // no arrancan aqui. Empezarlos antes del primer dibujado obligaba al
            // render visible a competir por el procesador, y como la tapa
            // "Cargando" se quita recien cuando hay pagina en pantalla, eso
            // alargaba directamente el arranque y la apertura de un PDF nuevo.
            // Queda preparado y se dispara en cuanto la pagina esta visible.
            scheduleDeferredDocumentWork(file, Math.max(0, preferredPage));

            // Coordinate extraction is deliberately deferred until the visible
            // page text is ready; it must not compete with first render / Play.
            selectionRepository.close();
            loadedSelectionPage = -1;
            loadingSelectionPage = -1;

            String savedHighlights = prefs.getString(highlightKey(), "");
            if ((savedHighlights == null || savedHighlights.length() == 0) && currentTitle != null) {
                savedHighlights = prefs.getString(legacyHighlightKey(), "");
            }
            final String deferredHighlights = savedHighlights;
            final File highlightFile = file;

            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
            pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
            pdfView.setReadingMarkerEnabled(!currentOcrMode && readingMarkerEnabled);
            pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));

            // Al abrir un PDF (nuevo o restaurado) hay un hueco entre que se
            // descarta la pagina anterior y aparece la nueva. Se oculta el cartel
            // "Abrir un PDF" durante ese hueco para que no destelle; se vuelve a
            // permitir en cuanto la primera pagina esta dibujada.
            pdfView.setSuppressEmptyLabel(true);

            // Si se cambia a un documento DISTINTO del que estaba en pantalla, se
            // tapa la vista con la pantalla de carga (fondo neutro + rueda) hasta
            // que la primera pagina del nuevo PDF este dibujada. Asi no se ve ni
            // el destello negro (que aparecia al borrar la imagen) ni la pagina
            // del PDF anterior colgada (que se veia al conservarla). La tapa se
            // quita sola en onPageRendered, cuando ya hay pagina real. Si es el
            // mismo archivo (solo cambio de pagina) no se tapa nada.
            boolean differentDocument = previousFile == null
                    || !previousFile.equals(file);
            // Si la primera pagina ya esta visible gracias al preview directo del
            // Uri, no se vuelve a tapar la pantalla al enlazar la copia local.
            if (differentDocument && !skipNextStartupCover && !pdfView.hasRenderedPage()) {
                showStartupCover();
            }
            skipNextStartupCover = false;

            pdfView.openFileAsync(file, new PdfPageView.DocumentOpenCallback() {
                @Override
                public void onOpened(int totalPages) {
                    if (currentFile == null || !currentFile.equals(file)) return;
                    pageCount = Math.max(0, totalPages);
                    if (pageCount <= 0) {
                        hideStartupCover();
                        if (pdfView != null) pdfView.setSuppressEmptyLabel(false);
                        Toast.makeText(MainActivity.this, t("Error al cargar PDF"), Toast.LENGTH_LONG).show();
                        return;
                    }

                    final int p = Math.max(0, Math.min(preferredPage, pageCount - 1));
                    // Se reprograma el trabajo pesado con la pagina definitiva.
                    // Sigue esperando al primer dibujado.
                    scheduleDeferredDocumentWork(file, p);

                    pdfView.showPage(p);
                    updatePageLabel();

                    // Ya se conoce el total de paginas: si la voz sigue activa se
                    // reconcilia la pagina visible con la que realmente esta
                    // leyendo el servicio. Cubre el caso de volver a la app tras
                    // sonar con la pantalla apagada, donde la sincronizacion del
                    // onResume corrio antes de que el documento estuviera abierto.
                    if (prefs != null && prefs.getBoolean(PREF_TTS_ACTIVE, false)) {
                        syncVisiblePageWithReader(true);
                    }

                    // Red de seguridad: si por lo que sea la pagina no llegara a
                    // dibujarse, el texto y la voz se preparan igual.
                    View safetyHost = root;
                    if (safetyHost == null) safetyHost = pdfView;
                    if (safetyHost != null) {
                        safetyHost.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (currentFile == null || !currentFile.equals(file)) return;
                                runDeferredDocumentWork();
                            }
                        }, 1500L);
                    }

                    // Large marker sets are loaded after the first render request.
                    pdfView.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (currentFile == null || !currentFile.equals(highlightFile)) return;
                            pdfView.loadHighlights(deferredHighlights);
                        }
                    }, 60L);
                }

                @Override
                public void onError(Exception error) {
                    if (currentFile == null || !currentFile.equals(file)) return;
                    deferredDocumentWork = null;
                    pageCount = 0;
                    updatePageLabel();
                    // Como ya no se descarta la imagen al empezar a abrir (para
                    // evitar el destello negro), si la apertura falla hay que
                    // limpiar aca la pagina del documento anterior que quedo en
                    // pantalla, y volver a permitir el cartel de estado vacio.
                    hideStartupCover();
                    if (pdfView != null) {
                        pdfView.closeDocument();
                        pdfView.setSuppressEmptyLabel(false);
                    }
                    Toast.makeText(MainActivity.this, t("Error al cargar PDF"), Toast.LENGTH_LONG).show();
                    scheduleTtsWarmup(500L);
                }
            });
        } catch (Exception e) {
            Toast.makeText(this, t("Error al cargar PDF"), Toast.LENGTH_LONG).show();
            scheduleTtsWarmup(500L);
        }
    }

    private String pdfLanguagePreferenceKey(String bookmarkKey) {
        return PREF_PDF_LANGUAGE_PREFIX + (bookmarkKey == null ? "unknown" : bookmarkKey);
    }

    private boolean isCurrentLanguageDetection(int token, File file, String documentKey) {
        return token == languageDetectionToken
                && currentFile != null && currentFile.equals(file)
                && currentBookmarkKey != null && currentBookmarkKey.equals(documentKey);
    }

    private void saveCurrentPdfLanguage(String languageCode, float confidence) {
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (!PdfLanguageDetector.isSupported(language) || currentBookmarkKey == null) return;
        currentPdfLanguage = language;
        provisionalPdfLanguageActive = false;
        currentPdfLanguageConfidence = Math.max(0f, Math.min(1f, confidence));
        languageSamplingToken = -1;
        prefs.edit().putString(pdfLanguagePreferenceKey(currentBookmarkKey), language).apply();
        TtsEngineManager.getInstance(this).setPreferredLanguage(language, appRegion);
        // Warm the correct language only after detection. This avoids initializing
        // a voice that immediately has to be replaced when Play is pressed.
        scheduleTtsWarmup(120L);
        // Y deja preparado el pequeño puente de arranque de la pagina visible.
        // Si el motor aun no esta listo, prepareFastResume... reintenta al terminar
        // el warm-up sin bloquear la interfaz.
        String visibleText = textRepository == null ? null : textRepository.getCachedText(currentPage);
        if ((visibleText == null || visibleText.trim().length() == 0) && textRepository != null) {
            visibleText = textRepository.getFastStartText(currentPage);
        }
        scheduleFastResumeAudioPreparation(currentPage, visibleText);
    }

    private void maybeDetectPdfLanguageFromCachedPage(final int page) {
        if (currentPdfLanguage.length() > 0 || currentFile == null
                || currentBookmarkKey == null || textRepository == null) return;
        final int token = languageDetectionToken;
        final File file = currentFile;
        final String documentKey = currentBookmarkKey;

        // Use several pages for the stored decision instead of trusting a cover
        // page or a short heading. The sampling runs after the visible page text
        // is already ready, so it does not block the first render or Play.
        audioStartHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isCurrentLanguageDetection(token, file, documentKey)
                        || currentPdfLanguage.length() > 0) return;
                schedulePdfLanguageSampling(page, token, file, documentKey);
            }
        }, 450L);
    }

    private void schedulePdfLanguageSampling(final int anchorPage, final int token,
                                             final File file, final String documentKey) {
        if (!isCurrentLanguageDetection(token, file, documentKey)
                || currentPdfLanguage.length() > 0 || languageSamplingToken == token
                || textRepository == null || pageCount <= 0) return;
        languageSamplingToken = token;
        final ArrayList<Integer> pages = new ArrayList<Integer>();
        int safeAnchor = Math.max(0, Math.min(anchorPage, pageCount - 1));
        int[] candidates = new int[]{safeAnchor, 0, pageCount / 2, pageCount - 1};
        for (int candidate : candidates) {
            int safe = Math.max(0, Math.min(candidate, pageCount - 1));
            if (!pages.contains(safe)) pages.add(safe);
        }
        collectPdfLanguageSamples(pages, 0, new StringBuilder(), token, file, documentKey);
    }

    private void collectPdfLanguageSamples(final ArrayList<Integer> pages, final int index,
                                           final StringBuilder sample, final int token,
                                           final File file, final String documentKey) {
        if (!isCurrentLanguageDetection(token, file, documentKey)
                || currentPdfLanguage.length() > 0 || textRepository == null) {
            if (languageSamplingToken == token) languageSamplingToken = -1;
            return;
        }
        if (index >= pages.size() || sample.length() >= 5000) {
            finishPdfLanguageSampling(sample.toString(), token, file, documentKey);
            return;
        }

        final int page = pages.get(index);
        textRepository.getPageText(page, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                if (!isCurrentLanguageDetection(token, file, documentKey)
                        || currentPdfLanguage.length() > 0) {
                    if (languageSamplingToken == token) languageSamplingToken = -1;
                    return;
                }
                String value = text == null ? "" : text.trim();
                if (value.length() > 0 && sample.length() < 5000) {
                    int remaining = 5000 - sample.length();
                    if (sample.length() > 0) sample.append('\n');
                    sample.append(value, 0, Math.min(value.length(), remaining));
                }
                collectPdfLanguageSamples(pages, index + 1, sample, token, file, documentKey);
            }
        });
    }

    private void finishPdfLanguageSampling(final String sample, final int token,
                                           final File file, final String documentKey) {
        if (!isCurrentLanguageDetection(token, file, documentKey)) {
            if (languageSamplingToken == token) languageSamplingToken = -1;
            return;
        }
        if (sample == null || sample.trim().length() < 24) {
            if (languageSamplingToken == token) languageSamplingToken = -1;
            return;
        }
        try {
            languageDetectionExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    final PdfLanguageDetector.Result result = PdfLanguageDetector.detect(
                            getApplicationContext(), sample);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentLanguageDetection(token, file, documentKey)) return;
                            if (languageSamplingToken == token) languageSamplingToken = -1;
                            if (currentPdfLanguage.length() == 0 && result.isConfident()) {
                                saveCurrentPdfLanguage(result.languageCode, result.confidence);
                            }
                        }
                    });
                }
            });
        } catch (Exception ignored) {
            if (languageSamplingToken == token) languageSamplingToken = -1;
        }
    }

    private String getDisplayName(Uri uri) {
        String result = "PDF";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return result == null ? "PDF" : result;
    }



    private void requestManualPageChange(int targetPage) {
        if (pageCount <= 0) return;

        final int nextPage = Math.max(0, Math.min(targetPage, pageCount - 1));
        restartAudioAfterRender = false;
        currentPage = nextPage;
        updatePageLabel();

        // Se recuerda que la pagina visible la eligio el usuario, para no
        // devolverlo a la pagina pausada al volver a la app.
        if (playbackState == TtsForegroundService.STATE_PAUSED
                || playbackState == TtsForegroundService.STATE_STOPPED) {
            userBrowsedAwayWhilePaused = true;
        }

        // Primero gana la pagina visible. Antes se lanzaba PDFBox antes de
        // showPage() y, en PDFs nuevos o saltos grandes, esa extraccion competia
        // con el render y hacia sentir lentas las flechas y el selector superior.
        // El texto urgente empieza apenas onPageRendered confirma que ya hay una
        // pagina real en pantalla. Si el usuario pulsa Play antes, el propio Play
        // toma prioridad y arranca la misma solicitud urgente.
        if (pdfView != null) {
            pdfView.clearReadingMarker();
            pdfView.showPage(nextPage);
        }
        // REGLA: cambiar de pagina NO toca el motor de voz. El motor ya quedo
        // preparado al abrir el documento y su idioma no cambia por saltar de
        // pagina; volver a pedirle que reaplique la voz mientras esta leyendo es
        // justo lo que hacia que la lectura se parara un momento en cada salto.
        // Al cambiar de pagina solo viaja el texto nuevo.

        loadedSelectionPage = -1;
        loadingSelectionPage = -1;

        if (playbackState == TtsForegroundService.STATE_PLAYING
                || playbackState == TtsForegroundService.STATE_PREPARING) {
            seekAudioToPage(nextPage, true);
        }
        // Si estaba pausado, no mover la sesion pausada del TTS a una pagina
        // nueva y vacia. La pagina visible queda precargada y el siguiente Play
        // inicia por la misma ruta rapida que un PDF recien abierto.
    }

    private void scheduleVisiblePageWork(final int page, final boolean requestFullIndex) {
        final int token = ++pageWorkToken;
        if (pageWorkRunnable != null) {
            pageWorkHandler.removeCallbacks(pageWorkRunnable);
        }
        pageWorkRunnable = new Runnable() {
            @Override
            public void run() {
                if (token != pageWorkToken || page != currentPage || currentFile == null) return;
                // El texto audible gana la carrera. Las coordenadas visuales se
                // procesan inmediatamente después, nunca al mismo tiempo.
                primeAudioPageForPlayback(page, new Runnable() {
                    @Override
                    public void run() {
                        if (token != pageWorkToken || page != currentPage || currentFile == null) return;
                        loadSelectionForPage(page);
                        if (markMode || readingMarkerEnabled) {
                            prefetchAroundPage(page);
                        }
                        if (readingMarkerEnabled && pendingReadingPage == page) {
                            schedulePendingReadingMarker();
                        }
                    }
                });
            }
        };
        pageWorkHandler.postDelayed(pageWorkRunnable, 16L);
    }

    private void seekAudioToPage(int page, boolean playNow) {
        if (pageCount <= 0) return;
        runDeferredDocumentWork();
        int safePage = Math.max(0, Math.min(page, pageCount - 1));
        if (currentPdfLanguage.length() == 0) {
            if (playNow) {
                startAudioFromPage(safePage);
            } else {
                audioRequestToken++;
                requestedAudioPage = -1;
                requestedAudioPageConfirmed = false;
                applyPlaybackState(TtsForegroundService.STATE_PAUSED, safePage, "Pausado", false);
            }
            return;
        }
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = safePage;
        requestedAudioPageConfirmed = false;
        applyPlaybackState(playNow
                        ? TtsForegroundService.STATE_PREPARING
                        : TtsForegroundService.STATE_PAUSED,
                safePage, playNow ? "" : "Pausado", false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_SEEK_PAGE);
        intent.putExtra(TtsForegroundService.EXTRA_PAGE, safePage);
        intent.putExtra(TtsForegroundService.EXTRA_AUTOPLAY, playNow);
        intent.putExtra("title", currentTitle);
        intent.putExtra("totalPages", pageCount);
        intent.putExtra("rate", speechRate);
        intent.putExtra("pitch", 1.0f);
        intent.putExtra(TtsForegroundService.EXTRA_TTS_LANGUAGE, currentPdfLanguage);
        intent.putExtra(TtsForegroundService.EXTRA_TTS_REGION, appRegion);

        String cachedPageText = textRepository == null ? null : textRepository.getCachedText(safePage);
        if (cachedPageText != null) {
            TtsForegroundService.setPageText(safePage, cachedPageText);
            intent.putExtra(TtsForegroundService.EXTRA_PAGE_TEXT, cachedPageText);
        } else {
            // No se usa un prefijo corto: se prepara la pagina completa para evitar
            // una transicion audible entre dos ordenes de voz.
            primeAudioPageForPlayback(safePage);
        }
        startService(intent);
    }

    /**
     * Deja listo el trabajo pesado del documento (abrir el texto con PDFBox,
     * coordenadas de seleccion y encendido del motor de voz) para ejecutarlo
     * recien cuando la primera pagina ya esta dibujada.
     */
    private void scheduleDeferredDocumentWork(final File file, final int page) {
        if (file == null) return;
        deferredDocumentWork = new Runnable() {
            @Override
            public void run() {
                if (currentFile == null || !currentFile.equals(file)) return;
                if (textRepository == null) return;

                textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
                textRepository.open(file);

                primeAudioPageForPlayback(page, new Runnable() {
                    @Override
                    public void run() {
                        if (currentFile == null || !currentFile.equals(file)) return;
                        if (currentPdfLanguage.length() == 0) {
                            maybeDetectPdfLanguageFromCachedPage(page);
                        }
                        loadedSelectionPage = -1;
                        loadingSelectionPage = -1;
                        if (!currentOcrMode) {
                            selectionRepository.open(file);
                            loadSelectionForPage(page);
                            if (markMode || readingMarkerEnabled) {
                                prefetchAroundPage(page);
                            }
                        } else {
                            selectionRepository.close();
                            if (pdfView != null) pdfView.setSelectionChars(new ArrayList<CharBox>());
                        }
                    }
                });

                warmTtsEngineNow();
            }
        };
    }

    private void runDeferredDocumentWork() {
        Runnable work = deferredDocumentWork;
        if (work == null) return;
        deferredDocumentWork = null;
        work.run();
    }

    private void preparePageForInstantPlay(final int page, final boolean requestFullIndex) {
        primeAudioPageForPlayback(page);
    }

    private void primeAudioPageForPlayback(final int page) {
        primeAudioPageForPlayback(page, null);
    }

    private void primeAudioPageForPlayback(final int page, final Runnable afterPrime) {
        if (textRepository == null || currentFile == null || page < 0) return;
        final File requestedFile = currentFile;

        // Toda navegacion interactiva cancela/pausa el indexado de baja prioridad.
        textRepository.noteInteractivePage(page);

        // Si ya existe un prefijo persistido, el servicio puede usarlo incluso
        // antes de que termine la pagina completa. Esto es especialmente util al
        // volver a una pagina visitada anteriormente.
        String fastCached = textRepository.getFastStartText(page);
        if (fastCached != null && fastCached.trim().length() > 0) {
            TtsForegroundService.setPageFastText(page, fastCached);
            if (page == currentPage) scheduleFastResumeAudioPreparation(page, fastCached);
        }

        String cached = textRepository.getCachedText(page);
        if (cached != null) {
            TtsForegroundService.setPageText(page, cached);
            if (page == currentPage) scheduleFastResumeAudioPreparation(page, cached);
            if (afterPrime != null) afterPrime.run();
            scheduleAudioNeighborPreload(page);
            scheduleAudioIdleIndex(page);
            return;
        }

        // Una sola extraccion publica primero un fragmento audible y luego la
        // pagina completa. Solicitudes simultaneas (render, Play y precarga) se
        // agrupan dentro de TextRepository y no duplican trabajo de PDFBox.
        textRepository.getPageTextFastStart(page,
                new TextRepository.TextCallback() {
                    @Override
                    public void onText(String text) {
                        if (currentFile == null || !currentFile.equals(requestedFile)) return;
                        String fast = text == null ? "" : text.trim();
                        if (fast.length() > 0) {
                            TtsForegroundService.setPageFastText(page, fast);
                            if (page == currentPage) scheduleFastResumeAudioPreparation(page, fast);
                        }
                    }
                },
                new TextRepository.TextCallback() {
                    @Override
                    public void onText(String text) {
                        if (currentFile == null || !currentFile.equals(requestedFile)) return;
                        String full = text == null ? "" : text;
                        TtsForegroundService.setPageText(page, full);
                        if (page == currentPage) scheduleFastResumeAudioPreparation(page, full);
                        if (afterPrime != null) afterPrime.run();
                        scheduleAudioNeighborPreload(page);
                        scheduleAudioIdleIndex(page);
                    }
                });
    }

    private void scheduleAudioNeighborPreload(final int page) {
        if (pageCount <= 0) return;
        if (audioNeighborPreloadRunnable != null) {
            audioStartHandler.removeCallbacks(audioNeighborPreloadRunnable);
        }
        audioNeighborPreloadRunnable = new Runnable() {
            @Override
            public void run() {
                audioNeighborPreloadRunnable = null;
                if (textRepository != null && pageCount > 0 && page == currentPage) {
                    // Mantiene listas la anterior y las cuatro siguientes. La cola
                    // es de fondo y siempre cede ante la página visible/Play.
                    textRepository.preloadAudioWindow(page, 4, pageCount);
                }
            }
        };
        // V136: en páginas con poco texto (comics/manga) la lectura las pasa
        // muy rápido, y esperar antes de precargar dejaba a la lectura
        // adelantarse al precargado; eso se sentía como una pausa breve al
        // pasar de página. Se dispara ya mismo, sin espera artificial.
        audioStartHandler.post(audioNeighborPreloadRunnable);
    }

    private void scheduleAudioIdleIndex(final int page) {
        if (audioIdleIndexRunnable != null) {
            audioStartHandler.removeCallbacks(audioIdleIndexRunnable);
        }
        audioIdleIndexRunnable = new Runnable() {
            @Override
            public void run() {
                audioIdleIndexRunnable = null;
                if (textRepository == null || currentFile == null || pageCount <= 0
                        || page != currentPage) return;
                // Tras unos segundos sin cambiar de página, completa la caché en
                // baja prioridad. Una nueva petición urgente hace que el indexado
                // se abandone de forma cooperativa y se reanude más adelante.
                textRepository.startFullPreload(page, pageCount);
            }
        };
        audioStartHandler.postDelayed(audioIdleIndexRunnable, 1100L);
    }

    private void prefetchAroundCurrentPage() {
        prefetchAroundPage(currentPage);
    }

    private void prefetchAroundPage(int page) {
        if (currentOcrMode) return;
        if (pageCount <= 0) return;
        int start = Math.max(0, page);
        selectionRepository.prefetch(start, 1, pageCount);
    }




    private void loadSelectionForPage(final int page) {
        if (currentOcrMode) return;
        if (pageCount <= 0 || selectionRepository == null || page < 0) return;
        if (loadedSelectionPage == page) {
            schedulePendingReadingMarker();
            return;
        }
        if (loadingSelectionPage == page) return;
        loadingSelectionPage = page;

        selectionRepository.getChars(page, new SelectionTextRepository.CharCallback() {
            @Override
            public void onChars(java.util.ArrayList<CharBox> chars) {
                loadingSelectionPage = -1;
                if (page == currentPage && pdfView != null) {
                    loadedSelectionPage = page;
                    pdfView.setSelectionChars(chars);
                    schedulePendingReadingMarker();
                }
            }
        });
    }

    private void loadRules() {
        rulesEnabled = prefs.getBoolean("rules_enabled", true);
        ruleTop = prefs.getFloat("rule_top", 0.08f);
        ruleBottom = prefs.getFloat("rule_bottom", 0.92f);
        if (ruleBottom <= ruleTop + 0.05f) {
            ruleTop = 0.08f;
            ruleBottom = 0.92f;
        }

        if (pdfView != null) {
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
            pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
        }

        if (textRepository != null) {
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        updateRulesButton();
    }

    private void toggleRules() {
        rulesEnabled = !rulesEnabled;
        saveRules(rulesEnabled, ruleTop, ruleBottom);

        if (pdfView != null) {
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        if (textRepository != null) {
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
            refreshTextCacheForRules();
        }

        updateRulesButton();
        Toast.makeText(this, rulesEnabled ? t("Reglas activadas. Arrastra las líneas.") : t("Reglas desactivadas"), Toast.LENGTH_SHORT).show();
    }


    private void refreshTextCacheForRules() {
        if (textRepository == null || currentFile == null || pageCount <= 0) return;
        fullIndexRequested = false;
        final int page = Math.max(0, Math.min(currentPage, pageCount - 1));
        TtsForegroundService.clearPages();
        // Mantiene exactamente el recorte entre las dos reglas, pero vuelve a dar
        // prioridad a la pagina visible antes de reconstruir el resto del cache.
        preparePageForInstantPlay(page, true);
    }

    private void saveRules(boolean enabled, float top, float bottom) {
        rulesEnabled = enabled;
        ruleTop = top;
        ruleBottom = bottom;
        prefs.edit()
                .putBoolean("rules_enabled", enabled)
                .putFloat("rule_top", top)
                .putFloat("rule_bottom", bottom)
                .apply();
        updateRulesButton();
    }

    private void updateRulesButton() {
        if (rulesButton != null) {
            rulesButton.setText(rulesEnabled ? t("Reglas ON") : t("Reglas OFF"));
        }
    }


    private void toggleReadingMarker() {
        if (currentOcrMode) {
            Toast.makeText(this, t("Subrayado y seguimiento no están disponibles en modo OCR"),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        readingMarkerEnabled = !readingMarkerEnabled;
        prefs.edit().putBoolean(PREF_READING_MARKER_ENABLED, readingMarkerEnabled).apply();
        if (pdfView != null) {
            pdfView.setReadingMarkerEnabled(readingMarkerEnabled);
            pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
        }
        if (readingMarkerEnabled) {
            // El orden importa: primero se limpia el resto anterior y despues se
            // cargan las coordenadas. Al reves, clearReadingMarker borraba el
            // marcador que loadSelectionForPage acababa de colocar y habia que
            // cambiar de pagina para que el seguimiento apareciera.
            if (pdfView != null) pdfView.clearReadingMarker();
            if (selectionRepository != null && currentFile != null) selectionRepository.open(currentFile);
            loadedSelectionPage = -1;
            loadingSelectionPage = -1;
            loadSelectionForPage(currentPage);

            // Si la lectura ya estaba a mitad de página, solicita al servicio la
            // frase/rango actual en vez de reutilizar una posición antigua o esperar
            // al siguiente cambio de página.
            if (playbackState == TtsForegroundService.STATE_PLAYING
                    || playbackState == TtsForegroundService.STATE_PAUSED
                    || playbackState == TtsForegroundService.STATE_PREPARING) {
                Intent report = new Intent(this, TtsForegroundService.class);
                report.setAction(TtsForegroundService.ACTION_REPORT_RANGE);
                startService(report);
                // Ademas se reaplica la frase que ya se conocia, para que el
                // recuadro aparezca al instante sin esperar la respuesta.
                schedulePendingReadingMarker();
            }
        } else {
            cancelPendingReadingMarker();
            if (pdfView != null) pdfView.clearReadingMarker();
            // Las coordenadas de la página se conservan para que Subrayar ON
            // responda inmediatamente aunque el seguimiento esté apagado.
        }
    }

    private void schedulePendingReadingMarker() {
        if (!readingMarkerEnabled || pdfView == null) return;
        if (readingMarkerUpdateTask == null) {
            readingMarkerUpdateTask = new Runnable() {
                @Override
                public void run() {
                    readingMarkerUpdateScheduled = false;
                    applyPendingReadingMarker();
                }
            };
        }
        if (readingMarkerUpdateScheduled) return;
        readingMarkerUpdateScheduled = true;
        readingMarkerHandler.postDelayed(readingMarkerUpdateTask, 16L);
    }

    private void cancelPendingReadingMarker() {
        if (readingMarkerUpdateTask != null) {
            readingMarkerHandler.removeCallbacks(readingMarkerUpdateTask);
        }
        readingMarkerUpdateScheduled = false;
    }

    private void applyPendingReadingMarker() {
        if (!readingMarkerEnabled || pdfView == null || pendingReadingPage < 0
                || pendingReadingChunk == null || pendingReadingChunk.length() == 0) return;
        if (pendingReadingPage != currentPage) return;
        pdfView.setReadingMarkerEnabled(true);
        pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
        pdfView.updateReadingMarker(pendingReadingPage, pendingReadingChunk, pendingReadingChunkIndex,
                pendingReadingRangeStart, pendingReadingRangeEnd);
    }

    /**
     * Azul de acento de Ajustes. En tema oscuro se mantiene el azul claro; en
     * tema claro se oscurece para que contraste contra el fondo blanco.
     */
    private int getSettingsAccentColor() {
        return darkTheme ? Color.rgb(59, 130, 246) : Color.rgb(29, 78, 216);
    }

    private int getUtilityColorRgb(int target) {
        if (target == COLOR_TARGET_RULE) {
            return useCustomRuleColor ? customRuleRgb : MARK_COLOR_RGB[safeMarkColorIndex(ruleColorIndex)];
        }
        if (target == COLOR_TARGET_READING_MARKER) {
            return useCustomReadingMarkerColor ? customReadingMarkerRgb : MARK_COLOR_RGB[safeMarkColorIndex(readingMarkerColorIndex)];
        }
        return MARK_COLOR_RGB[3];
    }

    private String getUtilityQuickPrefix(int target) {
        return target == COLOR_TARGET_RULE ? "quick_rule_color_" : "quick_tracking_color_";
    }

    private boolean hasQuickUtilityColor(int target, int slot) {
        return prefs.getBoolean(getUtilityQuickPrefix(target) + "set_" + slot, false);
    }

    private int getQuickUtilityColor(int target, int slot) {
        return prefs.getInt(getUtilityQuickPrefix(target) + slot, 0x003B82F6) & 0x00FFFFFF;
    }

    private void saveQuickUtilityColor(int target, int slot, int color) {
        prefs.edit()
                .putInt(getUtilityQuickPrefix(target) + slot, color & 0x00FFFFFF)
                .putBoolean(getUtilityQuickPrefix(target) + "set_" + slot, true)
                .apply();
    }

    private void applyUtilityCustomColor(int target, int color) {
        color &= 0x00FFFFFF;
        SharedPreferences.Editor editor = prefs.edit();
        if (target == COLOR_TARGET_RULE) {
            customRuleRgb = color;
            useCustomRuleColor = true;
            editor.putInt(PREF_CUSTOM_RULE_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_RULE_COLOR, true);
            if (pdfView != null) pdfView.setRuleColor(color);
        } else {
            customReadingMarkerRgb = color;
            useCustomReadingMarkerColor = true;
            editor.putInt(PREF_CUSTOM_READING_MARKER_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_READING_MARKER_COLOR, true);
            if (pdfView != null) {
                pdfView.setReadingMarkerColor(color);
                schedulePendingReadingMarker();
            }
        }
        editor.apply();
        if (target == COLOR_TARGET_READING_MARKER) updateReadingMarkerSettingsSwatch();
        if (target == COLOR_TARGET_RULE) updateRuleColorSettingsSwatch();
    }

    private void showUtilityColorDialog(final int target, String title) {
        final int selected = target == COLOR_TARGET_RULE ? ruleColorIndex : readingMarkerColorIndex;
        final boolean usingCustom = target == COLOR_TARGET_RULE ? useCustomRuleColor : useCustomReadingMarkerColor;
        final int currentCustom = target == COLOR_TARGET_RULE ? customRuleRgb : customReadingMarkerRgb;

        LinearLayout container = makeDialogContainer();
        container.setGravity(Gravity.CENTER_HORIZONTAL);
        container.setPadding(uiDp(16), uiDp(10), uiDp(16), uiDp(12));

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView(title))
                .setView(container)
                .setNegativeButton(t("Cancelar"), null)
                .create();

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(4);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setUseDefaultMargins(false);

        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                TextView swatch = new TextView(this);
                swatch.setGravity(Gravity.CENTER);
                swatch.setTypeface(Typeface.DEFAULT_BOLD);
                swatch.setTextSize(uiSp(18));

                if (col == 0) {
                    final int quickSlot = row;
                    final boolean hasQuick = hasQuickUtilityColor(target, quickSlot);
                    final int quickColor = getQuickUtilityColor(target, quickSlot);
                    final boolean selectedQuick = usingCustom && hasQuick && currentCustom == quickColor;
                    swatch.setText(hasQuick ? (selectedQuick ? "✓" : "") : "+");
                    swatch.setTextColor(hasQuick
                            ? (isDarkSwatch(quickColor) ? Color.WHITE : Color.BLACK)
                            : (darkTheme ? Color.WHITE : Color.rgb(30, 41, 59)));
                    swatch.setContentDescription(hasQuick
                            ? t("Color personalizado " + (quickSlot + 1))
                            : t("Crear color personalizado " + (quickSlot + 1)));
                    swatch.setBackground(buildMarkSwatchDrawable(hasQuick ? quickColor : -1, selectedQuick));
                    swatch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            if (target == COLOR_TARGET_READING_MARKER) {
                                // Seguimiento: un solo toque siempre abre el
                                // editor con ese color ya cargado.
                                showCustomUtilityColorDialog(target, quickSlot);
                            } else if (hasQuick) {
                                // Reglas conserva su comportamiento anterior.
                                applyUtilityCustomColor(target, quickColor);
                            } else {
                                showCustomUtilityColorDialog(target, quickSlot);
                            }
                        }
                    });
                    if (target == COLOR_TARGET_RULE) {
                        swatch.setOnLongClickListener(new View.OnLongClickListener() {
                            @Override public boolean onLongClick(View v) {
                                dialog.dismiss();
                                showCustomUtilityColorDialog(target, quickSlot);
                                return true;
                            }
                        });
                    }
                } else {
                    final int presetIndex = row * 3 + (col - 1);
                    final int presetColor = MARK_COLOR_RGB[presetIndex];
                    final boolean selectedPreset = !usingCustom && presetIndex == selected;
                    swatch.setText(selectedPreset ? "✓" : "");
                    swatch.setTextColor(isDarkSwatch(presetColor) ? Color.WHITE : Color.BLACK);
                    swatch.setBackground(buildMarkSwatchDrawable(presetColor, selectedPreset));
                    swatch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            SharedPreferences.Editor editor = prefs.edit();
                            if (target == COLOR_TARGET_RULE) {
                                ruleColorIndex = safeMarkColorIndex(presetIndex);
                                useCustomRuleColor = false;
                                editor.putInt(PREF_RULE_COLOR, ruleColorIndex)
                                        .putBoolean(PREF_USE_CUSTOM_RULE_COLOR, false);
                                if (pdfView != null) pdfView.setRuleColor(presetColor);
                            } else {
                                readingMarkerColorIndex = safeMarkColorIndex(presetIndex);
                                useCustomReadingMarkerColor = false;
                                editor.putInt(PREF_READING_MARKER_COLOR, readingMarkerColorIndex)
                                        .putBoolean(PREF_USE_CUSTOM_READING_MARKER_COLOR, false);
                                if (pdfView != null) {
                                    pdfView.setReadingMarkerColor(presetColor);
                                    schedulePendingReadingMarker();
                                }
                            }
                            editor.apply();
                            if (target == COLOR_TARGET_READING_MARKER) updateReadingMarkerSettingsSwatch();
                            if (target == COLOR_TARGET_RULE) updateRuleColorSettingsSwatch();
                            dialog.dismiss();
                        }
                    });
                }

                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = uiDp(60);
                lp.height = uiDp(60);
                lp.setMargins(uiDp(6), uiDp(6), uiDp(6), uiDp(6));
                grid.addView(swatch, lp);
            }
        }

        container.addView(grid, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        dialog.show();
        styleDialog(dialog);
    }

    private void showCustomUtilityColorDialog(final int target) {
        showCustomUtilityColorDialog(target, -1);
    }

    private void showCustomUtilityColorDialog(final int target, final int quickSlot) {
        final int initial = quickSlot >= 0 && hasQuickUtilityColor(target, quickSlot)
                ? getQuickUtilityColor(target, quickSlot)
                : (target == COLOR_TARGET_RULE ? customRuleRgb : customReadingMarkerRgb);

        LinearLayout box = makeDialogContainer();
        box.setPadding(uiDp(16), uiDp(12), uiDp(16), uiDp(14));

        final ProfessionalColorPickerView picker = new ProfessionalColorPickerView(this);
        picker.setColor(initial);
        box.addView(picker, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(205)));

        final HueSliderView hueSlider = new HueSliderView(this);
        hueSlider.setHue(picker.getHue());
        LinearLayout.LayoutParams hueLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(30));
        hueLp.setMargins(0, uiDp(10), 0, 0);
        box.addView(hueSlider, hueLp);

        final TextView sample = new TextView(this);
        sample.setTextSize(uiSp(20));
        sample.setTypeface(Typeface.DEFAULT_BOLD);
        sample.setGravity(Gravity.CENTER);
        sample.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(10));
        LinearLayout.LayoutParams sampleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(60));
        sampleLp.setMargins(0, uiDp(10), 0, 0);
        box.addView(sample, sampleLp);

        final GradientDrawable sampleBg = new GradientDrawable();
        sampleBg.setCornerRadius(uiDp(14));
        sampleBg.setStroke(uiDp(1), darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        sample.setBackground(sampleBg);

        final boolean[] sampleUpdatePending = new boolean[]{false};
        final Runnable update = new Runnable() {
            @Override
            public void run() {
                sampleUpdatePending[0] = false;
                int color = picker.getSelectedColor() & 0x00FFFFFF;
                sample.setText(String.format(Locale.US, "#%06X", color));
                sample.setTextColor(isDarkSwatch(color) ? Color.WHITE : Color.BLACK);
                sampleBg.setColor(0xFF000000 | color);
            }
        };

        picker.setOnColorChangedListener(new ProfessionalColorPickerView.OnColorChangedListener() {
            @Override
            public void onColorChanged(int color) {
                if (!sampleUpdatePending[0]) {
                    sampleUpdatePending[0] = true;
                    sample.postOnAnimation(update);
                }
            }
        });
        hueSlider.setOnHueChangedListener(new HueSliderView.OnHueChangedListener() {
            @Override
            public void onHueChanged(float hue) {
                picker.setHue(hue);
            }
        });
        update.run();

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Color personalizado"))
                .setView(box)
                .setNegativeButton(t("Cancelar"), null)
                .setPositiveButton(t("Guardar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int color = picker.getSelectedColor() & 0x00FFFFFF;
                        if (quickSlot >= 0) saveQuickUtilityColor(target, quickSlot, color);
                        applyUtilityCustomColor(target, color);
                    }
                }).create();
        dialog.show();
        styleDialog(dialog);
    }

    private void toggleMarkMode() {
        if (currentOcrMode) {
            Toast.makeText(this, t("Subrayado y seguimiento no están disponibles en modo OCR"),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        markMode = !markMode;
        if (pdfView != null) pdfView.setMarkMode(markMode);
        if (markMode) {
            if (selectionRepository != null && currentFile != null) {
                selectionRepository.open(currentFile);
            }
            loadSelectionForPage(currentPage);
            prefetchAroundCurrentPage();
        } else {
            // El repositorio permanece abierto para que un nuevo ON sea inmediato.
            // Solo se cancela una selección incompleta dentro de PdfPageView.
        }
        updateMarkControls();

        String message;
        if (!markMode) {
            message = "Marcado apagado";
        } else if (isHighlightStyle(markStyle)) {
            message = "Resaltado activo. Arrastra sobre el texto";
        } else {
            message = "Subrayado activo. Arrastra sobre el texto";
        }
        Toast.makeText(this, t(message), Toast.LENGTH_SHORT).show();
    }

    private void showMarkStyleDialog() {
        if (settingsScrollView != null) settingsScrollY = settingsScrollView.getScrollY();

        final int[] styles = new int[]{
                MARK_STYLE_UNDERLINE_FINE,
                MARK_STYLE_UNDERLINE_DOUBLE,
                MARK_STYLE_UNDERLINE_WAVY,
                MARK_STYLE_UNDERLINE_DOTTED,
                MARK_STYLE_HIGHLIGHT_SOFT,
                MARK_STYLE_HIGHLIGHT_INTENSE
        };

        LinearLayout container = makeDialogContainer();
        container.setPadding(uiDp(10), uiDp(8), uiDp(10), uiDp(4));

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Tipo de marcado"))
                .setView(container)
                .setNegativeButton(t("Cancelar"), null)
                .create();

        for (int i = 0; i < styles.length; i++) {
            final int style = styles[i];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(uiDp(10), uiDp(8), uiDp(8), uiDp(8));
            GradientDrawable rowBg = new GradientDrawable();
            rowBg.setCornerRadius(uiDp(14));
            rowBg.setColor(darkTheme ? Color.rgb(9, 31, 47) : Color.rgb(248, 250, 252));
            row.setBackground(rowBg);

            View preview = createDialogMarkStylePreview(style);

            TextView check = new TextView(this);
            check.setText(style == markStyle ? "◉" : "○");
            check.setTextSize(uiSp(24));
            check.setTextColor(style == markStyle ? getSettingsAccentColor()
                    : (darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139)));
            check.setGravity(Gravity.CENTER);

            row.addView(preview, new LinearLayout.LayoutParams(0, uiDp(84), 1));
            row.addView(check, new LinearLayout.LayoutParams(uiDp(44), uiDp(44)));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    setMarkStyle(style);
                    dialog.dismiss();
                    if (settingsMode) buildSettingsScreen();
                }
            });
            addRowWithMargin(container, row);
        }

        dialog.show();
        styleDialog(dialog);
    }

    private void showMarkThicknessDialog() {
        if (settingsScrollView != null) settingsScrollY = settingsScrollView.getScrollY();

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(uiDp(10), uiDp(8), uiDp(10), uiDp(4));

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Grosor del subrayado"))
                .setView(container)
                .setNegativeButton(t("Cancelar"), null)
                .create();

        for (int level = 0; level <= 2; level++) {
            final int selectedLevel = level;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(10));
            GradientDrawable rowBg = new GradientDrawable();
            rowBg.setCornerRadius(uiDp(12));
            rowBg.setColor(darkTheme ? Color.rgb(9, 31, 47) : Color.rgb(248, 250, 252));
            row.setBackground(rowBg);

            LinearLayout preview = createDialogSampleCard();
            View line = new View(this);
            GradientDrawable lineShape = new GradientDrawable();
            lineShape.setColor(Color.BLACK);
            lineShape.setCornerRadius(uiDp(3));
            line.setBackground(lineShape);
            preview.addView(line, new LinearLayout.LayoutParams(uiDp(132), getPreviewLineThickness(level)));

            TextView check = new TextView(this);
            check.setText(level == markThicknessLevel ? "◉" : "○");
            check.setTextSize(uiSp(24));
            check.setTextColor(level == markThicknessLevel ? getSettingsAccentColor()
                    : (darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139)));
            check.setGravity(Gravity.CENTER);

            row.addView(preview, new LinearLayout.LayoutParams(0, uiDp(70), 1));
            row.addView(check, new LinearLayout.LayoutParams(uiDp(44), uiDp(44)));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    markThicknessLevel = safeThicknessLevel(selectedLevel);
                    prefs.edit().putInt(PREF_MARK_THICKNESS, markThicknessLevel).apply();
                    applyMarkAppearance();
                    dialog.dismiss();
                    if (settingsMode) buildSettingsScreen();
                }
            });
            addRowWithMargin(container, row);
        }

        dialog.show();
        styleDialog(dialog);
    }

    private LinearLayout createDialogSampleCard() {
        LinearLayout preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.VERTICAL);
        preview.setGravity(Gravity.CENTER);
        preview.setPadding(uiDp(14), uiDp(10), uiDp(14), uiDp(10));
        GradientDrawable previewBg = new GradientDrawable();
        previewBg.setCornerRadius(uiDp(10));
        previewBg.setColor(Color.WHITE);
        previewBg.setStroke(uiDp(1), Color.rgb(226, 232, 240));
        preview.setBackground(previewBg);
        return preview;
    }

    private View createDialogMarkStylePreview(int style) {
        LinearLayout preview = createDialogSampleCard();

        if (style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE) {
            TextView sample = new TextView(this);
            sample.setText(t("Ejemplo"));
            sample.setTextSize(uiSp(17));
            sample.setTypeface(Typeface.DEFAULT_BOLD);
            sample.setTextColor(Color.BLACK);
            sample.setGravity(Gravity.CENTER);
            applySampleDecoration(sample, style, getPreviewColorForStyle(style));
            preview.addView(sample, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            return preview;
        }

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView sample = new TextView(this);
        sample.setText(t("Ejemplo"));
        sample.setTextSize(uiSp(17));
        sample.setTypeface(Typeface.DEFAULT_BOLD);
        sample.setTextColor(Color.BLACK);
        sample.setGravity(Gravity.CENTER);
        content.addView(sample, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        View line = createPreviewUnderlineView(style, markThicknessLevel, getPreviewColorForStyle(style), uiDp(118));
        LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lineParams.topMargin = uiDp(2);
        content.addView(line, lineParams);

        preview.addView(content, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return preview;
    }

    private int getPreviewColorForStyle(int style) {
        int target = isHighlightStyle(style) ? COLOR_TARGET_HIGHLIGHT : COLOR_TARGET_UNDERLINE;
        int index = target == COLOR_TARGET_HIGHLIGHT ? highlightColorIndex : underlineColorIndex;
        return getMarkColor(target, index);
    }

    private void showAudioExportDialog() {
        // Un segundo toque en menos de 400 ms no abre otra copia de esta pantalla.
        if (!acceptTap("showAudioExportDialog")) return;
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }
        if (!hasAdvancedAccess()) {
            requireAdvancedAccess("Crear audio", new Runnable() {
                @Override public void run() { showAudioExportDialog(); }
            });
            return;
        }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(uiDp(20), uiDp(8), uiDp(20), uiDp(14));
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        // Mismo color de siempre pero con esquinas redondeadas. Antes era un
        // rectangulo recto y sus cuatro puntas sobresalian por encima del borde
        // curvo del dialogo: esas puntas eran los "ticks" feos de los bordes.
        box.setBackground(makeRoundedContentBackground());

        AudioEmblemView emblem = new AudioEmblemView(this);
        LinearLayout.LayoutParams emblemLp = new LinearLayout.LayoutParams(uiDp(104), uiDp(104));
        emblemLp.topMargin = uiDp(6);
        emblemLp.bottomMargin = uiDp(10);
        box.addView(emblem, emblemLp);

        TextView info = new TextView(this);
        info.setText(t("Elige una opción"));
        info.setTextSize(uiSp(16));
        info.setTypeface(Typeface.DEFAULT_BOLD);
        info.setGravity(Gravity.CENTER);
        info.setTextColor(Color.rgb(226, 240, 245));
        info.setPadding(0, 0, 0, uiDp(4));
        box.addView(info);

        TextView folder = new TextView(this);
        folder.setText(t("Se guardará en  Geo Zeta / Audios"));
        folder.setTextSize(uiSp(13));
        folder.setGravity(Gravity.CENTER);
        folder.setTextColor(Color.rgb(120, 145, 165));
        folder.setPadding(0, 0, 0, uiDp(14));
        box.addView(folder);

        final SelectableOptionCard current = makeSelectableAudioOptionCard(
                "icon:doc", Color.rgb(45, 212, 191),
                "Página actual", "", true);
        final SelectableOptionCard full = makeSelectableAudioOptionCard(
                "icon:book", Color.rgb(96, 130, 240),
                "Todo el PDF", "", false);
        final SelectableOptionCard range = makeSelectableAudioOptionCard(
                "icon:range", Color.rgb(52, 199, 176),
                "Elegir rango", "", false);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(68));
        cardLp.setMargins(0, uiDp(4), 0, uiDp(4));
        box.addView(current.root, cardLp);
        box.addView(full.root, cardLp);
        box.addView(range.root, cardLp);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Crear audio"))
                .setView(box)
                .setNegativeButton(t("Cerrar"), null)
                .create();

        current.root.setOnClickListener(v -> selectOnly(current, current, full, range));
        full.root.setOnClickListener(v -> selectOnly(full, current, full, range));
        range.root.setOnClickListener(v -> selectOnly(range, current, full, range));

        current.arrow.setOnClickListener(v -> {
            dialog.dismiss();
            startAudioExportRange(currentPage, currentPage);
        });
        full.arrow.setOnClickListener(v -> {
            dialog.dismiss();
            startAudioExportRange(0, pageCount - 1);
        });
        range.arrow.setOnClickListener(v -> {
            dialog.dismiss();
            showAudioRangeDialog();
        });

        dialog.show();
        if (dialog.getWindow() != null) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(18));
            bg.setColor(Color.rgb(9, 20, 34));
            dialog.getWindow().setBackgroundDrawable(bg);
        }
        applyDialogTextColors(dialog);
        Button negative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        if (negative != null) negative.setTextColor(Color.rgb(45, 212, 191));
    }

    /**
     * Tarjeta de opcion de la pantalla "Crear audio": circulo con icono a la
     * izquierda, titulo y subtitulo en el centro y una flecha a la derecha. Si
     * highlighted es true, la tarjeta lleva el borde celeste resaltado como la
     * opcion activa del diseno.
     */
    private View makeAudioOptionCard(String iconKey, int iconColor,
                                     String title, String subtitle, boolean highlighted) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(uiDp(14), uiDp(10), uiDp(16), uiDp(10));
        card.setClickable(true);
        card.setFocusable(true);

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setCornerRadius(uiDp(16));
        cardBg.setColor(Color.rgb(16, 30, 48));
        cardBg.setStroke(uiDp(highlighted ? 2 : 1),
                highlighted ? Color.rgb(45, 212, 191) : Color.rgb(34, 52, 74));
        card.setBackground(cardBg);

        // Circulo con el icono.
        FrameLayout iconWrap = new FrameLayout(this);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.argb(38, Color.red(iconColor), Color.green(iconColor), Color.blue(iconColor)));
        circle.setStroke(uiDp(1), Color.argb(120, Color.red(iconColor), Color.green(iconColor), Color.blue(iconColor)));
        iconWrap.setBackground(circle);

        AudioCardIconView icon = new AudioCardIconView(this, iconKey, iconColor);
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(uiDp(22), uiDp(22));
        iconLp.gravity = Gravity.CENTER;
        iconWrap.addView(icon, iconLp);

        LinearLayout.LayoutParams wrapLp = new LinearLayout.LayoutParams(uiDp(42), uiDp(42));
        wrapLp.rightMargin = uiDp(12);
        card.addView(iconWrap, wrapLp);

        // Titulo y subtitulo.
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(t(title));
        tvTitle.setTextSize(uiSp(17));
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle.setTextColor(Color.rgb(233, 243, 248));
        texts.addView(tvTitle);

        TextView tvSub = new TextView(this);
        tvSub.setText(t(subtitle));
        tvSub.setTextSize(uiSp(13));
        tvSub.setTextColor(Color.rgb(130, 152, 172));
        tvSub.setPadding(0, uiDp(2), 0, 0);
        texts.addView(tvSub);

        card.addView(texts, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        // Flecha.
        TextView chevron = new TextView(this);
        chevron.setText("›");
        chevron.setTextSize(uiSp(22));
        chevron.setTextColor(Color.rgb(120, 140, 160));
        card.addView(chevron, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        return card;
    }

    private void setSelectableCardSelected(SelectableOptionCard card, boolean selected) {
        if (card == null || card.root == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(16));
        bg.setColor(Color.rgb(16, 30, 48));
        bg.setStroke(uiDp(selected ? 2 : 1), selected
                ? Color.rgb(45, 212, 191)
                : Color.rgb(34, 52, 74));
        card.root.setBackground(bg);
        card.root.setSelected(selected);
        if (card.arrow != null) {
            card.arrow.setTextColor(selected ? Color.rgb(45, 212, 191) : Color.rgb(120, 140, 160));
        }
    }

    private void selectOnly(SelectableOptionCard selected, SelectableOptionCard... cards) {
        if (cards == null) return;
        for (SelectableOptionCard card : cards) {
            setSelectableCardSelected(card, card == selected);
        }
    }

    /** Tarjeta real de seleccion: la fila selecciona y SOLO la flecha ejecuta. */
    private SelectableOptionCard makeSelectableAudioOptionCard(String iconKey, int iconColor,
                                                                 String title, String subtitle,
                                                                 boolean selected) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(uiDp(12), uiDp(6), uiDp(4), uiDp(6));
        card.setClickable(true);
        card.setFocusable(true);

        FrameLayout iconWrap = new FrameLayout(this);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.argb(38, Color.red(iconColor), Color.green(iconColor), Color.blue(iconColor)));
        circle.setStroke(uiDp(1), Color.argb(120, Color.red(iconColor), Color.green(iconColor), Color.blue(iconColor)));
        iconWrap.setBackground(circle);
        AudioCardIconView icon = new AudioCardIconView(this, iconKey, iconColor);
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(uiDp(26), uiDp(26));
        iconLp.gravity = Gravity.CENTER;
        iconWrap.addView(icon, iconLp);
        LinearLayout.LayoutParams wrapLp = new LinearLayout.LayoutParams(uiDp(52), uiDp(52));
        wrapLp.rightMargin = uiDp(14);
        card.addView(iconWrap, wrapLp);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);
        TextView tvTitle = new TextView(this);
        tvTitle.setText(t(title));
        tvTitle.setTextSize(uiSp(16));
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle.setTextColor(Color.rgb(233, 243, 248));
        texts.addView(tvTitle);
        // Sin subtitulo no se anade nada y el titulo queda centrado en la
        // tarjeta. "Pagina actual" ya lo dice todo; la linea de explicacion solo
        // hacia el cuadro mas alto sin aportar nada.
        if (subtitle != null && subtitle.length() > 0) {
            TextView tvSub = new TextView(this);
            tvSub.setText(t(subtitle));
            tvSub.setTextSize(uiSp(13));
            tvSub.setTextColor(Color.rgb(130, 152, 172));
            tvSub.setPadding(0, uiDp(2), 0, 0);
            texts.addView(tvSub);
        }
        card.addView(texts, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(uiSp(28));
        arrow.setGravity(Gravity.CENTER);
        arrow.setClickable(true);
        arrow.setFocusable(true);
        arrow.setContentDescription(t("Abrir " + title));
        card.addView(arrow, new LinearLayout.LayoutParams(uiDp(40), uiDp(46)));

        SelectableOptionCard result = new SelectableOptionCard(card, arrow, iconColor);
        setSelectableCardSelected(result, selected);
        return result;
    }

    private SelectableOptionCard makeSelectableModeOptionCard(String title, String subtitle, boolean ocr,
                                                                boolean selected, boolean locked) {
        int accent = ocr ? Color.rgb(45, 212, 191) : Color.rgb(96, 130, 240);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(uiDp(12), uiDp(6), uiDp(4), uiDp(6));
        card.setClickable(true);
        card.setFocusable(true);

        TextView icon = new TextView(this);
        icon.setText(ocr ? "OCR" : "Aa");
        icon.setGravity(Gravity.CENTER);
        icon.setTextSize(uiSp(14));
        icon.setTypeface(Typeface.DEFAULT_BOLD);
        icon.setTextColor(accent);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(Color.argb(34, Color.red(accent), Color.green(accent), Color.blue(accent)));
        iconBg.setStroke(uiDp(1), Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent)));
        icon.setBackground(iconBg);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(uiDp(52), uiDp(52));
        iconLp.rightMargin = uiDp(14);
        card.addView(icon, iconLp);

        LinearLayout textBox = new LinearLayout(this);
        textBox.setOrientation(LinearLayout.VERTICAL);
        TextView titleView = new TextView(this);
        titleView.setText(t(title));
        titleView.setTextSize(uiSp(16));
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setTextColor(Color.rgb(240, 248, 252));
        textBox.addView(titleView);
        // Sin subtitulo el titulo queda centrado solo en la tarjeta.
        if (subtitle != null && subtitle.length() > 0) {
            TextView subView = new TextView(this);
            subView.setText(subtitle);
            subView.setTextSize(uiSp(12));
            subView.setTextColor(Color.rgb(135, 155, 175));
            subView.setPadding(0, uiDp(2), 0, 0);
            textBox.addView(subView);
        }
        card.addView(textBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView arrow = new TextView(this);
        arrow.setText(locked ? "🔒" : "›");
        arrow.setTextSize(uiSp(locked ? 20 : 28));
        arrow.setGravity(Gravity.CENTER);
        arrow.setClickable(true);
        arrow.setFocusable(true);
        arrow.setContentDescription(t("Abrir " + title));
        card.addView(arrow, new LinearLayout.LayoutParams(uiDp(48), uiDp(58)));

        SelectableOptionCard result = new SelectableOptionCard(card, arrow, accent);
        setSelectableCardSelected(result, selected);
        // Igual que en Ajustes: bloqueo claro por candado, sin apagar toda la
        // tarjeta ni convertir los colores en tonos sucios/dorados.
        card.setAlpha(1f);
        return result;
    }

    private void showAudioRangeDialog() {
        LinearLayout box = makeDialogContainer();

        final EditText startInput = new EditText(this);
        startInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        startInput.setHint(t("Desde (1 - " + pageCount + ")"));
        startInput.setText(String.valueOf(currentPage + 1));
        startInput.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        startInput.setHintTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        final EditText endInput = new EditText(this);
        endInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        endInput.setHint(t("Hasta (1 - " + pageCount + ")"));
        endInput.setText(String.valueOf(currentPage + 1));
        endInput.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        endInput.setHintTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        box.addView(startInput);
        box.addView(endInput);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Elegir rango"))
                .setView(box)
                .setNegativeButton(t("Cancelar"), null)
                .setPositiveButton(t("Crear"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int start;
                        int end;
                        try {
                            start = Integer.parseInt(startInput.getText().toString().trim()) - 1;
                            end = Integer.parseInt(endInput.getText().toString().trim()) - 1;
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, t("Rango inválido"), Toast.LENGTH_SHORT).show();
                            return;
                        }
                        startAudioExportRange(start, end);
                    }
                })
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void startAudioExportRange(int startPage, int endPage) {
        if (currentFile == null || pageCount <= 0) return;

        int start = Math.max(0, Math.min(startPage, pageCount - 1));
        int end = Math.max(0, Math.min(endPage, pageCount - 1));
        if (end < start) {
            int tmp = start;
            start = end;
            end = tmp;
        }

        audioExportSessionToken++;
        if (exportTts != null) {
            try { exportTts.stop(); } catch (Exception ignored) { }
        }
        clearActiveExportState(true);
        clearExportTempDirectory();

        exportStartPage = start;
        exportEndPage = end;
        exportCurrentPage = start;
        exportSavedCount = 0;
        lastExportedAudioFile = null;
        exportAudioBase = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
        exportAudioDir = new File(getAudioSaveDir(), exportAudioBase + "_P" + (start + 1) + "_a_" + (end + 1));
        if (!exportAudioDir.exists()) exportAudioDir.mkdirs();

        ensureNotificationPermission();
        createExportNotificationChannel();
        lastExportPercentShown = -1;
        updateExportProgressNotification();
        ensureExportTtsAndExportNext();
    }

    private void ensureExportTtsAndExportNext() {
        if (exportTts != null) {
            if (!exportTtsReady) return;
            configureExportTtsListener();
            exportNextPageAudio();
            return;
        }

        exportTtsReady = false;
        exportTts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.SUCCESS) {
                    exportTtsReady = false;
                    if (exportTts != null) {
                        try { exportTts.shutdown(); } catch (Exception ignored) { }
                        exportTts = null;
                    }
                    Toast.makeText(MainActivity.this, t("No se pudo iniciar voz"), Toast.LENGTH_LONG).show();
                    return;
                }
                exportTtsReady = true;
                exportTts.setLanguage(new Locale("es", "PE"));
                exportTts.setSpeechRate(speechRate);
                configureExportTtsListener();
                exportNextPageAudio();
            }
        });
    }

    private void configureExportTtsListener() {
        if (exportTts == null) return;
        exportTts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) { }

            @Override
            public void onDone(final String utteranceId) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handleExportChunkDone(utteranceId);
                    }
                });
            }

            @Override
            public void onError(final String utteranceId) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handleExportChunkError(utteranceId);
                    }
                });
            }

            @Override
            public void onError(final String utteranceId, int errorCode) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handleExportChunkError(utteranceId);
                    }
                });
            }
        });
    }

    private void exportNextPageAudio() {
        if (exportCurrentPage < 0 || exportCurrentPage > exportEndPage) {
            showAudioExportCompleted();
            return;
        }

        final int sessionToken = audioExportSessionToken;
        final int page = exportCurrentPage;
        textRepository.getPageText(page, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                if (sessionToken != audioExportSessionToken || page != exportCurrentPage) return;
                if (text == null || text.trim().length() == 0) {
                    exportCurrentPage++;
                    exportNextPageAudio();
                    return;
                }
                beginPageAudioExport(page, text.trim(), sessionToken);
            }
        });
    }

    private void beginPageAudioExport(int page, String text, int sessionToken) {
        if (sessionToken != audioExportSessionToken || exportTts == null) return;

        ArrayList<String> chunks = splitTextForTtsExport(text);
        if (chunks.isEmpty()) {
            exportCurrentPage++;
            exportNextPageAudio();
            return;
        }

        clearActiveExportState(true);
        activeExportChunks.addAll(chunks);
        activeExportChunkIndex = 0;
        activeExportPage = page;
        activeExportOutputFile = new File(exportAudioDir, exportAudioBase + "_pagina_" + (page + 1) + ".wav");
        synthesizeActiveExportChunk(sessionToken);
    }

    private ArrayList<String> splitTextForTtsExport(String text) {
        ArrayList<String> chunks = new ArrayList<>();
        if (text == null) return chunks;

        String source = text.trim();
        if (source.length() == 0) return chunks;

        int engineLimit;
        try {
            engineLimit = TextToSpeech.getMaxSpeechInputLength();
        } catch (Exception ignored) {
            engineLimit = 4000;
        }
        // Trozos cortos a proposito. El motor podria aceptar hasta 3600 caracteres
        // de una, pero entonces una pagina entera era un solo paso y la barra de
        // progreso se quedaba clavada en 0 % hasta terminar. Con trozos de ~350
        // el avance se ve moverse de verdad, y el corte se busca igual en un
        // final de frase para que el audio unido suene continuo.
        int limit = Math.max(200, Math.min(350, engineLimit - 64));
        int start = 0;
        while (start < source.length()) {
            int end = Math.min(source.length(), start + limit);
            if (end < source.length()) {
                int minimumBreak = start + Math.max(64, limit / 2);
                int sentenceBreak = findExportBreak(source, minimumBreak, end, true);
                int whitespaceBreak = findExportBreak(source, minimumBreak, end, false);
                if (sentenceBreak > start) {
                    end = sentenceBreak;
                } else if (whitespaceBreak > start) {
                    end = whitespaceBreak;
                }
            }

            if (end <= start) end = Math.min(source.length(), start + limit);
            String chunk = source.substring(start, end).trim();
            if (chunk.length() > 0) chunks.add(chunk);
            start = end;
            while (start < source.length() && Character.isWhitespace(source.charAt(start))) start++;
        }
        return chunks;
    }

    private int findExportBreak(String text, int minimum, int end, boolean sentenceOnly) {
        int lower = Math.max(0, minimum);
        for (int i = end - 1; i >= lower; i--) {
            char c = text.charAt(i);
            if (sentenceOnly) {
                if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':' || c == '\n') return i + 1;
            } else if (Character.isWhitespace(c) || c == ',') {
                return i + 1;
            }
        }
        return -1;
    }

    private void synthesizeActiveExportChunk(int sessionToken) {
        if (sessionToken != audioExportSessionToken || exportTts == null) return;
        if (activeExportChunkIndex < 0 || activeExportChunkIndex >= activeExportChunks.size()) {
            finishActiveExportPage(sessionToken);
            return;
        }

        File tempDir = new File(getCacheDir(), "tts_export_chunks");
        if (!tempDir.exists()) tempDir.mkdirs();
        File tempFile = new File(tempDir,
                "export_" + sessionToken + "_p" + activeExportPage + "_c" + activeExportChunkIndex + "_" + System.nanoTime() + ".wav");
        activeExportChunkFiles.add(tempFile);

        activeExportUtteranceId = "EXPORT_" + sessionToken + "_" + activeExportPage + "_" + activeExportChunkIndex + "_" + System.nanoTime();
        Bundle params = new Bundle();
        int result;
        try {
            result = exportTts.synthesizeToFile(
                    activeExportChunks.get(activeExportChunkIndex),
                    params,
                    tempFile,
                    activeExportUtteranceId);
        } catch (Exception e) {
            result = TextToSpeech.ERROR;
        }
        if (result != TextToSpeech.SUCCESS) {
            handleExportChunkError(activeExportUtteranceId);
        }
    }

    private void handleExportChunkDone(String utteranceId) {
        if (utteranceId == null || !utteranceId.equals(activeExportUtteranceId)) return;
        int sessionToken = audioExportSessionToken;
        activeExportUtteranceId = null;
        activeExportChunkIndex++;
        updateExportProgressNotification();
        if (activeExportChunkIndex < activeExportChunks.size()) {
            synthesizeActiveExportChunk(sessionToken);
        } else {
            finishActiveExportPage(sessionToken);
        }
    }

    private void handleExportChunkError(String utteranceId) {
        if (utteranceId == null || !utteranceId.equals(activeExportUtteranceId)) return;
        activeExportUtteranceId = null;
        final int sessionToken = audioExportSessionToken;
        final int failedPage = activeExportPage;
        clearActiveExportState(true);
        if (failedPage == exportCurrentPage && sessionToken == audioExportSessionToken) {
            exportCurrentPage++;
            updateExportProgressNotification();
            Toast.makeText(this, t("No se pudo exportar la página " + (failedPage + 1)), Toast.LENGTH_SHORT).show();
            exportNextPageAudio();
        }
    }

    private void finishActiveExportPage(final int sessionToken) {
        if (sessionToken != audioExportSessionToken) return;
        final int page = activeExportPage;
        final File output = activeExportOutputFile;
        final ArrayList<File> parts = new ArrayList<>(activeExportChunkFiles);
        activeExportUtteranceId = null;

        audioExportExecutor.execute(new Runnable() {
            @Override
            public void run() {
                boolean ok = false;
                try {
                    ok = mergeExportWavParts(parts, output);
                } catch (Exception ignored) { }
                final boolean success = ok;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        deleteExportFiles(parts);
                        if (sessionToken != audioExportSessionToken || page != exportCurrentPage) {
                            if (output != null && output.exists()) {
                                try { output.delete(); } catch (Exception ignored) { }
                            }
                            return;
                        }
                        clearActiveExportState(false);
                        if (success && output != null && output.exists() && output.length() > 44) {
                            exportSavedCount++;
                            lastExportedAudioFile = output;
                        } else {
                            if (output != null && output.exists()) output.delete();
                            Toast.makeText(MainActivity.this,
                                    t("No se pudo exportar la página " + (page + 1)), Toast.LENGTH_SHORT).show();
                        }
                        exportCurrentPage++;
                        updateExportProgressNotification();
                        exportNextPageAudio();
                    }
                });
            }
        });
    }

    // ------------------------------------------------------------------
    // Aviso de progreso al crear audio (0 a 100 %), como una descarga.
    // ------------------------------------------------------------------
    private static final String EXPORT_CHANNEL_ID = "pdf_audio_export_v119";
    private static final int EXPORT_NOTIFICATION_ID = 7311;
    private static final String ACTION_CANCEL_AUDIO_EXPORT =
            "com.geozeta.pdfaudio.action.CANCEL_AUDIO_EXPORT";
    private int lastExportPercentShown = -1;

    private void createExportNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(EXPORT_CHANNEL_ID,
                t("Creación de audio"), NotificationManager.IMPORTANCE_LOW);
        channel.setDescription(t("Progreso al guardar el audio del PDF"));
        channel.enableVibration(false);
        channel.setSound(null, null);
        manager.createNotificationChannel(channel);
    }

    /** Cancela de verdad una exportacion de audio en curso. */
    private void cancelActiveAudioExport(boolean userInitiated) {
        boolean hadWork = exportStartPage >= 0 && exportEndPage >= exportStartPage;
        File incompleteOutput = activeExportOutputFile;
        audioExportSessionToken++;
        if (exportTts != null) {
            try { exportTts.stop(); } catch (Exception ignored) { }
        }
        clearActiveExportState(true);
        clearExportTempDirectory();
        if (incompleteOutput != null && incompleteOutput.exists()) {
            try { incompleteOutput.delete(); } catch (Exception ignored) { }
        }
        // Las paginas que ya terminaron correctamente se conservan. Solo se
        // elimina la carpeta si no quedo ningun audio completo dentro.
        if (exportAudioDir != null && exportAudioDir.exists()) {
            File[] children = exportAudioDir.listFiles();
            if (children == null || children.length == 0) {
                try { exportAudioDir.delete(); } catch (Exception ignored) { }
            }
        }

        exportStartPage = -1;
        exportEndPage = -1;
        exportCurrentPage = -1;
        exportSavedCount = 0;
        lastExportedAudioFile = null;
        exportAudioDir = null;
        exportAudioBase = null;
        lastExportPercentShown = -1;
        cancelExportNotification();
        invalidateLibraryCache();
        if (userInitiated && hadWork) {
            Toast.makeText(this, t("Creación de audio cancelada"), Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Calcula cuanto se lleva hecho contando las paginas terminadas mas la
     * fraccion del trozo que se esta sintetizando de la pagina en curso.
     */
    private int currentExportPercent() {
        int totalPages = exportEndPage - exportStartPage + 1;
        if (totalPages <= 0) return 0;
        float pagesDone = Math.max(0, exportCurrentPage - exportStartPage);
        float withinPage = 0f;
        int chunkTotal = activeExportChunks == null ? 0 : activeExportChunks.size();
        if (chunkTotal > 0 && activeExportChunkIndex >= 0) {
            withinPage = Math.min(1f, activeExportChunkIndex / (float) chunkTotal);
        }
        float done = pagesDone + withinPage;
        int percent = Math.round(100f * done / totalPages);
        return Math.max(0, Math.min(100, percent));
    }

    private void updateExportProgressNotification() {
        int percent = currentExportPercent();
        if (percent == lastExportPercentShown) return;
        lastExportPercentShown = percent;
        int totalPages = Math.max(1, exportEndPage - exportStartPage + 1);
        int pageNumber = Math.max(1, Math.min(totalPages,
                exportCurrentPage - exportStartPage + 1));
        showExportNotification(t("Creando audio") + "  " + percent + "%",
                t("Página") + " " + pageNumber + " " + t("de") + " " + totalPages,
                percent, true);
    }

    private void showExportFinishedNotification(boolean success) {
        lastExportPercentShown = -1;
        if (!success) {
            cancelExportNotification();
            return;
        }
        showExportNotification(t("Audio guardado"),
                exportSavedCount + " " + t("archivo(s) en Mis archivos"), 100, false);
    }

    private void showExportNotification(String title, String text, int percent,
                                        boolean ongoing) {
        try {
            NotificationManager manager =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager == null) return;
            Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, EXPORT_CHANNEL_ID)
                    : new Notification.Builder(this);
            builder.setSmallIcon(R.drawable.ic_notification_blank)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setOnlyAlertOnce(true)
                    .setOngoing(ongoing)
                    .setShowWhen(false);
            if (ongoing) {
                builder.setProgress(100, Math.max(0, Math.min(100, percent)), false);
                Intent cancelIntent = new Intent(ACTION_CANCEL_AUDIO_EXPORT);
                cancelIntent.setPackage(getPackageName());
                int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= 23) pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
                PendingIntent cancelPending = PendingIntent.getBroadcast(
                        this, EXPORT_NOTIFICATION_ID, cancelIntent, pendingFlags);
                builder.addAction(R.drawable.ic_notification_close, t("Cancelar"), cancelPending);
            }
            manager.notify(EXPORT_NOTIFICATION_ID, builder.build());
        } catch (Exception ignored) {
        }
    }

    private void cancelExportNotification() {
        try {
            NotificationManager manager =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.cancel(EXPORT_NOTIFICATION_ID);
        } catch (Exception ignored) {
        }
    }

    private void clearActiveExportState(boolean deleteTempFiles) {
        if (deleteTempFiles) deleteExportFiles(activeExportChunkFiles);
        activeExportChunks.clear();
        activeExportChunkFiles.clear();
        activeExportChunkIndex = -1;
        activeExportPage = -1;
        activeExportOutputFile = null;
        activeExportUtteranceId = null;
    }

    private void deleteExportFiles(ArrayList<File> files) {
        if (files == null) return;
        for (File file : files) {
            if (file != null && file.exists()) {
                try { file.delete(); } catch (Exception ignored) { }
            }
        }
    }

    private void clearExportTempDirectory() {
        File dir = new File(getCacheDir(), "tts_export_chunks");
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file != null && file.isFile()) {
                try { file.delete(); } catch (Exception ignored) { }
            }
        }
    }

    private boolean mergeExportWavParts(ArrayList<File> parts, File output) throws IOException {
        if (parts == null || parts.isEmpty() || output == null) return false;
        if (parts.size() == 1) return copyExportFile(parts.get(0), output);

        ArrayList<WavChunkInfo> infos = new ArrayList<>();
        long totalData = 0L;
        byte[] expectedFormat = null;
        for (File part : parts) {
            WavChunkInfo info = readWavChunkInfo(part);
            if (info == null || info.formatChunk == null || info.dataLength <= 0) return false;
            if (expectedFormat == null) {
                expectedFormat = info.formatChunk;
            } else if (!Arrays.equals(expectedFormat, info.formatChunk)) {
                return false;
            }
            totalData += info.dataLength;
            if (totalData > 0xFFFFFFFFL) return false;
            infos.add(info);
        }

        WavChunkInfo first = infos.get(0);
        byte[] header = Arrays.copyOf(first.headerBeforeData, first.headerBeforeData.length);
        int pad = (int) (totalData & 1L);
        long riffSize = header.length + totalData + pad - 8L;
        if (riffSize < 0 || riffSize > 0xFFFFFFFFL || first.dataSizeFieldOffset < 0
                || first.dataSizeFieldOffset + 4 > header.length) return false;

        writeUInt32Le(header, 4, riffSize);
        writeUInt32Le(header, (int) first.dataSizeFieldOffset, totalData);

        File parent = output.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (FileOutputStream out = new FileOutputStream(output, false)) {
            out.write(header);
            byte[] buffer = new byte[32 * 1024];
            for (WavChunkInfo info : infos) {
                try (RandomAccessFile in = new RandomAccessFile(info.file, "r")) {
                    in.seek(info.dataOffset);
                    long remaining = info.dataLength;
                    while (remaining > 0) {
                        int count = in.read(buffer, 0, (int) Math.min(buffer.length, remaining));
                        if (count < 0) return false;
                        out.write(buffer, 0, count);
                        remaining -= count;
                    }
                }
            }
            if (pad != 0) out.write(0);
            out.flush();
        }
        return output.exists() && output.length() > header.length;
    }

    private boolean copyExportFile(File source, File output) throws IOException {
        if (source == null || !source.exists() || source.length() == 0 || output == null) return false;
        File parent = output.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(output, false)) {
            byte[] buffer = new byte[32 * 1024];
            int count;
            while ((count = in.read(buffer)) >= 0) {
                if (count > 0) out.write(buffer, 0, count);
            }
            out.flush();
        }
        return output.exists() && output.length() > 0;
    }

    private WavChunkInfo readWavChunkInfo(File file) throws IOException {
        if (file == null || !file.exists() || file.length() < 44) return null;
        try (RandomAccessFile in = new RandomAccessFile(file, "r")) {
            if (!"RIFF".equals(readFourCc(in))) return null;
            readUInt32Le(in);
            if (!"WAVE".equals(readFourCc(in))) return null;

            byte[] format = null;
            long dataOffset = -1L;
            long dataLength = -1L;
            long dataSizeFieldOffset = -1L;
            while (in.getFilePointer() + 8L <= in.length()) {
                String chunkId = readFourCc(in);
                long chunkSize = readUInt32Le(in);
                long chunkDataStart = in.getFilePointer();
                if (chunkSize < 0 || chunkDataStart + chunkSize > in.length()) return null;

                if ("fmt ".equals(chunkId)) {
                    if (chunkSize <= 0 || chunkSize > 1024L) return null;
                    format = new byte[(int) chunkSize];
                    in.readFully(format);
                } else if ("data".equals(chunkId)) {
                    dataOffset = chunkDataStart;
                    dataLength = Math.min(chunkSize, in.length() - chunkDataStart);
                    dataSizeFieldOffset = chunkDataStart - 4L;
                    break;
                }

                long next = chunkDataStart + chunkSize + (chunkSize & 1L);
                if (next > in.length()) return null;
                in.seek(next);
            }
            if (format == null || dataOffset < 0 || dataLength <= 0 || dataOffset > Integer.MAX_VALUE) return null;

            byte[] header = new byte[(int) dataOffset];
            in.seek(0L);
            in.readFully(header);
            return new WavChunkInfo(file, format, dataOffset, dataLength, dataSizeFieldOffset, header);
        }
    }

    private String readFourCc(RandomAccessFile in) throws IOException {
        byte[] bytes = new byte[4];
        in.readFully(bytes);
        return new String(bytes, java.nio.charset.StandardCharsets.US_ASCII);
    }

    private long readUInt32Le(RandomAccessFile in) throws IOException {
        long b0 = in.readUnsignedByte();
        long b1 = in.readUnsignedByte();
        long b2 = in.readUnsignedByte();
        long b3 = in.readUnsignedByte();
        return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24);
    }

    private void writeUInt32Le(byte[] data, int offset, long value) {
        data[offset] = (byte) (value & 0xFF);
        data[offset + 1] = (byte) ((value >> 8) & 0xFF);
        data[offset + 2] = (byte) ((value >> 16) & 0xFF);
        data[offset + 3] = (byte) ((value >> 24) & 0xFF);
    }

    private static final class WavChunkInfo {
        final File file;
        final byte[] formatChunk;
        final long dataOffset;
        final long dataLength;
        final long dataSizeFieldOffset;
        final byte[] headerBeforeData;

        WavChunkInfo(File file, byte[] formatChunk, long dataOffset, long dataLength,
                     long dataSizeFieldOffset, byte[] headerBeforeData) {
            this.file = file;
            this.formatChunk = formatChunk;
            this.dataOffset = dataOffset;
            this.dataLength = dataLength;
            this.dataSizeFieldOffset = dataSizeFieldOffset;
            this.headerBeforeData = headerBeforeData;
        }
    }

    private void showMarkColorDialog(final int target) {
        showMarkColorDialog(target, false);
    }

    /** Los cuatro colores personalizados se crean o editan con un solo toque. */
    private void showMarkColorDialog(final int target, final boolean editMode) {
        final int selected = target == COLOR_TARGET_HIGHLIGHT ? highlightColorIndex : underlineColorIndex;
        final boolean usingCustom = target == COLOR_TARGET_HIGHLIGHT ? useCustomHighlightColor : useCustomUnderlineColor;
        final int currentCustom = target == COLOR_TARGET_HIGHLIGHT ? customHighlightRgb : customUnderlineRgb;
        final String title = target == COLOR_TARGET_HIGHLIGHT ? "Color del resaltado" : "Color del subrayado";

        // Cual de los cuatro colores propios es el que esta activo. Se resuelve
        // UNA sola vez y por posicion, no comparando el color de cada casilla:
        // si dos casillas guardaban el mismo color, antes las dos se marcaban
        // con el tilde a la vez.
        int matchingQuick = -1;
        if (usingCustom) {
            for (int slot = 0; slot < QUICK_MARK_SLOT_COUNT; slot++) {
                if (hasQuickMarkColor(slot) && getQuickMarkColor(slot) == currentCustom) {
                    matchingQuick = slot;
                    break;
                }
            }
        }
        final int selectedQuickSlot = matchingQuick;

        LinearLayout container = makeDialogContainer();
        container.setGravity(Gravity.CENTER_HORIZONTAL);
        container.setPadding(uiDp(16), uiDp(10), uiDp(16), uiDp(12));


        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView(title))
                .setView(container)
                .setNegativeButton(t("Cancelar"), null)
                .create();

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(4);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setUseDefaultMargins(false);

        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                TextView swatch = new TextView(this);
                swatch.setGravity(Gravity.CENTER);
                swatch.setTypeface(Typeface.DEFAULT_BOLD);
                swatch.setTextSize(uiSp(18));

                if (col == 0) {
                    if (row < QUICK_MARK_SLOT_COUNT) {
                        final int quickSlot = row;
                        final boolean hasQuick = hasQuickMarkColor(quickSlot);
                        final int quickColor = getQuickMarkColor(quickSlot);
                        final boolean selectedQuick = quickSlot == selectedQuickSlot;
                        swatch.setText(hasQuick ? (selectedQuick ? "✓" : "") : "+");
                        swatch.setTextColor(hasQuick
                                ? (isDarkSwatch(quickColor) ? Color.WHITE : Color.BLACK)
                                : (darkTheme ? Color.WHITE : Color.rgb(30, 41, 59)));
                        swatch.setContentDescription(hasQuick
                                ? t("Color personalizado " + (quickSlot + 1))
                                : t("Crear color personalizado " + (quickSlot + 1)));
                        swatch.setBackground(buildMarkSwatchDrawable(hasQuick ? quickColor : -1, selectedQuick));
                        swatch.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                                // Un toque abre el mismo selector con el color
                                // actual cargado; Guardar lo reemplaza y lo deja
                                // activo. Ya no existe pulsacion larga.
                                showCustomColorDialog(target, quickSlot);
                            }
                        });
                    }
                } else {
                    final int presetIndex = row * 3 + (col - 1);
                    final int presetColor = MARK_COLOR_RGB[presetIndex];
                    final boolean selectedPreset = !usingCustom && presetIndex == selected;
                    swatch.setText(selectedPreset ? "✓" : "");
                    swatch.setTextColor(isDarkSwatch(presetColor) ? Color.WHITE : Color.BLACK);
                    swatch.setContentDescription(t("Color base " + (presetIndex + 1)));
                    swatch.setBackground(buildMarkSwatchDrawable(presetColor, selectedPreset));
                    swatch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int safe = safeMarkColorIndex(presetIndex);
                            SharedPreferences.Editor editor = prefs.edit();
                            if (target == COLOR_TARGET_HIGHLIGHT) {
                                highlightColorIndex = safe;
                                useCustomHighlightColor = false;
                                editor.putInt(PREF_HIGHLIGHT_COLOR, safe)
                                        .putBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, false);
                            } else {
                                underlineColorIndex = safe;
                                useCustomUnderlineColor = false;
                                editor.putInt(PREF_UNDERLINE_COLOR, safe)
                                        .putBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, false);
                            }
                            editor.apply();
                            applyMarkAppearance();
                            dialog.dismiss();
                        }
                    });
                }

                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = uiDp(60);
                lp.height = uiDp(60);
                lp.setMargins(uiDp(6), uiDp(6), uiDp(6), uiDp(6));
                grid.addView(swatch, lp);
            }
        }

        container.addView(grid, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        dialog.show();
        styleDialog(dialog);
    }

    private GradientDrawable buildMarkSwatchDrawable(int color, boolean selected) {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.OVAL);
        if (color >= 0) {
            shape.setColor(0xFF000000 | (color & 0x00FFFFFF));
        } else {
            shape.setColor(darkTheme ? Color.rgb(16, 45, 66) : Color.rgb(226, 239, 255));
        }
        shape.setStroke(uiDp(selected ? 3 : 1), selected
                ? Color.rgb(59, 130, 246)
                : (darkTheme ? Color.WHITE : Color.rgb(71, 85, 105)));
        return shape;
    }

    private boolean hasQuickMarkColor(int slot) {
        return prefs.getBoolean("quick_mark_color_set_" + slot, false);
    }

    private int getQuickMarkColor(int slot) {
        return prefs.getInt("quick_mark_color_" + slot, 0x00FFD400) & 0x00FFFFFF;
    }

    private void saveQuickMarkColor(int slot, int color) {
        prefs.edit()
                .putInt("quick_mark_color_" + slot, color & 0x00FFFFFF)
                .putBoolean("quick_mark_color_set_" + slot, true)
                .apply();
    }

    private void applyQuickMarkColor(int target, int color) {
        color &= 0x00FFFFFF;
        SharedPreferences.Editor editor = prefs.edit();
        if (target == COLOR_TARGET_HIGHLIGHT) {
            customHighlightRgb = color;
            useCustomHighlightColor = true;
            editor.putInt(PREF_CUSTOM_HIGHLIGHT_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, true);
        } else {
            customUnderlineRgb = color;
            useCustomUnderlineColor = true;
            editor.putInt(PREF_CUSTOM_UNDERLINE_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, true);
        }
        editor.apply();
        applyMarkAppearance();
    }

    private void showCustomColorDialog(final int target) {
        showCustomColorDialog(target, -1);
    }

    private void showCustomColorDialog(final int target, final int quickSlot) {
        final int initial = quickSlot >= 0 && hasQuickMarkColor(quickSlot)
                ? getQuickMarkColor(quickSlot)
                : (target == COLOR_TARGET_HIGHLIGHT ? customHighlightRgb : customUnderlineRgb);

        LinearLayout box = makeDialogContainer();
        box.setPadding(uiDp(16), uiDp(12), uiDp(16), uiDp(14));

        final ProfessionalColorPickerView picker = new ProfessionalColorPickerView(this);
        picker.setColor(initial);
        box.addView(picker, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(205)));

        final HueSliderView hueSlider = new HueSliderView(this);
        hueSlider.setHue(picker.getHue());
        LinearLayout.LayoutParams hueLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(30));
        hueLp.setMargins(0, uiDp(10), 0, 0);
        box.addView(hueSlider, hueLp);

        final TextView sample = new TextView(this);
        sample.setTextSize(uiSp(20));
        sample.setTypeface(Typeface.DEFAULT_BOLD);
        sample.setGravity(Gravity.CENTER);
        sample.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(10));
        LinearLayout.LayoutParams sampleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(60));
        sampleLp.setMargins(0, uiDp(10), 0, 0);
        box.addView(sample, sampleLp);

        final GradientDrawable sampleBg = new GradientDrawable();
        sampleBg.setCornerRadius(uiDp(14));
        sampleBg.setStroke(uiDp(1), darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        sample.setBackground(sampleBg);

        final boolean[] sampleUpdatePending = new boolean[]{false};
        final Runnable update = new Runnable() {
            @Override
            public void run() {
                sampleUpdatePending[0] = false;
                int color = picker.getSelectedColor() & 0x00FFFFFF;
                sample.setText(String.format(Locale.US, "#%06X", color));
                sample.setTextColor(isDarkSwatch(color) ? Color.WHITE : Color.BLACK);
                sampleBg.setColor(0xFF000000 | color);
            }
        };

        picker.setOnColorChangedListener(new ProfessionalColorPickerView.OnColorChangedListener() {
            @Override
            public void onColorChanged(int color) {
                if (!sampleUpdatePending[0]) {
                    sampleUpdatePending[0] = true;
                    sample.postOnAnimation(update);
                }
            }
        });
        hueSlider.setOnHueChangedListener(new HueSliderView.OnHueChangedListener() {
            @Override
            public void onHueChanged(float hue) {
                picker.setHue(hue);
            }
        });
        update.run();

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Color personalizado"))
                .setView(box)
                .setNegativeButton(t("Cancelar"), null)
                .setPositiveButton(t("Guardar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int color = picker.getSelectedColor() & 0x00FFFFFF;
                        SharedPreferences.Editor editor = prefs.edit();
                        if (quickSlot >= 0) {
                            saveQuickMarkColor(quickSlot, color);
                        }
                        if (target == COLOR_TARGET_HIGHLIGHT) {
                            customHighlightRgb = color;
                            useCustomHighlightColor = true;
                            editor.putInt(PREF_CUSTOM_HIGHLIGHT_COLOR, color)
                                    .putBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, true);
                        } else {
                            customUnderlineRgb = color;
                            useCustomUnderlineColor = true;
                            editor.putInt(PREF_CUSTOM_UNDERLINE_COLOR, color)
                                    .putBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, true);
                        }
                        editor.apply();
                        applyMarkAppearance();
                    }
                }).create();
        dialog.show();
        styleDialog(dialog);
    }

    private boolean isDarkSwatch(int rgb) {
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        return (r * 299 + g * 587 + b * 114) / 1000 < 145;
    }

    private void setMarkStyle(int style) {
        markStyle = safeMarkStyle(style);
        prefs.edit().putInt(PREF_MARK_STYLE, markStyle).apply();
        applyMarkAppearance();
    }

    private void applyMarkAppearance() {
        if (pdfView != null) {
            pdfView.setMarkStyle(markStyle);
            pdfView.setMarkThickness(markThicknessLevel);
            pdfView.setMarkColor(getCurrentMarkColor());
        }
        updateMarkControls();
    }

    private void updateMarkControls() {
        if (markButton != null) {
            // "ON"/"OFF" se lee igual en los cinco idiomas y nunca desborda la
            // celda; la descripcion accesible si va traducida.
            if (markButtonLabel != null) markButtonLabel.setText(markMode ? "ON" : "OFF");
            if (markButtonIcon != null) {
                markButtonIcon.setIconColor(markMode
                        ? (0xFF000000 | (getCurrentMarkColor() & 0x00FFFFFF))
                        : (darkTheme ? Color.WHITE : Color.rgb(15, 23, 42)));
            }
            markButton.setAlpha(markMode ? 1f : 0.78f);
            markButton.setContentDescription(markMode
                    ? t("Subrayado activado: un dedo marca y dos dedos mueven")
                    : t("Subrayado desactivado"));
        }
        if (colorButton != null) {
            colorButton.setText(t("●"));
            colorButton.setTextColor(0xFF000000 | (getCurrentMarkColor() & 0x00FFFFFF));
            colorButton.setAlpha(1f);
        }
    }

    private boolean isHighlightStyle(int style) {
        return style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE;
    }

    private int getCurrentMarkColor() {
        int target = isHighlightStyle(markStyle) ? COLOR_TARGET_HIGHLIGHT : COLOR_TARGET_UNDERLINE;
        int index = target == COLOR_TARGET_HIGHLIGHT ? highlightColorIndex : underlineColorIndex;
        return getMarkColor(target, index);
    }

    private int getMarkColor(int target, int index) {
        int rgb;
        if (target == COLOR_TARGET_HIGHLIGHT && useCustomHighlightColor) {
            rgb = customHighlightRgb;
        } else if (target == COLOR_TARGET_UNDERLINE && useCustomUnderlineColor) {
            rgb = customUnderlineRgb;
        } else {
            rgb = MARK_COLOR_RGB[safeMarkColorIndex(index)];
        }
        int alpha;
        if (target == COLOR_TARGET_HIGHLIGHT) {
            alpha = markStyle == MARK_STYLE_HIGHLIGHT_INTENSE ? 0xA8 : 0x62;
        } else {
            alpha = 0xEE;
        }
        return (alpha << 24) | (rgb & 0x00FFFFFF);
    }

    private int safeMarkStyle(int style) {
        if (style == MARK_STYLE_TEXT_BOX) return MARK_STYLE_UNDERLINE_FINE;
        if (style < MARK_STYLE_UNDERLINE_FINE || style > MARK_STYLE_HIGHLIGHT_INTENSE) {
            return MARK_STYLE_UNDERLINE_FINE;
        }
        return style;
    }

    private int safeThicknessLevel(int level) {
        if (level < 0 || level > 2) return 1;
        return level;
    }

    private int migrateV71ColorIndex(int oldIndex) {
        switch (oldIndex) {
            case 1: return 3; // azul
            case 2: return 4; // verde
            case 3: return 1; // rojo
            case 4: return 6; // morado
            case 5: return 7; // celeste
            case 0:
            default: return 0;
        }
    }

    private int safeMarkColorIndex(int index) {
        if (index < 0 || index >= MARK_COLOR_RGB.length) return 0;
        return index;
    }

    private String highlightKey() {
        String safeTitle = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
        String safeFile = currentFile == null ? "nofile" : String.valueOf(currentFile.getAbsolutePath().hashCode());
        return "text_selection_markers_" + safeTitle + "_" + safeFile;
    }

    private String legacyHighlightKey() {
        return "text_selection_markers_" + currentTitle;
    }

    private void saveHighlights(String serialized) {
        prefs.edit().putString(highlightKey(), serialized == null ? "" : serialized).apply();
    }

    private void repairBrokenPlaybackStateOnce() {
        if (prefs.getBoolean(PREF_AUDIO_STATE_REPAIRED_V69, false)) return;

        try {
            stopService(new Intent(this, TtsForegroundService.class));
        } catch (Exception ignored) {
        }

        TtsForegroundService.clearPages();
        prefs.edit()
                .putBoolean(PREF_TTS_ACTIVE, false)
                .putBoolean(PREF_TTS_PAUSED, false)
                .putInt(PREF_TTS_CURRENT_PAGE, -1)
                .putInt(PREF_TTS_STATE, TtsForegroundService.STATE_STOPPED)
                .putString(PREF_TTS_MESSAGE, "")
                .remove("tts_service_preparing")
                .putBoolean(PREF_AUDIO_STATE_REPAIRED_V69, true)
                .apply();

        playbackState = TtsForegroundService.STATE_STOPPED;
        audioStarted = false;
        audioPaused = false;
        audioPreparing = false;
        requestedAudioPage = -1;
        requestedAudioPageConfirmed = false;
        audioRequestToken++;
    }

    private void clearStalePlaybackState() {
        playbackState = TtsForegroundService.STATE_STOPPED;
        audioPreparing = false;
        audioStarted = false;
        audioPaused = false;
        requestedAudioPage = -1;
        requestedAudioPageConfirmed = false;
        stopPlayPreparingDots();
        if (playButton != null) playButton.setText(t("▶"));
        if (prefs != null) {
            prefs.edit()
                    .putBoolean(PREF_TTS_ACTIVE, false)
                    .putBoolean(PREF_TTS_PAUSED, false)
                    .putInt(PREF_TTS_STATE, TtsForegroundService.STATE_STOPPED)
                    .putInt(PREF_TTS_CURRENT_PAGE, -1)
                    .putString(PREF_TTS_MESSAGE, "")
                    .apply();
        }
    }

    private void startPlayPreparingDots() {
        stopPlayPreparingDots();
        // v160: mientras prepara solo se muestran tres puntos fijos.
        // No se anima la cantidad de puntos: el indicador permanece estable.
        if (playButton != null) playButton.setText("...");
    }

    private void stopPlayPreparingDots() {
        if (playPreparingDotsRunnable != null) {
            audioStartHandler.removeCallbacks(playPreparingDotsRunnable);
            playPreparingDotsRunnable = null;
        }
    }

    private void toggleAudio() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }
        if (currentOcrMode && !hasAdvancedAccess()) {
            requireAdvancedAccess("Lectura OCR", new Runnable() {
                @Override
                public void run() { toggleAudio(); }
            });
            return;
        }

        // El campo local playbackState se actualiza por broadcast, que puede
        // llegar con unos milisegundos de retraso respecto al estado real del
        // servicio. Si el usuario toca Play/Pausa justo en ese hueco, la
        // decision se tomaba con un estado viejo y el toque no hacia nada (o
        // hacia lo contrario). Antes de decidir, se relee el estado real que
        // el servicio ya dejo guardado, sin esperar a que llegue el broadcast.
        if (prefs != null) {
            int realState = prefs.getInt(PREF_TTS_STATE, -1);
            if (realState >= 0 && realState != playbackState) {
                playbackState = realState;
            }
        }

        // Tras un cierre por memoria pueden quedar preferencias que dicen
        // PLAYING/PREPARING aunque ya no exista una sesión real del servicio.
        // En ese caso un ACTION_TOGGLE no tiene nada que reanudar y parecía que
        // Play estaba muerto hasta cambiar de página. Se descarta sólo ese estado
        // huérfano y se arranca una sesión nueva en la página visible.
        if ((playbackState == TtsForegroundService.STATE_PREPARING
                || playbackState == TtsForegroundService.STATE_PLAYING
                || playbackState == TtsForegroundService.STATE_PAUSED)
                && !TtsForegroundService.hasLivePlaybackSession()) {
            clearStalePlaybackState();
        }

        if (playbackState == TtsForegroundService.STATE_PREPARING || audioPreparing) {
            // Mientras se prepara, el botón muestra solo "..." y no se convierte
            // en una falsa pausa. Un segundo toque no rompe la sesión que está
            // a punto de empezar a hablar.
            return;
        }

        if (playbackState == TtsForegroundService.STATE_PLAYING) {
            Intent intent = new Intent(this, TtsForegroundService.class);
            intent.setAction(TtsForegroundService.ACTION_TOGGLE);
            startService(intent);
            return;
        }

        if (playbackState == TtsForegroundService.STATE_PAUSED) {
            // Solo reanudar si el servicio conserva de verdad una sesion pausada
            // con fragmentos preparados para esta misma pagina. Un estado PAUSED
            // guardado en preferencias, o una pagina cambiada mientras estaba en
            // pausa, debe arrancar por ACTION_START para usar el fast-start normal.
            if (TtsForegroundService.canResumePausedPage(currentPage)) {
                Intent intent = new Intent(this, TtsForegroundService.class);
                intent.setAction(TtsForegroundService.ACTION_TOGGLE);
                startService(intent);
            } else {
                startAudioFromPage(currentPage);
            }
            return;
        }

        startAudioFromPage(currentPage);
    }

    private void startAudioFromPage(final int pageToRead) {
        if (currentFile == null || pageCount <= 0) return;
        if (currentOcrMode && !hasAdvancedAccess()) {
            requireAdvancedAccess("Lectura OCR", new Runnable() {
                @Override
                public void run() { startAudioFromPage(pageToRead); }
            });
            return;
        }

        // Play siempre gana frente a la sintesis preventiva del puente. Si el
        // usuario toca ahora, no arrancamos trabajo TTS secundario en paralelo.
        cancelScheduledFastResumePreparation();

        // Si el usuario toca Play antes de que la pagina termine de dibujarse,
        // la preparacion del texto que estaba esperando arranca ya mismo.
        runDeferredDocumentWork();

        // Vuelve a leer: la pagina del lector pasa a ser la referencia otra vez.
        userBrowsedAwayWhilePaused = false;
        ensureNotificationPermission();
        cancelAudioPreparationTimeout();

        final int safePage = Math.max(0, Math.min(pageToRead, pageCount - 1));
        final int token = ++audioRequestToken;
        requestedAudioPage = safePage;
        requestedAudioPageConfirmed = false;

        // El boton muestra "..." desde el mismo toque. Antes esperaba al aviso
        // del servicio y durante ese hueco seguia en "▶": parecia que el toque
        // no habia hecho nada y de golpe saltaba a los tres puntos.
        audioPreparing = true;
        startPlayPreparingDots();
        // Red de seguridad: si por lo que sea la lectura nunca llega a arrancar,
        // el boton vuelve solo a "▶" en vez de quedarse en "..." para siempre,
        // que dejaria Play muerto hasta cambiar de pagina.
        cancelAudioPreparationTimeout();
        audioStartTimeout = new Runnable() {
            @Override
            public void run() {
                audioStartTimeout = null;
                if (token != audioRequestToken) return;
                if (playbackState == TtsForegroundService.STATE_PLAYING
                        || playbackState == TtsForegroundService.STATE_PAUSED) return;
                if (TtsForegroundService.hasLivePlaybackSession()) return;
                audioRequestToken++;
                requestedAudioPage = -1;
                requestedAudioPageConfirmed = false;
                applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1, "Detenido", false);
            }
        };
        audioStartHandler.postDelayed(audioStartTimeout, 20000L);

        if (currentPdfLanguage.length() > 0 && !provisionalPdfLanguageActive) {
            startAudioFromPageResolved(safePage, token);
            return;
        }

        // PDF nuevo: no esperamos a la deteccion de idioma para empezar a hablar.
        // Arrancamos con la mejor voz disponible (la ultima usada, o la del
        // idioma de la interfaz) y la deteccion sigue en paralelo. Si termina
        // dando otro idioma, la lectura se reinicia con la voz correcta.
        final String provisional = provisionalPdfLanguage();
        final boolean startedProvisionally;
        if (provisional.length() > 0) {
            currentPdfLanguage = provisional;
            currentPdfLanguageConfidence = 0f;
            provisionalPdfLanguageActive = true;
            TtsEngineManager.getInstance(this).setPreferredLanguage(provisional, appRegion);
            startAudioFromPageResolved(safePage, token);
            startedProvisionally = true;
        } else {
            startedProvisionally = false;
            applyPlaybackState(TtsForegroundService.STATE_PREPARING, safePage,
                    "Detectando idioma del PDF...", false);
        }

        ensurePdfLanguageForPlayback(safePage, token, new Runnable() {
            @Override
            public void run() {
                if (token != audioRequestToken || requestedAudioPage != safePage
                        || currentPdfLanguage.length() == 0) return;
                if (startedProvisionally) {
                    // Ya esta sonando: solo reiniciamos si el idioma real cambio.
                    if (provisionalPdfLanguageActive
                            && !provisional.equals(currentPdfLanguage)) {
                        provisionalPdfLanguageActive = false;
                        startAudioFromPage(safePage);
                    } else {
                        provisionalPdfLanguageActive = false;
                    }
                    return;
                }
                startAudioFromPageResolved(safePage, token);
            }
        });
    }

    /** Hay un idioma decidido de verdad (no el provisional de arranque). */
    private boolean hasConfirmedPdfLanguage() {
        return currentPdfLanguage.length() > 0 && !provisionalPdfLanguageActive;
    }

    /**
     * Idioma con el que arrancar antes de saber el real: primero el ultimo que
     * el motor de voz uso con exito, y si no hay, el idioma de la interfaz.
     */
    private String provisionalPdfLanguage() {
        try {
            String last = TtsEngineManager.getInstance(this).getPreferredLanguage();
            if (last != null && PdfLanguageDetector.isSupported(
                    PdfLanguageDetector.normalizeCode(last))) {
                return PdfLanguageDetector.normalizeCode(last);
            }
        } catch (Throwable ignored) {
        }
        String ui = PdfLanguageDetector.normalizeCode(appLanguage);
        return PdfLanguageDetector.isSupported(ui) ? ui : "";
    }

    private void startAudioFromPageResolved(final int safePage, final int token) {
        if (token != audioRequestToken || requestedAudioPage != safePage
                || currentPdfLanguage.length() == 0) return;
        applyPlaybackState(TtsForegroundService.STATE_PREPARING, safePage,
                "Preparando pagina " + (safePage + 1), false);

        String cached = textRepository == null ? null : textRepository.getCachedText(safePage);
        if (cached != null) {
            beginTtsWithText(safePage, cached, token);
            return;
        }

        // Espera la pagina completa. Empezar con un prefijo corto y continuar con
        // una segunda orden TTS era la principal fuente de microcortes audibles.
        beginTtsForPage(safePage, null, false, token);
    }

    private void ensurePdfLanguageForPlayback(final int page, final int requestToken,
                                              final Runnable afterResolved) {
        if (hasConfirmedPdfLanguage()) {
            if (afterResolved != null) afterResolved.run();
            return;
        }
        if (textRepository == null || currentFile == null || currentBookmarkKey == null) {
            showPdfLanguageChooser(requestToken, afterResolved);
            return;
        }

        final File file = currentFile;
        final String documentKey = currentBookmarkKey;
        final int detectionGeneration = languageDetectionToken;
        textRepository.getPageTextPriority(page, new TextRepository.TextCallback() {
            @Override
            public void onText(final String text) {
                if (requestToken != audioRequestToken
                        || !isCurrentLanguageDetection(detectionGeneration, file, documentKey)) return;
                if (hasConfirmedPdfLanguage()) {
                    if (afterResolved != null) afterResolved.run();
                    return;
                }
                final String sample = text == null ? "" : text.trim();
                if (sample.length() < 24) {
                    showPdfLanguageChooser(requestToken, afterResolved);
                    return;
                }
                try {
                    languageDetectionExecutor.execute(new Runnable() {
                        @Override
                        public void run() {
                            final PdfLanguageDetector.Result result = PdfLanguageDetector.detect(
                                    getApplicationContext(), sample.length() > 5000
                                            ? sample.substring(0, 5000) : sample);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (requestToken != audioRequestToken
                                            || !isCurrentLanguageDetection(detectionGeneration,
                                            file, documentKey)) return;
                                    if (hasConfirmedPdfLanguage()) {
                                        if (afterResolved != null) afterResolved.run();
                                        return;
                                    }
                                    if (result.isConfident()) {
                                        saveCurrentPdfLanguage(result.languageCode, result.confidence);
                                        if (afterResolved != null) afterResolved.run();
                                    } else {
                                        showPdfLanguageChooser(requestToken, afterResolved);
                                    }
                                }
                            });
                        }
                    });
                } catch (Exception ignored) {
                    showPdfLanguageChooser(requestToken, afterResolved);
                }
            }
        });
    }

    private void showPdfLanguageChooser(final int requestToken, final Runnable afterResolved) {
        if (requestToken != audioRequestToken || isFinishing()
                || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        if (hasConfirmedPdfLanguage()) {
            if (afterResolved != null) afterResolved.run();
            return;
        }
        if (pdfLanguageDialogVisible) return;
        pdfLanguageDialogVisible = true;
        final String[] codes = new String[]{UiStrings.ES, UiStrings.EN, UiStrings.PT,
                UiStrings.HI, UiStrings.ID};
        final String[] labels = new String[]{"Español", "English", "Português (Brasil)",
                "हिन्दी — Hindi", "Bahasa Indonesia"};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Idioma del PDF"))
                .setMessage(t("No pudimos detectar con seguridad el idioma de este PDF. Elige el idioma para leerlo."))
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        pdfLanguageDialogVisible = false;
                        if (requestToken != audioRequestToken || which < 0 || which >= codes.length) return;
                        saveCurrentPdfLanguage(codes[which], 1.0f);
                        if (afterResolved != null) afterResolved.run();
                    }
                })
                .setNegativeButton(t("Cancelar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        pdfLanguageDialogVisible = false;
                        if (requestToken == audioRequestToken) {
                            audioRequestToken++;
                            requestedAudioPage = -1;
                            requestedAudioPageConfirmed = false;
                            applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1,
                                    "Detenido", false);
                        }
                    }
                })
                .create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                pdfLanguageDialogVisible = false;
                // Cerrar tocando fuera equivale a cancelar. Sin esto el boton de
                // Play se quedaba en "..." para siempre, esperando una lectura
                // que ya nadie iba a arrancar.
                if (requestToken == audioRequestToken && currentPdfLanguage.length() == 0) {
                    audioRequestToken++;
                    requestedAudioPage = -1;
                    requestedAudioPageConfirmed = false;
                    applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1,
                            "Detenido", false);
                }
            }
        });
        dialog.show();
        styleDialog(dialog);
        styleDialog(dialog);
    }

    private void beginTtsWithText(final int safePage, String text, final int token) {
        beginTtsForPage(safePage, text, false, token);
    }

    private void beginTtsForPage(final int safePage, String text, boolean fastOnly,
                                 final int token) {
        if (token != audioRequestToken || requestedAudioPage != safePage) return;
        cancelAudioPreparationTimeout();

        if (text != null) {
            TtsForegroundService.setPageText(safePage, text);
        }

        // Si existe un pequeño audio puente preparado para esta misma pagina,
        // se entrega al servicio. Solo se utiliza cuando el motor TTS realmente
        // esta frio/no listo, de modo que no sustituye una reproduccion normal.
        String bridgeSource = text;
        if ((bridgeSource == null || bridgeSource.trim().length() == 0)
                && textRepository != null) {
            bridgeSource = textRepository.getCachedText(safePage);
            if (bridgeSource == null || bridgeSource.trim().length() == 0) {
                bridgeSource = textRepository.getFastStartText(safePage);
            }
        }
        FastResumeBridge bridge = findFastResumeBridge(safePage, bridgeSource);

        Intent intent = new Intent(MainActivity.this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_START);
        intent.putExtra("title", currentTitle);
        intent.putExtra("pageOffset", safePage);
        intent.putExtra("totalPages", pageCount);
        intent.putExtra("startIndex", 0);
        intent.putExtra("rate", speechRate);
        intent.putExtra("pitch", 1.0f);
        intent.putExtra(TtsForegroundService.EXTRA_TTS_LANGUAGE, currentPdfLanguage);
        intent.putExtra(TtsForegroundService.EXTRA_TTS_REGION, appRegion);
        if (text != null) {
            intent.putExtra(TtsForegroundService.EXTRA_PAGE_TEXT, text);
        }
        if (bridge != null) {
            intent.putExtra(TtsForegroundService.EXTRA_FAST_RESUME_AUDIO,
                    bridge.file.getAbsolutePath());
            intent.putExtra(TtsForegroundService.EXTRA_FAST_RESUME_TEXT, bridge.text);
        }

        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);

        // La precarga vecina empieza después de entregar la página actual al
        // servicio, y una nueva navegación cancela el trabajo anterior.
        applyPlaybackState(TtsForegroundService.STATE_PREPARING, safePage,
                "Iniciando pagina " + (safePage + 1), false);
        scheduleAudioNeighborPreload(safePage);
    }

    private void scheduleFastResumeAudioPreparation(final int page, String sourceText) {
        cancelScheduledFastResumePreparation();
        if (page < 0 || sourceText == null || sourceText.trim().length() < 12) return;
        final String source = sourceText;
        fastResumePrepareRunnable = new Runnable() {
            @Override public void run() {
                fastResumePrepareRunnable = null;
                if (page != currentPage || currentFile == null) return;
                if (playbackState == TtsForegroundService.STATE_PLAYING
                        || playbackState == TtsForegroundService.STATE_PREPARING
                        || audioPreparing) return;
                prepareFastResumeAudioForPage(page, source);
            }
        };
        // Deja primero libres el render, Play y la extraccion principal. El puente
        // solo se sintetiza cuando el usuario lleva un instante quieto en la pagina.
        audioStartHandler.postDelayed(fastResumePrepareRunnable, 900L);
    }

    private void cancelScheduledFastResumePreparation() {
        if (fastResumePrepareRunnable != null) {
            audioStartHandler.removeCallbacks(fastResumePrepareRunnable);
            fastResumePrepareRunnable = null;
        }
    }

    private void prepareFastResumeAudioForCurrentPage() {
        if (textRepository == null || currentFile == null || currentPage < 0) return;
        String text = textRepository.getCachedText(currentPage);
        if (text == null || text.trim().length() == 0) {
            text = textRepository.getFastStartText(currentPage);
        }
        prepareFastResumeAudioForPage(currentPage, text);
    }

    private void prepareFastResumeAudioForPage(final int page, String sourceText) {
        if (prefs == null || currentFile == null || currentBookmarkKey == null
                || currentPdfLanguage.length() == 0 || page < 0 || page != currentPage) return;
        if (playbackState == TtsForegroundService.STATE_PLAYING
                || playbackState == TtsForegroundService.STATE_PREPARING) return;

        final String bridgeText = buildFastResumeBridgeText(sourceText);
        if (bridgeText.length() < 12) return;
        final String documentKey = currentBookmarkKey;
        final float requestedRate = speechRate;
        final File finalFile = getFastResumeAudioFile();

        if (isFastResumeMetadataMatch(documentKey, page, bridgeText, requestedRate)
                && finalFile.exists() && finalFile.length() > 64L) {
            return;
        }

        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        if (!manager.isReady() || !currentPdfLanguage.equals(manager.getPreferredLanguage())
                || !manager.isPreferredLanguageAvailable()) {
            if (fastResumeWaitingForEngine) return;
            fastResumeWaitingForEngine = true;
            manager.ensureLanguage(currentPdfLanguage, appRegion, new TtsEngineManager.ReadyCallback() {
                @Override
                public void onReady(String enginePackage) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            fastResumeWaitingForEngine = false;
                            // El primer intento solo encendio/ajusto el motor.
                            // Ahora que ya esta listo se sintetiza de verdad el
                            // puente si el usuario sigue en la misma pagina.
                            if (currentFile != null && page == currentPage
                                    && playbackState != TtsForegroundService.STATE_PLAYING
                                    && playbackState != TtsForegroundService.STATE_PREPARING) {
                                prepareFastResumeAudioForPage(page, bridgeText);
                            }
                        }
                    });
                }

                @Override
                public void onError(String message) {
                    fastResumeWaitingForEngine = false;
                }
            });
            return;
        }

        final int token = ++fastResumeSynthesisToken;
        final File dir = finalFile.getParentFile();
        if (dir != null && !dir.exists()) dir.mkdirs();
        final File tempFile = new File(dir, "fast_resume_" + token + ".tmp.wav");
        if (tempFile.exists()) tempFile.delete();

        manager.setSpeechRate(requestedRate);
        manager.setPitch(1.0f);
        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
        final String utteranceId = "FAST_RESUME_" + token + "_P" + page;
        int result = manager.synthesizeToFile(bridgeText, params, tempFile, utteranceId,
                new TtsEngineManager.FileSynthesisCallback() {
                    @Override
                    public void onCompleted() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (token != fastResumeSynthesisToken
                                        || currentBookmarkKey == null
                                        || !currentBookmarkKey.equals(documentKey)
                                        || page != currentPage) {
                                    tempFile.delete();
                                    return;
                                }
                                if (!tempFile.exists() || tempFile.length() <= 64L) {
                                    tempFile.delete();
                                    return;
                                }
                                if (finalFile.exists()) finalFile.delete();
                                boolean saved = tempFile.renameTo(finalFile);
                                if (!saved) {
                                    saved = copyFastResumeFile(tempFile, finalFile);
                                    tempFile.delete();
                                }
                                if (!saved || !finalFile.exists() || finalFile.length() <= 64L) return;
                                prefs.edit()
                                        .putString(PREF_FAST_RESUME_DOC, documentKey)
                                        .putInt(PREF_FAST_RESUME_PAGE, page)
                                        .putString(PREF_FAST_RESUME_TEXT, bridgeText)
                                        .putFloat(PREF_FAST_RESUME_RATE, requestedRate)
                                        .putString(PREF_FAST_RESUME_ENGINE,
                                                manager.getActiveEnginePackage())
                                        .putString(PREF_FAST_RESUME_LANGUAGE, currentPdfLanguage)
                                        .apply();
                            }
                        });
                    }

                    @Override
                    public void onError(String message) {
                        tempFile.delete();
                    }
                });
        if (result == TextToSpeech.ERROR) tempFile.delete();
    }

    private FastResumeBridge findFastResumeBridge(int page, String availableText) {
        if (prefs == null || currentBookmarkKey == null || page < 0) return null;
        File file = getFastResumeAudioFile();
        if (!file.exists() || file.length() <= 64L) return null;
        String document = prefs.getString(PREF_FAST_RESUME_DOC, "");
        int storedPage = prefs.getInt(PREF_FAST_RESUME_PAGE, -1);
        String bridgeText = prefs.getString(PREF_FAST_RESUME_TEXT, "");
        float storedRate = prefs.getFloat(PREF_FAST_RESUME_RATE, -1f);
        String storedEngine = prefs.getString(PREF_FAST_RESUME_ENGINE, "");
        String storedLanguage = PdfLanguageDetector.normalizeCode(
                prefs.getString(PREF_FAST_RESUME_LANGUAGE, ""));
        if (!currentBookmarkKey.equals(document) || storedPage != page
                || bridgeText == null || bridgeText.trim().length() == 0
                || Math.abs(storedRate - speechRate) > 0.01f
                || (currentPdfLanguage.length() > 0 && !currentPdfLanguage.equals(storedLanguage))) return null;
        TtsEngineManager manager = TtsEngineManager.getInstance(this);
        String activeEngine = manager.getActiveEnginePackage();
        if (manager.isReady() && storedEngine != null && storedEngine.length() > 0
                && activeEngine != null && activeEngine.length() > 0
                && !storedEngine.equals(activeEngine)) return null;

        String available = normalizeFastResumeText(availableText);
        String bridge = normalizeFastResumeText(bridgeText);
        if (available.length() > 0) {
            boolean samePrefix = available.startsWith(bridge) || bridge.startsWith(available);
            if (!samePrefix) return null;
        }
        return new FastResumeBridge(file, bridgeText);
    }

    private File getFastResumeAudioFile() {
        File dir = new File(getFilesDir(), "fast_resume_audio");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, FAST_RESUME_FILE_NAME);
    }

    private boolean isFastResumeMetadataMatch(String documentKey, int page,
                                               String bridgeText, float rate) {
        if (prefs == null) return false;
        return documentKey.equals(prefs.getString(PREF_FAST_RESUME_DOC, ""))
                && page == prefs.getInt(PREF_FAST_RESUME_PAGE, -1)
                && bridgeText.equals(prefs.getString(PREF_FAST_RESUME_TEXT, ""))
                && Math.abs(rate - prefs.getFloat(PREF_FAST_RESUME_RATE, -1f)) <= 0.01f
                && (currentPdfLanguage.length() == 0 || currentPdfLanguage.equals(
                PdfLanguageDetector.normalizeCode(prefs.getString(PREF_FAST_RESUME_LANGUAGE, ""))));
    }

    private String buildFastResumeBridgeText(String sourceText) {
        String text = normalizeFastResumeText(sourceText);
        if (text.length() <= FAST_RESUME_TARGET_CHARS) return text;
        int maximum = Math.min(FAST_RESUME_TARGET_CHARS, text.length());
        int minimum = Math.min(FAST_RESUME_MIN_CHARS, maximum);
        for (int i = minimum; i < maximum; i++) {
            char c = text.charAt(i);
            if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':') {
                return text.substring(0, i + 1).trim();
            }
        }
        for (int i = maximum - 1; i >= minimum; i--) {
            if (Character.isWhitespace(text.charAt(i))) {
                return text.substring(0, i).trim();
            }
        }
        return text.substring(0, maximum).trim();
    }

    private String normalizeFastResumeText(String value) {
        if (value == null) return "";
        String text = value.replace('\u00A0', ' ').replace('\r', ' ').replace('\n', ' ');
        text = text.replaceAll("\\s+", " ");
        return text.trim();
    }

    private boolean copyFastResumeFile(File source, File target) {
        FileInputStream input = null;
        FileOutputStream output = null;
        try {
            input = new FileInputStream(source);
            output = new FileOutputStream(target);
            byte[] buffer = new byte[16384];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            output.flush();
            return true;
        } catch (Exception ignored) {
            if (target.exists()) target.delete();
            return false;
        } finally {
            if (input != null) {
                try { input.close(); } catch (Exception ignored) {}
            }
            if (output != null) {
                try { output.close(); } catch (Exception ignored) {}
            }
        }
    }

    private void cancelAudioPreparationTimeout() {
        if (audioStartTimeout != null) {
            audioStartHandler.removeCallbacks(audioStartTimeout);
            audioStartTimeout = null;
        }
    }

    private void stopAudioOnly() {
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = -1;
        requestedAudioPageConfirmed = false;
        applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1, "Detenido", false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
    }

    private void showGoto() {
        if (pageCount <= 0) return;

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setHint(t("Página 1 - " + pageCount));

        new AlertDialog.Builder(this)
                .setTitle(t("Ir a página"))
                .setView(input)
                .setPositiveButton(t("Ir"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            int p = Integer.parseInt(input.getText().toString()) - 1;
                            p = Math.max(0, Math.min(p, pageCount - 1));
                            requestManualPageChange(p);
                        } catch (Exception ignored) {
                        }
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .show();
    }

    private String buildBookmarkKey(File file) {
        if (file == null) return null;
        long hash = 1469598103934665603L;
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(file, "r");
            long length = raf.length();
            byte[] buffer = new byte[4096];
            int read = raf.read(buffer);
            for (int i = 0; i < read; i++) {
                hash ^= (buffer[i] & 0xFF);
                hash *= 1099511628211L;
            }
            if (length > buffer.length) {
                raf.seek(Math.max(0L, length - buffer.length));
                read = raf.read(buffer);
                for (int i = 0; i < read; i++) {
                    hash ^= (buffer[i] & 0xFF);
                    hash *= 1099511628211L;
                }
            }
            String identity = length + "|" + Long.toHexString(hash);
            return "pdf_bookmarks_v1_" + Integer.toHexString(identity.hashCode()) + "_" + Long.toHexString(hash);
        } catch (Exception e) {
            return "pdf_bookmarks_v1_" + Integer.toHexString((file.getName() + "|" + file.length()).hashCode());
        } finally {
            if (raf != null) {
                try {
                    raf.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private ArrayList<Integer> getBookmarkPages() {
        ArrayList<Integer> pages = new ArrayList<Integer>();
        if (prefs == null || currentBookmarkKey == null) return pages;
        java.util.Set<String> stored = prefs.getStringSet(currentBookmarkKey, null);
        if (stored == null || stored.isEmpty()) return pages;
        for (String value : stored) {
            try {
                int page = Integer.parseInt(value);
                if (page >= 0 && (pageCount <= 0 || page < pageCount)) pages.add(page);
            } catch (Exception ignored) {
            }
        }
        Collections.sort(pages);
        return pages;
    }

    private boolean isBookmarked(int page) {
        if (prefs == null || currentBookmarkKey == null || page < 0) return false;
        java.util.Set<String> stored = prefs.getStringSet(currentBookmarkKey, null);
        return stored != null && stored.contains(String.valueOf(page));
    }

    private void setBookmarked(int page, boolean bookmarked) {
        if (prefs == null || currentBookmarkKey == null || page < 0) return;
        java.util.Set<String> stored = prefs.getStringSet(currentBookmarkKey, null);
        HashSet<String> updated = stored == null
                ? new HashSet<String>()
                : new HashSet<String>(stored);
        String value = String.valueOf(page);
        if (bookmarked) updated.add(value);
        else updated.remove(value);
        prefs.edit().putStringSet(currentBookmarkKey, updated).apply();
        updateBookmarkButton();
    }

    private void updateBookmarkButton() {
        if (bookmarkButton == null) return;
        boolean ready = currentFile != null && pageCount > 0;
        bookmarkButton.setEnabled(ready);
        bookmarkButton.setAlpha(ready ? 1.0f : 0.45f);
        boolean marked = ready && isBookmarked(currentPage);
        bookmarkButton.setText(marked ? "★" : "☆");
        // Estrella llena y amarilla cuando la pagina esta guardada, para que se
        // vea de un vistazo al volver a pasar por ella.
        bookmarkButton.setTextColor(marked
                ? Color.rgb(250, 204, 21)
                : (darkTheme ? Color.WHITE : Color.rgb(15, 23, 42)));
        bookmarkButton.setContentDescription(marked
                ? t("Quitar pagina guardada")
                : t("Guardar pagina"));
    }

    /** Guarda o quita la pagina actual de la lista de marcadores. */
    private void toggleCurrentPageBookmark() {
        if (currentFile == null || pageCount <= 0 || currentBookmarkKey == null) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }
        boolean marked = isBookmarked(currentPage);
        setBookmarked(currentPage, !marked);
        Toast.makeText(this, t(marked ? "Marcador quitado" : "Página guardada"),
                Toast.LENGTH_SHORT).show();
    }

    /**
     * Pantalla de paginas guardadas (Ajustes > Paginas guardadas). Solo lista
     * los numeros de pagina marcados con la estrella; al tocar uno se va
     * directo a esa pagina. Reemplaza al antiguo cuadro emergente que salia al
     * tocar la estrella.
     */
    private void showBookmarksScreen() {
        settingsMode = true;
        settingsSubscreen = 7;

        LinearLayout screen = makeSettingsSubscreenBase(t("Páginas guardadas"),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        buildSettingsScreen();
                    }
                });

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(uiDp(16), uiDp(12), uiDp(16), uiDp(20));

        ArrayList<Integer> pages = getBookmarkPages();
        if (pages.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(t("Todavía no hay páginas guardadas.\nUsa la estrella ☆ mientras lees."));
            empty.setTextSize(uiSp(15));
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(uiDp(20), uiDp(70), uiDp(20), uiDp(40));
            empty.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
            content.addView(empty, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        } else {
            for (final int page : pages) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(uiDp(14), uiDp(12), uiDp(10), uiDp(12));

                GradientDrawable rowBg = new GradientDrawable();
                rowBg.setCornerRadius(uiDp(14));
                rowBg.setColor(darkTheme ? Color.rgb(8, 34, 55) : Color.WHITE);
                rowBg.setStroke(uiDp(1),
                        darkTheme ? Color.rgb(30, 76, 109) : Color.rgb(203, 213, 225));
                row.setBackground(rowBg);

                TextView star = new TextView(this);
                star.setText("★");
                star.setTextSize(uiSp(20));
                star.setTextColor(Color.rgb(250, 204, 21));
                star.setGravity(Gravity.CENTER);

                TextView label = new TextView(this);
                label.setText(t("Página") + " " + (page + 1));
                label.setTextSize(uiSp(16));
                label.setTypeface(Typeface.DEFAULT_BOLD);
                label.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
                label.setPadding(uiDp(12), 0, uiDp(8), 0);

                Button remove = new Button(this);
                remove.setText("✕");
                remove.setTextSize(uiSp(16));
                remove.setAllCaps(false);
                remove.setMinWidth(0);
                remove.setMinHeight(0);
                remove.setBackgroundColor(Color.TRANSPARENT);
                remove.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
                remove.setContentDescription(t("Quitar página") + " " + (page + 1));
                remove.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        setBookmarked(page, false);
                        showBookmarksScreen();
                    }
                });

                row.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        closeSettings();
                        requestManualPageChange(page);
                    }
                });

                row.addView(star, new LinearLayout.LayoutParams(uiDp(30), uiDp(34)));
                row.addView(label, new LinearLayout.LayoutParams(0,
                        LinearLayout.LayoutParams.WRAP_CONTENT, 1));
                row.addView(remove, new LinearLayout.LayoutParams(uiDp(44), uiDp(40)));

                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                rowLp.topMargin = uiDp(8);
                content.addView(row, rowLp);
            }
        }

        scroll.addView(content, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        screen.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        // Igual que las demas subpantallas de Ajustes: se monta encima en vez de
        // reemplazar la ventana entera (eso rompia la cadena de capas y dejaba un
        // parpadeo al volver).
        presentSettingsSubscreen(screen);
    }

    private void updatePageLabel() {
        if (pageCount <= 0) pageView.setText(t("0/0"));
        else pageView.setText((currentPage + 1) + "/" + pageCount);
        updateBookmarkButton();
    }

    private void applyPlaybackState(int state, int readingPage, String message, boolean fromBroadcast) {
        if ((state == TtsForegroundService.STATE_PREPARING
                || state == TtsForegroundService.STATE_PLAYING)
                && requestedAudioPage >= 0 && readingPage >= 0
                && readingPage != requestedAudioPage
                && !requestedAudioPageConfirmed) {
            // Ignora estados antiguos mientras el servicio confirma la última
            // página elegida por el usuario.
            return;
        }

        playbackState = state;
        if (message == null) message = "";

        if (state == TtsForegroundService.STATE_PREPARING) {
            audioPreparing = true;
            audioStarted = false;
            audioPaused = false;
            startPlayPreparingDots();
        } else if (state == TtsForegroundService.STATE_PLAYING) {
            cancelAudioPreparationTimeout();
            stopPlayPreparingDots();
            audioPreparing = false;
            audioStarted = true;
            audioPaused = false;
            if (playButton != null) playButton.setText(t("Ⅱ"));
        } else if (state == TtsForegroundService.STATE_PAUSED) {
            cancelAudioPreparationTimeout();
            stopPlayPreparingDots();
            audioPreparing = false;
            audioStarted = true;
            audioPaused = true;
            if (playButton != null) playButton.setText(t("▶"));
        } else {
            cancelAudioPreparationTimeout();
            stopPlayPreparingDots();
            audioPreparing = false;
            audioStarted = false;
            audioPaused = false;
            requestedAudioPage = -1;
            requestedAudioPageConfirmed = false;
            if (playButton != null) playButton.setText(t("▶"));
        }

        if (state == TtsForegroundService.STATE_ERROR && fromBroadcast) {
            audioRequestToken++;
            requestedAudioPage = -1;
            requestedAudioPageConfirmed = false;
        }
        if (state == TtsForegroundService.STATE_PLAYING || state == TtsForegroundService.STATE_PREPARING || state == TtsForegroundService.STATE_PAUSED) {
            if (readingMarkerEnabled) loadSelectionForPage(Math.max(0, readingPage));
        } else if (pdfView != null) {
            pdfView.clearReadingMarker();
        }

        if (state == TtsForegroundService.STATE_ERROR && fromBroadcast
                && message.length() > 0 && !message.equals(lastPlaybackError)) {
            lastPlaybackError = message;
            if (message.startsWith(TtsForegroundService.ERROR_MISSING_VOICE_PREFIX)) {
                String language = message.substring(
                        TtsForegroundService.ERROR_MISSING_VOICE_PREFIX.length());
                showMissingVoiceDialog(language);
            } else if (TtsEngineManager.ERROR_ENGINE_SLOW.equals(message)) {
                // El motor solo tardo en encender. El servicio ya reintento por
                // su cuenta; no hay nada que avisarle al usuario.
            } else {
                Toast.makeText(this, t(message), Toast.LENGTH_LONG).show();
            }
        } else if (state != TtsForegroundService.STATE_ERROR) {
            lastPlaybackError = "";
        }

        if ((state == TtsForegroundService.STATE_PREPARING
                || state == TtsForegroundService.STATE_PLAYING)
                && requestedAudioPage >= 0 && readingPage >= 0) {
            if (readingPage != requestedAudioPage) {
                if (!requestedAudioPageConfirmed) {
                    return;
                }
                // La página solicitada ya fue confirmada por el servicio. Un
                // cambio posterior puede ser el salto silencioso de una ilustración.
                requestedAudioPage = -1;
                requestedAudioPageConfirmed = false;
            } else if (fromBroadcast) {
                requestedAudioPageConfirmed = true;
                if (state == TtsForegroundService.STATE_PLAYING) {
                    requestedAudioPage = -1;
                    requestedAudioPageConfirmed = false;
                }
            }
        }

        boolean readerOwnsPage = state == TtsForegroundService.STATE_PREPARING
                || state == TtsForegroundService.STATE_PLAYING;
        // Refuerzo explicito: en pausa, la vista nunca se debe mover.
        if (state == TtsForegroundService.STATE_PAUSED) return;
        if (!readerOwnsPage || readingPage < 0 || currentFile == null || pageCount <= 0 || pdfView == null) {
            return;
        }

        final int safePage = Math.max(0, Math.min(readingPage, pageCount - 1));
        if (safePage == currentPage) return;

        restartAudioAfterRender = false;
        // El lector ya cambió de página: prepara únicamente la visible con
        // prioridad y una ventana pequeña. Evita indexar ocho páginas mientras
        // intenta empezar la siguiente frase.
        primeAudioPageForPlayback(safePage);
        currentPage = safePage;
        updatePageLabel();
        pdfView.showPage(safePage);
    }

    private void syncVisiblePageWithReader() {
        syncVisiblePageWithReader(false);
    }

    /**
     * @param returningToApp true solo cuando la Activity vuelve a primer plano.
     *        En ese caso la pagina del servicio manda sobre cualquier peticion
     *        local pendiente. El sondeo periodico NO debe hacerlo, o pisaria la
     *        pagina que el usuario acaba de elegir.
     */
    private void syncVisiblePageWithReader(boolean returningToApp) {
        if (prefs == null) return;

        int state = prefs.getInt(PREF_TTS_STATE, -1);
        if (state < 0) {
            boolean active = prefs.getBoolean(PREF_TTS_ACTIVE, false);
            boolean paused = prefs.getBoolean(PREF_TTS_PAUSED, false);
            state = !active ? TtsForegroundService.STATE_STOPPED
                    : (paused ? TtsForegroundService.STATE_PAUSED : TtsForegroundService.STATE_PLAYING);
        }
        int readingPage = prefs.getInt(PREF_TTS_CURRENT_PAGE, -1);
        String message = prefs.getString(PREF_TTS_MESSAGE, "");

        // Al volver a la app (por ejemplo tras dejarla sonando con la pantalla
        // apagada), la verdad la tiene el servicio: descartamos cualquier
        // solicitud propia pendiente para no ignorar su pagina real.
        boolean serviceActive = state == TtsForegroundService.STATE_PLAYING
                || state == TtsForegroundService.STATE_PREPARING
                || state == TtsForegroundService.STATE_PAUSED;
        if (serviceActive && !TtsForegroundService.hasLivePlaybackSession()) {
            clearStalePlaybackState();
            state = TtsForegroundService.STATE_STOPPED;
            readingPage = -1;
            message = "";
            serviceActive = false;
        }
        if (returningToApp && serviceActive && readingPage >= 0
                && readingPage != requestedAudioPage) {
            requestedAudioPage = -1;
            requestedAudioPageConfirmed = false;
        }

        applyPlaybackState(state, readingPage, message, false);

        // applyPlaybackState solo mueve la pagina visible mientras el lector
        // esta activo (PREPARING/PLAYING). Si volvimos y quedo en PAUSA, la
        // pantalla debe mostrar igual la pagina donde se detuvo la lectura.
        // ...salvo que el usuario haya pasado paginas a mano despues de pausar.
        // En ese caso mandar la vista de vuelta a la pagina pausada cada vez que
        // se volvia a la app (por ejemplo tras sacar una captura) era un salto
        // inesperado que hacia perder la pagina que se estaba mirando.
        if (returningToApp && state == TtsForegroundService.STATE_PAUSED && readingPage >= 0
                && !userBrowsedAwayWhilePaused
                && currentFile != null && pageCount > 0 && pdfView != null) {
            int safePage = Math.max(0, Math.min(readingPage, pageCount - 1));
            if (safePage != currentPage) {
                restartAudioAfterRender = false;
                primeAudioPageForPlayback(safePage);
                currentPage = safePage;
                updatePageLabel();
                pdfView.showPage(safePage);
            }
        }
    }

    private void saveProgress() {
        if (prefs == null) return;
        SharedPreferences.Editor editor = prefs.edit()
                .putInt("last_page", currentPage)
                .putString("last_title", currentTitle == null ? "PDF" : currentTitle);
        if (currentSourceKey != null && currentSourceKey.length() > 0) {
            editor.putInt(PREF_SOURCE_PAGE_PREFIX + currentSourceKey, Math.max(0, currentPage))
                    .putString(PREF_LAST_SOURCE_KEY, currentSourceKey);
        }
        if (currentFile != null && currentFile.exists()) {
            editor.putString(PREF_LAST_FILE_PATH, currentFile.getAbsolutePath());
        }
        editor.apply();
    }

    /**
     * Scales programmatic UI geometry for common phone sizes without changing
     * PDF rendering, TTS, playback or stored coordinates. Android dp still
     * handles density; this extra factor only compensates for very small/large
     * phone viewports.
     */
    private float responsiveUiScale() {
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        float density = Math.max(0.1f, metrics.density);
        float widthDp = metrics.widthPixels / density;
        float heightDp = metrics.heightPixels / density;
        // Se mide por el lado corto y el lado largo de la pantalla, no por el
        // ancho y alto del momento. Asi la interfaz conserva el mismo tamano al
        // girar el telefono (antes, acostado, el "alto" pasaba a ser chico y
        // toda la geometria cambiaba respecto a como se habia armado) y se
        // adapta igual de bien en pantallas chicas, grandes y tablets.
        float shortDp = Math.min(widthDp, heightDp);
        float longDp = Math.max(widthDp, heightDp);
        float shortScale = shortDp / 360f;
        float longScale = longDp / 740f;
        float scale = Math.min(shortScale, longScale);
        return Math.max(0.85f, Math.min(1.15f, scale));
    }

    private int uiDp(int value) {
        return Math.max(1, Math.round(dp(value) * responsiveUiScale()));
    }

    private float uiSp(float value) {
        float geometryScale = responsiveUiScale();
        float textScale = 1f + ((geometryScale - 1f) * 0.40f);
        textScale = Math.max(0.95f, Math.min(1.04f, textScale));
        return value * textScale;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Antes el manifiesto no declaraba nada, asi que Android destruia y
        // rehacia la pantalla entera en cada giro: se cerraba el PDF, se volvia
        // a abrir, y por eso el parpadeo y el tiron. Ahora la pantalla sobrevive
        // al giro y aqui solo se reacomodan las alturas.
        applyOrientationLayout();
    }

    private boolean isLandscape() {
        return getResources().getConfiguration().orientation
                == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
    }

    /**
     * En horizontal la pantalla tiene poca altura y las barras fijas se comen
     * casi todo el visor. Se encogen y el banner se esconde, de modo que la
     * pagina recupera el espacio.
     */
    private void applyOrientationLayout() {
        boolean landscape = isLandscape();
        setViewHeight(readerTopBar, uiDp(landscape ? 46 : 62));
        setViewHeight(readerControls, uiDp(landscape ? 44 : 54));
        setViewHeight(readerMarkControls, uiDp(landscape ? 38 : 46));
        applyBannerVisibility();
        if (pdfView != null) pdfView.requestLayout();
    }

    private void setViewHeight(View view, int heightPx) {
        if (view == null) return;
        ViewGroup.LayoutParams params = view.getLayoutParams();
        if (params == null || params.height == heightPx) return;
        params.height = heightPx;
        view.setLayoutParams(params);
    }

    @Override
    public void onBackPressed() {
        if (onboardingMode) {
            if (onboardingStep == 2) {
                showOnboardingWelcome();
            } else {
                super.onBackPressed();
            }
            return;
        }
        if (imageViewerMode) {
            closeFullscreenImageViewer();
            return;
        }
        if (libraryMode) {
            closeFileLibrary();
            return;
        }
        if (settingsMode) {
            if (settingsSubscreen == 2 || settingsSubscreen == 3) {
                showLanguageRegionSettingsScreen();
            } else if (settingsSubscreen == 8) {
                showVoicesScreen();
            } else if (settingsSubscreen == 1 || settingsSubscreen == 4
                    || settingsSubscreen == 7) {
                buildSettingsScreen();
            } else {
                closeSettings();
            }
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        cancelAdvancedAccessExpiryRefresh();
        destroyBannerAd();
        pdfOpenRequestToken++;
        pageWorkToken++;
        if (pageWorkRunnable != null) pageWorkHandler.removeCallbacks(pageWorkRunnable);
        if (audioNeighborPreloadRunnable != null) {
            audioStartHandler.removeCallbacks(audioNeighborPreloadRunnable);
            audioNeighborPreloadRunnable = null;
        }
        if (audioIdleIndexRunnable != null) {
            audioStartHandler.removeCallbacks(audioIdleIndexRunnable);
            audioIdleIndexRunnable = null;
        }
        imageExportExecutor.shutdownNow();
        audioExportSessionToken++;
        clearActiveExportState(true);
        audioExportExecutor.shutdownNow();
        imageDecodeExecutor.shutdownNow();
        libraryLoadToken++;
        libraryScanExecutor.shutdownNow();
        audioMetadataExecutor.shutdownNow();
        languageDetectionToken++;
        languageDetectionExecutor.shutdownNow();
        if (imagePager != null) {
            imagePager.setAdapter(null);
            imagePager = null;
        }
        if (imagePagerAdapter != null) {
            imagePagerAdapter.release();
            imagePagerAdapter = null;
        }
        if (imageViewerBitmap != null && !imageViewerBitmap.isRecycled()) {
            imageViewerBitmap.recycle();
            imageViewerBitmap = null;
        }
        cancelAudioPreparationTimeout();
        stopPlayPreparingDots();
        cancelTtsWarmup();
        if (pdfView != null) pdfView.release();
        stopFilePreview();
        stopPageSyncLoop();
        cancelPendingReadingMarker();
        unregisterPlaybackReceiver();
        unregisterExportCancelReceiver();
        super.onDestroy();
        saveProgress();
        // Si el audio sigue activo, el servicio conserva SOLO el repositorio
        // actualmente usado. El otro puede cerrarse sin afectar la reproduccion.
        boolean ttsStillActive = prefs.getBoolean(PREF_TTS_ACTIVE, false);
        if (!ttsStillActive) {
            if (normalTextRepository != null) normalTextRepository.close();
            if (ocrTextRepository != null) ocrTextRepository.shutdownOcr();
        } else if (currentOcrMode) {
            if (normalTextRepository != null) normalTextRepository.close();
        } else {
            if (ocrTextRepository != null) ocrTextRepository.shutdownOcr();
        }
        pendingAdvancedAction = null;
        if (selectionRepository != null) selectionRepository.close();
        if (exportTts != null) {
            try { exportTts.shutdown(); } catch (Exception ignored) {}
            exportTts = null;
        }
        exportTtsReady = false;
    }

    /** Emblema del selector de tipo de PDF: documento + Aa + insignia OCR. */
    private static final class PdfModeEmblemView extends View {
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dots = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint doc = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        PdfModeEmblemView(Context context) {
            super(context);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeCap(Paint.Cap.ROUND);
            ring.setColor(Color.rgb(96, 165, 250));
            dots.setStyle(Paint.Style.FILL);
            dots.setColor(Color.argb(170, 45, 212, 191));
            doc.setStyle(Paint.Style.STROKE);
            doc.setStrokeJoin(Paint.Join.ROUND);
            doc.setStrokeCap(Paint.Cap.ROUND);
            doc.setColor(Color.rgb(96, 165, 250));
            text.setTypeface(Typeface.DEFAULT_BOLD);
            text.setTextAlign(Paint.Align.CENTER);
            badge.setStyle(Paint.Style.FILL);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            float u = Math.min(w, h), cx = w * 0.5f, cy = h * 0.5f;
            float r = u * 0.34f;
            ring.setStrokeWidth(u * 0.012f);
            canvas.drawCircle(cx, cy, r, ring);
            for (int i = 0; i < 30; i++) {
                double a = Math.PI * 2.0 * i / 30.0;
                canvas.drawCircle(cx + (float)Math.cos(a) * r * 1.18f,
                        cy + (float)Math.sin(a) * r * 1.18f, u * 0.0065f, dots);
            }

            float pw = u * 0.34f, ph = u * 0.46f;
            float left = cx - pw * 0.5f, top = cy - ph * 0.5f;
            float fold = pw * 0.27f;
            doc.setStrokeWidth(u * 0.016f);
            path.reset();
            path.moveTo(left, top);
            path.lineTo(left + pw - fold, top);
            path.lineTo(left + pw, top + fold);
            path.lineTo(left + pw, top + ph);
            path.lineTo(left, top + ph);
            path.close();
            canvas.drawPath(path, doc);
            path.reset();
            path.moveTo(left + pw - fold, top);
            path.lineTo(left + pw - fold, top + fold);
            path.lineTo(left + pw, top + fold);
            canvas.drawPath(path, doc);

            text.setColor(Color.rgb(180, 210, 255));
            text.setTextSize(u * 0.13f);
            canvas.drawText("Aa", cx, cy + u * 0.055f, text);

            float br = u * 0.105f;
            float bx = cx + r * 0.82f, by = cy + r * 0.78f;
            badge.setColor(Color.rgb(13, 74, 76));
            canvas.drawCircle(bx, by, br, badge);
            text.setColor(Color.rgb(45, 212, 191));
            text.setTextSize(u * 0.075f);
            canvas.drawText("OCR", bx, by + u * 0.026f, text);
        }
    }

    /**
     * Emblema central de la pantalla "Crear audio": un anillo con puntos, un
     * circulo interior con barras de onda de sonido, unas estrellitas alrededor
     * y una insignia de auriculares abajo a la derecha. Dibujado con Canvas para
     * clonar el diseno sin depender de imagenes externas.
     */
    private static final class AudioEmblemView extends View {
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerRingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint starPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badgeGlyphPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path glyphPath = new Path();

        private final int accent = Color.rgb(45, 212, 191);

        // Alturas relativas de las barras de onda (0..1), patron fijo.
        private final float[] bars = {
                0.30f, 0.55f, 0.42f, 0.78f, 0.50f, 0.92f, 0.62f, 1.00f,
                0.58f, 0.85f, 0.46f, 0.70f, 0.38f, 0.52f, 0.28f
        };

        AudioEmblemView(android.content.Context context) {
            super(context);
            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setColor(Color.argb(150, 45, 212, 191));
            dotPaint.setColor(Color.argb(180, 120, 190, 200));
            innerRingPaint.setStyle(Paint.Style.STROKE);
            innerRingPaint.setColor(accent);
            barPaint.setStrokeCap(Paint.Cap.ROUND);
            barPaint.setColor(accent);
            starPaint.setColor(Color.argb(160, 130, 180, 195));
            badgePaint.setColor(Color.rgb(15, 60, 74));
            badgeGlyphPaint.setStyle(Paint.Style.STROKE);
            badgeGlyphPaint.setStrokeCap(Paint.Cap.ROUND);
            badgeGlyphPaint.setColor(accent);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            if (w <= 0 || h <= 0) return;

            float cx = w * 0.5f;
            float cy = h * 0.5f;
            float unit = Math.min(w, h);
            float outerR = unit * 0.34f;
            float innerR = unit * 0.24f;

            // Resplandor suave detras del circulo interior.
            glowPaint.setShader(new RadialGradient(cx, cy, innerR * 1.9f,
                    new int[]{Color.argb(70, 45, 212, 191), Color.argb(0, 45, 212, 191)},
                    null, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, innerR * 1.9f, glowPaint);

            // Anillo exterior de puntos.
            ringPaint.setStrokeWidth(unit * 0.006f);
            canvas.drawCircle(cx, cy, outerR, ringPaint);
            int dots = 48;
            float dotR = unit * 0.007f;
            for (int i = 0; i < dots; i++) {
                double a = (Math.PI * 2 * i) / dots;
                float dx = cx + (float) Math.cos(a) * outerR;
                float dy = cy + (float) Math.sin(a) * outerR;
                canvas.drawCircle(dx, dy, dotR, dotPaint);
            }

            // Circulo interior brillante.
            innerRingPaint.setStrokeWidth(unit * 0.012f);
            canvas.drawCircle(cx, cy, innerR, innerRingPaint);

            // Barras de onda de sonido dentro del circulo interior.
            int n = bars.length;
            float span = innerR * 1.5f;
            float step = span / n;
            float barW = step * 0.45f;
            barPaint.setStrokeWidth(barW);
            float startX = cx - span * 0.5f + step * 0.5f;
            float maxBar = innerR * 1.15f;
            for (int i = 0; i < n; i++) {
                float bx = startX + step * i;
                float bh = maxBar * bars[i];
                canvas.drawLine(bx, cy - bh * 0.5f, bx, cy + bh * 0.5f, barPaint);
            }

            // Estrellitas de cuatro puntas alrededor.
            drawStar(canvas, cx - outerR * 1.15f, cy - outerR * 0.55f, unit * 0.018f);
            drawStar(canvas, cx + outerR * 1.10f, cy - outerR * 0.9f, unit * 0.013f);
            drawStar(canvas, cx + outerR * 1.2f, cy + outerR * 0.35f, unit * 0.016f);
            drawStar(canvas, cx - outerR * 0.95f, cy + outerR * 0.85f, unit * 0.012f);
            canvas.drawCircle(cx + outerR * 0.85f, cy - outerR * 1.0f, unit * 0.006f, starPaint);
            canvas.drawCircle(cx - outerR * 1.25f, cy + outerR * 0.15f, unit * 0.006f, starPaint);

            // Insignia de auriculares abajo a la derecha.
            float badgeCx = cx + outerR * 0.82f;
            float badgeCy = cy + outerR * 0.82f;
            float badgeR = unit * 0.085f;
            badgePaint.setShader(new RadialGradient(badgeCx, badgeCy, badgeR,
                    new int[]{Color.rgb(20, 78, 92), Color.rgb(12, 46, 58)},
                    null, Shader.TileMode.CLAMP));
            canvas.drawCircle(badgeCx, badgeCy, badgeR, badgePaint);
            drawHeadphones(canvas, badgeCx, badgeCy, badgeR * 0.62f);
        }

        private void drawStar(Canvas canvas, float cx, float cy, float r) {
            glyphPath.reset();
            float inner = r * 0.32f;
            for (int i = 0; i < 4; i++) {
                double a = Math.PI / 2 * i;
                float px = cx + (float) Math.cos(a) * r;
                float py = cy + (float) Math.sin(a) * r;
                double a2 = a + Math.PI / 4;
                float ix = cx + (float) Math.cos(a2) * inner;
                float iy = cy + (float) Math.sin(a2) * inner;
                if (i == 0) glyphPath.moveTo(px, py);
                else glyphPath.lineTo(px, py);
                glyphPath.lineTo(ix, iy);
            }
            glyphPath.close();
            canvas.drawPath(glyphPath, starPaint);
        }

        private void drawHeadphones(Canvas canvas, float cx, float cy, float r) {
            badgeGlyphPaint.setStrokeWidth(r * 0.28f);
            // Banda superior (arco).
            RectF band = new RectF(cx - r, cy - r, cx + r, cy + r);
            badgeGlyphPaint.setStyle(Paint.Style.STROKE);
            canvas.drawArc(band, 180, 180, false, badgeGlyphPaint);
            // Almohadillas (dos rectangulos redondeados a los lados).
            badgeGlyphPaint.setStyle(Paint.Style.FILL);
            float earW = r * 0.42f;
            float earH = r * 0.85f;
            float earY = cy;
            RectF left = new RectF(cx - r - earW * 0.3f, earY, cx - r + earW * 0.7f, earY + earH);
            RectF right = new RectF(cx + r - earW * 0.7f, earY, cx + r + earW * 0.3f, earY + earH);
            canvas.drawRoundRect(left, earW * 0.4f, earW * 0.4f, badgeGlyphPaint);
            canvas.drawRoundRect(right, earW * 0.4f, earW * 0.4f, badgeGlyphPaint);
        }
    }

    /**
     * Icono de cada tarjeta de "Crear audio", dibujado con lineas (Canvas) en el
     * color de acento correspondiente: documento (pagina actual), libro abierto
     * (todo el PDF) o marco punteado (elegir rango).
     */
    private static final class AudioCardIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final String key;

        AudioCardIconView(android.content.Context context, String key, int color) {
            super(context);
            this.key = key;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setColor(color);
            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(color);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            if (w <= 0 || h <= 0) return;
            float u = Math.min(w, h);
            float sw = u * 0.09f;
            paint.setStrokeWidth(sw);
            float cx = w * 0.5f;
            float cy = h * 0.5f;

            if ("icon:doc".equals(key)) {
                float pw = u * 0.52f;
                float ph = u * 0.68f;
                float left = cx - pw * 0.5f;
                float top = cy - ph * 0.5f;
                float fold = pw * 0.34f;
                path.reset();
                path.moveTo(left, top);
                path.lineTo(left + pw - fold, top);
                path.lineTo(left + pw, top + fold);
                path.lineTo(left + pw, top + ph);
                path.lineTo(left, top + ph);
                path.close();
                canvas.drawPath(path, paint);
                // Doblez de la esquina.
                path.reset();
                path.moveTo(left + pw - fold, top);
                path.lineTo(left + pw - fold, top + fold);
                path.lineTo(left + pw, top + fold);
                canvas.drawPath(path, paint);
                // Lineas de texto.
                float lx1 = left + pw * 0.22f;
                float lx2 = left + pw * 0.78f;
                for (int i = 0; i < 3; i++) {
                    float ly = top + ph * (0.5f + i * 0.16f);
                    canvas.drawLine(lx1, ly, lx2, ly, paint);
                }
            } else if ("icon:book".equals(key)) {
                float bw = u * 0.72f;
                float bh = u * 0.56f;
                float left = cx - bw * 0.5f;
                float top = cy - bh * 0.5f;
                // Dos paginas con el lomo en el centro.
                path.reset();
                path.moveTo(cx, top + bh * 0.12f);
                path.cubicTo(cx - bw * 0.2f, top - bh * 0.05f,
                        left + bw * 0.02f, top, left, top + bh * 0.08f);
                path.lineTo(left, top + bh);
                path.cubicTo(left + bw * 0.02f, top + bh * 0.9f,
                        cx - bw * 0.2f, top + bh * 0.92f, cx, top + bh);
                canvas.drawPath(path, paint);
                path.reset();
                path.moveTo(cx, top + bh * 0.12f);
                path.cubicTo(cx + bw * 0.2f, top - bh * 0.05f,
                        left + bw * 0.98f, top, left + bw, top + bh * 0.08f);
                path.lineTo(left + bw, top + bh);
                path.cubicTo(left + bw * 0.98f, top + bh * 0.9f,
                        cx + bw * 0.2f, top + bh * 0.92f, cx, top + bh);
                canvas.drawPath(path, paint);
                canvas.drawLine(cx, top + bh * 0.12f, cx, top + bh, paint);
            } else if ("icon:mark".equals(key)) {
                // Resaltador marcando lineas de texto: tres lineas y un
                // marcador diagonal sobre la del medio.
                float lw = u * 0.6f;
                float lx = cx - lw * 0.5f;
                float ly0 = cy - u * 0.22f;
                for (int i = 0; i < 3; i++) {
                    float ly = ly0 + i * u * 0.22f;
                    canvas.drawLine(lx, ly, lx + lw, ly, paint);
                }
                // Punta del resaltador (rombo) sobre la linea del medio.
                float mx = cx + lw * 0.28f;
                float my = cy;
                float r = u * 0.14f;
                path.reset();
                path.moveTo(mx, my - r);
                path.lineTo(mx + r * 0.7f, my);
                path.lineTo(mx, my + r);
                path.lineTo(mx - r * 0.7f, my);
                path.close();
                canvas.drawPath(path, fillPaint);
            } else { // icon:range - marco con esquinas punteadas
                float s = u * 0.62f;
                float left = cx - s * 0.5f;
                float top = cy - s * 0.5f;
                float seg = s * 0.3f;
                // Cuatro esquinas en forma de L.
                // Sup izq.
                canvas.drawLine(left, top, left + seg, top, paint);
                canvas.drawLine(left, top, left, top + seg, paint);
                // Sup der.
                canvas.drawLine(left + s - seg, top, left + s, top, paint);
                canvas.drawLine(left + s, top, left + s, top + seg, paint);
                // Inf izq.
                canvas.drawLine(left, top + s - seg, left, top + s, paint);
                canvas.drawLine(left, top + s, left + seg, top + s, paint);
                // Inf der.
                canvas.drawLine(left + s - seg, top + s, left + s, top + s, paint);
                canvas.drawLine(left + s, top + s - seg, left + s, top + s, paint);
                // Punto central.
                canvas.drawCircle(cx, cy, u * 0.06f, fillPaint);
            }
        }
    }

    /**
     * Emblema central de la pantalla "Guardar PDF": mismo estilo que el de audio
     * (anillo de puntos, resplandor, estrellitas y una insignia abajo) pero con
     * una hoja de documento PDF en el centro en tono azul.
     */
    private static final class PdfEmblemView extends View {
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerRingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint docPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint starPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badgeGlyphPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final Path glyphPath = new Path();

        private final int accent = Color.rgb(96, 165, 250);

        PdfEmblemView(android.content.Context context) {
            super(context);
            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setColor(Color.argb(150, 96, 165, 250));
            dotPaint.setColor(Color.argb(180, 130, 165, 210));
            innerRingPaint.setStyle(Paint.Style.STROKE);
            innerRingPaint.setColor(accent);
            docPaint.setStyle(Paint.Style.STROKE);
            docPaint.setStrokeJoin(Paint.Join.ROUND);
            docPaint.setStrokeCap(Paint.Cap.ROUND);
            docPaint.setColor(accent);
            linePaint.setStrokeCap(Paint.Cap.ROUND);
            linePaint.setColor(Color.argb(220, 96, 165, 250));
            starPaint.setColor(Color.argb(160, 140, 170, 210));
            badgePaint.setColor(Color.rgb(28, 58, 100));
            badgeGlyphPaint.setStyle(Paint.Style.STROKE);
            badgeGlyphPaint.setStrokeCap(Paint.Cap.ROUND);
            badgeGlyphPaint.setStrokeJoin(Paint.Join.ROUND);
            badgeGlyphPaint.setColor(accent);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            if (w <= 0 || h <= 0) return;
            float cx = w * 0.5f;
            float cy = h * 0.5f;
            float unit = Math.min(w, h);
            float outerR = unit * 0.34f;
            float innerR = unit * 0.24f;

            glowPaint.setShader(new RadialGradient(cx, cy, innerR * 1.9f,
                    new int[]{Color.argb(70, 96, 165, 250), Color.argb(0, 96, 165, 250)},
                    null, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, innerR * 1.9f, glowPaint);

            ringPaint.setStrokeWidth(unit * 0.006f);
            canvas.drawCircle(cx, cy, outerR, ringPaint);
            int dots = 48;
            float dotR = unit * 0.007f;
            for (int i = 0; i < dots; i++) {
                double a = (Math.PI * 2 * i) / dots;
                float dx = cx + (float) Math.cos(a) * outerR;
                float dy = cy + (float) Math.sin(a) * outerR;
                canvas.drawCircle(dx, dy, dotR, dotPaint);
            }

            innerRingPaint.setStrokeWidth(unit * 0.012f);
            canvas.drawCircle(cx, cy, innerR, innerRingPaint);

            // Hoja de documento en el centro.
            float pw = innerR * 0.95f;
            float ph = innerR * 1.25f;
            float left = cx - pw * 0.5f;
            float top = cy - ph * 0.5f;
            float fold = pw * 0.34f;
            docPaint.setStrokeWidth(unit * 0.012f);
            path.reset();
            path.moveTo(left, top);
            path.lineTo(left + pw - fold, top);
            path.lineTo(left + pw, top + fold);
            path.lineTo(left + pw, top + ph);
            path.lineTo(left, top + ph);
            path.close();
            canvas.drawPath(path, docPaint);
            path.reset();
            path.moveTo(left + pw - fold, top);
            path.lineTo(left + pw - fold, top + fold);
            path.lineTo(left + pw, top + fold);
            canvas.drawPath(path, docPaint);
            // Lineas de texto dentro de la hoja.
            linePaint.setStrokeWidth(unit * 0.011f);
            float lx1 = left + pw * 0.2f;
            float lx2 = left + pw * 0.8f;
            for (int i = 0; i < 3; i++) {
                float ly = top + ph * (0.52f + i * 0.16f);
                canvas.drawLine(lx1, ly, lx2, ly, linePaint);
            }

            // Estrellitas alrededor.
            drawStar(canvas, cx - outerR * 1.15f, cy - outerR * 0.55f, unit * 0.018f);
            drawStar(canvas, cx + outerR * 1.10f, cy - outerR * 0.9f, unit * 0.013f);
            drawStar(canvas, cx + outerR * 1.2f, cy + outerR * 0.35f, unit * 0.016f);
            drawStar(canvas, cx - outerR * 0.95f, cy + outerR * 0.85f, unit * 0.012f);
            canvas.drawCircle(cx + outerR * 0.85f, cy - outerR * 1.0f, unit * 0.006f, starPaint);
            canvas.drawCircle(cx - outerR * 1.25f, cy + outerR * 0.15f, unit * 0.006f, starPaint);

            // Insignia con un check de "guardado" abajo a la derecha.
            float badgeCx = cx + outerR * 0.82f;
            float badgeCy = cy + outerR * 0.82f;
            float badgeR = unit * 0.085f;
            badgePaint.setShader(new RadialGradient(badgeCx, badgeCy, badgeR,
                    new int[]{Color.rgb(40, 84, 140), Color.rgb(22, 50, 92)},
                    null, Shader.TileMode.CLAMP));
            canvas.drawCircle(badgeCx, badgeCy, badgeR, badgePaint);
            badgeGlyphPaint.setStrokeWidth(badgeR * 0.28f);
            path.reset();
            path.moveTo(badgeCx - badgeR * 0.42f, badgeCy);
            path.lineTo(badgeCx - badgeR * 0.08f, badgeCy + badgeR * 0.34f);
            path.lineTo(badgeCx + badgeR * 0.46f, badgeCy - badgeR * 0.34f);
            canvas.drawPath(path, badgeGlyphPaint);
        }

        private void drawStar(Canvas canvas, float cx, float cy, float r) {
            glyphPath.reset();
            float inner = r * 0.32f;
            for (int i = 0; i < 4; i++) {
                double a = Math.PI / 2 * i;
                float px = cx + (float) Math.cos(a) * r;
                float py = cy + (float) Math.sin(a) * r;
                double a2 = a + Math.PI / 4;
                float ix = cx + (float) Math.cos(a2) * inner;
                float iy = cy + (float) Math.sin(a2) * inner;
                if (i == 0) glyphPath.moveTo(px, py);
                else glyphPath.lineTo(px, py);
                glyphPath.lineTo(ix, iy);
            }
            glyphPath.close();
            canvas.drawPath(glyphPath, starPaint);
        }
    }
}
