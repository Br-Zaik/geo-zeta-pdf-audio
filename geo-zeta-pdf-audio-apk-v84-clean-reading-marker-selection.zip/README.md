# Geo Zeta PDF a Audio V84

Correcciones sobre V83:

- El seguimiento de lectura queda como una franja semitransparente sin borde ni contorno.
- Se eliminaron los avisos emergentes al activar o desactivar el seguimiento.
- El subrayado reconoce mejor el inicio del gesto aunque el dedo caiga ligeramente fuera de una letra.
- La selección permanece estable en la línea inicial pese a pequeños movimientos verticales.
- El cambio hacia otra línea exige un movimiento vertical claro.
- La vista previa del marcado aparece mientras se arrastra y deja de ignorar gestos cercanos al texto.
- Un dedo marca con Subrayar ON y dos dedos continúan destinados al movimiento y zoom.
- Se conservan visor profesional, colores personalizados, exportación y persistencia de marcas.

VersionCode: 84
VersionName: 84.0-clean-reading-marker-selection
