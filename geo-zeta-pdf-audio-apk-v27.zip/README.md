# Geo Zeta PDF a Audio V27

Optimizada para celulares gama baja.

Cambios:
- Modo rápido por defecto.
- Selector de rendimiento:
  - Modo rápido: menos lag, ideal gama baja.
  - Modo balanceado.
  - Modo nítido: más calidad, usa más memoria.
- Render de PDF más liviano en modo rápido.
- Zoom máximo controlado para evitar trabas.
- Menos re-render durante pellizco.
- Audio con bloques más pequeños en gama baja.
- Preparación de audio con pausas cortas para no congelar la interfaz.
- La capa de subrayado se carga menos en modo rápido.

Recomendación:
- En celulares gama baja usa Modo rápido.
- En PDFs grandes, guarda audio por rangos.
- Modo nítido solo para celulares más fuertes.
