package com.geozeta.pdfaudio;

import android.app.Application;

/**
 * Process application entry point.
 *
 * TTS is intentionally not initialized here: Application.onCreate shares the
 * critical startup window with the first Activity and PDF restoration. The
 * Activity warms the engine after the UI/first PDF render, while Play can still
 * initialize it immediately on demand through TtsForegroundService.
 */
public class GeoZetaApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
