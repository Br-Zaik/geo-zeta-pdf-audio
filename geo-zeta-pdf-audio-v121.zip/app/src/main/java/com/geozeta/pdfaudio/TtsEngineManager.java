package com.geozeta.pdfaudio;

import android.content.Context;
import android.util.Log;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Process-wide TextToSpeech owner.
 *
 * The engine is created once from the Application process and is not tied to
 * the short lifecycle of a Service. If the default engine does not answer, the
 * manager tries the configured engine and every installed TTS service.
 */
public final class TtsEngineManager {
    public static final String PREF_ENGINE_PACKAGE = "tts_engine_package";
    public static final String PREF_PREFERRED_LANGUAGE = "tts_preferred_language_v28";
    public static final String PREF_PREFERRED_REGION = "tts_preferred_region_v28";
    private static final String PREF_LAST_WORKING_ENGINE = "tts_last_working_engine";
    private static final String PREF_MANUAL_VOICE_PREFIX = "tts_manual_voice_";

    public interface ReadyCallback {
        void onReady(String enginePackage);
        void onError(String message);
    }

    public interface StateListener {
        void onStateChanged(String status, boolean ready, String enginePackage);
    }

    public interface UtteranceListener {
        void onStart(String utteranceId);
        void onDone(String utteranceId);
        void onError(String utteranceId, int errorCode);
        void onStop(String utteranceId, boolean interrupted);
        void onRangeStart(String utteranceId, int start, int end);
    }

    public interface TestCallback {
        void onStarted();
        void onCompleted();
        void onError(String message);
    }

    public interface FileSynthesisCallback {
        void onCompleted();
        void onError(String message);
    }


    public static final class VoiceAvailability {
        public final String languageCode;
        public final boolean engineReady;
        public final boolean supported;
        public final boolean anyVoice;
        public final boolean offlineVoice;
        public final boolean networkOnly;

        VoiceAvailability(String languageCode, boolean engineReady, boolean supported,
                          boolean anyVoice, boolean offlineVoice) {
            this.languageCode = PdfLanguageDetector.normalizeCode(languageCode);
            this.engineReady = engineReady;
            this.supported = supported;
            this.anyVoice = anyVoice;
            this.offlineVoice = offlineVoice;
            this.networkOnly = anyVoice && !offlineVoice;
        }
    }

    public static final class EngineChoice {
        public final String packageName;
        public final String label;

        EngineChoice(String packageName, String label) {
            this.packageName = packageName;
            this.label = label;
        }
    }

    public static final class VoiceOption {
        public final String voiceName;
        public final String countryLabel;
        public final boolean offline;
        public final boolean selected;

        VoiceOption(String voiceName, String countryLabel, boolean offline, boolean selected) {
            this.voiceName = voiceName;
            this.countryLabel = countryLabel;
            this.offline = offline;
            this.selected = selected;
        }
    }

    private static final String TAG = "GeoZetaTTS";
    private static final String PREFS_NAME = "pdf_audio_prefs";
    private static final long FIRST_ATTEMPT_TIMEOUT_MS = 5000L;
    private static final long FALLBACK_ATTEMPT_TIMEOUT_MS = 2500L;
    private static volatile TtsEngineManager instance;

    public static TtsEngineManager getInstance(Context context) {
        if (instance == null) {
            synchronized (TtsEngineManager.class) {
                if (instance == null) {
                    instance = new TtsEngineManager(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    private final Context appContext;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final CopyOnWriteArrayList<ReadyCallback> readyCallbacks =
            new CopyOnWriteArrayList<ReadyCallback>();
    private final CopyOnWriteArrayList<StateListener> stateListeners =
            new CopyOnWriteArrayList<StateListener>();
    private final CopyOnWriteArrayList<UtteranceListener> utteranceListeners =
            new CopyOnWriteArrayList<UtteranceListener>();
    /** Ultima muestra de voz pedida: solo esa puede mostrar un aviso de error. */
    /**
     * getVoices() del motor es una llamada lenta: consulta al servicio del motor
     * y puede tardar cerca de un segundo. Se guarda el resultado apenas se arma
     * la lista de voces en Ajustes y se reutiliza al tocar una, para que la
     * muestra suene al instante en vez de esperar esa consulta.
     */
    private java.util.HashMap<String, Voice> voiceByNameCache;
    private int voiceCacheGeneration = -1;
    private volatile String latestTestUtteranceId = "";
    private int testSampleCounter;
    private final Map<String, TestCallback> testCallbacks =
            new ConcurrentHashMap<String, TestCallback>();
    private final Map<String, FileSynthesisCallback> fileSynthesisCallbacks =
            new ConcurrentHashMap<String, FileSynthesisCallback>();

    private TextToSpeech tts;
    private TextToSpeech pendingTts;
    private boolean ready;
    private boolean initializing;
    private int generation;
    private int candidateIndex;
    private List<String> candidates = Collections.emptyList();
    private String activeEnginePackage = "";
    private String statusText = "Motor de voz sin iniciar";
    private String preferredLanguage = "";
    private String preferredRegion = "";
    private boolean preferredLanguageAvailable = true;
    private boolean preferredOfflineVoiceAvailable;
    private boolean pipelineWarmed;
    private boolean prioritizeSelectedOnNextInitialization;
    private Runnable attemptTimeout;

    private TtsEngineManager(Context context) {
        appContext = context;
        SharedPreferences prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        preferredLanguage = PdfLanguageDetector.normalizeCode(
                prefs.getString(PREF_PREFERRED_LANGUAGE, ""));
        preferredRegion = normalizeRegionCode(prefs.getString(PREF_PREFERRED_REGION, ""));
    }

    public void initialize(ReadyCallback callback) {
        runOnMain(new Runnable() {
            @Override
            public void run() {
                if (callback != null) readyCallbacks.add(callback);
                if (ready && tts != null) {
                    notifyReadyCallbacks();
                    return;
                }
                if (initializing) return;
                beginInitialization();
            }
        });
    }

    public void retryInitialization() {
        runOnMain(new Runnable() {
            @Override
            public void run() {
                resetInternal(true);
                beginInitialization();
            }
        });
    }

    public boolean isReady() {
        return ready && tts != null;
    }

    public String getActiveEnginePackage() {
        return activeEnginePackage == null ? "" : activeEnginePackage;
    }

    public String getStatusText() {
        return statusText == null ? "" : statusText;
    }

    public String getPreferredLanguage() {
        return preferredLanguage == null ? "" : preferredLanguage;
    }

    public String getPreferredRegion() {
        return preferredRegion == null ? "" : preferredRegion;
    }

    public boolean isPreferredLanguageAvailable() {
        return preferredLanguage == null || preferredLanguage.length() == 0
                || preferredLanguageAvailable;
    }

    public boolean hasPreferredOfflineVoice() {
        return preferredOfflineVoiceAvailable;
    }

    public void setPreferredLanguage(String languageCode, String regionCode) {
        final String language = PdfLanguageDetector.normalizeCode(languageCode);
        final String region = normalizeRegionCode(regionCode);
        runOnMain(new Runnable() {
            @Override
            public void run() {
                preferredLanguage = language;
                preferredRegion = region;
                appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                        .putString(PREF_PREFERRED_LANGUAGE, preferredLanguage)
                        .putString(PREF_PREFERRED_REGION, preferredRegion)
                        .apply();
                if (ready && tts != null) {
                    preferredLanguageAvailable = applyPreferredLanguage(tts);
                }
            }
        });
    }

    /**
     * Ensures that the active engine can speak the requested PDF language. If the
     * current engine cannot, initialization is repeated across installed engines.
     */
    public void ensureLanguage(String languageCode, String regionCode, ReadyCallback callback) {
        final String language = PdfLanguageDetector.normalizeCode(languageCode);
        final String region = normalizeRegionCode(regionCode);
        runOnMain(new Runnable() {
            @Override
            public void run() {
                if (callback != null) readyCallbacks.add(callback);

                // El idioma ya esta configurado, confirmado y funcionando: no
                // hay nada que cambiar. Volver a pedirle al motor que reaplique
                // la misma voz (por ejemplo cada vez que se vuelve a la app o se
                // salta de pagina) era un riesgo innecesario -- si esa
                // reconfirmacion fallaba por un tropiezo pasajero (el motor
                // ocupado hablando, por ejemplo), la app lo tomaba como "no hay
                // voz" y reiniciaba el motor entero, mostrando "Falta una voz"
                // aunque la voz estuviera instalada y funcionando.
                boolean sameLanguageAlreadyWorking = ready && tts != null
                        && language.equals(preferredLanguage)
                        && region.equals(preferredRegion)
                        && preferredLanguageAvailable;
                if (sameLanguageAlreadyWorking) {
                    notifyReadyCallbacks();
                    return;
                }

                preferredLanguage = language;
                preferredRegion = region;
                appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                        .putString(PREF_PREFERRED_LANGUAGE, preferredLanguage)
                        .putString(PREF_PREFERRED_REGION, preferredRegion)
                        .apply();

                if (ready && tts != null && applyPreferredLanguage(tts)) {
                    preferredLanguageAvailable = true;
                    notifyReadyCallbacks();
                    return;
                }
                if (initializing) return;
                resetInternal(true);
                beginInitialization();
            }
        });
    }

    public VoiceAvailability getVoiceAvailability(String languageCode, String regionCode) {
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        TextToSpeech current = tts;
        if (!ready || current == null || !PdfLanguageDetector.isSupported(language)) {
            return new VoiceAvailability(language, false, false, false, false);
        }
        try {
            Locale locale = localeForLanguage(language, regionCode);
            int status = current.isLanguageAvailable(locale);
            boolean supported = status != TextToSpeech.LANG_NOT_SUPPORTED;
            boolean missing = status == TextToSpeech.LANG_MISSING_DATA;
            Set<Voice> voices = current.getVoices();
            boolean any = false;
            boolean offline = false;
            if (voices != null) {
                for (Voice voice : voices) {
                    if (voice == null || voice.getLocale() == null) continue;
                    if (!language.equals(PdfLanguageDetector.normalizeCode(
                            voice.getLocale().getLanguage()))) continue;
                    any = true;
                    if (!voice.isNetworkConnectionRequired()) offline = true;
                }
            }
            if (!any && supported && !missing && (voices == null || voices.isEmpty())) {
                any = true;
            }
            return new VoiceAvailability(language, true, supported && !missing, any, offline);
        } catch (Exception ignored) {
            return new VoiceAvailability(language, true, false, false, false);
        }
    }

    public void addStateListener(StateListener listener) {
        if (listener == null) return;
        stateListeners.addIfAbsent(listener);
        listener.onStateChanged(getStatusText(), isReady(), getActiveEnginePackage());
    }

    public void removeStateListener(StateListener listener) {
        if (listener != null) stateListeners.remove(listener);
    }

    public void addUtteranceListener(UtteranceListener listener) {
        if (listener != null) utteranceListeners.addIfAbsent(listener);
    }

    public void removeUtteranceListener(UtteranceListener listener) {
        if (listener != null) utteranceListeners.remove(listener);
    }

    public List<EngineChoice> getInstalledEngines() {
        ArrayList<EngineChoice> result = new ArrayList<EngineChoice>();
        try {
            PackageManager pm = appContext.getPackageManager();
            Intent query = new Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE);
            List<ResolveInfo> services;
            if (Build.VERSION.SDK_INT >= 33) {
                services = pm.queryIntentServices(query,
                        PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL));
            } else {
                services = pm.queryIntentServices(query, PackageManager.MATCH_ALL);
            }
            if (services != null) {
                LinkedHashSet<String> seen = new LinkedHashSet<String>();
                for (ResolveInfo info : services) {
                    if (info == null || info.serviceInfo == null) continue;
                    String pkg = info.serviceInfo.packageName;
                    if (pkg == null || pkg.length() == 0 || !seen.add(pkg)) continue;
                    CharSequence labelSequence = info.loadLabel(pm);
                    String label = labelSequence == null ? pkg : labelSequence.toString();
                    result.add(new EngineChoice(pkg, label));
                }
            }
        } catch (Exception ignored) {
        }
        return result;
    }

    public void selectEngine(String packageName) {
        final String value = packageName == null ? "" : packageName.trim();
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putString(PREF_ENGINE_PACKAGE, value).apply();
        prioritizeSelectedOnNextInitialization = true;
        retryInitialization();
    }

    public int speak(String text, int queueMode, Bundle params, String utteranceId) {
        TextToSpeech current = tts;
        if (!ready || current == null || text == null || text.trim().length() == 0) {
            return TextToSpeech.ERROR;
        }
        try {
            if (Build.VERSION.SDK_INT >= 21) {
                return current.speak(text, queueMode, params, utteranceId);
            }
            return TextToSpeech.ERROR;
        } catch (Exception ignored) {
            return TextToSpeech.ERROR;
        }
    }

    public int synthesizeToFile(String text, Bundle params, File file, String utteranceId,
                                FileSynthesisCallback callback) {
        TextToSpeech current = tts;
        if (!ready || current == null || text == null || text.trim().length() == 0
                || file == null || utteranceId == null || utteranceId.length() == 0) {
            if (callback != null) callback.onError("El motor de voz aun no esta listo");
            return TextToSpeech.ERROR;
        }
        if (callback != null) fileSynthesisCallbacks.put(utteranceId, callback);
        try {
            Bundle safeParams = params == null ? new Bundle() : params;
            int result = current.synthesizeToFile(text, safeParams, file, utteranceId);
            if (result == TextToSpeech.ERROR) {
                FileSynthesisCallback pending = fileSynthesisCallbacks.remove(utteranceId);
                if (pending != null) pending.onError("El motor rechazo el audio rapido");
            }
            return result;
        } catch (Exception ignored) {
            FileSynthesisCallback pending = fileSynthesisCallbacks.remove(utteranceId);
            if (pending != null) pending.onError("No se pudo preparar el audio rapido");
            return TextToSpeech.ERROR;
        }
    }

    public void setSpeechRate(float value) {
        TextToSpeech current = tts;
        if (current == null || !ready) return;
        try { current.setSpeechRate(value); } catch (Exception ignored) {}
    }

    public void setPitch(float value) {
        TextToSpeech current = tts;
        if (current == null || !ready) return;
        try { current.setPitch(value); } catch (Exception ignored) {}
    }

    public void stop() {
        TextToSpeech current = tts;
        if (current == null) return;
        try { current.stop(); } catch (Exception ignored) {}
    }

    public boolean isSpeaking() {
        TextToSpeech current = tts;
        if (current == null || !ready) return false;
        try { return current.isSpeaking(); } catch (Exception ignored) { return false; }
    }

    public void testVoice(final String text, final TestCallback callback) {
        initialize(new ReadyCallback() {
            @Override
            public void onReady(String enginePackage) {
                final String id = "TEST_" + System.currentTimeMillis()
                        + "_" + (testSampleCounter++);
                latestTestUtteranceId = id;
                // Las muestras anteriores ya no interesan: se descartan sin avisar.
                testCallbacks.clear();
                if (callback != null) testCallbacks.put(id, callback);
                Bundle params = new Bundle();
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
                int result = speak(text, TextToSpeech.QUEUE_FLUSH, params, id);
                if (result == TextToSpeech.ERROR) {
                    TestCallback pending = testCallbacks.remove(id);
                    if (pending != null) pending.onError("El motor rechazo la prueba de voz");
                }
            }

            @Override
            public void onError(String message) {
                if (callback != null) callback.onError(message);
            }
        });
    }

    /**
     * Guarda la voz elegida y la prueba en un solo paso (evita fijar la voz
     * en el motor dos veces seguidas, que sumaba una demora perceptible antes
     * de escucharse).
     */
    public void selectAndTestVoice(final String languageCode, final String voiceName,
                                    final String text, final TestCallback callback) {
        final String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (language.length() > 0) {
            appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                    .putString(PREF_MANUAL_VOICE_PREFIX + language,
                            voiceName == null ? "" : voiceName)
                    .apply();
        }
        testSpecificVoice(voiceName, text, callback);
    }

    /**
     * Reproduce una muestra con una voz especifica (por nombre interno del
     * motor), sin cambiar el idioma preferido guardado. Se usa para escuchar
     * cada opcion en la pantalla de "elegir voz" antes de confirmarla.
     */
    public void testSpecificVoice(final String voiceName, final String text,
                                   final TestCallback callback) {
        // Corte inmediato: si habia una muestra sonando, se calla en el mismo
        // toque. Sin esto el motor esperaba a terminar la frase anterior antes
        // de aceptar la voz nueva y la respuesta se sentia lenta.
        stop();
        initialize(new ReadyCallback() {
            @Override
            public void onReady(String enginePackage) {
                Voice voice = findVoiceByName(tts, voiceName);
                if (voice == null) {
                    if (callback != null) callback.onError("No se encontro esa voz");
                    return;
                }
                try {
                    // Segundo corte, ya con el motor listo: algunos motores
                    // ignoran el cambio de voz mientras siguen hablando.
                    stop();
                    tts.setVoice(voice);
                } catch (Exception e) {
                    if (callback != null) callback.onError("No se pudo activar esa voz");
                    return;
                }
                final String id = "TEST_" + System.currentTimeMillis()
                        + "_" + (testSampleCounter++);
                latestTestUtteranceId = id;
                // Las muestras anteriores ya no interesan: se descartan sin avisar.
                testCallbacks.clear();
                if (callback != null) testCallbacks.put(id, callback);
                Bundle params = new Bundle();
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
                int result = speak(text, TextToSpeech.QUEUE_FLUSH, params, id);
                if (result == TextToSpeech.ERROR) {
                    TestCallback pending = testCallbacks.remove(id);
                    if (pending != null) pending.onError("El motor rechazo la prueba de voz");
                }
            }

            @Override
            public void onError(String message) {
                if (callback != null) callback.onError(message);
            }
        });
    }

    private void beginInitialization() {
        generation++;
        candidateIndex = 0;
        candidates = buildCandidateList();
        initializing = true;
        ready = false;
        activeEnginePackage = "";
        updateStatus("Buscando motor de voz", false);
        tryNextCandidate(generation);
    }

    private List<String> buildCandidateList() {
        LinkedHashSet<String> ordered = new LinkedHashSet<String>();
        SharedPreferences prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String selected = prefs.getString(PREF_ENGINE_PACKAGE, "");
        String lastWorking = prefs.getString(PREF_LAST_WORKING_ENGINE, "");
        boolean forceSelected = prioritizeSelectedOnNextInitialization;
        prioritizeSelectedOnNextInitialization = false;

        // En un arranque normal se prueba primero el ultimo motor que ya funciono.
        // Solo una seleccion manual del usuario tiene prioridad sobre ese historial.
        if (forceSelected) {
            if (selected != null && selected.trim().length() > 0) ordered.add(selected.trim());
            else ordered.add("");
        } else if (lastWorking != null && lastWorking.trim().length() > 0) {
            ordered.add(lastWorking.trim());
        }
        if (selected != null && selected.trim().length() > 0) ordered.add(selected.trim());
        if (lastWorking != null && lastWorking.trim().length() > 0) ordered.add(lastWorking.trim());

        try {
            String systemDefault = Settings.Secure.getString(
                    appContext.getContentResolver(), Settings.Secure.TTS_DEFAULT_SYNTH);
            if (systemDefault != null && systemDefault.trim().length() > 0) {
                ordered.add(systemDefault.trim());
            }
        } catch (Exception ignored) {
        }

        List<EngineChoice> installed = getInstalledEngines();
        for (EngineChoice choice : installed) {
            if ("com.google.android.tts".equals(choice.packageName)) {
                ordered.add(choice.packageName);
            }
        }
        for (EngineChoice choice : installed) ordered.add(choice.packageName);

        // Empty string means the Android default constructor.
        ordered.add("");
        return new ArrayList<String>(ordered);
    }

    private void tryNextCandidate(final int requestGeneration) {
        if (requestGeneration != generation) return;
        shutdownPending();
        cancelAttemptTimeout();

        if (candidateIndex >= candidates.size()) {
            initializing = false;
            ready = false;
            preferredLanguageAvailable = preferredLanguage == null || preferredLanguage.length() == 0;
            String message = preferredLanguage != null && preferredLanguage.length() > 0
                    ? "VOICE_MISSING:" + preferredLanguage
                    : "Android no pudo iniciar ningun motor de voz instalado";
            updateStatus(message, false);
            notifyErrorCallbacks(message);
            return;
        }

        final String candidate = candidates.get(candidateIndex++);
        String display = candidate.length() == 0 ? "motor predeterminado" : candidate;
        updateStatus("Iniciando " + display, false);
        final int attemptGeneration = requestGeneration;
        final TextToSpeech[] holder = new TextToSpeech[1];

        TextToSpeech.OnInitListener listener = new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(final int status) {
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (attemptGeneration != generation) {
                            shutdownSafely(holder[0]);
                            return;
                        }
                        cancelAttemptTimeout();
                        TextToSpeech created = holder[0];
                        if (status != TextToSpeech.SUCCESS || created == null) {
                            shutdownSafely(created);
                            tryNextCandidate(attemptGeneration);
                            return;
                        }
                        acceptEngine(created, candidate);
                    }
                });
            }
        };

        try {
            if (candidate.length() == 0) {
                holder[0] = new TextToSpeech(appContext, listener);
            } else {
                holder[0] = new TextToSpeech(appContext, listener, candidate);
            }
            pendingTts = holder[0];
        } catch (Exception e) {
            Log.w(TAG, "No se pudo crear el motor TTS"
                    + (candidate.length() == 0 ? " (por defecto)" : ": " + candidate), e);
            shutdownSafely(holder[0]);
            tryNextCandidate(attemptGeneration);
            return;
        }

        attemptTimeout = new Runnable() {
            @Override
            public void run() {
                if (attemptGeneration != generation || !initializing || ready) return;
                shutdownSafely(holder[0]);
                if (pendingTts == holder[0]) pendingTts = null;
                tryNextCandidate(attemptGeneration);
            }
        };
        mainHandler.postDelayed(attemptTimeout, candidateIndex <= 1
                ? FIRST_ATTEMPT_TIMEOUT_MS : FALLBACK_ATTEMPT_TIMEOUT_MS);
    }

    private void acceptEngine(TextToSpeech created, String requestedPackage) {
        cancelAttemptTimeout();
        shutdownSafely(tts);
        tts = null;
        if (pendingTts == created) pendingTts = null;

        boolean languageReady = configureEngine(created);
        if (!languageReady && preferredLanguage != null && preferredLanguage.length() > 0) {
            preferredLanguageAvailable = false;
            shutdownSafely(created);
            tryNextCandidate(generation);
            return;
        }

        tts = created;
        ready = true;
        initializing = false;

        String actual = requestedPackage;
        if (actual == null || actual.length() == 0) {
            try {
                String fromEngine = created.getDefaultEngine();
                if (fromEngine != null && fromEngine.trim().length() > 0) {
                    actual = fromEngine.trim();
                }
            } catch (Exception ignored) {
            }
        }
        activeEnginePackage = actual == null ? "" : actual;
        if (activeEnginePackage.length() > 0) {
            appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit().putString(PREF_LAST_WORKING_ENGINE, activeEnginePackage).apply();
        }
        updateStatus("Motor listo" + (activeEnginePackage.length() > 0
                ? ": " + activeEnginePackage : ""), true);
        primeAudioPipeline(created);
        notifyReadyCallbacks();
    }


    private void primeAudioPipeline(TextToSpeech engine) {
        if (pipelineWarmed || engine == null || Build.VERSION.SDK_INT < 21) return;
        pipelineWarmed = true;
        try {
            Bundle params = new Bundle();
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 0.0f);
            engine.speak(".", TextToSpeech.QUEUE_FLUSH, params,
                    "__GEO_ZETA_SILENT_WARMUP__");
        } catch (Exception e) {
            Log.w(TAG, "Fallo al precalentar el pipeline de audio", e);
            pipelineWarmed = false;
        }
    }

    private boolean configureEngine(TextToSpeech engine) {
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                engine.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build());
            } catch (Exception ignored) {
            }
        }

        boolean languageReady;
        if (preferredLanguage != null && preferredLanguage.length() > 0) {
            languageReady = applyPreferredLanguage(engine);
        } else {
            languageReady = tryLanguage(engine, Locale.getDefault());
            if (!languageReady) languageReady = tryLanguage(engine, Locale.US);
            preferredLanguageAvailable = true;
            preferredOfflineVoiceAvailable = false;
        }

        engine.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
                TestCallback test = utteranceId == null ? null : testCallbacks.get(utteranceId);
                if (test != null) test.onStarted();
                for (UtteranceListener listener : utteranceListeners) {
                    listener.onStart(utteranceId);
                }
            }

            @Override
            public void onDone(String utteranceId) {
                TestCallback test = utteranceId == null ? null : testCallbacks.remove(utteranceId);
                if (test != null) test.onCompleted();
                FileSynthesisCallback synthesis = utteranceId == null
                        ? null : fileSynthesisCallbacks.remove(utteranceId);
                if (synthesis != null) synthesis.onCompleted();
                for (UtteranceListener listener : utteranceListeners) {
                    listener.onDone(utteranceId);
                }
            }

            @Override
            public void onError(String utteranceId) {
                dispatchError(utteranceId, TextToSpeech.ERROR);
            }

            @Override
            public void onError(String utteranceId, int errorCode) {
                dispatchError(utteranceId, errorCode);
            }

            @Override
            public void onStop(String utteranceId, boolean interrupted) {
                // Cortar una muestra de voz es justamente lo que se busca cuando
                // el usuario toca otra voz: se descarta en silencio, sin avisos.
                if (utteranceId != null) testCallbacks.remove(utteranceId);
                FileSynthesisCallback synthesis = utteranceId == null
                        ? null : fileSynthesisCallbacks.remove(utteranceId);
                if (synthesis != null && interrupted) {
                    synthesis.onError("La preparacion del audio rapido fue interrumpida");
                }
                for (UtteranceListener listener : utteranceListeners) {
                    listener.onStop(utteranceId, interrupted);
                }
            }

            @Override
            public void onRangeStart(String utteranceId, int start, int end, int frame) {
                for (UtteranceListener listener : utteranceListeners) {
                    listener.onRangeStart(utteranceId, start, end);
                }
            }
        });
        return preferredLanguage == null || preferredLanguage.length() == 0 || languageReady;
    }

    private void dispatchError(String utteranceId, int errorCode) {
        TestCallback test = utteranceId == null ? null : testCallbacks.remove(utteranceId);
        // Una muestra que quedo vieja porque el usuario ya toco otra voz no debe
        // mostrar ningun aviso: se descarta en silencio.
        if (test != null && utteranceId.equals(latestTestUtteranceId)) {
            test.onError("Error del motor de voz: " + errorCode);
        }
        FileSynthesisCallback synthesis = utteranceId == null
                ? null : fileSynthesisCallbacks.remove(utteranceId);
        if (synthesis != null) synthesis.onError("Error al preparar el audio rapido: " + errorCode);
        for (UtteranceListener listener : utteranceListeners) {
            listener.onError(utteranceId, errorCode);
        }
    }

    private boolean applyPreferredLanguage(TextToSpeech engine) {
        String language = PdfLanguageDetector.normalizeCode(preferredLanguage);
        if (engine == null || language.length() == 0) {
            preferredLanguageAvailable = language.length() == 0;
            preferredOfflineVoiceAvailable = false;
            return language.length() == 0;
        }

        Voice best = findVoiceByName(engine, getManualVoiceName(language));
        if (best == null) {
            best = selectBestVoiceForLanguage(engine, language, preferredRegion);
        }
        if (best != null) {
            try {
                int result = engine.setVoice(best);
                if (result == TextToSpeech.SUCCESS) {
                    preferredLanguageAvailable = true;
                    preferredOfflineVoiceAvailable = !best.isNetworkConnectionRequired();
                    return true;
                }
                Log.w(TAG, "setVoice devolvio error para " + best.getName());
            } catch (Exception e) {
                Log.w(TAG, "Fallo al aplicar la voz seleccionada", e);
            }
        }

        Locale preferredLocale = localeForLanguage(language, preferredRegion);
        boolean languageSet = tryLanguage(engine, preferredLocale);
        if (!languageSet) {
            Locale fallback = defaultLocaleForLanguage(language);
            if (!fallback.equals(preferredLocale)) languageSet = tryLanguage(engine, fallback);
        }
        preferredLanguageAvailable = languageSet;
        preferredOfflineVoiceAvailable = languageSet && hasOfflineVoice(engine, language);
        return languageSet;
    }

    /**
     * Nombre de la voz elegida a mano por el usuario para un idioma, o vacio
     * si no eligio ninguna (en ese caso se sigue usando la automatica).
     */
    public String getManualVoiceName(String languageCode) {
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (language.length() == 0) return "";
        SharedPreferences prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getString(PREF_MANUAL_VOICE_PREFIX + language, "");
    }

    /**
     * Guarda la voz elegida a mano para un idioma y la aplica de inmediato si
     * el motor ya esta listo y ese es el idioma activo. Pasar voiceName vacio
     * vuelve a dejar la seleccion automatica.
     */
    public void setManualVoice(final String languageCode, final String voiceName) {
        final String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (language.length() == 0) return;
        runOnMain(new Runnable() {
            @Override
            public void run() {
                appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                        .putString(PREF_MANUAL_VOICE_PREFIX + language,
                                voiceName == null ? "" : voiceName)
                        .apply();
                if (ready && tts != null && language.equals(
                        PdfLanguageDetector.normalizeCode(preferredLanguage))) {
                    preferredLanguageAvailable = applyPreferredLanguage(tts);
                }
            }
        });
    }

    private Voice findVoiceByName(TextToSpeech engine, String voiceName) {
        if (engine == null || voiceName == null || voiceName.length() == 0
                || Build.VERSION.SDK_INT < 21) {
            return null;
        }
        if (engine == tts && voiceByNameCache != null
                && voiceCacheGeneration == generation) {
            Voice cached = voiceByNameCache.get(voiceName);
            if (cached != null) return cached;
        }
        try {
            Set<Voice> voices = engine.getVoices();
            if (voices == null) return null;
            for (Voice voice : voices) {
                if (voice != null && voiceName.equals(voice.getName())) return voice;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /**
     * Lista las voces instaladas del motor para un idioma, para que el usuario
     * elija una a mano en Ajustes. Se ordenan de mejor a peor segun el mismo
     * criterio que la seleccion automatica.
     */
    public List<VoiceOption> getVoiceOptionsForLanguage(String languageCode, String regionCode) {
        List<VoiceOption> result = new ArrayList<VoiceOption>();
        if (tts == null || !ready || Build.VERSION.SDK_INT < 21) return result;
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (language.length() == 0) return result;
        String preferredCountry = preferredCountryForLanguage(language, regionCode);
        String defaultCountry = defaultCountryForLanguage(language);
        String manualName = getManualVoiceName(language);

        List<Voice> matches = new ArrayList<Voice>();
        try {
            Set<Voice> voices = tts.getVoices();
            if (voices != null) {
                // Se guarda el listado para no volver a consultarlo al tocar una voz.
                java.util.HashMap<String, Voice> cache = new java.util.HashMap<String, Voice>();
                for (Voice voice : voices) {
                    if (voice != null && voice.getName() != null) {
                        cache.put(voice.getName(), voice);
                    }
                }
                voiceByNameCache = cache;
                voiceCacheGeneration = generation;
                for (Voice voice : voices) {
                    if (voice == null || voice.getLocale() == null) continue;
                    if (voice.isNetworkConnectionRequired()) continue;
                    if (!language.equals(PdfLanguageDetector.normalizeCode(
                            voice.getLocale().getLanguage()))) continue;
                    matches.add(voice);
                }
            }
        } catch (Exception e) {
            return result;
        }

        Collections.sort(matches, new java.util.Comparator<Voice>() {
            @Override
            public int compare(Voice a, Voice b) {
                return scoreVoiceForSort(b, preferredCountry, defaultCountry)
                        - scoreVoiceForSort(a, preferredCountry, defaultCountry);
            }
        });

        for (Voice voice : matches) {
            String country = normalizeRegionCode(voice.getLocale().getCountry());
            String label = country.length() > 0
                    ? voice.getLocale().getDisplayCountry(voice.getLocale())
                    : "";
            if (label == null || label.length() == 0) label = country;
            boolean selected = voice.getName().equals(manualName);
            result.add(new VoiceOption(voice.getName(), label, true, selected));
        }
        return result;
    }

    private int scoreVoiceForSort(Voice voice, String preferredCountry, String defaultCountry) {
        String country = normalizeRegionCode(voice.getLocale().getCountry());
        int score = 0;
        if (preferredCountry.length() > 0 && preferredCountry.equals(country)) score += 5000;
        if (defaultCountry.length() > 0 && defaultCountry.equals(country)) score += 2500;
        if (country.length() > 0) score += 300;
        score += Math.max(0, voice.getQuality());
        score -= Math.max(0, voice.getLatency()) / 2;
        return score;
    }

    private Voice selectBestVoiceForLanguage(TextToSpeech engine, String languageCode,
                                             String regionCode) {
        if (engine == null || Build.VERSION.SDK_INT < 21) return null;
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (language.length() == 0) return null;
        String preferredCountry = preferredCountryForLanguage(language, regionCode);
        String defaultCountry = defaultCountryForLanguage(language);
        try {
            Set<Voice> voices = engine.getVoices();
            if (voices == null || voices.isEmpty()) return null;
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            for (Voice voice : voices) {
                if (voice == null || voice.getLocale() == null) continue;
                Locale locale = voice.getLocale();
                if (!language.equals(PdfLanguageDetector.normalizeCode(locale.getLanguage()))) continue;

                int score = voice.isNetworkConnectionRequired() ? 0 : 10000;
                String country = normalizeRegionCode(locale.getCountry());
                if (preferredCountry.length() > 0 && preferredCountry.equals(country)) score += 5000;
                if (defaultCountry.length() > 0 && defaultCountry.equals(country)) score += 2500;
                if (country.length() > 0) score += 300;
                score += Math.max(0, voice.getQuality());
                score -= Math.max(0, voice.getLatency()) / 2;

                if (best == null || score > bestScore) {
                    best = voice;
                    bestScore = score;
                }
            }
            return best;
        } catch (Exception e) {
            Log.w(TAG, "Fallo al listar/seleccionar voces del motor", e);
            return null;
        }
    }

    private boolean hasOfflineVoice(TextToSpeech engine, String languageCode) {
        if (engine == null || Build.VERSION.SDK_INT < 21) return false;
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        try {
            Set<Voice> voices = engine.getVoices();
            if (voices == null) return false;
            for (Voice voice : voices) {
                if (voice == null || voice.getLocale() == null) continue;
                if (language.equals(PdfLanguageDetector.normalizeCode(
                        voice.getLocale().getLanguage())) && !voice.isNetworkConnectionRequired()) {
                    return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    public static Locale localeForLanguage(String languageCode, String regionCode) {
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (language.length() == 0) return Locale.getDefault();
        String country = preferredCountryForLanguage(language, regionCode);
        if (country.length() == 0) country = defaultCountryForLanguage(language);
        return country.length() == 0 ? new Locale(language) : new Locale(language, country);
    }

    private static Locale defaultLocaleForLanguage(String languageCode) {
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        String country = defaultCountryForLanguage(language);
        return country.length() == 0 ? new Locale(language) : new Locale(language, country);
    }

    private static String defaultCountryForLanguage(String languageCode) {
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (UiStrings.ES.equals(language)) return "PE";
        if (UiStrings.EN.equals(language)) return "US";
        if (UiStrings.PT.equals(language)) return "BR";
        if (UiStrings.HI.equals(language)) return "IN";
        if (UiStrings.ID.equals(language)) return "ID";
        return "";
    }

    private static String preferredCountryForLanguage(String languageCode, String regionCode) {
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        String region = normalizeRegionCode(regionCode);
        if (region.length() == 0) return defaultCountryForLanguage(language);
        if (UiStrings.ES.equals(language)) {
            String spanish = "PE,MX,CO,AR,CL,EC,BO,PY,UY,VE,GT,HN,SV,NI,CR,PA,CU,DO,ES,US";
            if (containsCountry(spanish, region)) return region;
        } else if (UiStrings.EN.equals(language)) {
            if (containsCountry("US,GB,CA,AU,IN,PH", region)) return region;
        } else if (UiStrings.PT.equals(language)) {
            if (containsCountry("BR,PT", region)) return region;
        } else if (UiStrings.HI.equals(language) && "IN".equals(region)) {
            return region;
        } else if (UiStrings.ID.equals(language) && "ID".equals(region)) {
            return region;
        }
        return defaultCountryForLanguage(language);
    }

    private static boolean containsCountry(String csv, String region) {
        return ("," + csv + ",").contains("," + region + ",");
    }

    private static String normalizeRegionCode(String regionCode) {
        if (regionCode == null) return "";
        String value = regionCode.trim().toUpperCase(Locale.ROOT);
        return value.matches("[A-Z]{2}") ? value : "";
    }

    private boolean tryLanguage(TextToSpeech engine, Locale locale) {
        if (engine == null || locale == null) return false;
        try {
            int available = engine.isLanguageAvailable(locale);
            if (available == TextToSpeech.LANG_MISSING_DATA
                    || available == TextToSpeech.LANG_NOT_SUPPORTED) return false;
            int result = engine.setLanguage(locale);
            return result != TextToSpeech.LANG_MISSING_DATA
                    && result != TextToSpeech.LANG_NOT_SUPPORTED;
        } catch (Exception ignored) {
            return false;
        }
    }

    private void notifyReadyCallbacks() {
        ArrayList<ReadyCallback> copy = new ArrayList<ReadyCallback>(readyCallbacks);
        readyCallbacks.clear();
        for (ReadyCallback callback : copy) {
            if (callback != null) callback.onReady(activeEnginePackage);
        }
    }

    private void notifyErrorCallbacks(String message) {
        ArrayList<ReadyCallback> copy = new ArrayList<ReadyCallback>(readyCallbacks);
        readyCallbacks.clear();
        for (ReadyCallback callback : copy) {
            if (callback != null) callback.onError(message);
        }
    }

    private void updateStatus(String status, boolean isReady) {
        statusText = status == null ? "" : status;
        for (StateListener listener : stateListeners) {
            listener.onStateChanged(statusText, isReady, activeEnginePackage);
        }
    }

    private void resetInternal(boolean keepCallbacks) {
        generation++;
        voiceByNameCache = null;
        voiceCacheGeneration = -1;
        cancelAttemptTimeout();
        shutdownPending();
        shutdownSafely(tts);
        tts = null;
        ready = false;
        initializing = false;
        activeEnginePackage = "";
        pipelineWarmed = false;
        preferredLanguageAvailable = preferredLanguage == null || preferredLanguage.length() == 0;
        preferredOfflineVoiceAvailable = false;
        if (!keepCallbacks) readyCallbacks.clear();
        testCallbacks.clear();
        updateStatus("Reiniciando motor de voz", false);
    }

    private void shutdownPending() {
        shutdownSafely(pendingTts);
        pendingTts = null;
    }

    private void shutdownSafely(TextToSpeech engine) {
        if (engine == null) return;
        try { engine.stop(); } catch (Exception ignored) {}
        try { engine.shutdown(); } catch (Exception ignored) {}
    }

    private void cancelAttemptTimeout() {
        if (attemptTimeout != null) {
            mainHandler.removeCallbacks(attemptTimeout);
            attemptTimeout = null;
        }
    }

    private void runOnMain(Runnable runnable) {
        if (Looper.myLooper() == Looper.getMainLooper()) runnable.run();
        else mainHandler.post(runnable);
    }
}
