Geo Zeta PDF a Audio - V29

Cambios V29:
- Corregido el render de banderas en Idioma de la aplicacion y Pais / Region usando recorte visual limpio (CENTER_CROP) para ocultar el borde/blanco lateral del asset.
- Corregida la alineacion vertical de la bandera y del texto en la fila de Region actual.
- Aplicado el mismo ajuste en la pantalla inicial de region y en la pantalla de Ajustes > Pais / Region.
- Se mantiene la deteccion de voces instalada por Android; si la pantalla Voces muestra "Instalada", la app la detecta como disponible en el motor TTS del telefono.
