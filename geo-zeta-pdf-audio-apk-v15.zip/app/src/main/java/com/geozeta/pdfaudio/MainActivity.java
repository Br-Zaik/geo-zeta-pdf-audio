package com.geozeta.pdfaudio;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.os.Environment;
import android.util.Base64;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 55);
        }

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidTTS");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.evaluateJavascript("window.syncNativePage && window.syncNativePage();", null);
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.evaluateJavascript("window.saveCurrentState && window.saveCurrentState();", null);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.evaluateJavascript("window.saveCurrentState && window.saveCurrentState();", null);
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private String safeName(String name, String fallback) {
        if (name == null || name.trim().isEmpty()) name = fallback;
        return name.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    private Uri saveBytes(byte[] data, String displayName, String mimeType, boolean image) throws Exception {
        displayName = safeName(displayName, image ? "pagina.png" : "texto.txt");
        ContentResolver resolver = getContentResolver();

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, (image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS) + "/PDF a Audio");

            Uri collection = image ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            Uri uri = resolver.insert(collection, values);
            if (uri == null) throw new Exception("No se pudo crear archivo.");
            OutputStream os = resolver.openOutputStream(uri);
            if (os == null) throw new Exception("No se pudo abrir archivo.");
            os.write(data);
            os.flush();
            os.close();
            return uri;
        } else {
            File dir = new File(getExternalFilesDir(image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS), "PDF a Audio");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, displayName);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(data);
            fos.flush();
            fos.close();
            return Uri.fromFile(file);
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void clearNativePages() { TtsForegroundService.clearPages(); }
        @JavascriptInterface public void addNativePage(String text) { TtsForegroundService.addPage(text == null ? "" : text); }
        @JavascriptInterface public int getNativePageCount() { return TtsForegroundService.getPageCount(); }

        @JavascriptInterface
        public void startBackgroundRead(int startIndex, int pageOffset, String title, float rate, float pitch) {
            Intent i = new Intent(MainActivity.this, TtsForegroundService.class);
            i.setAction(TtsForegroundService.ACTION_START);
            i.putExtra("startIndex", startIndex);
            i.putExtra("pageOffset", pageOffset);
            i.putExtra("title", title == null ? "PDF a Audio" : title);
            i.putExtra("rate", rate);
            i.putExtra("pitch", pitch);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        }

        @JavascriptInterface
        public void stopBackgroundRead() {
            Intent i = new Intent(MainActivity.this, TtsForegroundService.class);
            i.setAction(TtsForegroundService.ACTION_STOP);
            startService(i);
        }

        @JavascriptInterface
        public int getCurrentPage() {
            SharedPreferences p = getSharedPreferences(TtsForegroundService.PREFS, MODE_PRIVATE);
            return p.getInt("currentPage", 1);
        }

        @JavascriptInterface
        public boolean isReading() {
            SharedPreferences p = getSharedPreferences(TtsForegroundService.PREFS, MODE_PRIVATE);
            return p.getBoolean("isReading", false);
        }

        @JavascriptInterface
        public void shareText(String text, String title) {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "PDF a Audio" : title);
                send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                startActivity(Intent.createChooser(send, "Compartir texto"));
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "No se pudo compartir.", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface
        public void saveTextFile(String text, String filename, boolean share) {
            try {
                byte[] bytes = (text == null ? "" : text).getBytes(StandardCharsets.UTF_8);
                Uri uri = saveBytes(bytes, filename, "text/plain", false);
                Toast.makeText(MainActivity.this, "Texto guardado en Descargas/PDF a Audio", Toast.LENGTH_LONG).show();
                if (share) {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "Compartir archivo"));
                }
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "No se pudo guardar texto.", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface
        public void savePng(String dataUrl, String filename, boolean share) {
            try {
                if (dataUrl == null) throw new Exception("Imagen vacía.");
                String base64 = dataUrl.contains(",") ? dataUrl.substring(dataUrl.indexOf(",") + 1) : dataUrl;
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                Uri uri = saveBytes(bytes, filename, "image/png", true);
                Toast.makeText(MainActivity.this, "Imagen guardada en Pictures/PDF a Audio", Toast.LENGTH_LONG).show();
                if (share) {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("image/png");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "Compartir imagen"));
                }
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "No se pudo guardar imagen.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
