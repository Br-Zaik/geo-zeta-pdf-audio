# Geo Zeta PDF a Audio V15 limpia

Base limpia enfocada en estabilidad:
- Audio por bloques desde la página actual.
- No vuelve a página 1 al reproducir.
- Panel plegable con flecha.
- Zoom con dos dedos.
- Reglas rojas movibles.
- Modos visuales: normal, blanco y negro, sepia, oscuro, protección visual.
- Subrayado simple guardado por PDF y página.
- Compartir texto de página.
- Guardar o compartir página como PNG con subrayado.
- Sin Word ni funciones pesadas por ahora.
