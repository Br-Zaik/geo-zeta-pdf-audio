package com.geozeta.pdfaudio;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TextRepository {
    public interface TextCallback {
        void onText(String text);
    }

    private ExecutorService executor;
    private ExecutorService priorityExecutor;
    private Handler mainHandler;
    private Map<Integer, String> cache;
    private PDDocument document;
    private PDDocument priorityDocument;
    private File sourceFile;
    private volatile int preloadGeneration;
    private volatile boolean preloadRunning;
    private volatile int knownPageCount;
    private boolean rulesEnabled;
    private float ruleTop;
    private float ruleBottom;

    public TextRepository(Context context) {
        PDFBoxResourceLoader.init(context);
        executor = Executors.newSingleThreadExecutor();
        priorityExecutor = Executors.newSingleThreadExecutor();
        mainHandler = new Handler(Looper.getMainLooper());
        cache = new ConcurrentHashMap<Integer, String>();
        rulesEnabled = true;
        ruleTop = 0.08f;
        ruleBottom = 0.92f;
    }

    public synchronized void setRules(boolean enabled, float top, float bottom) {
        rulesEnabled = enabled;
        ruleTop = Math.max(0f, Math.min(top, 0.95f));
        ruleBottom = Math.max(0.05f, Math.min(bottom, 1f));
        if (ruleBottom <= ruleTop + 0.05f) {
            ruleTop = 0.08f;
            ruleBottom = 0.92f;
        }
        cache.clear();
    }

    public synchronized void open(final File file) {
        close();
        cache.clear();
        sourceFile = file;
        preloadGeneration++;
        preloadRunning = false;
        knownPageCount = 0;

        // Carga principal en segundo plano.
        executor.execute(new Runnable() {
            @Override
            public void run() {
                loadMainDocument(file);
            }
        });

        // Documento separado para Play. Evita esperar al caché completo.
        priorityExecutor.execute(new Runnable() {
            @Override
            public void run() {
                loadPriorityDocument(file);
            }
        });
    }

    private void loadMainDocument(File file) {
        try {
            synchronized (TextRepository.this) {
                if (document != null) return;
            }

            PDDocument doc = PDDocument.load(file);

            synchronized (TextRepository.this) {
                if (document == null) {
                    document = doc;
                    knownPageCount = doc.getNumberOfPages();
                } else {
                    try { doc.close(); } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void loadPriorityDocument(File file) {
        try {
            synchronized (TextRepository.this) {
                if (priorityDocument != null) return;
            }

            PDDocument doc = PDDocument.load(file);

            synchronized (TextRepository.this) {
                if (priorityDocument == null) {
                    priorityDocument = doc;
                    if (knownPageCount <= 0) knownPageCount = doc.getNumberOfPages();
                } else {
                    try { doc.close(); } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {
        }
    }


    public void getPageText(final int zeroBasedPage, final TextCallback callback) {
        getPageTextInternal(zeroBasedPage, callback, 0);
    }

    public String getCachedText(int page) {
        return cache.get(page);
    }

    public boolean isPageCached(int page) {
        return cache.containsKey(page);
    }

    public int getKnownPageCount() {
        return knownPageCount;
    }

    public void startFullPreload(final int startPage, final int totalPages) {
        final int generation = preloadGeneration;

        if (preloadRunning) return;
        preloadRunning = true;

        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // Espera corta al documento principal.
                    PDDocument doc = null;
                    for (int i = 0; i < 60; i++) {
                        synchronized (TextRepository.this) {
                            doc = document;
                        }
                        if (doc != null) break;
                        try { Thread.sleep(50); } catch (InterruptedException ignored) {}
                    }

                    if (doc == null) {
                        File f;
                        synchronized (TextRepository.this) {
                            f = sourceFile;
                        }
                        if (f == null || !f.exists()) return;
                        loadMainDocument(f);
                        synchronized (TextRepository.this) {
                            doc = document;
                        }
                    }

                    if (doc == null) return;

                    int total = totalPages > 0 ? totalPages : doc.getNumberOfPages();
                    knownPageCount = total;

                    // Primero desde la página visible hasta el final.
                    for (int p = Math.max(0, startPage); p < total && generation == preloadGeneration; p++) {
                        cachePageIfMissing(doc, p);
                    }

                    // Luego las anteriores.
                    for (int p = 0; p < Math.max(0, startPage) && generation == preloadGeneration; p++) {
                        cachePageIfMissing(doc, p);
                    }
                } catch (Exception ignored) {
                } finally {
                    preloadRunning = false;
                }
            }
        });
    }

    private void cachePageIfMissing(PDDocument doc, int page) {
        if (cache.containsKey(page)) return;
        try {
            String value = extractPageText(doc, page);
            cache.put(page, value);
        } catch (Exception ignored) {
        }
    }

    public void preloadAudioWindow(final int centerPage, final int radius, final int totalPages) {
        final int generation = preloadGeneration;

        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    PDDocument doc;
                    synchronized (TextRepository.this) {
                        doc = document;
                    }

                    if (doc == null) {
                        File f;
                        synchronized (TextRepository.this) {
                            f = sourceFile;
                        }
                        if (f == null || !f.exists()) return;
                        loadMainDocument(f);
                        synchronized (TextRepository.this) {
                            doc = document;
                        }
                    }

                    if (doc == null) return;

                    int total = totalPages > 0 ? totalPages : doc.getNumberOfPages();
                    knownPageCount = total;

                    int start = Math.max(0, centerPage);
                    int end = Math.min(total - 1, centerPage + Math.max(1, radius));

                    for (int p = start; p <= end && generation == preloadGeneration; p++) {
                        cachePageIfMissing(doc, p);
                    }

                    int backStart = Math.max(0, centerPage - Math.max(1, radius / 3));
                    for (int p = backStart; p < start && generation == preloadGeneration; p++) {
                        cachePageIfMissing(doc, p);
                    }
                } catch (Exception ignored) {
                }
            }
        });
    }

    public void getPageTextPriority(final int zeroBasedPage, final TextCallback callback) {
        String cached = cache.get(zeroBasedPage);
        if (cached != null) {
            final String value = cached;
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    callback.onText(value);
                }
            });
            return;
        }

        priorityExecutor.execute(new Runnable() {
            @Override
            public void run() {
                String result = "";

                try {
                    PDDocument doc = null;

                    for (int i = 0; i < 12; i++) {
                        synchronized (TextRepository.this) {
                            doc = priorityDocument;
                        }

                        if (doc != null) break;

                        File f;
                        synchronized (TextRepository.this) {
                            f = sourceFile;
                        }

                        if (f != null && f.exists()) {
                            loadPriorityDocument(f);
                        }

                        try { Thread.sleep(20); } catch (InterruptedException ignored) {}
                    }

                    if (doc != null) {
                        result = extractPageText(doc, zeroBasedPage);
                    } else {
                        File f;
                        synchronized (TextRepository.this) {
                            f = sourceFile;
                        }

                        if (f != null && f.exists()) {
                            PDDocument temp = null;
                            try {
                                temp = PDDocument.load(f);
                                result = extractPageText(temp, zeroBasedPage);
                            } finally {
                                if (temp != null) {
                                    try { temp.close(); } catch (Exception ignored) {}
                                }
                            }
                        }
                    }

                    cache.put(zeroBasedPage, result);
                } catch (Exception ignored) {
                }

                final String finalResult = result;
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onText(finalResult);
                    }
                });
            }
        });
    }

    private String extractPageText(PDDocument doc, int zeroBasedPage) throws Exception {
        if (doc == null) return "";

        synchronized (doc) {
            PDFTextStripper stripper;
            if (rulesEnabled) {
                stripper = new RuleTextStripper(ruleTop, ruleBottom);
            } else {
                stripper = new PDFTextStripper();
            }

            int page = zeroBasedPage + 1;
            stripper.setStartPage(page);
            stripper.setEndPage(page);
            return cleanSpeechText(stripper.getText(doc));
        }
    }

    private String cleanSpeechText(String value) {
        if (value == null) return "";

        String text = value.replace('\u00A0', ' ');
        text = text.replace('\r', '\n');

        // Quita líneas basura que TTS lee como "ene", números de página o letras sueltas.
        text = text.replaceAll("(?m)^\\s*[NnÑñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[A-ZÑ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[a-zñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[0-9]{1,4}\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[IVXLCDMivxlcdm]{1,8}\\s*$", "");

        // Quita encabezados comunes que se meten al audio.
        text = text.replaceAll("(?im)^\\s*pdf a audio\\s*$", "");
        text = text.replaceAll("(?im)^\\s*classroom.*$", "");
        text = text.replaceAll("(?im)^\\s*youkoso.*$", "");

        // Quita secuencias iniciales tipo "N N N" o "n n n".
        text = text.replaceFirst("(?i)^(\\s*[nñ]\\s+){1,10}", "");

        // Limpieza general sin destruir saltos útiles.
        text = text.replaceAll("[ \\t]{2,}", " ");
        text = text.replaceAll("\\n[ \\t]+", "\\n");
        text = text.replaceAll("\\n{3,}", "\\n\\n");

        return text.trim();
    }


    private void getPageTextInternal(final int zeroBasedPage, final TextCallback callback, final int attempt) {
        String cached = cache.get(zeroBasedPage);
        if (cached != null) {
            final String value = cached;
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    callback.onText(value);
                }
            });
            return;
        }

        executor.execute(new Runnable() {
            @Override
            public void run() {
                String text = "";

                try {
                    PDDocument doc;
                    synchronized (TextRepository.this) {
                        doc = document;
                    }

                    if (doc == null && attempt < 40) {
                        mainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                getPageTextInternal(zeroBasedPage, callback, attempt + 1);
                            }
                        }, 80);
                        return;
                    }

                    if (doc != null) {
                        text = extractPageText(doc, zeroBasedPage);
                        cache.put(zeroBasedPage, text);
                    }
                } catch (Exception ignored) {
                }

                final String result = text;
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onText(result);
                    }
                });
            }
        });
    }


    public boolean hasCachedText(int page) {
        return cache.containsKey(page);
    }

    public void prefetch(int fromPage, int count, int totalPages) {
        for (int i = 0; i < count; i++) {
            int p = fromPage + i;
            if (p >= 0 && p < totalPages && !cache.containsKey(p)) {
                getPageText(p, new TextCallback() {
                    @Override
                    public void onText(String text) {
                    }
                });
            }
        }
    }

    public synchronized void close() {
        try {
            if (document != null) document.close();
        } catch (Exception ignored) {
        }
        try {
            if (priorityDocument != null) priorityDocument.close();
        } catch (Exception ignored) {
        }
        document = null;
        priorityDocument = null;
        sourceFile = null;
        knownPageCount = 0;
        preloadRunning = false;
    }

    private static class RuleTextStripper extends PDFTextStripper {
        private final float topRatio;
        private final float bottomRatio;

        RuleTextStripper(float topRatio, float bottomRatio) throws java.io.IOException {
            super();
            this.topRatio = topRatio;
            this.bottomRatio = bottomRatio;
            setSortByPosition(true);
        }

        @Override
        protected void processTextPosition(TextPosition text) {
            float pageHeight = Math.max(1f, text.getPageHeight());
            float y = text.getYDirAdj() / pageHeight;

            if (y >= topRatio && y <= bottomRatio) {
                super.processTextPosition(text);
            }
        }
    }

}
