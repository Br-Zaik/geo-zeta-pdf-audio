# Geo Zeta PDF a Audio V44 Native Basic Highlight

Base:
- Hecha desde V43, sin tocar zoom ni audio principal.

Agregado:
- Modo Marcar.
- Colores básicos: amarillo, azul, verde y rojo.
- Subrayado/resaltado por zona arrastrando el dedo.
- Borrar último resaltado.
- Limpiar resaltados de la página actual.
- Guardado local de resaltados por PDF.

No agregado todavía:
- Guardar imagen PNG.
- Compartir imagen.
- Reglas arriba/abajo.
- OCR.
- Modo estudio.

Objetivo:
- Agregar marcado básico sin romper zoom ni audio.
