
package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfPageView extends View {
    public interface PageChangeListener {
        void onPageRendered(int pageIndex, int pageCount);
        void onError(String message);
        void onHighlightsChanged(String serialized);
    }

    private static class Highlight {
        int page;
        int color;
        float left;
        float top;
        float right;
        float bottom;

        Highlight(int page, int color, float left, float top, float right, float bottom) {
            this.page = page;
            this.color = color;
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
        }
    }

    private final Paint paint;
    private final Paint highlightPaint;
    private final Paint previewPaint;
    private final ExecutorService executor;
    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private Bitmap bitmap;
    private int pageIndex;
    private int pageCount;
    private boolean renderBusy;
    private int pendingPage;
    private int serial;
    private float zoom;
    private float panX;
    private float panY;
    private PageChangeListener listener;
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestureDetector;
    private final Object lock = new Object();

    private boolean markMode;
    private int markColor;
    private boolean draggingMark;
    private float markStartX;
    private float markStartY;
    private float markEndX;
    private float markEndY;
    private final Map<Integer, ArrayList<Highlight>> highlights;

    public PdfPageView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(238, 238, 238));
        paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);

        highlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        highlightPaint.setStyle(Paint.Style.FILL);

        previewPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        previewPaint.setStyle(Paint.Style.FILL);
        previewPaint.setColor(0x55FFD400);

        executor = Executors.newSingleThreadExecutor();
        pendingPage = -1;
        zoom = 1.0f;
        markMode = false;
        markColor = 0x66FFD400;
        highlights = new HashMap<Integer, ArrayList<Highlight>>();

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float oldZoom = zoom;
                zoom = clamp(zoom * detector.getScaleFactor(), 1.0f, 4.0f);
                float focusX = detector.getFocusX();
                float focusY = detector.getFocusY();
                panX = focusX - (focusX - panX) * (zoom / oldZoom);
                panY = focusY - (focusY - panY) * (zoom / oldZoom);
                clampPan();
                invalidate();
                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {
                requestRender();
            }
        });

        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (markMode) return true;
                if (zoom > 1.2f) {
                    zoom = 1.0f;
                    panX = 0f;
                    panY = 0f;
                } else {
                    zoom = 2.0f;
                    panX = e.getX() - e.getX() * zoom;
                    panY = e.getY() - e.getY() * zoom;
                    clampPan();
                }
                requestRender();
                invalidate();
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                if (markMode) return true;
                panX -= distanceX;
                panY -= distanceY;
                clampPan();
                invalidate();
                return true;
            }
        });
    }

    public void setPageChangeListener(PageChangeListener listener) {
        this.listener = listener;
    }

    public int getPageCount() {
        return pageCount;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setMarkMode(boolean enabled) {
        markMode = enabled;
        draggingMark = false;
        invalidate();
    }

    public boolean isMarkMode() {
        return markMode;
    }

    public void setMarkColor(int color) {
        markColor = color;
        previewPaint.setColor(color);
        invalidate();
    }

    public void undoLastHighlight() {
        ArrayList<Highlight> list = highlights.get(pageIndex);
        if (list != null && list.size() > 0) {
            list.remove(list.size() - 1);
            notifyHighlightsChanged();
            invalidate();
        }
    }

    public void clearPageHighlights() {
        highlights.remove(pageIndex);
        notifyHighlightsChanged();
        invalidate();
    }

    public void loadHighlights(String data) {
        highlights.clear();
        if (data == null || data.trim().length() == 0) {
            invalidate();
            return;
        }

        try {
            String[] items = data.split(";");
            for (String item : items) {
                String trimmed = item.trim();
                if (trimmed.length() == 0) continue;

                String[] p = trimmed.split(",");
                if (p.length != 6) continue;

                int page = Integer.parseInt(p[0]);
                int color = (int) Long.parseLong(p[1], 16);
                float left = Float.parseFloat(p[2]);
                float top = Float.parseFloat(p[3]);
                float right = Float.parseFloat(p[4]);
                float bottom = Float.parseFloat(p[5]);

                addHighlightObject(new Highlight(page, color, left, top, right, bottom), false);
            }
        } catch (Exception ignored) {
        }

        invalidate();
    }

    public String serializeHighlights() {
        StringBuilder builder = new StringBuilder();
        for (Map.Entry<Integer, ArrayList<Highlight>> entry : highlights.entrySet()) {
            ArrayList<Highlight> list = entry.getValue();
            if (list == null) continue;
            for (Highlight h : list) {
                builder.append(h.page).append(",");
                builder.append(Integer.toHexString(h.color)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.left)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.top)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.right)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.bottom)).append(";");
            }
        }
        return builder.toString();
    }

    public void openFile(File file) throws IOException {
        closeDocument();
        descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
        renderer = new PdfRenderer(descriptor);
        pageCount = renderer.getPageCount();
        pageIndex = 0;
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        requestRender();
    }

    public void showPage(int index) {
        if (renderer == null || pageCount <= 0) return;
        pageIndex = Math.max(0, Math.min(index, pageCount - 1));
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        requestRender();
    }

    public void nextPage() {
        showPage(pageIndex + 1);
    }

    public void previousPage() {
        showPage(pageIndex - 1);
    }

    public void fitPage() {
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        requestRender();
    }

    private void requestRender() {
        if (renderer == null || getWidth() <= 0 || getHeight() <= 0) return;

        if (renderBusy) {
            pendingPage = pageIndex;
            return;
        }

        renderBusy = true;
        final int requestedPage = pageIndex;
        final int token = ++serial;

        executor.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap produced = null;
                PdfRenderer.Page openedPage = null;
                try {
                    synchronized (lock) {
                        if (renderer == null) return;

                        openedPage = renderer.openPage(requestedPage);
                        int viewWidth = Math.max(320, getWidth());
                        float ratio = openedPage.getHeight() / (float) openedPage.getWidth();

                        int targetWidth = Math.round(viewWidth * zoom * 1.5f);
                        targetWidth = Math.max(viewWidth, Math.min(targetWidth, 3200));
                        int targetHeight = Math.round(targetWidth * ratio);
                        targetHeight = Math.max(1, Math.min(targetHeight, 4800));

                        produced = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
                        produced.eraseColor(Color.WHITE);
                        openedPage.render(produced, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    }

                    final Bitmap readyBitmap = produced;
                    produced = null;

                    post(new Runnable() {
                        @Override
                        public void run() {
                            applyRenderedBitmap(readyBitmap, token);
                        }
                    });
                } catch (Exception ex) {
                    if (produced != null && !produced.isRecycled()) {
                        produced.recycle();
                    }
                    post(new Runnable() {
                        @Override
                        public void run() {
                            notifyRenderError();
                        }
                    });
                } finally {
                    if (openedPage != null) {
                        try {
                            openedPage.close();
                        } catch (Exception ignored) {
                        }
                    }
                    post(new Runnable() {
                        @Override
                        public void run() {
                            finishRenderQueue();
                        }
                    });
                }
            }
        });
    }

    private void applyRenderedBitmap(Bitmap readyBitmap, int token) {
        if (token != serial) {
            if (readyBitmap != null && !readyBitmap.isRecycled()) readyBitmap.recycle();
            return;
        }

        Bitmap old = bitmap;
        bitmap = readyBitmap;
        if (old != null && !old.isRecycled()) old.recycle();

        clampPan();
        invalidate();

        if (listener != null) {
            listener.onPageRendered(pageIndex, pageCount);
        }
    }

    private void notifyRenderError() {
        if (listener != null) listener.onError("Error al renderizar PDF");
    }

    private void finishRenderQueue() {
        renderBusy = false;
        if (pendingPage >= 0) {
            int p = pendingPage;
            pendingPage = -1;
            pageIndex = p;
            requestRender();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        requestRender();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (bitmap == null || bitmap.isRecycled()) {
            Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            textPaint.setColor(Color.DKGRAY);
            textPaint.setTextSize(42f);
            textPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Abre un PDF", getWidth() / 2f, getHeight() / 2f, textPaint);
            return;
        }

        float displayWidth = getWidth() * zoom;
        float displayHeight = displayWidth * (bitmap.getHeight() / (float) bitmap.getWidth());

        if (displayWidth <= getWidth()) panX = (getWidth() - displayWidth) / 2f;
        if (displayHeight <= getHeight()) panY = (getHeight() - displayHeight) / 2f;

        RectF dst = new RectF(panX, panY, panX + displayWidth, panY + displayHeight);
        canvas.drawBitmap(bitmap, null, dst, paint);
        drawHighlights(canvas, dst);

        if (draggingMark) {
            RectF preview = makeRect(markStartX, markStartY, markEndX, markEndY);
            canvas.drawRect(preview, previewPaint);
        }
    }

    private void drawHighlights(Canvas canvas, RectF pageRect) {
        ArrayList<Highlight> list = highlights.get(pageIndex);
        if (list == null) return;

        for (Highlight h : list) {
            highlightPaint.setColor(h.color);
            RectF r = new RectF(
                    pageRect.left + h.left * pageRect.width(),
                    pageRect.top + h.top * pageRect.height(),
                    pageRect.left + h.right * pageRect.width(),
                    pageRect.top + h.bottom * pageRect.height()
            );
            canvas.drawRect(r, highlightPaint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (markMode && event.getPointerCount() == 1) {
            handleMarkTouch(event);
            return true;
        }

        scaleDetector.onTouchEvent(event);
        if (!scaleDetector.isInProgress()) gestureDetector.onTouchEvent(event);

        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            clampPan();
            invalidate();
        }
        return true;
    }

    private void handleMarkTouch(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            draggingMark = true;
            markStartX = event.getX();
            markStartY = event.getY();
            markEndX = markStartX;
            markEndY = markStartY;
            invalidate();
        } else if (action == MotionEvent.ACTION_MOVE) {
            markEndX = event.getX();
            markEndY = event.getY();
            invalidate();
        } else if (action == MotionEvent.ACTION_UP) {
            markEndX = event.getX();
            markEndY = event.getY();
            draggingMark = false;
            addHighlightFromScreen(markStartX, markStartY, markEndX, markEndY);
            invalidate();
        } else if (action == MotionEvent.ACTION_CANCEL) {
            draggingMark = false;
            invalidate();
        }
    }

    private void addHighlightFromScreen(float x1, float y1, float x2, float y2) {
        RectF pageRect = getCurrentPageRect();
        RectF r = makeRect(x1, y1, x2, y2);

        if (r.width() < 12 || r.height() < 8) {
            return;
        }

        if (!RectF.intersects(pageRect, r)) {
            return;
        }

        r.intersect(pageRect);

        float left = clamp((r.left - pageRect.left) / pageRect.width(), 0f, 1f);
        float top = clamp((r.top - pageRect.top) / pageRect.height(), 0f, 1f);
        float right = clamp((r.right - pageRect.left) / pageRect.width(), 0f, 1f);
        float bottom = clamp((r.bottom - pageRect.top) / pageRect.height(), 0f, 1f);

        addHighlightObject(new Highlight(pageIndex, markColor, left, top, right, bottom), true);
    }

    private void addHighlightObject(Highlight h, boolean notify) {
        ArrayList<Highlight> list = highlights.get(h.page);
        if (list == null) {
            list = new ArrayList<Highlight>();
            highlights.put(h.page, list);
        }
        list.add(h);
        if (notify) notifyHighlightsChanged();
    }

    private void notifyHighlightsChanged() {
        if (listener != null) {
            listener.onHighlightsChanged(serializeHighlights());
        }
    }

    private RectF getCurrentPageRect() {
        float displayWidth = getWidth() * zoom;
        float displayHeight = displayWidth * (bitmap.getHeight() / (float) bitmap.getWidth());
        if (displayWidth <= getWidth()) panX = (getWidth() - displayWidth) / 2f;
        if (displayHeight <= getHeight()) panY = (getHeight() - displayHeight) / 2f;
        return new RectF(panX, panY, panX + displayWidth, panY + displayHeight);
    }

    private RectF makeRect(float x1, float y1, float x2, float y2) {
        return new RectF(Math.min(x1, x2), Math.min(y1, y2), Math.max(x1, x2), Math.max(y1, y2));
    }

    private void clampPan() {
        if (bitmap == null) return;
        float displayWidth = getWidth() * zoom;
        float displayHeight = displayWidth * (bitmap.getHeight() / (float) bitmap.getWidth());

        if (displayWidth <= getWidth()) {
            panX = (getWidth() - displayWidth) / 2f;
        } else {
            panX = clamp(panX, getWidth() - displayWidth, 0f);
        }

        if (displayHeight <= getHeight()) {
            panY = (getHeight() - displayHeight) / 2f;
        } else {
            panY = clamp(panY, getHeight() - displayHeight, 0f);
        }
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public void closeDocument() {
        try {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            bitmap = null;
            if (renderer != null) renderer.close();
            if (descriptor != null) descriptor.close();
        } catch (Exception ignored) {
        }

        renderer = null;
        descriptor = null;
        pageCount = 0;
        pageIndex = 0;
    }
}
