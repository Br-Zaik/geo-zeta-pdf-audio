# Geo Zeta PDF a Audio V82

Correcciones de marcado y seguimiento visual sobre V81.

- Botón principal `Subrayar ON / Subrayar OFF`, con el estado real del visor.
- Se quitó de Ajustes el interruptor duplicado de Herramienta de marcado.
- Con Subrayar ON: un dedo marca texto y dos dedos desplazan o hacen zoom.
- Un dedo sobre una zona sin texto ya no mueve la página ni crea marcas enormes.
- Las coordenadas del texto se cargan al abrir y al cambiar de página para que el marcado responda desde el primer toque.
- Los subrayados guardados permanecen al cambiar de página y al volver a abrir el PDF.
- Al activar el seguimiento durante una lectura ya iniciada, la app solicita inmediatamente la frase y posición actuales al servicio TTS.
- El seguimiento se actualiza en la misma página sin esperar a pasar a la siguiente.
- Al cambiar manualmente de página se elimina el seguimiento anterior y se prepara la página nueva.

VersionCode: 82
VersionName: 82.0-mark-on-off-gesture-reading-sync
