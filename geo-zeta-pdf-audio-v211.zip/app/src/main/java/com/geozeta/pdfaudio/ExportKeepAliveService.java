package com.geozeta.pdfaudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * V211. Sostiene la creacion de audio mientras dura.
 *
 * El problema: "Crear audio" se sintetizaba entero dentro de la Activity, con
 * una notificacion normal. En cuanto el usuario salia de la app o se apagaba la
 * pantalla, Android metia el proceso en cache (y lo congela) y el progreso se
 * quedaba clavado a media barra, por ejemplo en 33 %.
 *
 * Este servicio no sintetiza nada. Solo hace dos cosas mientras el guardado
 * esta en marcha: mantener una notificacion en primer plano, que es lo que
 * impide que Android congele el proceso, y sostener un wakelock parcial para
 * que la CPU siga trabajando con la pantalla apagada. Cuando el guardado
 * termina o se cancela, suelta las dos cosas y se apaga solo.
 */
public class ExportKeepAliveService extends Service {

    public static final String ACTION_UPDATE = "com.geozeta.pdfaudio.EXPORT_UPDATE";
    public static final String ACTION_DONE = "com.geozeta.pdfaudio.EXPORT_DONE";
    public static final String ACTION_DISMISS = "com.geozeta.pdfaudio.EXPORT_DISMISS";

    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_TEXT = "text";
    public static final String EXTRA_PERCENT = "percent";
    public static final String EXTRA_CANCEL_LABEL = "cancelLabel";

    public static final String CHANNEL_ID = "pdf_audio_export_v119";
    public static final int NOTIFICATION_ID = 7714;

    private PowerManager.WakeLock wakeLock;
    private boolean foregroundStarted;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) {
            stopEverything(true);
            return START_NOT_STICKY;
        }
        String action = intent.getAction();

        if (ACTION_UPDATE.equals(action)) {
            String title = safe(intent.getStringExtra(EXTRA_TITLE));
            String text = safe(intent.getStringExtra(EXTRA_TEXT));
            String cancelLabel = safe(intent.getStringExtra(EXTRA_CANCEL_LABEL));
            int percent = Math.max(0, Math.min(100, intent.getIntExtra(EXTRA_PERCENT, 0)));
            Notification notification = buildNotification(title, text, percent, true, cancelLabel);
            if (!foregroundStarted) {
                try {
                    startForeground(NOTIFICATION_ID, notification);
                    foregroundStarted = true;
                } catch (Exception ignored) {
                    // Si el sistema rechaza el primer plano (restricciones de
                    // arranque), la grabacion sigue funcionando mientras la app
                    // este abierta: solo se pierde la proteccion contra el
                    // congelado. El servicio se aparta enseguida para no quedar
                    // colgado sin haber llamado a startForeground.
                    notifyDirect(notification);
                    releaseWakeLock();
                    stopSelf();
                    return START_NOT_STICKY;
                }
            } else {
                notifyDirect(notification);
            }
            acquireWakeLock();
            return START_NOT_STICKY;
        }

        if (ACTION_DONE.equals(action)) {
            String title = safe(intent.getStringExtra(EXTRA_TITLE));
            String text = safe(intent.getStringExtra(EXTRA_TEXT));
            releaseWakeLock();
            detachForeground(false);
            notifyDirect(buildNotification(title, text, 100, false, ""));
            stopSelf();
            return START_NOT_STICKY;
        }

        stopEverything(true);
        return START_NOT_STICKY;
    }

    private void stopEverything(boolean removeNotification) {
        releaseWakeLock();
        detachForeground(removeNotification);
        if (removeNotification) {
            NotificationManager manager =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) {
                try { manager.cancel(NOTIFICATION_ID); } catch (Exception ignored) { }
            }
        }
        stopSelf();
    }

    private void detachForeground(boolean removeNotification) {
        if (!foregroundStarted) return;
        foregroundStarted = false;
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                stopForeground(removeNotification
                        ? Service.STOP_FOREGROUND_REMOVE : Service.STOP_FOREGROUND_DETACH);
            } else {
                stopForeground(removeNotification);
            }
        } catch (Exception ignored) { }
    }

    private void acquireWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) return;
        try {
            PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
            if (power == null) return;
            wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    "GeoZeta:crearAudio");
            wakeLock.setReferenceCounted(false);
            // Tope de seguridad: si algo fallara, el wakelock nunca queda
            // colgado gastando bateria indefinidamente.
            wakeLock.acquire(60L * 60L * 1000L);
        } catch (Exception ignored) {
            wakeLock = null;
        }
    }

    private void releaseWakeLock() {
        if (wakeLock == null) return;
        try {
            if (wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) { }
        wakeLock = null;
    }

    private void notifyDirect(Notification notification) {
        NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        try { manager.notify(NOTIFICATION_ID, notification); } catch (Exception ignored) { }
    }

    private Notification buildNotification(String title, String text, int percent,
                                           boolean ongoing, String cancelLabel) {
        createChannel();
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int openFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) openFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent openPending = PendingIntent.getActivity(this, 0, openIntent, openFlags);

        builder.setSmallIcon(R.drawable.ic_notification_blank)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(openPending)
                .setOnlyAlertOnce(true)
                .setOngoing(ongoing)
                .setShowWhen(false);
        if (Build.VERSION.SDK_INT >= 21) {
            builder.setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setColor(0xFF08283A);
        }
        if (Build.VERSION.SDK_INT < 26) builder.setPriority(Notification.PRIORITY_LOW);

        if (ongoing) {
            builder.setProgress(100, percent, false);
            Intent cancelIntent = new Intent(MainActivity.ACTION_CANCEL_AUDIO_EXPORT);
            cancelIntent.setPackage(getPackageName());
            int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent cancelPending = PendingIntent.getBroadcast(
                    this, NOTIFICATION_ID, cancelIntent, pendingFlags);
            String label = cancelLabel.length() > 0
                    ? cancelLabel : UiStrings.translate(this, "Cancelar");
            builder.addAction(R.drawable.ic_notification_close, label, cancelPending);
        }
        return builder.build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                UiStrings.translate(this, "Creación de audio"),
                NotificationManager.IMPORTANCE_LOW);
        channel.setShowBadge(false);
        channel.enableVibration(false);
        channel.setSound(null, null);
        try { manager.createNotificationChannel(channel); } catch (Exception ignored) { }
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }

    @Override
    public void onDestroy() {
        releaseWakeLock();
        super.onDestroy();
    }
}
