package com.geozeta.pdfaudio;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Extrae y conserva el texto de cada pagina sin bloquear la interfaz.
 *
 * Hay dos documentos PDF independientes:
 * - urgentDocument: solo para la pagina visible/Play.
 * - backgroundDocument: para precarga e indexado completo.
 *
 * De esta forma, indexar un PDF grande nunca deja esperando al boton Play.
 */
public class TextRepository {

    private static final String TAG = "GeoZetaPDF";
    // El primer fragmento debe salir apenas haya unas pocas palabras utiles.
    // El resto de la pagina sigue extrayendose mientras el TTS ya esta hablando.
    private static final int FAST_START_MIN_CHARS = 12;
    // El fragmento de arranque se emite en cuanto hay una frase natural, pero se
    // deja crecer hasta este tamano cuando no aparece un punto cercano. Un
    // colchon mas grande evita que la voz alcance a la extraccion completa de
    // PDFBox y se quede en silencio tras la primera frase. No atrasa el arranque:
    // la primera orden hablada la sigue recortando el servicio a su primer trozo.
    private static final int FAST_START_TARGET_CHARS = 280;
    // Tamano minimo con el que se acepta cortar el arranque en una frase natural.
    // Debajo de esto se sigue acumulando para no emitir un colchon demasiado
    // corto que deje a la voz esperando enseguida.
    private static final int FAST_START_EARLY_EMIT_CHARS = 90;

    public interface TextCallback {
        void onText(String text);
    }

    private final Handler mainHandler;
    private final ExecutorService urgentExecutor;
    private final ExecutorService backgroundExecutor;
    /** Paginas completas que se conservan en memoria a la vez. */
    private static final int MAX_FULL_PAGES_IN_MEMORY = 40;
    /** Fragmentos de arranque rapido conservados en memoria a la vez. */
    private static final int MAX_FAST_PAGES_IN_MEMORY = 80;

    private final Map<Integer, String> memoryCache;
    private final Map<Integer, String> fastStartCache;
    private final Map<Integer, List<TextCallback>> urgentWaiters;
    private final Map<Integer, List<TextCallback>> fastStartWaiters;
    private final Object fastStartLock = new Object();
    private final AtomicInteger prioritySerial;
    private final AtomicInteger interactiveSerial;
    private volatile int latestPriorityPage = -1;
    private final Object urgentDocumentLock = new Object();
    private final Object backgroundDocumentLock = new Object();
    private final File cacheRoot;

    private volatile PDDocument urgentDocument;
    private volatile PDDocument backgroundDocument;
    private volatile File sourceFile;
    private volatile File activeCacheDir;
    private volatile int generation;
    private volatile int knownPageCount;
    private volatile boolean fullIndexRunning;
    private volatile int fullIndexGeneration = -1;
    private volatile long lastInteractiveAtMs;

    private volatile boolean rulesEnabled = true;
    private volatile float ruleTop = 0.08f;
    private volatile float ruleBottom = 0.92f;

    public TextRepository(Context context) {
        Context appContext = context.getApplicationContext();
        PDFBoxResourceLoader.init(appContext);
        mainHandler = new Handler(Looper.getMainLooper());
        // El hilo urgente extrae la pagina que el usuario esta por escuchar. Se
        // le da una prioridad Java levemente por encima de lo normal para que no
        // pierda CPU frente a hilos de fondo, pero SIN pasarse: una prioridad
        // demasiado alta en un hilo con trabajo sostenido de PDFBox puede robarle
        // ciclos al hilo principal en telefonos modestos y provocar un ANR. Un
        // solo escalon por encima de lo normal alcanza para adelantar la
        // extraccion sin ese riesgo.
        urgentExecutor = Executors.newSingleThreadExecutor(new java.util.concurrent.ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "PdfTextUrgent");
                try {
                    t.setPriority(Thread.NORM_PRIORITY + 1);
                } catch (Exception ignored) {
                }
                return t;
            }
        });
        backgroundExecutor = Executors.newSingleThreadExecutor();
        // Caches acotadas: un PDF de cientos de paginas llenaba la memoria sin
        // techo. Al desbordar se descarta la pagina usada hace mas tiempo; el
        // texto sigue estando en el cache de disco, asi que no se pierde nada.
        memoryCache = newBoundedCache(MAX_FULL_PAGES_IN_MEMORY);
        fastStartCache = newBoundedCache(MAX_FAST_PAGES_IN_MEMORY);
        urgentWaiters = new ConcurrentHashMap<Integer, List<TextCallback>>();
        fastStartWaiters = new ConcurrentHashMap<Integer, List<TextCallback>>();
        prioritySerial = new AtomicInteger();
        interactiveSerial = new AtomicInteger();
        cacheRoot = new File(appContext.getFilesDir(), "pdf_text_cache");
        if (!cacheRoot.exists()) cacheRoot.mkdirs();
    }

    /**
     * Mapa con limite de entradas y orden de acceso: la pagina que lleva mas
     * tiempo sin usarse es la primera en salir. Sincronizado porque lo usan el
     * hilo principal y los hilos de extraccion.
     */
    private static Map<Integer, String> newBoundedCache(final int maxEntries) {
        return java.util.Collections.synchronizedMap(
                new java.util.LinkedHashMap<Integer, String>(16, 0.75f, true) {
                    @Override
                    protected boolean removeEldestEntry(Map.Entry<Integer, String> eldest) {
                        return size() > maxEntries;
                    }
                });
    }

    public synchronized void setRules(boolean enabled, float top, float bottom) {
        float safeTop = Math.max(0f, Math.min(top, 0.95f));
        float safeBottom = Math.max(0.05f, Math.min(bottom, 1f));
        if (safeBottom <= safeTop + 0.05f) {
            safeTop = 0.08f;
            safeBottom = 0.92f;
        }

        boolean changed = rulesEnabled != enabled
                || Math.abs(ruleTop - safeTop) > 0.0001f
                || Math.abs(ruleBottom - safeBottom) > 0.0001f;

        rulesEnabled = enabled;
        ruleTop = safeTop;
        ruleBottom = safeBottom;

        if (changed) {
            generation++;
            memoryCache.clear();
            fastStartCache.clear();
            urgentWaiters.clear();
            fastStartWaiters.clear();
            latestPriorityPage = -1;
            prioritySerial.incrementAndGet();
            interactiveSerial.incrementAndGet();
            activeCacheDir = buildCacheDirectory(sourceFile);
            fullIndexRunning = false;
            fullIndexGeneration = -1;
        }
    }

    public synchronized void open(final File file) {
        generation++;
        memoryCache.clear();
        fastStartCache.clear();
        urgentWaiters.clear();
        fastStartWaiters.clear();
        latestPriorityPage = -1;
        prioritySerial.incrementAndGet();
        interactiveSerial.incrementAndGet();
        knownPageCount = 0;
        fullIndexRunning = false;
        fullIndexGeneration = -1;
        lastInteractiveAtMs = SystemClock.uptimeMillis();
        sourceFile = file;
        activeCacheDir = buildCacheDirectory(file);
        pruneOldCacheDirectories(activeCacheDir);
        // Cerrar aqui mismo el PDF anterior bloqueaba al que llama: el cierre
        // pide el mismo candado que sostiene la carga en curso de PDFBox, asi
        // que habia que esperar a que terminara de abrirse el documento viejo
        // antes de poder abrir el nuevo. El cierre viaja a los mismos hilos de
        // trabajo, donde ocurre en orden y sin frenar la app.
        closeDocumentsAsync();

        // Abre desde ya el documento URGENTE en su propio hilo. No bloquea la UI.
        // La solicitud de la pagina visible se encola detras de esta apertura y
        // reutiliza el mismo PDDocument, de modo que al tocar Play no tenga que
        // pagar primero el coste de PDDocument.load().
        final int openGeneration = generation;
        urgentExecutor.execute(new Runnable() {
            @Override
            public void run() {
                if (openGeneration != generation) return;
                ensureUrgentDocument(openGeneration);
            }
        });

        // El documento de fondo sigue sin abrirse aqui: indexado, paginas vecinas
        // y marcado deben esperar para no competir con la pagina visible/Play.
    }

    public String getCachedText(int page) {
        String cached = memoryCache.get(page);
        if (cached != null) return cached;

        // Los archivos de caché son muy pequeños (texto plano por página). Leer
        // uno de forma directa evita que Play tenga que esperar una vuelta por
        // el executor cuando esa página ya fue analizada en una sesión anterior.
        String diskValue = readPageFromDisk(page, generation);
        if (diskValue != null) {
            memoryCache.put(page, diskValue);
            return diskValue;
        }
        return null;
    }

    public String getFastStartText(int page) {
        String full = memoryCache.get(page);
        if (full != null) return makeFastStartText(full);

        String fast = fastStartCache.get(page);
        if (fast != null) return fast;

        // Al reabrir la app puede que la pagina completa aun no hubiera terminado
        // de extraerse en la sesion anterior. Conservamos tambien el fragmento
        // minimo para que el primer Play no vuelva a esperar a PDFBox.
        String diskFast = readFastStartFromDisk(page, generation);
        if (diskFast != null && diskFast.trim().length() > 0) {
            fastStartCache.put(page, diskFast);
            return diskFast;
        }
        return null;
    }

    /**
     * Entrega un fragmento inicial tan pronto como PDFBox encuentra suficiente
     * texto y, sin detener esa misma extraccion, entrega despues la pagina completa.
     */
    public void getPageTextFastStart(final int zeroBasedPage,
                                     final TextCallback fastCallback,
                                     final TextCallback fullCallback) {
        if (zeroBasedPage < 0) {
            postResult(fastCallback, "");
            postResult(fullCallback, "");
            return;
        }

        String full = getCachedText(zeroBasedPage);
        if (full != null) {
            postResult(fullCallback, full);
            return;
        }

        final int requestGeneration = generation;

        // Primero intenta recuperar las primeras palabras persistidas de la
        // ultima sesion. Es un archivo diminuto y permite restaurar la pagina
        // con texto audible listo incluso si la extraccion completa no termino.
        String persistedFast = getFastStartText(zeroBasedPage);
        String fast;
        synchronized (fastStartLock) {
            fast = persistedFast != null ? persistedFast : fastStartCache.get(zeroBasedPage);
            if (fast == null && fastCallback != null) {
                List<TextCallback> waiters = fastStartWaiters.get(zeroBasedPage);
                if (waiters == null) {
                    waiters = Collections.synchronizedList(new ArrayList<TextCallback>());
                    fastStartWaiters.put(zeroBasedPage, waiters);
                }
                waiters.add(fastCallback);
            }
        }
        if (fast != null && fastCallback != null) postResult(fastCallback, fast);

        getPageTextPriority(zeroBasedPage, new TextCallback() {
            @Override
            public void onText(String text) {
                String value = text == null ? "" : text;
                publishFastStart(zeroBasedPage, makeFastStartText(value), requestGeneration);
                if (fullCallback != null) fullCallback.onText(value);
            }
        });
    }

    public void noteInteractivePage(int page) {
        interactiveSerial.incrementAndGet();
        latestPriorityPage = page;
        lastInteractiveAtMs = SystemClock.uptimeMillis();
    }

    public boolean isPageCached(int page) {
        return memoryCache.containsKey(page);
    }



    /**
     * Solicitud normal (exportaciones y tareas no interactivas). Usa la cola de
     * fondo para que nunca se ponga delante de la página que el usuario quiere oír.
     */
    public void getPageText(final int zeroBasedPage, final TextCallback callback) {
        if (zeroBasedPage < 0) {
            postResult(callback, "");
            return;
        }
        String cached = memoryCache.get(zeroBasedPage);
        if (cached != null) {
            postResult(callback, cached);
            return;
        }
        final int requestGeneration = generation;
        backgroundExecutor.execute(new Runnable() {
            @Override
            public void run() {
                lowerBackgroundPriority();
                String result = "";
                try {
                    if (requestGeneration == generation) {
                        String diskValue = readPageFromDisk(zeroBasedPage, requestGeneration);
                        if (diskValue != null) {
                            result = diskValue;
                        } else {
                            PDDocument doc = ensureBackgroundDocument(requestGeneration);
                            if (doc != null && requestGeneration == generation) {
                                synchronized (backgroundDocumentLock) {
                                    if (doc == backgroundDocument && requestGeneration == generation) {
                                        result = extractPageText(doc, zeroBasedPage);
                                    }
                                }
                                writePageToDisk(zeroBasedPage, result, requestGeneration);
                            }
                        }
                    }
                } catch (Exception ignored) {
                    result = "";
                }
                if (requestGeneration == generation) {
                    memoryCache.put(zeroBasedPage, result == null ? "" : result);
                }
                postResult(callback, result == null ? "" : result);
            }
        });
    }

    /**
     * V210. Texto completo de la pagina SIN aplicar las reglas, para el guardado
     * de audio "pagina completa". No toca las caches normales: la lectura sigue
     * usando su propio texto recortado por las reglas.
     */
    public void getPageTextIgnoringRules(final int zeroBasedPage, final TextCallback callback) {
        if (zeroBasedPage < 0) {
            postResult(callback, "");
            return;
        }
        final int requestGeneration = generation;
        backgroundExecutor.execute(new Runnable() {
            @Override
            public void run() {
                lowerBackgroundPriority();
                String result = "";
                try {
                    if (requestGeneration == generation) {
                        PDDocument doc = ensureBackgroundDocument(requestGeneration);
                        if (doc != null && requestGeneration == generation) {
                            synchronized (backgroundDocumentLock) {
                                if (doc == backgroundDocument && requestGeneration == generation) {
                                    result = extractFullPageText(doc, zeroBasedPage);
                                }
                            }
                        }
                    }
                } catch (Exception ignored) {
                    result = "";
                }
                postResult(callback, result == null ? "" : result);
            }
        });
    }

    private String extractFullPageText(PDDocument doc, int zeroBasedPage) throws Exception {
        if (doc == null || zeroBasedPage < 0 || zeroBasedPage >= doc.getNumberOfPages()) return "";
        PDFTextStripper stripper = new PDFTextStripper();
        stripper.setSortByPosition(true);
        int page = zeroBasedPage + 1;
        stripper.setStartPage(page);
        stripper.setEndPage(page);
        return cleanSpeechText(stripper.getText(doc));
    }

    /**
     * Devuelve la pagina desde RAM/disco o la extrae con el documento urgente.
     * Las solicitudes simultaneas de la misma pagina se agrupan en una sola extraccion.
     */
    public void getPageTextPriority(final int zeroBasedPage, final TextCallback callback) {
        if (zeroBasedPage < 0) {
            postResult(callback, "");
            return;
        }

        String cached = memoryCache.get(zeroBasedPage);
        if (cached != null) {
            postResult(callback, cached);
            return;
        }

        interactiveSerial.incrementAndGet();
        latestPriorityPage = zeroBasedPage;
        List<TextCallback> created = Collections.synchronizedList(new ArrayList<TextCallback>());
        if (callback != null) created.add(callback);
        List<TextCallback> existing = urgentWaiters.putIfAbsent(zeroBasedPage, created);
        if (existing != null) {
            if (callback != null) existing.add(callback);
            return;
        }

        final int requestGeneration = generation;
        final int requestPrioritySerial = prioritySerial.incrementAndGet();
        urgentExecutor.execute(new Runnable() {
            @Override
            public void run() {
                raiseUrgentPriority();
                String result = "";
                boolean stale = requestPrioritySerial != prioritySerial.get()
                        || zeroBasedPage != latestPriorityPage;
                try {
                    if (!stale && requestGeneration == generation) {
                        String diskValue = readPageFromDisk(zeroBasedPage, requestGeneration);
                        if (diskValue != null) {
                            result = diskValue;
                        } else {
                            stale = requestPrioritySerial != prioritySerial.get()
                                    || zeroBasedPage != latestPriorityPage;
                            if (!stale) {
                                PDDocument doc = ensureUrgentDocument(requestGeneration);
                                stale = requestPrioritySerial != prioritySerial.get()
                                        || zeroBasedPage != latestPriorityPage;
                                if (!stale && doc != null && requestGeneration == generation) {
                                    synchronized (urgentDocumentLock) {
                                        if (doc == urgentDocument && requestGeneration == generation
                                                && requestPrioritySerial == prioritySerial.get()
                                                && zeroBasedPage == latestPriorityPage) {
                                            result = extractPageTextProgressive(
                                                    doc, zeroBasedPage, requestGeneration);
                                        } else {
                                            stale = true;
                                        }
                                    }
                                    if (!stale) writePageToDisk(zeroBasedPage, result, requestGeneration);
                                }
                            }
                        }
                    }
                } catch (Exception ignored) {
                    result = "";
                }

                if (!stale && requestGeneration == generation) {
                    memoryCache.put(zeroBasedPage, result == null ? "" : result);
                }

                final String finalResult = result == null ? "" : result;
                final List<TextCallback> callbacks = urgentWaiters.remove(zeroBasedPage);
                if (!stale && callbacks != null) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            synchronized (callbacks) {
                                for (TextCallback item : callbacks) {
                                    if (item != null) item.onText(finalResult);
                                }
                            }
                        }
                    });
                }
            }
        });
    }


    /**
     * Precarga un grupo pequeno alrededor de la pagina actual usando el documento de fondo.
     * Nunca ocupa la cola urgente de Play.
     */
    public void preloadAudioWindow(final int centerPage, final int radius, final int totalPages) {
        final int requestGeneration = generation;
        backgroundExecutor.execute(new Runnable() {
            @Override
            public void run() {
                lowerBackgroundPriority();
                PDDocument doc = ensureBackgroundDocument(requestGeneration);
                if (doc == null || requestGeneration != generation) return;

                int total = totalPages > 0 ? totalPages : doc.getNumberOfPages();
                knownPageCount = total;
                int safeCenter = Math.max(0, Math.min(centerPage, Math.max(0, total - 1)));
                int safeRadius = Math.max(1, radius);

                cachePageBackground(doc, safeCenter, requestGeneration);
                for (int distance = 1; distance <= safeRadius && requestGeneration == generation; distance++) {
                    int next = safeCenter + distance;
                    int previous = safeCenter - distance;
                    if (next < total) cachePageBackground(doc, next, requestGeneration);
                    if (previous >= 0 && distance <= Math.max(2, safeRadius / 3)) {
                        cachePageBackground(doc, previous, requestGeneration);
                    }
                }
            }
        });
    }

    /**
     * Indexa todo el PDF una sola vez y guarda cada pagina en disco.
     * Puede aumentar el almacenamiento usado, pero hace instantaneas las lecturas posteriores.
     */
    public synchronized void startFullPreload(final int startPage, final int totalPages) {
        if (totalPages <= 0 || sourceFile == null) return;
        if (fullIndexRunning && fullIndexGeneration == generation) return;

        fullIndexRunning = true;
        fullIndexGeneration = generation;
        final int requestGeneration = generation;
        final int safeStart = Math.max(0, Math.min(startPage, totalPages - 1));

        backgroundExecutor.execute(new Runnable() {
            @Override
            public void run() {
                lowerBackgroundPriority();
                try {
                    PDDocument doc = ensureBackgroundDocument(requestGeneration);
                    if (doc == null || requestGeneration != generation) return;
                    knownPageCount = totalPages;

                    // Completa primero desde la página visible hacia adelante.
                    // Cuando el usuario toca/navega, la cola de fondo se PAUSA
                    // brevemente en lugar de cancelarse; luego continúa sola.
                    for (int page = safeStart; page < totalPages
                            && requestGeneration == generation; page++) {
                        waitUntilInteractiveWorkIsQuiet(requestGeneration);
                        if (requestGeneration != generation) return;
                        cachePageBackground(doc, page, requestGeneration);
                    }

                    // Finalmente completa las páginas anteriores.
                    for (int page = 0; page < safeStart
                            && requestGeneration == generation; page++) {
                        waitUntilInteractiveWorkIsQuiet(requestGeneration);
                        if (requestGeneration != generation) return;
                        cachePageBackground(doc, page, requestGeneration);
                    }
                } catch (Exception ignored) {
                } finally {
                    if (requestGeneration == generation) {
                        fullIndexRunning = false;
                    }
                }
            }
        });
    }

    private void waitUntilInteractiveWorkIsQuiet(int requestGeneration) {
        while (requestGeneration == generation) {
            long sinceTouch = SystemClock.uptimeMillis() - lastInteractiveAtMs;
            if (sinceTouch >= 750L) return;
            try {
                Thread.sleep(90L);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    public void prefetch(int fromPage, int count, int totalPages) {
        preloadAudioWindow(fromPage, Math.max(1, count - 1), totalPages);
    }

    private void lowerBackgroundPriority() {
        try {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
        } catch (Exception ignored) {
        }
    }

    private void raiseUrgentPriority() {
        try {
            // Menos que el hilo de UI, pero por encima del resto: la extraccion
            // de la pagina que se va a escuchar no debe quedar relegada.
            android.os.Process.setThreadPriority(
                    android.os.Process.THREAD_PRIORITY_MORE_FAVORABLE);
        } catch (Exception ignored) {
        }
    }

    private void cachePageBackground(PDDocument doc, int page, int requestGeneration) {
        if (requestGeneration != generation || page < 0) return;
        if (memoryCache.containsKey(page)) return;

        try {
            String diskValue = readPageFromDisk(page, requestGeneration);
            if (diskValue != null) {
                memoryCache.put(page, diskValue);
                return;
            }

            String value;
            synchronized (backgroundDocumentLock) {
                if (doc != backgroundDocument || requestGeneration != generation) return;
                value = extractPageText(doc, page);
            }
            if (requestGeneration != generation) return;
            memoryCache.put(page, value == null ? "" : value);
            writePageToDisk(page, value, requestGeneration);
        } catch (Exception ignored) {
        }
    }

    private PDDocument ensureUrgentDocument(int requestGeneration) {
        if (requestGeneration != generation) return null;
        synchronized (urgentDocumentLock) {
            if (requestGeneration != generation) return null;
            if (urgentDocument != null) return urgentDocument;
            File file = sourceFile;
            if (file == null || !file.exists()) return null;
            try {
                urgentDocument = PDDocument.load(file);
                knownPageCount = urgentDocument.getNumberOfPages();
            } catch (Exception e) {
                Log.w(TAG, "No se pudo abrir el PDF (lectura prioritaria): "
                        + file.getName(), e);
                urgentDocument = null;
            }
            return urgentDocument;
        }
    }

    private PDDocument ensureBackgroundDocument(int requestGeneration) {
        if (requestGeneration != generation) return null;
        synchronized (backgroundDocumentLock) {
            if (requestGeneration != generation) return null;
            if (backgroundDocument != null) return backgroundDocument;
            File file = sourceFile;
            if (file == null || !file.exists()) return null;
            try {
                backgroundDocument = PDDocument.load(file);
                knownPageCount = backgroundDocument.getNumberOfPages();
            } catch (Exception e) {
                Log.w(TAG, "No se pudo abrir el PDF (lectura en segundo plano): "
                        + file.getName(), e);
                backgroundDocument = null;
            }
            return backgroundDocument;
        }
    }

    private String extractPageTextProgressive(PDDocument doc, int zeroBasedPage,
                                              int requestGeneration) throws Exception {
        if (doc == null || zeroBasedPage < 0 || zeroBasedPage >= doc.getNumberOfPages()) return "";

        ProgressiveTextStripper stripper = new ProgressiveTextStripper(
                rulesEnabled, ruleTop, ruleBottom, zeroBasedPage, requestGeneration);
        int page = zeroBasedPage + 1;
        stripper.setStartPage(page);
        stripper.setEndPage(page);
        String full = cleanSpeechText(stripper.getText(doc));
        publishFastStart(zeroBasedPage, makeFastStartText(full), requestGeneration);
        return full;
    }

    private String makeFastStartText(String value) {
        String text = cleanSpeechText(value);
        if (text.length() <= FAST_START_TARGET_CHARS) return text;

        int max = Math.min(FAST_START_TARGET_CHARS, text.length());
        int min = Math.min(FAST_START_MIN_CHARS, Math.max(1, max / 2));
        // Se busca el ULTIMO corte de frase dentro del objetivo, no el primero,
        // para entregar un colchon lo mas grande posible sin pasar el limite.
        // Un colchon mayor evita que la voz alcance a la extraccion completa.
        int lastStop = -1;
        for (int i = min; i < max; i++) {
            char c = text.charAt(i);
            if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':' || c == '\n') {
                lastStop = i;
            }
        }
        if (lastStop >= min) {
            return text.substring(0, lastStop + 1).trim();
        }
        for (int i = max - 1; i >= min; i--) {
            if (Character.isWhitespace(text.charAt(i))) {
                return text.substring(0, i).trim();
            }
        }
        return text.substring(0, max).trim();
    }

    private void publishFastStart(int page, String value, int requestGeneration) {
        if (requestGeneration != generation || page < 0 || value == null || value.trim().length() == 0) {
            return;
        }

        final String fast = value.trim();
        final List<TextCallback> callbacks;
        synchronized (fastStartLock) {
            if (requestGeneration != generation) return;
            if (fastStartCache.containsKey(page)) return;
            fastStartCache.put(page, fast);
            writeFastStartToDisk(page, fast, requestGeneration);
            callbacks = fastStartWaiters.remove(page);
        }

        if (callbacks != null) {
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    synchronized (callbacks) {
                        for (TextCallback callback : callbacks) {
                            if (callback != null) callback.onText(fast);
                        }
                    }
                }
            });
        }
    }

    private String extractPageText(PDDocument doc, int zeroBasedPage) throws Exception {
        if (doc == null || zeroBasedPage < 0 || zeroBasedPage >= doc.getNumberOfPages()) return "";

        PDFTextStripper stripper;
        if (rulesEnabled) {
            stripper = new RuleTextStripper(ruleTop, ruleBottom);
        } else {
            stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
        }

        int page = zeroBasedPage + 1;
        stripper.setStartPage(page);
        stripper.setEndPage(page);
        return cleanSpeechText(stripper.getText(doc));
    }

    private String readPageFromDisk(int page, int requestGeneration) {
        if (requestGeneration != generation) return null;
        File dir = activeCacheDir;
        if (dir == null) return null;
        File pageFile = new File(dir, "page_" + page + ".txt");
        if (!pageFile.exists()) return null;

        StringBuilder builder = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    new FileInputStream(pageFile), StandardCharsets.UTF_8));
            char[] buffer = new char[8192];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                builder.append(buffer, 0, read);
            }
            reader.close();
            return builder.toString();
        } catch (Exception ignored) {
            return null;
        }
    }

    private String readFastStartFromDisk(int page, int requestGeneration) {
        if (requestGeneration != generation) return null;
        File dir = activeCacheDir;
        if (dir == null) return null;
        File fastFile = new File(dir, "fast_" + page + ".txt");
        if (!fastFile.exists()) return null;

        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    new FileInputStream(fastFile), StandardCharsets.UTF_8));
            String value = reader.readLine();
            reader.close();
            return value == null ? null : value.trim();
        } catch (Exception ignored) {
            return null;
        }
    }

    private void writeFastStartToDisk(int page, String value, int requestGeneration) {
        if (requestGeneration != generation || value == null || value.trim().length() == 0) return;
        File dir = activeCacheDir;
        if (dir == null) return;
        if (!dir.exists() && !dir.mkdirs()) return;

        File fastFile = new File(dir, "fast_" + page + ".txt");
        File tempFile = new File(dir, "fast_" + page + ".tmp");
        try {
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(tempFile), StandardCharsets.UTF_8));
            writer.write(value.trim());
            writer.close();
            if (fastFile.exists()) fastFile.delete();
            if (!tempFile.renameTo(fastFile)) {
                FileInputStream input = new FileInputStream(tempFile);
                FileOutputStream output = new FileOutputStream(fastFile);
                byte[] buffer = new byte[256];
                int read;
                while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                input.close();
                output.close();
                tempFile.delete();
            }
        } catch (Exception ignored) {
            tempFile.delete();
        }
    }

    private void writePageToDisk(int page, String value, int requestGeneration) {
        if (requestGeneration != generation) return;
        File dir = activeCacheDir;
        if (dir == null) return;
        if (!dir.exists() && !dir.mkdirs()) return;

        File pageFile = new File(dir, "page_" + page + ".txt");
        File tempFile = new File(dir, "page_" + page + ".tmp");
        try {
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(tempFile), StandardCharsets.UTF_8));
            writer.write(value == null ? "" : value);
            writer.close();
            if (pageFile.exists()) pageFile.delete();
            if (!tempFile.renameTo(pageFile)) {
                FileInputStream input = new FileInputStream(tempFile);
                FileOutputStream output = new FileOutputStream(pageFile);
                byte[] buffer = new byte[8192];
                int read;
                while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                input.close();
                output.close();
                tempFile.delete();
            }
        } catch (Exception ignored) {
            tempFile.delete();
        }
    }

    private File buildCacheDirectory(File file) {
        if (file == null) return null;
        String signature = fileSignature(file)
                + "|" + rulesEnabled + "|" + String.format(Locale.US, "%.4f|%.4f", ruleTop, ruleBottom)
                // Version de la limpieza de texto. Al cambiarla, el texto que
                // quedo guardado con la limpieza anterior deja de usarse y se
                // vuelve a extraer. Sin esto, los PDF ya abiertos seguirian sin
                // encabezado ni numero de pagina aunque el codigo ya este bien.
                + "|c2";
        String key = sha256(signature);
        File dir = new File(cacheRoot, key);
        if (!dir.exists()) dir.mkdirs();
        else dir.setLastModified(System.currentTimeMillis());
        return dir;
    }

    /** Cuantas carpetas de cache (una por PDF distinto) se conservan a la vez. */
    private static final int MAX_CACHED_DOCUMENTS = 6;

    /**
     * Cada PDF abierto deja una carpeta de texto en cache que antes nunca se
     * borraba, ni siquiera si el PDF se eliminaba o se abrian docenas de
     * archivos distintos con el tiempo. Se conservan solo las carpetas de los
     * documentos usados mas recientemente y el resto se borra en segundo
     * plano. No toca la carpeta que se acaba de abrir (keepDir).
     */
    private void pruneOldCacheDirectories(final File keepDir) {
        backgroundExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    File[] dirs = cacheRoot.listFiles();
                    if (dirs == null || dirs.length <= MAX_CACHED_DOCUMENTS) return;
                    java.util.Arrays.sort(dirs, new java.util.Comparator<File>() {
                        @Override
                        public int compare(File a, File b) {
                            return Long.compare(b.lastModified(), a.lastModified());
                        }
                    });
                    for (int i = 0; i < dirs.length; i++) {
                        File dir = dirs[i];
                        if (keepDir != null && dir.equals(keepDir)) continue;
                        if (i < MAX_CACHED_DOCUMENTS) continue;
                        deleteDirectoryQuietly(dir);
                    }
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void deleteDirectoryQuietly(File dir) {
        File[] children = dir.listFiles();
        if (children != null) {
            for (File child : children) {
                if (child.isDirectory()) deleteDirectoryQuietly(child);
                else child.delete();
            }
        }
        dir.delete();
    }

    private String fileSignature(File file) {
        if (file == null) return "none";
        RandomAccessFile random = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            long length = file.length();
            digest.update(Long.toString(length).getBytes(StandardCharsets.UTF_8));
            random = new RandomAccessFile(file, "r");
            byte[] buffer = new byte[65536];
            int read = random.read(buffer);
            if (read > 0) digest.update(buffer, 0, read);
            if (length > buffer.length) {
                random.seek(Math.max(0, length - buffer.length));
                read = random.read(buffer);
                if (read > 0) digest.update(buffer, 0, read);
            }
            byte[] data = digest.digest();
            StringBuilder builder = new StringBuilder();
            for (byte item : data) builder.append(String.format(Locale.US, "%02x", item));
            return builder.toString();
        } catch (Exception ignored) {
            return file.getAbsolutePath() + "|" + file.length() + "|" + file.lastModified();
        } finally {
            if (random != null) {
                try { random.close(); } catch (Exception ignored) {}
            }
        }
    }

    private String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] data = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte item : data) builder.append(String.format(Locale.US, "%02x", item));
            return builder.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(value.hashCode());
        }
    }

    private void postResult(final TextCallback callback, final String value) {
        if (callback == null) return;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                callback.onText(value == null ? "" : value);
            }
        });
    }

    private String cleanSpeechText(String value) {
        if (value == null) return "";

        String text = value.replace('\u00A0', ' ');
        text = text.replace("\\r\\n", "\n");
        text = text.replace("\\n", "\n");
        text = text.replace("\\r", "\n");
        text = text.replace("/n", "\n");
        text = text.replace('\r', '\n');

        // Aqui habia una lista de borrados que se comia texto real del documento:
        //   - lineas que fueran solo un numero  -> borraba los numeros de pagina
        //   - lineas que fueran solo un numero romano
        //   - cualquier linea que empezara por "classroom" o por "youkoso"
        //   - la linea "pdf a audio"
        //   - lineas de una sola letra, mayuscula o minuscula
        // Las dos del medio estaban puestas a fuego para tapar el encabezado de
        // unos PDF concretos de prueba, y le borraban la linea entera a
        // cualquiera que leyera un documento con esas palabras. Ademas hacian
        // que el encabezado, el pie y el numero de pagina no se leyeran NUNCA,
        // ni siquiera con las reglas apagadas, que es justo lo contrario de lo
        // que el usuario espera. Quien decide que se lee y que no son las
        // reglas de arriba y abajo, no una lista de palabras escondida.
        //
        // Se conserva unicamente la limpieza de basura de extraccion real: los
        // saltos de linea escritos como texto y los guiones de corte de palabra.
        text = text.replaceFirst("(?i)^(\\s*[nñ]\\s+){1,10}", "");
        text = text.replaceAll("(?iu)([a-záéíóúüñ])-\\s*\\n\\s*([a-záéíóúüñ])", "$1$2");
        text = text.replaceAll("[ \\t]{2,}", " ");
        text = text.replaceAll("\\n[ \\t]+", "\n");
        text = text.replaceAll("\\n{3,}", "\n\n");
        return text.trim();
    }

    public synchronized void close() {
        generation++;
        sourceFile = null;
        activeCacheDir = null;
        knownPageCount = 0;
        fullIndexRunning = false;
        fullIndexGeneration = -1;
        memoryCache.clear();
        fastStartCache.clear();
        urgentWaiters.clear();
        fastStartWaiters.clear();
        interactiveSerial.incrementAndGet();
        closeDocumentsAsync();
    }

    /**
     * Cierra los documentos de PDFBox en sus propios hilos. Como cada executor
     * es de un solo hilo, el cierre se encola detras de cualquier carga en curso
     * y por delante de la carga siguiente, sin que nadie tenga que esperar.
     */
    private void closeDocumentsAsync() {
        try {
            urgentExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    synchronized (urgentDocumentLock) {
                        if (urgentDocument != null) {
                            try { urgentDocument.close(); } catch (Exception ignored) {}
                            urgentDocument = null;
                        }
                    }
                }
            });
        } catch (Exception ignored) {
        }
        try {
            backgroundExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    synchronized (backgroundDocumentLock) {
                        if (backgroundDocument != null) {
                            try { backgroundDocument.close(); } catch (Exception ignored) {}
                            backgroundDocument = null;
                        }
                    }
                }
            });
        } catch (Exception ignored) {
        }
    }

    private class ProgressiveTextStripper extends PDFTextStripper {
        private final boolean applyRules;
        private final float topRatio;
        private final float bottomRatio;
        private final int pageIndex;
        private final int requestGeneration;
        private final StringBuilder earlyText = new StringBuilder();
        private float lastY = Float.NaN;
        private float lastEndX = Float.NaN;
        private boolean published;

        ProgressiveTextStripper(boolean applyRules, float topRatio, float bottomRatio,
                                int pageIndex, int requestGeneration) throws java.io.IOException {
            super();
            this.applyRules = applyRules;
            this.topRatio = topRatio;
            this.bottomRatio = bottomRatio;
            this.pageIndex = pageIndex;
            this.requestGeneration = requestGeneration;
            setSortByPosition(true);
        }

        @Override
        protected void processTextPosition(TextPosition text) {
            float pageHeight = Math.max(1f, text.getPageHeight());
            float yRatio = text.getYDirAdj() / pageHeight;
            if (applyRules && (yRatio < topRatio || yRatio > bottomRatio)) return;

            captureEarlyText(text);
            super.processTextPosition(text);
        }

        private void captureEarlyText(TextPosition text) {
            if (published || requestGeneration != generation || text == null) return;
            String unicode = text.getUnicode();
            if (unicode == null || unicode.length() == 0) return;

            float x = text.getXDirAdj();
            float y = text.getYDirAdj();
            float height = Math.max(1f, text.getHeightDir());
            if (!Float.isNaN(lastY)) {
                if (Math.abs(y - lastY) > Math.max(2f, height * 0.65f)) {
                    earlyText.append('\n');
                } else if (!Float.isNaN(lastEndX)
                        && x - lastEndX > Math.max(1.2f, height * 0.22f)) {
                    earlyText.append(' ');
                }
            }
            earlyText.append(unicode);
            lastY = y;
            lastEndX = x + Math.max(0f, text.getWidthDirAdj());

            int length = earlyText.length();
            char last = unicode.charAt(unicode.length() - 1);
            boolean naturalStop = last == '.' || last == '!' || last == '?'
                    || last == ';' || last == ':' || last == '\n';
            // Se publica el arranque en la primera frase natural que ya tenga un
            // tamano audible razonable (>= EARLY, no solo unas letras sueltas), o
            // al llegar al colchon objetivo si no aparece ningun corte cercano.
            // Asi la voz arranca rapido pero con suficiente texto por delante
            // para no quedarse muda mientras PDFBox termina la pagina completa.
            int earlyEmit = Math.min(FAST_START_TARGET_CHARS, FAST_START_EARLY_EMIT_CHARS);
            if (length >= FAST_START_MIN_CHARS
                    && ((naturalStop && length >= earlyEmit)
                        || length >= FAST_START_TARGET_CHARS)) {
                String fast = makeFastStartText(earlyText.toString());
                if (fast.length() >= Math.min(FAST_START_MIN_CHARS, length)) {
                    published = true;
                    publishFastStart(pageIndex, fast, requestGeneration);
                }
            }
        }
    }

    private static class RuleTextStripper extends PDFTextStripper {
        private final float topRatio;
        private final float bottomRatio;

        RuleTextStripper(float topRatio, float bottomRatio) throws java.io.IOException {
            super();
            this.topRatio = topRatio;
            this.bottomRatio = bottomRatio;
            setSortByPosition(true);
        }

        @Override
        protected void processTextPosition(TextPosition text) {
            float pageHeight = Math.max(1f, text.getPageHeight());
            float y = text.getYDirAdj() / pageHeight;
            if (y >= topRatio && y <= bottomRatio) super.processTextPosition(text);
        }
    }
}
