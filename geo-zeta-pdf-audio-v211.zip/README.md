# Geo Zeta - PDF a Voz y Audio

Lector de PDF para Android con lectura en voz alta (TTS), disponible en
cinco idiomas: espanol, ingles, portugues, hindi e indonesio.

## Funciones

- Lectura en voz alta de PDFs con el motor TTS del propio dispositivo
- Reproduccion en segundo plano con controles en la notificacion
- Zoom independiente por pagina (cada pagina recuerda el suyo)
- Subrayado y marcado de texto sobre la pagina
- Exportar cualquier pagina como imagen PNG
- Reglas de recorte para ignorar encabezados y pies de pagina
- Seleccion de voz, velocidad y region

## Estructura

- `MainActivity.java` - interfaz principal y control general
- `PdfPageView.java` - renderizado de paginas, zoom, marcado
- `TextRepository.java` - extraccion y cache de texto
- `SelectionTextRepository.java` - texto para seleccion manual
- `TtsForegroundService.java` - reproduccion de audio en segundo plano
- `ExportKeepAliveService.java` - sostiene la creacion de audio mientras dura
- `TtsEngineManager.java` - gestion del motor de voz
- `UiStrings.java` - todos los textos en los cinco idiomas

## Compilacion

El proyecto compila por GitHub Actions (`.github/workflows/`), que genera:

- **APK debug** para instalar y probar directamente
- **AAB de release** firmado, listo para subir a Google Play

Para compilar en local hace falta crear un archivo `keystore.properties`
siguiendo el modelo de `keystore.properties.ejemplo`. Ese archivo y el
keystore nunca se suben al repositorio.

## Notas tecnicas

- `minSdk` 23, `targetSdk` 36
- PDFBox (`com.tom-roush:pdfbox-android`) para leer los PDF
- R8 activado en release; las reglas de `proguard-rules.pro` son
  necesarias para que PDFBox y BouncyCastle no fallen al ofuscar
- Los PDF se abren con el selector del sistema (SAF): no se piden
  permisos de almacenamiento

## V158

- Arranque visible inmediato: sin pantalla negra vacia al recrear la app.
- Tipo de PDF, Crear audio y Guardar PDF usan seleccion real; solo la flecha ejecuta.
- Colores personalizados de seguimiento/marcado se editan con un toque.
- La notificacion de creacion de audio incluye Cancelar y detiene el trabajo real.
- Guardar imagen muestra solo un indicador de carga transparente.
- El visor de imagenes usa previsualizaciones para evitar flashes oscuros entre paginas.
- Mis archivos mantiene una sola pantalla viva y carga duraciones de audio fuera del hilo principal.
- Los toques rapidos en Audios/Imagenes/PDF ya no pueden atravesar hacia Ajustes.
