package com.geozeta.pdfaudio;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Extrae y conserva el texto de cada pagina sin bloquear la interfaz.
 *
 * Hay dos documentos PDF independientes:
 * - urgentDocument: solo para la pagina visible/Play.
 * - backgroundDocument: para precarga e indexado completo.
 *
 * De esta forma, indexar un PDF grande nunca deja esperando al boton Play.
 */
public class TextRepository {
    public interface TextCallback {
        void onText(String text);
    }

    private final Handler mainHandler;
    private final ExecutorService urgentExecutor;
    private final ExecutorService backgroundExecutor;
    private final Map<Integer, String> memoryCache;
    private final Map<Integer, List<TextCallback>> urgentWaiters;
    private final Object urgentDocumentLock = new Object();
    private final Object backgroundDocumentLock = new Object();
    private final File cacheRoot;

    private volatile PDDocument urgentDocument;
    private volatile PDDocument backgroundDocument;
    private volatile File sourceFile;
    private volatile File activeCacheDir;
    private volatile int generation;
    private volatile int knownPageCount;
    private volatile boolean fullIndexRunning;
    private volatile int fullIndexGeneration = -1;

    private volatile boolean rulesEnabled = true;
    private volatile float ruleTop = 0.08f;
    private volatile float ruleBottom = 0.92f;

    public TextRepository(Context context) {
        Context appContext = context.getApplicationContext();
        PDFBoxResourceLoader.init(appContext);
        mainHandler = new Handler(Looper.getMainLooper());
        urgentExecutor = Executors.newSingleThreadExecutor();
        backgroundExecutor = Executors.newSingleThreadExecutor();
        memoryCache = new ConcurrentHashMap<Integer, String>();
        urgentWaiters = new ConcurrentHashMap<Integer, List<TextCallback>>();
        cacheRoot = new File(appContext.getFilesDir(), "pdf_text_cache");
        if (!cacheRoot.exists()) cacheRoot.mkdirs();
    }

    public synchronized void setRules(boolean enabled, float top, float bottom) {
        float safeTop = Math.max(0f, Math.min(top, 0.95f));
        float safeBottom = Math.max(0.05f, Math.min(bottom, 1f));
        if (safeBottom <= safeTop + 0.05f) {
            safeTop = 0.08f;
            safeBottom = 0.92f;
        }

        boolean changed = rulesEnabled != enabled
                || Math.abs(ruleTop - safeTop) > 0.0001f
                || Math.abs(ruleBottom - safeBottom) > 0.0001f;

        rulesEnabled = enabled;
        ruleTop = safeTop;
        ruleBottom = safeBottom;

        if (changed) {
            generation++;
            memoryCache.clear();
            urgentWaiters.clear();
            activeCacheDir = buildCacheDirectory(sourceFile);
            fullIndexRunning = false;
            fullIndexGeneration = -1;
        }
    }

    public synchronized void open(final File file) {
        generation++;
        memoryCache.clear();
        urgentWaiters.clear();
        knownPageCount = 0;
        fullIndexRunning = false;
        fullIndexGeneration = -1;
        sourceFile = file;
        activeCacheDir = buildCacheDirectory(file);
        closeDocuments();

        // No se abre ningun documento PDF de fondo aqui. La pagina visible/Play
        // debe ganar la primera carrera de CPU y disco. La precarga abre su propio
        // documento solo despues de que la pagina prioritaria ya fue entregada.
    }

    public String getCachedText(int page) {
        return memoryCache.get(page);
    }

    public boolean isPageCached(int page) {
        return memoryCache.containsKey(page);
    }

    public boolean hasCachedText(int page) {
        return isPageCached(page);
    }

    public int getKnownPageCount() {
        return knownPageCount;
    }

    /** Solicitud interactiva. Siempre usa la via urgente. */
    public void getPageText(final int zeroBasedPage, final TextCallback callback) {
        getPageTextPriority(zeroBasedPage, callback);
    }

    /**
     * Devuelve la pagina desde RAM/disco o la extrae con el documento urgente.
     * Las solicitudes simultaneas de la misma pagina se agrupan en una sola extraccion.
     */
    public void getPageTextPriority(final int zeroBasedPage, final TextCallback callback) {
        if (zeroBasedPage < 0) {
            postResult(callback, "");
            return;
        }

        String cached = memoryCache.get(zeroBasedPage);
        if (cached != null) {
            postResult(callback, cached);
            return;
        }

        List<TextCallback> created = Collections.synchronizedList(new ArrayList<TextCallback>());
        if (callback != null) created.add(callback);
        List<TextCallback> existing = urgentWaiters.putIfAbsent(zeroBasedPage, created);
        if (existing != null) {
            if (callback != null) existing.add(callback);
            return;
        }

        final int requestGeneration = generation;
        urgentExecutor.execute(new Runnable() {
            @Override
            public void run() {
                String result = "";
                try {
                    if (requestGeneration == generation) {
                        String diskValue = readPageFromDisk(zeroBasedPage, requestGeneration);
                        if (diskValue != null) {
                            result = diskValue;
                        } else {
                            PDDocument doc = ensureUrgentDocument(requestGeneration);
                            if (doc != null && requestGeneration == generation) {
                                synchronized (urgentDocumentLock) {
                                    if (doc == urgentDocument && requestGeneration == generation) {
                                        result = extractPageText(doc, zeroBasedPage);
                                    }
                                }
                                writePageToDisk(zeroBasedPage, result, requestGeneration);
                            }
                        }
                    }
                } catch (Exception ignored) {
                    result = "";
                }

                if (requestGeneration == generation) {
                    memoryCache.put(zeroBasedPage, result == null ? "" : result);
                }

                final String finalResult = result == null ? "" : result;
                final List<TextCallback> callbacks = urgentWaiters.remove(zeroBasedPage);
                if (callbacks != null) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            synchronized (callbacks) {
                                for (TextCallback item : callbacks) {
                                    if (item != null) item.onText(finalResult);
                                }
                            }
                        }
                    });
                }
            }
        });
    }

    /** Prepara la pagina visible con prioridad maxima. */
    public void prepareVisiblePage(int page, TextCallback callback) {
        getPageTextPriority(page, callback);
    }

    /**
     * Precarga un grupo pequeno alrededor de la pagina actual usando el documento de fondo.
     * Nunca ocupa la cola urgente de Play.
     */
    public void preloadAudioWindow(final int centerPage, final int radius, final int totalPages) {
        final int requestGeneration = generation;
        backgroundExecutor.execute(new Runnable() {
            @Override
            public void run() {
                lowerBackgroundPriority();
                PDDocument doc = ensureBackgroundDocument(requestGeneration);
                if (doc == null || requestGeneration != generation) return;

                int total = totalPages > 0 ? totalPages : doc.getNumberOfPages();
                knownPageCount = total;
                int safeCenter = Math.max(0, Math.min(centerPage, Math.max(0, total - 1)));
                int safeRadius = Math.max(1, radius);

                cachePageBackground(doc, safeCenter, requestGeneration);
                for (int distance = 1; distance <= safeRadius && requestGeneration == generation; distance++) {
                    int next = safeCenter + distance;
                    int previous = safeCenter - distance;
                    if (next < total) cachePageBackground(doc, next, requestGeneration);
                    if (previous >= 0 && distance <= Math.max(2, safeRadius / 3)) {
                        cachePageBackground(doc, previous, requestGeneration);
                    }
                }
            }
        });
    }

    /**
     * Indexa todo el PDF una sola vez y guarda cada pagina en disco.
     * Puede aumentar el almacenamiento usado, pero hace instantaneas las lecturas posteriores.
     */
    public synchronized void startFullPreload(final int startPage, final int totalPages) {
        if (totalPages <= 0 || sourceFile == null) return;
        if (fullIndexRunning && fullIndexGeneration == generation) return;

        fullIndexRunning = true;
        fullIndexGeneration = generation;
        final int requestGeneration = generation;
        final int safeStart = Math.max(0, Math.min(startPage, totalPages - 1));

        backgroundExecutor.execute(new Runnable() {
            @Override
            public void run() {
                lowerBackgroundPriority();
                try {
                    PDDocument doc = ensureBackgroundDocument(requestGeneration);
                    if (doc == null || requestGeneration != generation) return;
                    knownPageCount = totalPages;

                    // Primero la zona visible y lo que sigue.
                    for (int page = safeStart; page < totalPages && requestGeneration == generation; page++) {
                        cachePageBackground(doc, page, requestGeneration);
                    }
                    // Despues completa las paginas anteriores.
                    for (int page = 0; page < safeStart && requestGeneration == generation; page++) {
                        cachePageBackground(doc, page, requestGeneration);
                    }
                } catch (Exception ignored) {
                } finally {
                    if (requestGeneration == generation) {
                        fullIndexRunning = false;
                    }
                }
            }
        });
    }

    public void prefetch(int fromPage, int count, int totalPages) {
        preloadAudioWindow(fromPage, Math.max(1, count - 1), totalPages);
    }

    private void lowerBackgroundPriority() {
        try {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
        } catch (Exception ignored) {
        }
    }

    private void cachePageBackground(PDDocument doc, int page, int requestGeneration) {
        if (requestGeneration != generation || page < 0) return;
        if (memoryCache.containsKey(page)) return;

        try {
            String diskValue = readPageFromDisk(page, requestGeneration);
            if (diskValue != null) {
                memoryCache.put(page, diskValue);
                return;
            }

            String value;
            synchronized (backgroundDocumentLock) {
                if (doc != backgroundDocument || requestGeneration != generation) return;
                value = extractPageText(doc, page);
            }
            if (requestGeneration != generation) return;
            memoryCache.put(page, value == null ? "" : value);
            writePageToDisk(page, value, requestGeneration);
        } catch (Exception ignored) {
        }
    }

    private PDDocument ensureUrgentDocument(int requestGeneration) {
        if (requestGeneration != generation) return null;
        synchronized (urgentDocumentLock) {
            if (requestGeneration != generation) return null;
            if (urgentDocument != null) return urgentDocument;
            File file = sourceFile;
            if (file == null || !file.exists()) return null;
            try {
                urgentDocument = PDDocument.load(file);
                knownPageCount = urgentDocument.getNumberOfPages();
            } catch (Exception ignored) {
                urgentDocument = null;
            }
            return urgentDocument;
        }
    }

    private PDDocument ensureBackgroundDocument(int requestGeneration) {
        if (requestGeneration != generation) return null;
        synchronized (backgroundDocumentLock) {
            if (requestGeneration != generation) return null;
            if (backgroundDocument != null) return backgroundDocument;
            File file = sourceFile;
            if (file == null || !file.exists()) return null;
            try {
                backgroundDocument = PDDocument.load(file);
                knownPageCount = backgroundDocument.getNumberOfPages();
            } catch (Exception ignored) {
                backgroundDocument = null;
            }
            return backgroundDocument;
        }
    }

    private String extractPageText(PDDocument doc, int zeroBasedPage) throws Exception {
        if (doc == null || zeroBasedPage < 0 || zeroBasedPage >= doc.getNumberOfPages()) return "";

        PDFTextStripper stripper;
        if (rulesEnabled) {
            stripper = new RuleTextStripper(ruleTop, ruleBottom);
        } else {
            stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
        }

        int page = zeroBasedPage + 1;
        stripper.setStartPage(page);
        stripper.setEndPage(page);
        return cleanSpeechText(stripper.getText(doc));
    }

    private String readPageFromDisk(int page, int requestGeneration) {
        if (requestGeneration != generation) return null;
        File dir = activeCacheDir;
        if (dir == null) return null;
        File pageFile = new File(dir, "page_" + page + ".txt");
        if (!pageFile.exists()) return null;

        StringBuilder builder = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    new FileInputStream(pageFile), StandardCharsets.UTF_8));
            char[] buffer = new char[8192];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                builder.append(buffer, 0, read);
            }
            reader.close();
            return builder.toString();
        } catch (Exception ignored) {
            return null;
        }
    }

    private void writePageToDisk(int page, String value, int requestGeneration) {
        if (requestGeneration != generation) return;
        File dir = activeCacheDir;
        if (dir == null) return;
        if (!dir.exists() && !dir.mkdirs()) return;

        File pageFile = new File(dir, "page_" + page + ".txt");
        File tempFile = new File(dir, "page_" + page + ".tmp");
        try {
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(tempFile), StandardCharsets.UTF_8));
            writer.write(value == null ? "" : value);
            writer.close();
            if (pageFile.exists()) pageFile.delete();
            if (!tempFile.renameTo(pageFile)) {
                FileInputStream input = new FileInputStream(tempFile);
                FileOutputStream output = new FileOutputStream(pageFile);
                byte[] buffer = new byte[8192];
                int read;
                while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                input.close();
                output.close();
                tempFile.delete();
            }
        } catch (Exception ignored) {
            tempFile.delete();
        }
    }

    private File buildCacheDirectory(File file) {
        if (file == null) return null;
        String signature = fileSignature(file)
                + "|" + rulesEnabled + "|" + String.format(Locale.US, "%.4f|%.4f", ruleTop, ruleBottom);
        String key = sha256(signature);
        File dir = new File(cacheRoot, key);
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private String fileSignature(File file) {
        if (file == null) return "none";
        RandomAccessFile random = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            long length = file.length();
            digest.update(Long.toString(length).getBytes(StandardCharsets.UTF_8));
            random = new RandomAccessFile(file, "r");
            byte[] buffer = new byte[65536];
            int read = random.read(buffer);
            if (read > 0) digest.update(buffer, 0, read);
            if (length > buffer.length) {
                random.seek(Math.max(0, length - buffer.length));
                read = random.read(buffer);
                if (read > 0) digest.update(buffer, 0, read);
            }
            byte[] data = digest.digest();
            StringBuilder builder = new StringBuilder();
            for (byte item : data) builder.append(String.format(Locale.US, "%02x", item));
            return builder.toString();
        } catch (Exception ignored) {
            return file.getAbsolutePath() + "|" + file.length() + "|" + file.lastModified();
        } finally {
            if (random != null) {
                try { random.close(); } catch (Exception ignored) {}
            }
        }
    }

    private String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] data = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte item : data) builder.append(String.format(Locale.US, "%02x", item));
            return builder.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(value.hashCode());
        }
    }

    private void postResult(final TextCallback callback, final String value) {
        if (callback == null) return;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                callback.onText(value == null ? "" : value);
            }
        });
    }

    private String cleanSpeechText(String value) {
        if (value == null) return "";

        String text = value.replace('\u00A0', ' ');
        text = text.replace("\\r\\n", "\n");
        text = text.replace("\\n", "\n");
        text = text.replace("\\r", "\n");
        text = text.replace("/n", "\n");
        text = text.replace('\r', '\n');

        text = text.replaceAll("(?m)^\\s*[\\\\/]*[NnÑñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[A-ZÑ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[a-zñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[0-9]{1,4}\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[IVXLCDMivxlcdm]{1,8}\\s*$", "");
        text = text.replaceAll("(?im)^\\s*pdf a audio\\s*$", "");
        text = text.replaceAll("(?im)^\\s*classroom.*$", "");
        text = text.replaceAll("(?im)^\\s*youkoso.*$", "");
        text = text.replaceFirst("(?i)^(\\s*[nñ]\\s+){1,10}", "");
        text = text.replaceAll("(?i)(^|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-])[nñ](?=($|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-]))", "$1");
        text = text.replaceAll("(?iu)([a-záéíóúüñ])-\\s*\\n\\s*([a-záéíóúüñ])", "$1$2");
        text = text.replaceAll("[ \\t]{2,}", " ");
        text = text.replaceAll("\\n[ \\t]+", "\n");
        text = text.replaceAll("\\n{3,}", "\n\n");
        return text.trim();
    }

    public synchronized void close() {
        generation++;
        sourceFile = null;
        activeCacheDir = null;
        knownPageCount = 0;
        fullIndexRunning = false;
        fullIndexGeneration = -1;
        memoryCache.clear();
        urgentWaiters.clear();
        closeDocuments();
    }

    private void closeDocuments() {
        synchronized (urgentDocumentLock) {
            if (urgentDocument != null) {
                try { urgentDocument.close(); } catch (Exception ignored) {}
                urgentDocument = null;
            }
        }
        synchronized (backgroundDocumentLock) {
            if (backgroundDocument != null) {
                try { backgroundDocument.close(); } catch (Exception ignored) {}
                backgroundDocument = null;
            }
        }
    }

    private static class RuleTextStripper extends PDFTextStripper {
        private final float topRatio;
        private final float bottomRatio;

        RuleTextStripper(float topRatio, float bottomRatio) throws java.io.IOException {
            super();
            this.topRatio = topRatio;
            this.bottomRatio = bottomRatio;
            setSortByPosition(true);
        }

        @Override
        protected void processTextPosition(TextPosition text) {
            float pageHeight = Math.max(1f, text.getPageHeight());
            float y = text.getYDirAdj() / pageHeight;
            if (y >= topRatio && y <= bottomRatio) super.processTextPosition(text);
        }
    }
}
