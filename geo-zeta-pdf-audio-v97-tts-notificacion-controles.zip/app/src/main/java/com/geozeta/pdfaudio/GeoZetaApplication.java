package com.geozeta.pdfaudio;

import android.app.Application;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;

/**
 * Starts the process-wide TTS engine as early as possible.
 *
 * The silent prime is intentionally tiny: it makes the first real Play request
 * react faster without changing the foreground service or background playback.
 */
public class GeoZetaApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        manager.initialize(new TtsEngineManager.ReadyCallback() {
            @Override
            public void onReady(String enginePackage) {
                Bundle params = new Bundle();
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 0.0f);
                manager.speak("a", TextToSpeech.QUEUE_FLUSH, params,
                        "APP_INSTANT_PLAY_PRIME");
            }

            @Override
            public void onError(String message) {
                // The normal retry/fallback flow remains in TtsEngineManager.
            }
        });
    }
}
