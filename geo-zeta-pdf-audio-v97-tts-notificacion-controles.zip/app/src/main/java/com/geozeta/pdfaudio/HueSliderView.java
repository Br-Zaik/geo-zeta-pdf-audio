package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Smooth horizontal hue selector. Uses a cached gradient shader instead of a bitmap. */
public class HueSliderView extends View {
    public interface OnHueChangedListener {
        void onHueChanged(float hue);
    }

    private final Paint huePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indicatorOuterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indicatorInnerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clipPath = new Path();
    private int shaderWidth = -1;
    private float hue = 0f;
    private OnHueChangedListener listener;

    public HueSliderView(Context context) {
        this(context, null);
    }

    public HueSliderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setClickable(true);

        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(1));
        borderPaint.setColor(Color.rgb(148, 163, 184));

        indicatorOuterPaint.setStyle(Paint.Style.STROKE);
        indicatorOuterPaint.setStrokeWidth(dp(3));
        indicatorOuterPaint.setColor(Color.WHITE);

        indicatorInnerPaint.setStyle(Paint.Style.STROKE);
        indicatorInnerPaint.setStrokeWidth(dp(1.2f));
        indicatorInnerPaint.setColor(Color.rgb(15, 23, 42));
    }

    public void setOnHueChangedListener(OnHueChangedListener listener) {
        this.listener = listener;
    }

    public void setHue(float hueValue) {
        hue = normalizeHue(hueValue);
        invalidate();
    }

    public float getHue() {
        return hue;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        shaderWidth = -1;
    }

    private void ensureShader() {
        int width = Math.max(1, getWidth());
        if (width == shaderWidth) return;
        int[] colors = new int[]{
                Color.RED,
                Color.YELLOW,
                Color.GREEN,
                Color.CYAN,
                Color.BLUE,
                Color.MAGENTA,
                Color.RED
        };
        huePaint.setShader(new LinearGradient(0f, 0f, width, 0f, colors, null, Shader.TileMode.CLAMP));
        shaderWidth = width;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ensureShader();
        RectF rect = new RectF(0f, 0f, getWidth(), getHeight());
        float radius = getHeight() / 2f;
        int save = canvas.save();
        clipPath.reset();
        clipPath.addRoundRect(rect, radius, radius, Path.Direction.CW);
        canvas.clipPath(clipPath);
        canvas.drawRect(rect, huePaint);
        canvas.restoreToCount(save);

        RectF border = new RectF(dp(0.5f), dp(0.5f), getWidth() - dp(0.5f), getHeight() - dp(0.5f));
        canvas.drawRoundRect(border, radius, radius, borderPaint);

        float x = (hue / 360f) * Math.max(1f, getWidth() - 1f);
        float indicatorRadius = Math.max(dp(7), getHeight() * 0.36f);
        canvas.drawCircle(x, getHeight() / 2f, indicatorRadius, indicatorOuterPaint);
        canvas.drawCircle(x, getHeight() / 2f, Math.max(dp(4), indicatorRadius - dp(2)), indicatorInnerPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            float x = Math.max(0f, Math.min(event.getX(), Math.max(1f, getWidth() - 1f)));
            hue = (x / Math.max(1f, getWidth() - 1f)) * 360f;
            if (listener != null) listener.onHueChanged(hue);
            postInvalidateOnAnimation();
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            performClick();
            return true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private float normalizeHue(float value) {
        float result = value % 360f;
        if (result < 0f) result += 360f;
        return result;
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
