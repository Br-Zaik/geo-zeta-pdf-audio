Geo Zeta PDF a Audio - V28

Cambios V28:
- Detecta automaticamente el idioma del PDF entre espanol, ingles, portugues, hindi e indonesio.
- Guarda el idioma detectado por PDF para no analizarlo de nuevo en cada apertura.
- Selecciona automaticamente una voz TTS compatible y prioriza una voz offline cuando existe.
- Usa Pais/Region para preferir el acento compatible cuando el motor TTS lo ofrece.
- Nueva pantalla Ajustes > Voces para ver voces instaladas, solo en linea o faltantes.
- Si falta una voz, ofrece acceso al instalador de datos TTS de Android.
- Si el idioma no se detecta con suficiente seguridad, permite elegirlo manualmente entre los 5 idiomas.
- Mantiene Play rapido, pagina guardada, cache, reproduccion en segundo plano, marcadores y exportacion.
