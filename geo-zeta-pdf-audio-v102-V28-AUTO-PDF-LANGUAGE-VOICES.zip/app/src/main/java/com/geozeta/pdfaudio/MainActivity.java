package com.geozeta.pdfaudio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.pdf.PdfDocument;
import android.media.MediaPlayer;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.LruCache;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.GridLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.graphics.Typeface;
import android.widget.Toast;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.content.DialogInterface;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.text.TextUtils;
import android.text.Editable;
import android.text.TextWatcher;
import android.webkit.MimeTypeMap;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.text.SimpleDateFormat;
import java.text.Normalizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_OPEN_PDF = 1001;
    private static final String PREF_TTS_ACTIVE = "tts_service_active";
    private static final String PREF_TTS_PAUSED = "tts_service_paused";
    private static final String PREF_TTS_CURRENT_PAGE = "tts_current_page";
    private static final String PREF_TTS_STATE = "tts_service_state";
    private static final String PREF_TTS_MESSAGE = "tts_service_message";
    private static final String PREF_AUDIO_STATE_REPAIRED_V69 = "audio_state_repaired_v69";
    private static final String PREF_FAST_RESUME_DOC = "fast_resume_doc_v7";
    private static final String PREF_FAST_RESUME_PAGE = "fast_resume_page_v7";
    private static final String PREF_FAST_RESUME_TEXT = "fast_resume_text_v7";
    private static final String PREF_FAST_RESUME_RATE = "fast_resume_rate_v7";
    private static final String PREF_FAST_RESUME_ENGINE = "fast_resume_engine_v7";
    private static final String PREF_FAST_RESUME_LANGUAGE = "fast_resume_language_v28";
    private static final String PREF_PDF_LANGUAGE_PREFIX = "pdf_language_v28_";
    private static final String FAST_RESUME_FILE_NAME = "fast_resume_bridge.wav";
    private static final int FAST_RESUME_MIN_CHARS = 120;
    private static final int FAST_RESUME_TARGET_CHARS = 260;
    private static final String PREF_MARK_STYLE = "mark_style";
    private static final String PREF_MARK_STYLE_V72_MIGRATED = "mark_style_v72_migrated";
    private static final String PREF_MARK_COLORS_V72_MIGRATED = "mark_colors_v72_migrated";
    private static final String PREF_MARK_THICKNESS = "mark_thickness_level";
    private static final String PREF_UNDERLINE_COLOR = "underline_color_index";
    private static final String PREF_HIGHLIGHT_COLOR = "highlight_color_index";
    private static final String PREF_CUSTOM_UNDERLINE_COLOR = "custom_underline_color";
    private static final String PREF_CUSTOM_HIGHLIGHT_COLOR = "custom_highlight_color";
    private static final String PREF_USE_CUSTOM_UNDERLINE_COLOR = "use_custom_underline_color";
    private static final String PREF_USE_CUSTOM_HIGHLIGHT_COLOR = "use_custom_highlight_color";
    private static final String PREF_RULE_COLOR = "rule_color_index";
    private static final String PREF_CUSTOM_RULE_COLOR = "custom_rule_color";
    private static final String PREF_USE_CUSTOM_RULE_COLOR = "use_custom_rule_color";
    private static final String PREF_READING_MARKER_ENABLED = "reading_marker_enabled";
    private static final String PREF_READING_MARKER_COLOR = "reading_marker_color_index";
    private static final String PREF_CUSTOM_READING_MARKER_COLOR = "custom_reading_marker_color";
    private static final String PREF_USE_CUSTOM_READING_MARKER_COLOR = "use_custom_reading_marker_color";
    private static final String PREF_READING_MARKER_V81_RESET = "reading_marker_v81_reset";
    private static final String PREF_READING_BRIGHTNESS = "reading_brightness";
    private static final String PREF_IMAGE_LIBRARY_GRID = "image_library_grid";
    private static final int QUICK_MARK_SLOT_COUNT = 4;

    private static final int MARK_STYLE_UNDERLINE_FINE = 0;
    private static final int MARK_STYLE_UNDERLINE_DOUBLE = 1;
    private static final int MARK_STYLE_UNDERLINE_WAVY = 2;
    private static final int MARK_STYLE_UNDERLINE_DOTTED = 3;
    private static final int MARK_STYLE_HIGHLIGHT_SOFT = 4;
    private static final int MARK_STYLE_HIGHLIGHT_INTENSE = 5;
    private static final int MARK_STYLE_TEXT_BOX = 6;

    private static final int COLOR_TARGET_UNDERLINE = 0;
    private static final int COLOR_TARGET_HIGHLIGHT = 1;
    private static final int COLOR_TARGET_RULE = 2;
    private static final int COLOR_TARGET_READING_MARKER = 3;

    private static final int LIBRARY_AUDIO = 0;
    private static final int LIBRARY_IMAGE = 1;
    private static final int LIBRARY_PDF = 2;

    // Colores mostrados como muestras reales. Sus nombres no aparecen en la interfaz.
    private static final int[] MARK_COLOR_RGB = new int[]{
            0x00FFD400, 0x00EF4444, 0x00EC4899, 0x003B82F6,
            0x0022C55E, 0x00F97316, 0x00A855F7, 0x0006B6D4,
            0x0084CC16, 0x0092400E, 0x00111111, 0x00FFFFFF
    };

    private PdfPageView pdfView;
    private TextRepository textRepository;
    private SelectionTextRepository selectionRepository;
    private TextView titleView;
    private HorizontalScrollView titleScroller;
    private TextView pageView;
    private Button bookmarkButton;
    private Button playButton;
    private File currentFile;
    private String currentBookmarkKey;
    private String currentTitle;
    private int currentPage;
    private int pageCount;
    private boolean audioStarted;
    private boolean audioPaused;
    private boolean audioPreparing;
    private boolean markMode;
    private int markStyle;
    private int underlineColorIndex;
    private int highlightColorIndex;
    private int customUnderlineRgb;
    private int customHighlightRgb;
    private boolean useCustomUnderlineColor;
    private boolean useCustomHighlightColor;
    private int markThicknessLevel;
    private float readingBrightness;
    private Button markButton;
    private Button colorButton;
    private Button rulesButton;
    private TextView readingMarkerSettingsSwatch;
    private boolean rulesEnabled;
    private int ruleColorIndex;
    private int customRuleRgb;
    private boolean useCustomRuleColor;
    private boolean readingMarkerEnabled;
    private int readingMarkerColorIndex;
    private int customReadingMarkerRgb;
    private boolean useCustomReadingMarkerColor;
    private int pendingReadingPage = -1;
    private String pendingReadingChunk = "";
    private int pendingReadingChunkIndex = -1;
    private int pendingReadingRangeStart;
    private int pendingReadingRangeEnd;
    private int loadedSelectionPage = -1;
    private int loadingSelectionPage = -1;
    private float ruleTop;
    private float ruleBottom;
    private boolean restartAudioAfterRender;
    private int requestedAudioPage;
    private boolean requestedAudioPageConfirmed;
    private int audioRequestToken;
    private boolean darkTheme;
    private float speechRate;
    private boolean settingsMode;
    private int settingsSubscreen;
    private boolean settingsNeedsMainRebuild;
    private LinearLayout root;
    private FrameLayout screenHost;
    private View settingsOverlay;
    private View imageViewerOverlay;
    private TextToSpeech exportTts;
    private boolean exportTtsReady;
    private SharedPreferences prefs;
    private ScrollView settingsScrollView;
    private int settingsScrollY;
    private int exportStartPage = -1;
    private int exportEndPage = -1;
    private int exportCurrentPage = -1;
    private int exportSavedCount;
    private File exportAudioDir;
    private String exportAudioBase;
    private File lastExportedAudioFile;
    private final ArrayList<String> activeExportChunks = new ArrayList<>();
    private final ArrayList<File> activeExportChunkFiles = new ArrayList<>();
    private int activeExportChunkIndex = -1;
    private int activeExportPage = -1;
    private File activeExportOutputFile;
    private String activeExportUtteranceId;
    private int audioExportSessionToken;
    private boolean libraryMode;
    private boolean imageLibraryGridMode;
    private boolean libraryReturnToSettings;
    private int libraryShowingType = LIBRARY_AUDIO;
    private boolean imageViewerMode;
    private boolean imageViewerReturnToLibrary;
    private boolean imageViewerReturnToSettings;
    private Bitmap imageViewerBitmap;
    private ViewPager2 imagePager;
    private ImagePagerAdapter imagePagerAdapter;
    private MediaPlayer previewPlayer;
    private Handler previewHandler = new Handler(Looper.getMainLooper());
    private Runnable previewProgressTask;
    private final Handler readingMarkerHandler = new Handler(Looper.getMainLooper());
    private Runnable readingMarkerUpdateTask;
    private boolean readingMarkerUpdateScheduled;
    private Handler pageSyncHandler;
    private Runnable pageSyncRunnable;
    private BroadcastReceiver playbackReceiver;
    private boolean receiverRegistered;
    private boolean notificationWarningShown;
    private final Handler audioStartHandler = new Handler(Looper.getMainLooper());
    private Runnable audioNeighborPreloadRunnable;
    private Runnable audioIdleIndexRunnable;
    private Runnable ttsWarmupRunnable;
    private final Handler pageWorkHandler = new Handler(Looper.getMainLooper());
    private Runnable pageWorkRunnable;
    private int pageWorkToken;
    private final ExecutorService imageExportExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService audioExportExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService imageDecodeExecutor = Executors.newFixedThreadPool(2);
    private final ExecutorService languageDetectionExecutor = Executors.newFixedThreadPool(2);
    private final LruCache<String, Bitmap> imageViewerCache = new LruCache<String, Bitmap>(48 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            if (value == null) return 0;
            return Math.max(1, value.getByteCount() / 1024);
        }
    };
    private final LruCache<String, Bitmap> imagePreviewCache = new LruCache<String, Bitmap>(12 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            if (value == null) return 0;
            return Math.max(1, value.getByteCount() / 1024);
        }
    };
    private final HashSet<String> imageDecodeInFlight = new HashSet<String>();
    private Runnable audioStartTimeout;
    private int playbackState = TtsForegroundService.STATE_STOPPED;
    private String lastPlaybackError = "";
    private boolean fullIndexRequested;
    private String appLanguage;
    private String appRegion;
    private String currentPdfLanguage = "";
    private float currentPdfLanguageConfidence;
    private int languageDetectionToken;
    private int languageSamplingToken = -1;
    private boolean pdfLanguageDialogVisible;
    private boolean waitingForTtsDataInstall;
    private boolean voicesInventoryLoading;
    private boolean initialLanguagePending;
    private boolean startupCompleted;
    private int pdfOpenRequestToken;
    private boolean onboardingMode;
    private int onboardingStep;
    private int fastResumeSynthesisToken;
    private boolean fastResumeWaitingForEngine;

    private static final class FastResumeBridge {
        final File file;
        final String text;

        FastResumeBridge(File file, String text) {
            this.file = file;
            this.text = text;
        }
    }

    /**
     * Android 15/16 enforce edge-to-edge for modern target SDKs. Keep the existing
     * programmatic UI inside the status/navigation bar safe area without changing
     * any of the reader layouts or controls.
     */
    private void installAndroid16SystemBarInsets() {
        if (Build.VERSION.SDK_INT < 35) return;

        final View content = findViewById(android.R.id.content);
        if (content == null) return;

        content.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets bars = insets.getInsets(
                            WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                    v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                }
                return insets;
            }
        });
        content.requestApplyInsets();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        installAndroid16SystemBarInsets();
        currentTitle = "PDF a Audio";
        prefs = getSharedPreferences("pdf_audio_prefs", MODE_PRIVATE);
        appLanguage = UiStrings.normalize(prefs.getString(UiStrings.PREF_LANGUAGE, UiStrings.detectDeviceLanguage()));
        initialLanguagePending = !prefs.getBoolean(UiStrings.PREF_ONBOARDING_COMPLETE, false);
        // En una instalación nueva la bienvenida nace en el idioma del teléfono.
        // Si el usuario ya había elegido un idioma en una versión anterior, se
        // respeta esa preferencia al mostrar una sola vez el nuevo onboarding.
        if (initialLanguagePending && !prefs.getBoolean(UiStrings.PREF_LANGUAGE_CHOSEN, false)) {
            appLanguage = UiStrings.detectDeviceLanguage();
        }
        appRegion = UiStrings.normalizeRegion(
                prefs.getString(UiStrings.PREF_REGION, UiStrings.detectDeviceRegion(appLanguage)),
                appLanguage);
        if (!prefs.contains(UiStrings.PREF_REGION)) {
            prefs.edit().putString(UiStrings.PREF_REGION, appRegion).apply();
        }
        darkTheme = prefs.getBoolean("dark_theme", true);
        speechRate = prefs.getFloat("speech_rate", 1.0f);
        int storedMarkStyle = prefs.getInt(PREF_MARK_STYLE, MARK_STYLE_UNDERLINE_FINE);
        if (!prefs.getBoolean(PREF_MARK_STYLE_V72_MIGRATED, false)) {
            // V71 usaba 0=subrayado y 1=resaltado. Se conserva la eleccion al migrar.
            storedMarkStyle = storedMarkStyle == 1 ? MARK_STYLE_HIGHLIGHT_SOFT : MARK_STYLE_UNDERLINE_FINE;
            prefs.edit()
                    .putInt(PREF_MARK_STYLE, storedMarkStyle)
                    .putBoolean(PREF_MARK_STYLE_V72_MIGRATED, true)
                    .apply();
        }
        markStyle = safeMarkStyle(storedMarkStyle);
        if (storedMarkStyle == MARK_STYLE_TEXT_BOX) {
            markStyle = MARK_STYLE_UNDERLINE_FINE;
            prefs.edit().putInt(PREF_MARK_STYLE, markStyle).apply();
        }
        markThicknessLevel = safeThicknessLevel(prefs.getInt(PREF_MARK_THICKNESS, 1));

        int storedUnderlineColor = prefs.getInt(PREF_UNDERLINE_COLOR, 0);
        int storedHighlightColor = prefs.getInt(PREF_HIGHLIGHT_COLOR, 0);
        if (!prefs.getBoolean(PREF_MARK_COLORS_V72_MIGRATED, false)) {
            storedUnderlineColor = migrateV71ColorIndex(storedUnderlineColor);
            storedHighlightColor = migrateV71ColorIndex(storedHighlightColor);
            prefs.edit()
                    .putInt(PREF_UNDERLINE_COLOR, storedUnderlineColor)
                    .putInt(PREF_HIGHLIGHT_COLOR, storedHighlightColor)
                    .putBoolean(PREF_MARK_COLORS_V72_MIGRATED, true)
                    .apply();
        }
        underlineColorIndex = safeMarkColorIndex(storedUnderlineColor);
        highlightColorIndex = safeMarkColorIndex(storedHighlightColor);
        customUnderlineRgb = prefs.getInt(PREF_CUSTOM_UNDERLINE_COLOR, 0x00FFD400) & 0x00FFFFFF;
        customHighlightRgb = prefs.getInt(PREF_CUSTOM_HIGHLIGHT_COLOR, 0x00FFD400) & 0x00FFFFFF;
        useCustomUnderlineColor = prefs.getBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, false);
        useCustomHighlightColor = prefs.getBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, false);
        ruleColorIndex = safeMarkColorIndex(prefs.getInt(PREF_RULE_COLOR, 3));
        customRuleRgb = prefs.getInt(PREF_CUSTOM_RULE_COLOR, 0x003B82F6) & 0x00FFFFFF;
        useCustomRuleColor = prefs.getBoolean(PREF_USE_CUSTOM_RULE_COLOR, false);
        readingMarkerEnabled = prefs.getBoolean(PREF_READING_MARKER_ENABLED, false);
        if (!prefs.getBoolean(PREF_READING_MARKER_V81_RESET, false)) {
            readingMarkerEnabled = false;
            prefs.edit().putBoolean(PREF_READING_MARKER_ENABLED, false)
                    .putBoolean(PREF_READING_MARKER_V81_RESET, true).apply();
        }
        readingMarkerColorIndex = safeMarkColorIndex(prefs.getInt(PREF_READING_MARKER_COLOR, 3));
        customReadingMarkerRgb = prefs.getInt(PREF_CUSTOM_READING_MARKER_COLOR, 0x003B82F6) & 0x00FFFFFF;
        useCustomReadingMarkerColor = prefs.getBoolean(PREF_USE_CUSTOM_READING_MARKER_COLOR, false);
        readingBrightness = prefs.getFloat(PREF_READING_BRIGHTNESS, -1f);
        imageLibraryGridMode = prefs.getBoolean(PREF_IMAGE_LIBRARY_GRID, true);
        applyReadingBrightness();
        repairBrokenPlaybackStateOnce();
        setupPlaybackSync();
        textRepository = new TextRepository(this);
        selectionRepository = new SelectionTextRepository(this);
        TtsForegroundService.setPageProvider(new TtsForegroundService.PageProvider() {
            @Override
            public void requestPageText(final int page, final TtsForegroundService.PageTextCallback callback) {
                textRepository.getPageTextFastStart(page, new TextRepository.TextCallback() {
                    @Override
                    public void onText(String text) {
                        callback.onFastText(text);
                    }
                }, new TextRepository.TextCallback() {
                    @Override
                    public void onText(String text) {
                        callback.onText(text);
                    }
                });
            }
        });
        if (initialLanguagePending) {
            showInitialRegionSelectionScreen();
        } else {
            buildUi();
            finishStartupAfterLanguageSelection();
        }
    }

    private String t(String text) {
        return UiStrings.translate(appLanguage, text);
    }

    private void finishStartupAfterLanguageSelection() {
        if (startupCompleted) return;
        startupCompleted = true;
        initialLanguagePending = false;

        final File last = new File(getFilesDir(), "last.pdf");
        final String lastTitle = prefs.getString("last_title", t("PDF guardado"));
        final Runnable afterFirstFrame = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                ensureNotificationPermission();
                if (last.exists()) {
                    openLocalPdf(last, lastTitle, true);
                } else {
                    scheduleTtsWarmup(700L);
                }
            }
        };

        // Deja que la interfaz dibuje primero. Restaurar PdfRenderer, caché y
        // marcados en el mismo onCreate hacía que el arranque pareciera congelado.
        if (root != null) root.postDelayed(afterFirstFrame, 48L);
        else new Handler(Looper.getMainLooper()).postDelayed(afterFirstFrame, 48L);
    }

    private void showInitialLanguageDialog() {
        showOnboardingWelcome();
    }

    /**
     * First launch onboarding. It is deliberately a full-screen surface so the
     * reader UI never appears behind the language choice.
     */
    private void showOnboardingWelcome() {
        // Legacy entry point retained only for compatibility with old internal paths.
        // The welcome screen itself no longer exists; first run goes straight to region.
        showInitialRegionSelectionScreen();
    }

    private LinearLayout makeOnboardingStep(int number, int iconRes, String label, int accent) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView numberView = new TextView(this);
        numberView.setText(String.valueOf(number));
        numberView.setTextColor(Color.WHITE);
        numberView.setTextSize(uiSp(12));
        numberView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        numberView.setGravity(Gravity.CENTER);
        GradientDrawable numberBg = new GradientDrawable();
        numberBg.setShape(GradientDrawable.OVAL);
        numberBg.setColor(Color.rgb(24, 94, 224));
        numberView.setBackground(numberBg);
        item.addView(numberView, new LinearLayout.LayoutParams(uiDp(26), uiDp(26)));

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(uiDp(44), uiDp(44));
        iconLp.topMargin = uiDp(4);
        item.addView(icon, iconLp);

        TextView text = new TextView(this);
        text.setText(label);
        text.setTextColor(Color.rgb(235, 242, 252));
        text.setTextSize(uiSp(13.2f));
        text.setGravity(Gravity.CENTER);
        text.setMaxLines(2);
        text.setLineSpacing(0, 1.02f);
        LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        textLp.topMargin = uiDp(3);
        item.addView(text, textLp);
        return item;
    }

    private TextView makeOnboardingArrow() {
        TextView arrow = new TextView(this);
        arrow.setText("→");
        arrow.setTextColor(Color.rgb(96, 165, 250));
        arrow.setTextSize(uiSp(24));
        arrow.setGravity(Gravity.CENTER);
        return arrow;
    }

    private LinearLayout makeOnboardingBenefit(int iconRes, String title, String subtitle, int accent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(4), 0, uiDp(4), 0);

        FrameLayout iconBox = new FrameLayout(this);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.rgb(7, 48, 82));
        circle.setStroke(uiDp(1), Color.rgb(20, 89, 137));
        iconBox.setBackground(circle);
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setPadding(uiDp(8), uiDp(8), uiDp(8), uiDp(8));
        iconBox.addView(icon, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        row.addView(iconBox, new LinearLayout.LayoutParams(uiDp(42), uiDp(42)));

        LinearLayout textWrap = new LinearLayout(this);
        textWrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams wrapLp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        wrapLp.leftMargin = uiDp(7);
        row.addView(textWrap, wrapLp);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(uiSp(13.2f));
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleView.setMaxLines(1);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        textWrap.addView(titleView);

        TextView subtitleView = new TextView(this);
        subtitleView.setText(subtitle);
        subtitleView.setTextColor(Color.rgb(174, 192, 215));
        subtitleView.setTextSize(uiSp(10.9f));
        subtitleView.setMaxLines(2);
        subtitleView.setLineSpacing(0, 1.02f);
        textWrap.addView(subtitleView);
        return row;
    }

    private LinearLayout makeOnboardingInfoRow(int iconRes, String title, String subtitle,
                                                boolean arrow, int accent, int primary, int secondary,
                                                int background, int border) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(12), uiDp(7), uiDp(12), uiDp(7));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(16));
        bg.setColor(background);
        bg.setStroke(uiDp(1), border);
        row.setBackground(bg);
        row.setClickable(arrow);
        row.setFocusable(arrow);

        FrameLayout iconBox = new FrameLayout(this);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(Color.rgb(8, 49, 86));
        iconBg.setStroke(uiDp(1), Color.rgb(24, 91, 150));
        iconBox.setBackground(iconBg);
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setPadding(uiDp(8), uiDp(8), uiDp(8), uiDp(8));
        iconBox.addView(icon, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        row.addView(iconBox, new LinearLayout.LayoutParams(uiDp(42), uiDp(42)));

        LinearLayout textWrap = new LinearLayout(this);
        textWrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        textLp.leftMargin = uiDp(10);
        row.addView(textWrap, textLp);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(primary);
        titleView.setTextSize(uiSp(14.8f));
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleView.setMaxLines(1);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        textWrap.addView(titleView);

        TextView subtitleView = new TextView(this);
        subtitleView.setText(subtitle);
        subtitleView.setTextColor(secondary);
        subtitleView.setTextSize(uiSp(11.6f));
        subtitleView.setMaxLines(1);
        textWrap.addView(subtitleView);

        if (arrow) {
            TextView arrowView = new TextView(this);
            arrowView.setText("›");
            arrowView.setTextColor(Color.rgb(170, 197, 230));
            arrowView.setTextSize(uiSp(30));
            arrowView.setGravity(Gravity.CENTER);
            row.addView(arrowView, new LinearLayout.LayoutParams(uiDp(24), uiDp(42)));
        }
        return row;
    }

    /**
     * First launch is intentionally reduced to one decision: country / region.
     * The interface language is detected from Android and can still be changed
     * later from Settings. Selecting a country completes first-run setup.
     */
    private void showInitialRegionSelectionScreen() {
        onboardingMode = true;
        onboardingStep = 3;
        settingsMode = false;
        settingsSubscreen = 0;

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));
        screen.setClickable(true);
        screen.setFocusable(true);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(18), uiDp(10), uiDp(18), uiDp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        TextView title = new TextView(this);
        title.setText(t("País / Región"));
        title.setTextSize(uiSp(22));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(46)));
        screen.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(62)));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(uiDp(16), uiDp(10), uiDp(16), uiDp(16));

        final EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("🔎  " + t("Buscar país..."));
        search.setTextSize(uiSp(16));
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.rgb(148, 163, 184));
        search.setPadding(uiDp(16), 0, uiDp(16), 0);
        GradientDrawable searchBg = new GradientDrawable();
        searchBg.setCornerRadius(uiDp(18));
        searchBg.setColor(Color.rgb(8, 31, 51));
        searchBg.setStroke(uiDp(1), Color.rgb(37, 84, 120));
        search.setBackground(searchBg);
        body.addView(search, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(52)));

        LinearLayout regionStatus = new LinearLayout(this);
        regionStatus.setOrientation(LinearLayout.HORIZONTAL);
        regionStatus.setGravity(Gravity.CENTER_VERTICAL);
        regionStatus.setPadding(uiDp(4), 0, uiDp(4), 0);

        TextView currentPrefix = new TextView(this);
        currentPrefix.setText(t("Región actual") + ":");
        currentPrefix.setTextColor(Color.WHITE);
        currentPrefix.setTextSize(uiSp(14));
        currentPrefix.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        regionStatus.addView(currentPrefix, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, uiDp(42)));

        ImageView currentFlag = makeFlagImageView(appRegion);
        LinearLayout.LayoutParams currentFlagLp = new LinearLayout.LayoutParams(uiDp(28), uiDp(19));
        currentFlagLp.leftMargin = uiDp(6);
        currentFlagLp.rightMargin = uiDp(6);
        regionStatus.addView(currentFlag, currentFlagLp);

        TextView currentName = new TextView(this);
        currentName.setText(UiStrings.regionName(appRegion, appLanguage));
        currentName.setTextColor(Color.WHITE);
        currentName.setTextSize(uiSp(14));
        currentName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        currentName.setSingleLine(true);
        currentName.setEllipsize(TextUtils.TruncateAt.END);
        regionStatus.addView(currentName, new LinearLayout.LayoutParams(0, uiDp(42), 1));

        TextView total = new TextView(this);
        total.setText(t("28 países"));
        total.setTextColor(Color.rgb(96, 165, 250));
        total.setTextSize(uiSp(13));
        total.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        total.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        regionStatus.addView(total, new LinearLayout.LayoutParams(uiDp(92), uiDp(42)));
        body.addView(regionStatus, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(42)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        body.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        populateRegionRows(list, "", true);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                populateRegionRows(list, s == null ? "" : s.toString(), true);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        screen.addView(body, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(screen);
    }

    private void completeInitialRegionAndEnterApp(String regionCode) {
        appRegion = UiStrings.normalizeRegion(regionCode, appLanguage);
        prefs.edit()
                .putString(UiStrings.PREF_LANGUAGE, UiStrings.normalize(appLanguage))
                .putString(UiStrings.PREF_REGION, appRegion)
                .putBoolean(UiStrings.PREF_ONBOARDING_COMPLETE, true)
                .apply();
        onboardingMode = false;
        initialLanguagePending = false;
        buildUi();
        finishStartupAfterLanguageSelection();
    }

    private void showOnboardingLanguageSelection() {
        onboardingMode = true;
        onboardingStep = 2;

        final int accent = Color.rgb(37, 99, 235);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(uiDp(22), uiDp(10), uiDp(22), uiDp(14));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(3, 17, 31), Color.rgb(3, 37, 64)});
        page.setBackground(bg);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(Color.WHITE);
        back.setTextSize(uiSp(38));
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showOnboardingWelcome(); }
        });
        top.addView(back, new LinearLayout.LayoutParams(uiDp(44), uiDp(44)));
        View topSpacer = new View(this);
        top.addView(topSpacer, new LinearLayout.LayoutParams(0, uiDp(44), 1));
        TextView globe = makeRoundHeaderIcon("🌐");
        top.addView(globe, new LinearLayout.LayoutParams(uiDp(44), uiDp(44)));
        page.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(44)));

        TextView title = new TextView(this);
        title.setText(t("Elige tu idioma"));
        title.setTextColor(Color.WHITE);
        title.setTextSize(uiSp(25));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleLp.topMargin = uiDp(5);
        page.addView(title, titleLp);

        TextView info = new TextView(this);
        info.setText(t("Selecciona el idioma que deseas usar en la aplicación."));
        info.setTextColor(Color.rgb(203, 213, 225));
        info.setTextSize(uiSp(14));
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        infoLp.topMargin = uiDp(4);
        infoLp.bottomMargin = uiDp(10);
        page.addView(info, infoLp);

        final String[] codes = new String[]{UiStrings.ES, UiStrings.EN, UiStrings.PT, UiStrings.HI, UiStrings.ID};
        final String[] flagCodes = new String[]{"ES", "US", "BR", "IN", "ID"};
        final String[] names = new String[]{"Español", "English", "Português (Brasil)", "हिन्दी — Hindi", "Bahasa Indonesia"};
        final String deviceLanguage = UiStrings.detectDeviceLanguage();

        for (int i = 0; i < codes.length; i++) {
            final String code = codes[i];
            boolean selected = code.equals(UiStrings.normalize(appLanguage));
            String note = code.equals(deviceLanguage) ? t("Idioma del dispositivo") : "";
            View option = makeDesign3SelectionRow(flagCodes[i], names[i], note, selected);
            option.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    appLanguage = code;
                    showOnboardingLanguageSelection();
                }
            });
            LinearLayout.LayoutParams optionLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, uiDp(54));
            optionLp.bottomMargin = uiDp(7);
            page.addView(option, optionLp);
        }

        View stretch = new View(this);
        page.addView(stretch, new LinearLayout.LayoutParams(1, 0, 0.08f));

        Button continueButton = makeOnboardingPrimaryButton(t("Continuar"), accent);
        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                prefs.edit()
                        .putString(UiStrings.PREF_LANGUAGE, UiStrings.normalize(appLanguage))
                        .putString(UiStrings.PREF_REGION, UiStrings.normalizeRegion(appRegion, appLanguage))
                        .putBoolean(UiStrings.PREF_LANGUAGE_CHOSEN, true)
                        .apply();
                showOnboardingWelcome();
            }
        });
        page.addView(continueButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(58)));

        setContentView(page);
    }

    private void completeOnboardingAndEnterApp() {
        prefs.edit()
                .putString(UiStrings.PREF_LANGUAGE, UiStrings.normalize(appLanguage))
                .putString(UiStrings.PREF_REGION, UiStrings.normalizeRegion(appRegion, appLanguage))
                .putBoolean(UiStrings.PREF_LANGUAGE_CHOSEN, true)
                .putBoolean(UiStrings.PREF_ONBOARDING_COMPLETE, true)
                .apply();
        onboardingMode = false;
        initialLanguagePending = false;
        buildUi();
        finishStartupAfterLanguageSelection();
    }

    private String onboardingLanguageLabel(String code) {
        code = UiStrings.normalize(code);
        if (UiStrings.ES.equals(code)) return "Español";
        if (UiStrings.PT.equals(code)) return "Português";
        if (UiStrings.HI.equals(code)) return "हिन्दी — Hindi";
        if (UiStrings.ID.equals(code)) return "Bahasa Indonesia";
        return "English";
    }

    private Button makeOnboardingPrimaryButton(String label, int accent) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(uiSp(16));
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(accent);
        bg.setCornerRadius(uiDp(16));
        button.setBackground(bg);
        return button;
    }

    private View makeOnboardingLanguageRow(String flagCode, String name, boolean selected, int accent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), 0, dp(16), 0);
        row.setClickable(true);
        row.setFocusable(true);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16));
        bg.setColor(darkTheme ? Color.rgb(10, 35, 52) : Color.WHITE);
        bg.setStroke(dp(selected ? 2 : 1), selected ? accent
                : (darkTheme ? Color.rgb(30, 58, 75) : Color.rgb(226, 232, 240)));
        row.setBackground(bg);

        ImageView flagView = makeFlagImageView(flagCode);
        row.addView(flagView, new LinearLayout.LayoutParams(dp(44), dp(30)));

        TextView nameView = new TextView(this);
        nameView.setText(name);
        nameView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        nameView.setTextSize(17);
        if (selected) nameView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        nameLp.leftMargin = dp(10);
        row.addView(nameView, nameLp);

        TextView radio = new TextView(this);
        radio.setText(selected ? "●" : "○");
        radio.setTextColor(selected ? accent
                : (darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139)));
        radio.setTextSize(25);
        radio.setGravity(Gravity.CENTER);
        row.addView(radio, new LinearLayout.LayoutParams(dp(38), dp(48)));

        return row;
    }

    private LinearLayout makeWelcomeInfoCard(String icon, String title, String subtitle,
                                           int primary, int secondary, int background,
                                           int outline, int accent, boolean showArrow) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(22));
        bg.setColor(background);
        bg.setStroke(dp(1), outline);
        row.setBackground(bg);
        row.setClickable(true);
        row.setFocusable(true);

        TextView iconView = new TextView(this);
        iconView.setText(icon);
        iconView.setTextSize(20);
        iconView.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(darkTheme ? Color.rgb(9, 53, 84) : Color.rgb(239, 246, 255));
        iconBg.setStroke(dp(1), darkTheme ? Color.rgb(24, 72, 109) : Color.rgb(191, 219, 254));
        iconView.setBackground(iconBg);
        row.addView(iconView, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout textWrap = new LinearLayout(this);
        textWrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        textLp.leftMargin = dp(12);
        row.addView(textWrap, textLp);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(primary);
        titleView.setTextSize(16);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        textWrap.addView(titleView);

        TextView subtitleView = new TextView(this);
        subtitleView.setText(subtitle);
        subtitleView.setTextColor(secondary);
        subtitleView.setTextSize(14);
        subtitleView.setLineSpacing(0, 1.1f);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        subLp.topMargin = dp(4);
        textWrap.addView(subtitleView, subLp);

        if (showArrow) {
            TextView arrow = new TextView(this);
            arrow.setText("›");
            arrow.setTextColor(accent);
            arrow.setTextSize(28);
            arrow.setGravity(Gravity.CENTER);
            row.addView(arrow, new LinearLayout.LayoutParams(dp(24), dp(48)));
        }
        return row;
    }

    private LinearLayout makeWelcomeFeatureItem(String icon, int tint, int softBackground, String label) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        item.setPadding(dp(4), 0, dp(4), 0);

        TextView iconView = new TextView(this);
        iconView.setText(icon);
        iconView.setTextSize(22);
        iconView.setTextColor(tint);
        iconView.setGravity(Gravity.CENTER);
        GradientDrawable badge = new GradientDrawable();
        badge.setCornerRadius(dp(16));
        badge.setColor(softBackground);
        badge.setStroke(dp(1), darkTheme ? Color.rgb(24, 72, 109) : Color.rgb(191, 219, 254));
        iconView.setBackground(badge);
        item.addView(iconView, new LinearLayout.LayoutParams(dp(72), dp(48)));

        TextView text = new TextView(this);
        text.setText(label);
        text.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(51, 65, 85));
        text.setTextSize(13);
        text.setGravity(Gravity.CENTER);
        text.setLineSpacing(0, 1.1f);
        LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        textLp.topMargin = dp(10);
        item.addView(text, textLp);
        return item;
    }

    private void showLanguageDialog(final boolean firstLaunch) {
        final String[] codes = new String[]{UiStrings.ES, UiStrings.EN, UiStrings.PT, UiStrings.HI, UiStrings.ID};
        final String[] labels = new String[]{"Español", "English", "Português", "हिन्दी", "Bahasa Indonesia"};
        int current = 0;
        for (int i = 0; i < codes.length; i++) {
            if (codes[i].equals(UiStrings.normalize(appLanguage))) {
                current = i;
                break;
            }
        }
        final int[] selected = new int[]{current};

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), 0, dp(10), dp(4));
        TextView info = new TextView(this);
        info.setText(t("Puedes cambiarlo después en Ajustes."));
        info.setTextSize(13);
        info.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
        info.setPadding(dp(18), dp(4), dp(18), dp(8));
        box.addView(info);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(firstLaunch ? t("Selecciona tu idioma") : t("Idioma de la aplicación"))
                .setSingleChoiceItems(labels, current, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        selected[0] = which;
                    }
                })
                .setView(box)
                .setPositiveButton(firstLaunch ? t("Continuar") : t("Aplicar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String chosen = codes[Math.max(0, Math.min(selected[0], codes.length - 1))];
                        boolean changed = !chosen.equals(appLanguage);
                        appLanguage = chosen;
                        prefs.edit()
                                .putString(UiStrings.PREF_LANGUAGE, chosen)
                                .putBoolean(UiStrings.PREF_LANGUAGE_CHOSEN, true)
                                .putBoolean(UiStrings.PREF_ONBOARDING_COMPLETE, true)
                                .apply();

                        if (firstLaunch) {
                            if (changed) buildUi();
                            finishStartupAfterLanguageSelection();
                        } else {
                            settingsNeedsMainRebuild = true;
                            settingsScrollY = 0;
                            buildSettingsScreen();
                        }
                    }
                });
        if (!firstLaunch) {
            builder.setNegativeButton(t("Cancelar"), null);
        }
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(!firstLaunch);
        dialog.setCancelable(!firstLaunch);
        dialog.show();
        styleDialog(dialog);
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Mantener el receptor activo mientras la Activity siga visible/arrancada.
        // Al bajar el panel de notificaciones Android puede pausar la Activity,
        // pero no debe perder los cambios Play/Pausa/Siguiente del servicio.
        registerPlaybackReceiver();
    }

    @Override
    protected void onResume() {
        super.onResume();
        startPageSyncLoop();
        syncVisiblePageWithReader();
        if (waitingForTtsDataInstall) {
            waitingForTtsDataInstall = false;
            audioStartHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                    TtsEngineManager manager = TtsEngineManager.getInstance(MainActivity.this);
                    if (currentPdfLanguage.length() > 0) {
                        manager.ensureLanguage(currentPdfLanguage, appRegion, null);
                    } else {
                        manager.retryInitialization();
                    }
                    if (settingsMode && settingsSubscreen == 4) {
                        showVoicesScreen();
                    }
                }
            }, 450L);
        }
    }

    @Override
    protected void onPause() {
        stopPageSyncLoop();
        cancelPendingReadingMarker();
        prepareFastResumeAudioForCurrentPage();
        super.onPause();
    }

    @Override
    protected void onStop() {
        unregisterPlaybackReceiver();
        super.onStop();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        syncVisiblePageWithReader();
    }

    private void setupPlaybackSync() {
        pageSyncHandler = new Handler(Looper.getMainLooper());
        pageSyncRunnable = new Runnable() {
            @Override
            public void run() {
                syncVisiblePageWithReader();
                if (pageSyncHandler != null) {
                    pageSyncHandler.postDelayed(this, 700);
                }
            }
        };
        playbackReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !TtsForegroundService.ACTION_PAGE_CHANGED.equals(intent.getAction())) return;
                int state = intent.getIntExtra(TtsForegroundService.EXTRA_STATE,
                        TtsForegroundService.STATE_STOPPED);
                int page = intent.getIntExtra(TtsForegroundService.EXTRA_PAGE, -1);
                String message = intent.getStringExtra(TtsForegroundService.EXTRA_MESSAGE);
                String chunk = intent.getStringExtra(TtsForegroundService.EXTRA_CHUNK_TEXT);
                boolean rangeOnlyUpdate = chunk != null && chunk.length() > 0
                        && state == playbackState && (page < 0 || page == currentPage);
                if (!rangeOnlyUpdate) {
                    applyPlaybackState(state, page, message, true);
                }
                if (readingMarkerEnabled && chunk != null && chunk.length() > 0) {
                    pendingReadingPage = page;
                    pendingReadingChunk = chunk;
                    pendingReadingChunkIndex = intent.getIntExtra(TtsForegroundService.EXTRA_CHUNK_INDEX, 0);
                    pendingReadingRangeStart = intent.getIntExtra(TtsForegroundService.EXTRA_RANGE_START, 0);
                    pendingReadingRangeEnd = intent.getIntExtra(TtsForegroundService.EXTRA_RANGE_END, 1);
                    schedulePendingReadingMarker();
                }
            }
        };
    }

    private void registerPlaybackReceiver() {
        if (receiverRegistered || playbackReceiver == null) return;
        IntentFilter filter = new IntentFilter(TtsForegroundService.ACTION_PAGE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(playbackReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(playbackReceiver, filter);
        }
        receiverRegistered = true;
    }

    private void unregisterPlaybackReceiver() {
        if (!receiverRegistered || playbackReceiver == null) return;
        try {
            unregisterReceiver(playbackReceiver);
        } catch (Exception ignored) {
        }
        receiverRegistered = false;
    }

    private void startPageSyncLoop() {
        if (pageSyncHandler == null || pageSyncRunnable == null) return;
        pageSyncHandler.removeCallbacks(pageSyncRunnable);
        pageSyncHandler.postDelayed(pageSyncRunnable, 700);
    }

    private void stopPageSyncLoop() {
        if (pageSyncHandler != null && pageSyncRunnable != null) {
            pageSyncHandler.removeCallbacks(pageSyncRunnable);
        }
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33) return;
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return;

        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 33);
        if (!notificationWarningShown) {
            notificationWarningShown = true;
            Toast.makeText(this, t("Acepta el permiso de notificaciones para ver los controles del audio"), Toast.LENGTH_LONG).show();
        }
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(8), uiDp(8), uiDp(8), uiDp(6));
        top.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        Button openButton = makeButton("Abrir");
        openButton.setTextSize(uiSp(12.0f));
        openButton.setSingleLine(true);
        openButton.setPadding(uiDp(2), 0, uiDp(2), 0);
        
openButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        choosePdf();
    }
});

        titleScroller = new HorizontalScrollView(this);
        titleScroller.setHorizontalScrollBarEnabled(false);
        titleScroller.setFillViewport(false);
        titleScroller.setOverScrollMode(View.OVER_SCROLL_NEVER);
        titleScroller.setClipToPadding(false);
        titleScroller.setPadding(0, 0, uiDp(8), 0);

        titleView = new TextView(this);
        titleView.setText("PDF a Audio");
        titleView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        titleView.setTextSize(uiSp(15.5f));
        titleView.setSingleLine(true);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        titleView.setPadding(0, 0, uiDp(8), 0);
        titleView.setHorizontallyScrolling(true);
        titleScroller.addView(titleView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, uiDp(44)));

        pageView = new TextView(this);
        pageView.setText(t("0/0"));
        pageView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        pageView.setTextSize(uiSp(13.5f));
        pageView.setSingleLine(true);
        pageView.setGravity(Gravity.CENTER);
        pageView.setClickable(true);
        pageView.setFocusable(true);
        pageView.setContentDescription(t("Ir a página"));
        pageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showGoto();
            }
        });

        bookmarkButton = makeButton("☆");
        bookmarkButton.setTextSize(uiSp(20));
        bookmarkButton.setContentDescription(t("Marcadores"));
        bookmarkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBookmarksDialog();
            }
        });

        Button filesButton = makeButton("📁");
        filesButton.setTextSize(uiSp(20));
        filesButton.setContentDescription(t("Mis archivos"));
        filesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(true);
            }
        });

        rulesButton = makeButton("Reglas");
        rulesButton.setTextSize(uiSp(8.9f));
        rulesButton.setSingleLine(false);
        rulesButton.setPadding(uiDp(2), 0, uiDp(2), 0);
        rulesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleRules();
            }
        });
        rulesButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showUtilityColorDialog(COLOR_TARGET_RULE, "Color de las reglas");
                return true;
            }
        });

        top.addView(openButton, new LinearLayout.LayoutParams(uiDp(58), uiDp(44)));
        top.addView(titleScroller, new LinearLayout.LayoutParams(0, uiDp(44), 1));
        top.addView(pageView, new LinearLayout.LayoutParams(uiDp(50), uiDp(44)));
        top.addView(rulesButton, new LinearLayout.LayoutParams(uiDp(62), uiDp(44)));
        top.addView(filesButton, new LinearLayout.LayoutParams(uiDp(42), uiDp(44)));

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(getPdfWorkspaceColor());
        pdfView = new PdfPageView(this);
        pdfView.setPageChangeListener(new PdfPageView.PageChangeListener() {
            @Override
            public void onPageRendered(final int pageIndex, int total) {
                currentPage = pageIndex;
                pageCount = total;
                updatePageLabel();
                saveProgress();

                // El render visible termina primero. El texto, las coordenadas y
                // la precarga se agrupan y se retrasan unos milisegundos para que
                // varios toques seguidos no bloqueen ni hagan regresar páginas.
                scheduleVisiblePageWork(pageIndex, true);
                if (readingMarkerEnabled && pendingReadingPage == pageIndex) {
                    schedulePendingReadingMarker();
                }
                if (!TtsEngineManager.getInstance(MainActivity.this).isReady()) {
                    scheduleTtsWarmup(220L);
                }
                if (restartAudioAfterRender) {
                    restartAudioAfterRender = false;
                    startAudioFromPage(currentPage);
                }
            }

            @Override
            public void onError(String message) {
                Toast.makeText(MainActivity.this, t(message), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onHighlightsChanged(String serialized) {
                saveHighlights(serialized);
            }

            @Override
            public void onRulesChanged(boolean enabled, float top, float bottom) {
                saveRules(enabled, top, bottom);
                textRepository.setRules(enabled, top, bottom);
                refreshTextCacheForRules();
            }
        });
        pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
        pdfView.setReadingMarkerEnabled(readingMarkerEnabled);
        pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
        pdfView.setWorkspaceColor(getPdfWorkspaceColor());
        frame.addView(pdfView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(uiDp(6), uiDp(5), uiDp(6), uiDp(5));
        controls.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        View prevButton = makeNavigationButton("left", true);
        
prevButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) requestManualPageChange(currentPage - 1);
    }
});

        playButton = makeButton("▶");
        playButton.setTextSize(uiSp(21));
        
playButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        toggleAudio();
    }
});

        View nextButton = makeNavigationButton("right", true);
        
nextButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) requestManualPageChange(currentPage + 1);
    }
});

        Button fitButton = makeButton("Ajustes");
        fitButton.setTextSize(uiSp(10.0f));
        fitButton.setSingleLine(false);
        fitButton.setMaxLines(2);
        fitButton.setGravity(Gravity.CENTER);
        fitButton.setPadding(uiDp(1), 0, uiDp(1), 0);
        
fitButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        showSettings();
    }
});

        controls.addView(prevButton, new LinearLayout.LayoutParams(0, uiDp(44), 0.85f));
        controls.addView(playButton, new LinearLayout.LayoutParams(0, uiDp(44), 0.85f));
        controls.addView(nextButton, new LinearLayout.LayoutParams(0, uiDp(44), 0.85f));
        controls.addView(bookmarkButton, new LinearLayout.LayoutParams(0, uiDp(44), 0.85f));
        controls.addView(fitButton, new LinearLayout.LayoutParams(0, uiDp(44), 1.60f));

        LinearLayout markControls = new LinearLayout(this);
        markControls.setOrientation(LinearLayout.HORIZONTAL);
        markControls.setGravity(Gravity.CENTER);
        markControls.setPadding(uiDp(8), uiDp(2), uiDp(8), uiDp(2));
        markControls.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        markButton = makeButton("Subrayar OFF");
        markButton.setTextSize(uiSp(9.0f));
        markButton.setSingleLine(true);
        markButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleMarkMode();
            }
        });

        colorButton = makeButton("●");
        colorButton.setTextSize(uiSp(22));
        colorButton.setContentDescription(t("Elegir color del marcado"));
        colorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkColorDialog(isHighlightStyle(markStyle) ? COLOR_TARGET_HIGHLIGHT : COLOR_TARGET_UNDERLINE);
            }
        });

        View undoButton = makeMarkHistoryButton("undo", "Deshacer marca");
        undoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.undoLastHighlight();
            }
        });

        View redoButton = makeMarkHistoryButton("redo", "Rehacer marca");
        redoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.redoLastHighlight();
            }
        });

        Button clearButton = makeButton("Limpiar");
        clearButton.setTextSize(uiSp(9.8f));
        clearButton.setSingleLine(true);
        clearButton.setPadding(uiDp(1), 0, uiDp(1), 0);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.clearPageHighlights();
            }
        });

        markControls.addView(markButton, new LinearLayout.LayoutParams(0, uiDp(42), 1.55f));
        markControls.addView(colorButton, new LinearLayout.LayoutParams(0, uiDp(42), 0.65f));
        markControls.addView(undoButton, new LinearLayout.LayoutParams(0, uiDp(42), 0.70f));
        markControls.addView(redoButton, new LinearLayout.LayoutParams(0, uiDp(42), 0.70f));
        markControls.addView(clearButton, new LinearLayout.LayoutParams(0, uiDp(42), 1.10f));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.addView(controls, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(54)));
        bottom.addView(markControls, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(46)));

        root.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(62)));
        root.addView(frame, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        root.addView(bottom, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(100)));

        screenHost = new FrameLayout(this);
        screenHost.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
        screenHost.addView(root, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(screenHost);
        settingsOverlay = null;

        pdfView.setMarkStyle(markStyle);
        pdfView.setMarkThickness(markThicknessLevel);
        pdfView.setMarkColor(getCurrentMarkColor());
        pdfView.setMarkMode(markMode);
        updateMarkControls();
        loadRules();
        updateBookmarkButton();
    }

    private int getPdfWorkspaceColor() {
        // El espacio libre del visor se mantiene blanco. Más adelante podrá
        // reutilizarse para banners sin alterar el tamaño ni el render del PDF.
        return Color.WHITE;
    }

    private Button makeButton(String text) {
        Button button = new Button(this);
        button.setText(t(text));
        button.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        button.setTextSize(uiSp(16));
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setPadding(uiDp(4), 0, uiDp(4), 0);
        button.setBackgroundColor(darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255));
        return button;
    }



    private void showSettings() {
        settingsMode = true;
        settingsSubscreen = 0;
        settingsNeedsMainRebuild = false;
        buildSettingsScreen();
    }

    private String formatSpeed() {
        return String.format(Locale.US, "%.2fx", speechRate);
    }


    private String getVoiceSummary() {
        TtsEngineManager manager = TtsEngineManager.getInstance(this);
        String engine = manager.getActiveEnginePackage();
        if (engine != null && engine.length() > 0 && manager.isReady()) {
            return "Listo: " + engine;
        }
        String status = manager.getStatusText();
        if (status != null && status.startsWith(TtsForegroundService.ERROR_MISSING_VOICE_PREFIX)) {
            return t("Falta una voz");
        }
        return status == null || status.length() == 0 ? "Preparando motor" : status;
    }

    private void showVoicesScreen() {
        settingsMode = true;
        settingsSubscreen = 4;

        final LinearLayout screen = makeSettingsSubscreenBase(t("Voces"), new View.OnClickListener() {
            @Override public void onClick(View v) { buildSettingsScreen(); }
        });
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(uiDp(16), uiDp(12), uiDp(16), uiDp(20));

        TextView info = new TextView(this);
        info.setText(t("Comprueba qué voces están listas para leer PDFs."));
        info.setTextColor(darkTheme ? Color.rgb(191, 205, 220) : Color.rgb(71, 85, 105));
        info.setTextSize(uiSp(14));
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        infoLp.bottomMargin = uiDp(14);
        content.addView(info, infoLp);

        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        final String[] codes = new String[]{UiStrings.ES, UiStrings.EN, UiStrings.PT, UiStrings.HI, UiStrings.ID};
        final String[] flags = new String[]{"ES", "US", "BR", "IN", "ID"};
        final String[] names = new String[]{"Español", "English", "Português (Brasil)",
                "हिन्दी — Hindi", "Bahasa Indonesia"};
        boolean managerReady = manager.isReady();
        boolean needsDownload = false;

        for (int i = 0; i < codes.length; i++) {
            final String code = codes[i];
            TtsEngineManager.VoiceAvailability availability = manager.getVoiceAvailability(code, appRegion);
            String status;
            boolean canDownload;
            if (!managerReady) {
                status = t("Comprobando voces...");
                canDownload = false;
            } else if (availability.offlineVoice) {
                status = t("Instalada");
                canDownload = false;
            } else if (availability.networkOnly) {
                status = t("Solo en línea");
                canDownload = true;
                needsDownload = true;
            } else {
                status = t("Falta descargar");
                canDownload = true;
                needsDownload = true;
            }

            LinearLayout row = makeDesign3MenuCard("flag:" + flags[i], names[i], status, canDownload);
            if (canDownload) {
                row.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { launchTtsVoiceInstaller(); }
                });
            }
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, uiDp(64));
            rowLp.bottomMargin = uiDp(8);
            content.addView(row, rowLp);
        }

        if (managerReady && needsDownload) {
            Button download = makeButton("Descargar voces faltantes");
            download.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { launchTtsVoiceInstaller(); }
            });
            LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, uiDp(52));
            buttonLp.topMargin = uiDp(8);
            content.addView(download, buttonLp);
        }

        scroll.addView(content, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        screen.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        presentSettingsSubscreen(screen);

        if (!managerReady && !voicesInventoryLoading) {
            voicesInventoryLoading = true;
            final String languageToRestore = currentPdfLanguage;
            manager.setPreferredLanguage("", appRegion);
            manager.initialize(new TtsEngineManager.ReadyCallback() {
                @Override
                public void onReady(String enginePackage) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            voicesInventoryLoading = false;
                            if (languageToRestore.length() > 0) {
                                manager.setPreferredLanguage(languageToRestore, appRegion);
                            }
                            if (settingsMode && settingsSubscreen == 4) showVoicesScreen();
                        }
                    });
                }

                @Override
                public void onError(String message) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            voicesInventoryLoading = false;
                            if (languageToRestore.length() > 0) {
                                manager.setPreferredLanguage(languageToRestore, appRegion);
                            }
                            if (settingsMode && settingsSubscreen == 4) showVoicesScreen();
                        }
                    });
                }
            });
        }
    }

    private void launchTtsVoiceInstaller() {
        try {
            waitingForTtsDataInstall = true;
            Intent intent = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
            startActivity(intent);
        } catch (Exception e) {
            waitingForTtsDataInstall = false;
            Toast.makeText(this, t("No se encontró el instalador de voces"), Toast.LENGTH_LONG).show();
        }
    }

    private void showMissingVoiceDialog(String languageCode) {
        final String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (!PdfLanguageDetector.isSupported(language) || isFinishing()
                || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        String message = t("Falta la voz para leer este PDF.") + "\n\n" + UiStrings.languageName(language);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t("Falta una voz"))
                .setMessage(message)
                .setPositiveButton(t("Descargar voz"), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialogInterface, int which) {
                        launchTtsVoiceInstaller();
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void showVoiceEngineDialog() {
        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        final java.util.List<TtsEngineManager.EngineChoice> engines = manager.getInstalledEngines();
        final String[] labels = new String[engines.size() + 1];
        final String[] packages = new String[engines.size() + 1];
        labels[0] = t("Automatico (recomendado)");
        packages[0] = "";
        for (int i = 0; i < engines.size(); i++) {
            TtsEngineManager.EngineChoice item = engines.get(i);
            labels[i + 1] = t(item.label) + "\n" + item.packageName;
            packages[i + 1] = item.packageName;
        }

        String selectedPackage = prefs.getString(TtsEngineManager.PREF_ENGINE_PACKAGE, "");
        int selected = 0;
        for (int i = 1; i < packages.length; i++) {
            if (packages[i].equals(selectedPackage)) {
                selected = i;
                break;
            }
        }

        new AlertDialog.Builder(this)
                .setTitle(t("Motor de voz"))
                .setSingleChoiceItems(labels, selected, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        manager.selectEngine(packages[which]);
                        Toast.makeText(MainActivity.this,
                                t("Preparando " + labels[which].replace("\n", " ")),
                                Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                })
                .setNeutralButton(t("Reintentar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        manager.retryInitialization();
                        Toast.makeText(MainActivity.this,
                                t("Reiniciando el motor de voz"), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .show();
    }

    private void testSystemVoice() {
        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        final String testLanguage = currentPdfLanguage.length() > 0
                ? currentPdfLanguage : UiStrings.normalize(appLanguage);
        manager.setPreferredLanguage(testLanguage, appRegion);
        Toast.makeText(this, t("Preparando prueba de voz"), Toast.LENGTH_SHORT).show();
        manager.testVoice(voiceTestText(testLanguage),
                new TtsEngineManager.TestCallback() {
                    @Override
                    public void onStarted() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this,
                                        t("La voz comenzo correctamente"), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

                    @Override
                    public void onCompleted() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (settingsMode) buildSettingsScreen();
                            }
                        });
                    }

                    @Override
                    public void onError(final String message) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (message != null && message.startsWith(
                                        TtsForegroundService.ERROR_MISSING_VOICE_PREFIX)) {
                                    showMissingVoiceDialog(message.substring(
                                            TtsForegroundService.ERROR_MISSING_VOICE_PREFIX.length()));
                                } else {
                                    Toast.makeText(MainActivity.this, t(message),
                                            Toast.LENGTH_LONG).show();
                                }
                                if (settingsMode) buildSettingsScreen();
                            }
                        });
                    }
                });
    }

    private String voiceTestText(String languageCode) {
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (UiStrings.EN.equals(language)) {
            return "This is a voice test. The PDF reader is ready.";
        }
        if (UiStrings.PT.equals(language)) {
            return "Este é um teste de voz. O leitor de PDF está pronto.";
        }
        if (UiStrings.HI.equals(language)) {
            return "यह आवाज़ की जाँच है। PDF रीडर तैयार है।";
        }
        if (UiStrings.ID.equals(language)) {
            return "Ini adalah uji suara. Pembaca PDF sudah siap.";
        }
        return "Esta es una prueba de voz. El lector de PDF está listo.";
    }

    private void showSpeedDialog() {
        final String[] labels = new String[]{"0.75x", "1.0x", "1.25x", "1.5x", "1.75x", "2.0x"};
        final float[] values = new float[]{0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f};

        int selected = 1;
        for (int i = 0; i < values.length; i++) {
            if (Math.abs(values[i] - speechRate) < 0.01f) {
                selected = i;
                break;
            }
        }

        new AlertDialog.Builder(this)
                .setTitle(t("Velocidad de lectura"))
                .setSingleChoiceItems(labels, selected, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        speechRate = values[which];
                        prefs.edit().putFloat("speech_rate", speechRate).apply();
                        Toast.makeText(MainActivity.this, t("Velocidad: " + labels[which]), Toast.LENGTH_SHORT).show();

                        if (audioStarted && !audioPaused) {
                            startAudioFromPage(currentPage);
                        }

                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .show();
    }

    private void closeSettings() {
        settingsMode = false;
        settingsSubscreen = 0;

        if (!settingsNeedsMainRebuild && screenHost != null) {
            if (settingsOverlay != null && settingsOverlay.getParent() == screenHost) {
                screenHost.removeView(settingsOverlay);
            }
            settingsOverlay = null;
            if (screenHost.getParent() == null) {
                setContentView(screenHost);
            }
            if (pdfView != null) {
                pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
                pdfView.setReadingMarkerEnabled(readingMarkerEnabled);
                pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
                pdfView.setWorkspaceColor(getPdfWorkspaceColor());
                pdfView.setMarkStyle(markStyle);
                pdfView.setMarkThickness(markThicknessLevel);
                pdfView.setMarkColor(getCurrentMarkColor());
                pdfView.setMarkMode(markMode);
                pdfView.invalidate();
            }
            updatePageLabel();
            updateMarkControls();
            applyReadingBrightness();
            return;
        }

        settingsNeedsMainRebuild = false;
        File file = currentFile;
        String title = currentTitle;
        int page = currentPage;
        buildUi();
        if (file != null && file.exists()) {
            openLocalPdfAtPage(file, title, page);
        }
    }

    private void showLanguageRegionSettingsScreen() {
        settingsMode = true;
        settingsSubscreen = 1;

        LinearLayout screen = makeSettingsSubscreenBase(t("Idioma y región"), new View.OnClickListener() {
            @Override public void onClick(View v) { buildSettingsScreen(); }
        });

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(uiDp(16), uiDp(14), uiDp(16), uiDp(22));

        TextView intro = new TextView(this);
        intro.setText(t("Idioma y región"));
        intro.setTextColor(Color.WHITE);
        intro.setTextSize(uiSp(22));
        intro.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        content.addView(intro);

        TextView description = new TextView(this);
        description.setText(t("Configura el idioma de la interfaz y tu país o región."));
        description.setTextColor(Color.rgb(191, 205, 220));
        description.setTextSize(uiSp(13));
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        descLp.topMargin = uiDp(5);
        descLp.bottomMargin = uiDp(18);
        content.addView(description, descLp);

        LinearLayout languageCard = makeDesign3MenuCard("flag:" + languageFlagCode(appLanguage),
                t("Idioma de la aplicación"), UiStrings.languageName(appLanguage), true);
        languageCard.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSettingsLanguageScreen(); }
        });
        content.addView(languageCard, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(66)));

        LinearLayout regionCard = makeDesign3MenuCard("flag:" + appRegion,
                t("País / Región"), UiStrings.regionName(appRegion, appLanguage), true);
        regionCard.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSettingsRegionScreen(); }
        });
        LinearLayout.LayoutParams regionLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(66));
        regionLp.topMargin = uiDp(10);
        content.addView(regionCard, regionLp);

        TextView ready = new TextView(this);
        ready.setText(t("La región ayuda a elegir el acento de voz cuando está disponible."));
        ready.setTextColor(Color.rgb(148, 163, 184));
        ready.setTextSize(uiSp(12));
        ready.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams readyLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        readyLp.topMargin = uiDp(16);
        content.addView(ready, readyLp);

        screen.addView(content, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        presentSettingsSubscreen(screen);
    }

    private void showSettingsLanguageScreen() {
        settingsMode = true;
        settingsSubscreen = 2;

        LinearLayout screen = makeSettingsSubscreenBase(t("Idioma de la aplicación"), new View.OnClickListener() {
            @Override public void onClick(View v) { showLanguageRegionSettingsScreen(); }
        });

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(uiDp(16), uiDp(12), uiDp(16), uiDp(18));

        TextView globe = makeRoundHeaderIcon("🌐");
        content.addView(globe, new LinearLayout.LayoutParams(uiDp(54), uiDp(54)));

        TextView title = new TextView(this);
        title.setText(t("Elige tu idioma"));
        title.setTextColor(Color.WHITE);
        title.setTextSize(uiSp(25));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleLp.topMargin = uiDp(8);
        content.addView(title, titleLp);

        TextView info = new TextView(this);
        info.setText(t("Puedes cambiarlo cuando quieras desde Ajustes."));
        info.setTextColor(Color.rgb(191, 205, 220));
        info.setTextSize(uiSp(14));
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        infoLp.topMargin = uiDp(5);
        infoLp.bottomMargin = uiDp(16);
        content.addView(info, infoLp);

        final String[] codes = new String[]{UiStrings.ES, UiStrings.EN, UiStrings.PT, UiStrings.HI, UiStrings.ID};
        final String[] flagCodes = new String[]{"ES", "US", "BR", "IN", "ID"};
        final String[] names = new String[]{"Español", "English", "Português (Brasil)", "हिन्दी — Hindi", "Bahasa Indonesia"};
        final String deviceLanguage = UiStrings.detectDeviceLanguage();

        for (int i = 0; i < codes.length; i++) {
            final String code = codes[i];
            String note = code.equals(deviceLanguage) ? t("Idioma del dispositivo") : "";
            View option = makeDesign3SelectionRow(flagCodes[i], names[i], note,
                    code.equals(UiStrings.normalize(appLanguage)));
            option.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!code.equals(UiStrings.normalize(appLanguage))) {
                        appLanguage = code;
                        prefs.edit()
                                .putString(UiStrings.PREF_LANGUAGE, code)
                                .putBoolean(UiStrings.PREF_LANGUAGE_CHOSEN, true)
                                .apply();
                        settingsNeedsMainRebuild = true;
                    }
                    showSettingsLanguageScreen();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, uiDp(58));
            lp.bottomMargin = uiDp(8);
            content.addView(option, lp);
        }

        screen.addView(content, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        presentSettingsSubscreen(screen);
    }

    private void showSettingsRegionScreen() {
        settingsMode = true;
        settingsSubscreen = 3;

        final LinearLayout screen = makeSettingsSubscreenBase(t("País / Región"), new View.OnClickListener() {
            @Override public void onClick(View v) { showLanguageRegionSettingsScreen(); }
        });
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(uiDp(16), uiDp(10), uiDp(16), uiDp(16));

        final EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("🔎  " + t("Buscar país..."));
        search.setTextSize(uiSp(16));
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.rgb(148, 163, 184));
        search.setPadding(uiDp(16), 0, uiDp(16), 0);
        GradientDrawable searchBg = new GradientDrawable();
        searchBg.setCornerRadius(uiDp(18));
        searchBg.setColor(Color.rgb(8, 31, 51));
        searchBg.setStroke(uiDp(1), Color.rgb(37, 84, 120));
        search.setBackground(searchBg);
        body.addView(search, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(52)));

        LinearLayout regionStatus = new LinearLayout(this);
        regionStatus.setOrientation(LinearLayout.HORIZONTAL);
        regionStatus.setGravity(Gravity.CENTER_VERTICAL);
        regionStatus.setPadding(uiDp(4), 0, uiDp(4), 0);
        LinearLayout currentBox = new LinearLayout(this);
        currentBox.setOrientation(LinearLayout.HORIZONTAL);
        currentBox.setGravity(Gravity.CENTER_VERTICAL);

        TextView currentPrefix = new TextView(this);
        currentPrefix.setText(t("Región actual") + ":");
        currentPrefix.setTextColor(Color.WHITE);
        currentPrefix.setTextSize(uiSp(14));
        currentPrefix.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        currentBox.addView(currentPrefix, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, uiDp(42)));

        ImageView currentFlag = makeFlagImageView(appRegion);
        LinearLayout.LayoutParams currentFlagLp = new LinearLayout.LayoutParams(uiDp(28), uiDp(19));
        currentFlagLp.leftMargin = uiDp(6);
        currentFlagLp.rightMargin = uiDp(6);
        currentBox.addView(currentFlag, currentFlagLp);

        TextView currentName = new TextView(this);
        currentName.setText(UiStrings.regionName(appRegion, appLanguage));
        currentName.setTextColor(Color.WHITE);
        currentName.setTextSize(uiSp(14));
        currentName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        currentName.setSingleLine(true);
        currentName.setEllipsize(TextUtils.TruncateAt.END);
        currentBox.addView(currentName, new LinearLayout.LayoutParams(0, uiDp(42), 1));

        regionStatus.addView(currentBox, new LinearLayout.LayoutParams(0, uiDp(42), 1));
        TextView total = new TextView(this);
        total.setText(t("28 países"));
        total.setTextColor(Color.rgb(96, 165, 250));
        total.setTextSize(uiSp(13));
        total.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        total.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        regionStatus.addView(total, new LinearLayout.LayoutParams(uiDp(100), uiDp(42)));
        body.addView(regionStatus, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(42)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        body.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        populateRegionRows(list, "");
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                populateRegionRows(list, s == null ? "" : s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        screen.addView(body, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        presentSettingsSubscreen(screen);
    }

    private void populateRegionRows(LinearLayout list, String query) {
        populateRegionRows(list, query, false);
    }

    private void populateRegionRows(LinearLayout list, String query, final boolean finishInitialSelection) {
        list.removeAllViews();
        String normalizedQuery = normalizeSearchText(query);
        int matches = 0;
        for (String code : UiStrings.regionCodes()) {
            final String regionCode = code;
            String name = UiStrings.regionName(code, appLanguage);
            String searchable = normalizeSearchText(name + " " + code);
            if (normalizedQuery.length() > 0 && !searchable.contains(normalizedQuery)) continue;

            View row = makeSettingsSelectionRow(code, name, code.equals(appRegion));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    appRegion = regionCode;
                    prefs.edit().putString(UiStrings.PREF_REGION, appRegion).apply();
                    if (currentPdfLanguage.length() > 0) {
                        TtsEngineManager.getInstance(MainActivity.this)
                                .setPreferredLanguage(currentPdfLanguage, appRegion);
                    }
                    if (finishInitialSelection) {
                        completeInitialRegionAndEnterApp(regionCode);
                    } else {
                        showSettingsRegionScreen();
                    }
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, uiDp(58));
            lp.bottomMargin = uiDp(7);
            list.addView(row, lp);
            matches++;
        }
        if (matches == 0) {
            TextView empty = new TextView(this);
            empty.setText(t("No se encontraron países"));
            empty.setTextColor(Color.rgb(203, 213, 225));
            empty.setTextSize(uiSp(16));
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(uiDp(12), uiDp(36), uiDp(12), uiDp(36));
            list.addView(empty, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
    }

    private View makeSettingsSelectionRow(String flagCode, String name, boolean selected) {
        return makeDesign3SelectionRow(flagCode, name, "", selected);
    }

    private TextView makeRoundHeaderIcon(String symbol) {
        TextView icon = new TextView(this);
        icon.setText(symbol);
        icon.setTextSize(uiSp(22));
        icon.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.rgb(11, 54, 91));
        bg.setStroke(uiDp(1), Color.rgb(37, 99, 235));
        icon.setBackground(bg);
        return icon;
    }

    private LinearLayout makeCompactWelcomeFeature(String iconText, String label, int accent) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(4), dp(4), dp(4), dp(4));

        TextView icon = new TextView(this);
        icon.setText(iconText);
        icon.setTextColor(Color.WHITE);
        icon.setTextSize(17);
        icon.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(Color.argb(245, Color.red(accent), Color.green(accent), Color.blue(accent)));
        iconBg.setStroke(dp(1), Color.argb(255, Math.min(255, Color.red(accent) + 35),
                Math.min(255, Color.green(accent) + 35), Math.min(255, Color.blue(accent) + 35)));
        icon.setBackground(iconBg);
        box.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));

        TextView text = new TextView(this);
        text.setText(label);
        text.setTextColor(Color.WHITE);
        text.setTextSize(13.2f);
        text.setGravity(Gravity.CENTER);
        text.setMaxLines(2);
        text.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        textLp.topMargin = dp(5);
        box.addView(text, textLp);
        return box;
    }

    private LinearLayout makeDesign3MenuCard(String iconText, String titleText, String subtitleText, boolean arrowVisible) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(12), 0, uiDp(12), 0);
        row.setClickable(true);
        row.setFocusable(true);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(18));
        bg.setColor(Color.rgb(8, 34, 55));
        bg.setStroke(uiDp(1), Color.rgb(30, 76, 109));
        row.setBackground(bg);

        View icon;
        if (iconText != null && iconText.startsWith("flag:")) {
            FrameLayout holder = new FrameLayout(this);
            GradientDrawable iconBg = new GradientDrawable();
            iconBg.setCornerRadius(uiDp(13));
            iconBg.setColor(Color.rgb(10, 49, 82));
            iconBg.setStroke(uiDp(1), Color.rgb(37, 99, 235));
            holder.setBackground(iconBg);

            ImageView flagIcon = makeFlagImageView(iconText.substring(5));
            FrameLayout.LayoutParams flagLp = new FrameLayout.LayoutParams(uiDp(36), uiDp(24), Gravity.CENTER);
            holder.addView(flagIcon, flagLp);
            icon = holder;
        } else {
            TextView textIcon = new TextView(this);
            textIcon.setText(iconText);
            textIcon.setTextSize(uiSp(25));
            textIcon.setGravity(Gravity.CENTER);
            textIcon.setAlpha(1f);
            GradientDrawable iconBg = new GradientDrawable();
            iconBg.setCornerRadius(uiDp(13));
            iconBg.setColor(Color.rgb(10, 49, 82));
            iconBg.setStroke(uiDp(1), Color.rgb(37, 99, 235));
            textIcon.setBackground(iconBg);
            icon = textIcon;
        }
        row.addView(icon, new LinearLayout.LayoutParams(uiDp(46), uiDp(42)));

        LinearLayout words = new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams wordsLp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        wordsLp.leftMargin = uiDp(12);
        row.addView(words, wordsLp);

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextColor(Color.WHITE);
        title.setTextSize(uiSp(15));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        words.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText(subtitleText);
        subtitle.setTextColor(Color.rgb(191, 205, 220));
        subtitle.setTextSize(uiSp(12));
        subtitle.setMaxLines(1);
        subtitle.setEllipsize(TextUtils.TruncateAt.END);
        words.addView(subtitle);

        if (arrowVisible) {
            TextView arrow = new TextView(this);
            arrow.setText("›");
            arrow.setTextColor(Color.rgb(59, 130, 246));
            arrow.setTextSize(uiSp(30));
            arrow.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            arrow.setGravity(Gravity.CENTER);
            row.addView(arrow, new LinearLayout.LayoutParams(uiDp(28), uiDp(48)));
        }
        return row;
    }

    private int flagDrawableRes(String countryCode) {
        if (countryCode == null) return 0;
        switch (countryCode.toUpperCase(Locale.ROOT)) {
            case "PE": return R.drawable.flag_pe;
            case "MX": return R.drawable.flag_mx;
            case "CO": return R.drawable.flag_co;
            case "AR": return R.drawable.flag_ar;
            case "CL": return R.drawable.flag_cl;
            case "EC": return R.drawable.flag_ec;
            case "BO": return R.drawable.flag_bo;
            case "PY": return R.drawable.flag_py;
            case "UY": return R.drawable.flag_uy;
            case "VE": return R.drawable.flag_ve;
            case "GT": return R.drawable.flag_gt;
            case "HN": return R.drawable.flag_hn;
            case "SV": return R.drawable.flag_sv;
            case "NI": return R.drawable.flag_ni;
            case "CR": return R.drawable.flag_cr;
            case "PA": return R.drawable.flag_pa;
            case "CU": return R.drawable.flag_cu;
            case "DO": return R.drawable.flag_do;
            case "ES": return R.drawable.flag_es;
            case "BR": return R.drawable.flag_br;
            case "PT": return R.drawable.flag_pt;
            case "IN": return R.drawable.flag_in;
            case "ID": return R.drawable.flag_id;
            case "PH": return R.drawable.flag_ph;
            case "US": return R.drawable.flag_us;
            case "GB": return R.drawable.flag_gb;
            case "CA": return R.drawable.flag_ca;
            case "AU": return R.drawable.flag_au;
            default: return 0;
        }
    }

    private ImageView makeFlagImageView(String countryCode) {
        ImageView flag = new ImageView(this);
        int resId = flagDrawableRes(countryCode);
        if (resId != 0) flag.setImageResource(resId);
        flag.setScaleType(ImageView.ScaleType.FIT_CENTER);
        flag.setAdjustViewBounds(false);

        GradientDrawable clip = new GradientDrawable();
        clip.setColor(Color.TRANSPARENT);
        clip.setCornerRadius(uiDp(4));
        flag.setBackground(clip);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            flag.setClipToOutline(true);
        }
        return flag;
    }

    private View makeDesign3SelectionRow(String flagCode, String name, String note, boolean selected) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(12), 0, uiDp(12), 0);
        row.setClickable(true);
        row.setFocusable(true);

        GradientDrawable bg;
        if (selected) {
            bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.rgb(37, 99, 235), Color.rgb(29, 78, 216)});
            bg.setCornerRadius(uiDp(16));
            bg.setStroke(uiDp(1), Color.rgb(96, 165, 250));
        } else {
            bg = new GradientDrawable();
            bg.setCornerRadius(uiDp(16));
            bg.setColor(Color.rgb(8, 31, 51));
            bg.setStroke(uiDp(1), Color.rgb(31, 65, 88));
        }
        row.setBackground(bg);

        ImageView flagView = makeFlagImageView(flagCode);
        row.addView(flagView, new LinearLayout.LayoutParams(uiDp(46), uiDp(31)));

        LinearLayout words = new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams wordsLp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        wordsLp.leftMargin = uiDp(12);
        row.addView(words, wordsLp);

        TextView nameView = new TextView(this);
        nameView.setText(name);
        nameView.setTextColor(Color.WHITE);
        nameView.setTextSize(uiSp(17));
        nameView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        nameView.setMaxLines(1);
        nameView.setEllipsize(TextUtils.TruncateAt.END);
        words.addView(nameView);

        if (note != null && note.length() > 0) {
            TextView noteView = new TextView(this);
            noteView.setText(note);
            noteView.setTextColor(selected ? Color.WHITE : Color.rgb(203, 213, 225));
            noteView.setTextSize(uiSp(11));
            noteView.setMaxLines(1);
            words.addView(noteView);
        }

        TextView marker = new TextView(this);
        marker.setText(selected ? "✓" : "○");
        marker.setTextColor(selected ? Color.WHITE : Color.rgb(148, 163, 184));
        marker.setTextSize(uiSp(selected ? 20f : 24f));
        marker.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        marker.setGravity(Gravity.CENTER);
        if (selected) {
            GradientDrawable markerBg = new GradientDrawable();
            markerBg.setShape(GradientDrawable.OVAL);
            markerBg.setColor(Color.rgb(59, 130, 246));
            marker.setBackground(markerBg);
        }
        row.addView(marker, new LinearLayout.LayoutParams(uiDp(32), uiDp(32)));
        return row;
    }

    private LinearLayout makeSettingsSubscreenBase(String titleText, View.OnClickListener backListener) {
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));
        screen.setClickable(true);
        screen.setFocusable(true);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        View back = makeNavigationButton("back", false);
        back.setOnClickListener(backListener);
        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextSize(uiSp(22));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);
        View spacer = new View(this);
        top.addView(back, new LinearLayout.LayoutParams(uiDp(42), uiDp(46)));
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(title, new LinearLayout.LayoutParams(0, uiDp(46), 1));
        top.addView(spacer, new LinearLayout.LayoutParams(uiDp(42), uiDp(46)));
        screen.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(62)));
        return screen;
    }

    private void presentSettingsSubscreen(View screen) {
        if (screenHost == null) {
            screenHost = new FrameLayout(this);
            if (root != null) {
                screenHost.addView(root, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
        }
        if (screenHost.getParent() == null) setContentView(screenHost);
        if (settingsOverlay != null && settingsOverlay.getParent() == screenHost) {
            screenHost.removeView(settingsOverlay);
        }
        settingsOverlay = screen;
        screenHost.addView(settingsOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private String languageFlagCode(String language) {
        language = UiStrings.normalize(language);
        if (UiStrings.ES.equals(language)) return "ES";
        if (UiStrings.PT.equals(language)) return "BR";
        if (UiStrings.HI.equals(language)) return "IN";
        if (UiStrings.ID.equals(language)) return "ID";
        return "US";
    }

    private String normalizeSearchText(String value) {
        if (value == null) return "";
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        return normalized.toLowerCase(Locale.ROOT).trim();
    }

    private void buildSettingsScreen() {
        settingsSubscreen = 0;
        if (settingsScrollView != null) {
            settingsScrollY = settingsScrollView.getScrollY();
        }

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));
        // Consume taps on empty settings areas so they never fall through to
        // the page selector or controls in the reader underneath.
        screen.setClickable(true);
        screen.setFocusable(true);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        View back = makeNavigationButton("back", false);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeSettings();
            }
        });

        TextView title = new TextView(this);
        title.setText(t("Ajustes"));
        title.setTextSize(uiSp(24));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);

        View topSpacer = new View(this);
        topSpacer.setClickable(true);
        top.setClickable(true);

        top.addView(back, new LinearLayout.LayoutParams(uiDp(42), uiDp(46)));
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(title, new LinearLayout.LayoutParams(0, uiDp(46), 1));
        top.addView(topSpacer, new LinearLayout.LayoutParams(uiDp(42), uiDp(46)));

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(uiDp(14), uiDp(8), uiDp(14), uiDp(22));

        addSettingsSection(content, "IDIOMA Y REGIÓN");
        LinearLayout languageRegionEntry = makeDesign3MenuCard("🌐", t("Idioma y región"),
                UiStrings.languageName(appLanguage) + " · " + UiStrings.regionName(appRegion, appLanguage), true);
        languageRegionEntry.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showLanguageRegionSettingsScreen(); }
        });
        LinearLayout.LayoutParams languageRegionEntryLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(66));
        languageRegionEntryLp.bottomMargin = uiDp(6);
        content.addView(languageRegionEntry, languageRegionEntryLp);

        addSettingsSection(content, "APARIENCIA");
        addChoiceRow(content, "☀", "Tema claro", "Fondo blanco", !darkTheme, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (darkTheme) toggleTheme();
            }
        });
        addChoiceRow(content, "☾", "Tema oscuro", "Fondo oscuro", darkTheme, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!darkTheme) toggleTheme();
            }
        });
        addSettingsSection(content, "LECTURA Y AUDIO");
        addActionRow(content, "♬", "Voces", "Ver voces instaladas y faltantes", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showVoicesScreen();
            }
        });
        addActionRow(content, "♬", "Motor de voz", getVoiceSummary(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showVoiceEngineDialog();
            }
        });
        addActionRow(content, "♪", "Probar voz", "Escuchar una muestra", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testSystemVoice();
            }
        });
        addActionRow(content, "◴", "Velocidad", formatSpeed(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSpeedDialog();
            }
        });
        addSettingsSection(content, "SEGUIMIENTO VISUAL");
        final Switch[] trackingSwitchHolder = new Switch[1];
        View.OnClickListener trackingToggle = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleReadingMarker();
                if (trackingSwitchHolder[0] != null) {
                    trackingSwitchHolder[0].setChecked(readingMarkerEnabled);
                }
            }
        };
        trackingSwitchHolder[0] = addSwitchRow(content, "icon:tracking", "Seguir lectura",
                "Durante la reproducción", readingMarkerEnabled, trackingToggle);
        readingMarkerSettingsSwatch = addColorRow(content, "●", "Color del seguimiento",
                getUtilityColorRgb(COLOR_TARGET_READING_MARKER), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showUtilityColorDialog(COLOR_TARGET_READING_MARKER, "Color del seguimiento");
                    }
                });

        addSettingsSection(content, "MARCADO");
        addMarkStyleRow(content, "icon:mark", "Tipo de marcado", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkStyleDialog();
            }
        });
        addMarkThicknessRow(content, "icon:thickness", "Grosor del subrayado", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkThicknessDialog();
            }
        });
        addSettingsSection(content, "ARCHIVOS Y EXPORTACIÓN");
        addActionRow(content, "icon:files", "Mis archivos", "Ver audios, imágenes y PDF guardados", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(LIBRARY_AUDIO);
            }
        });
        addActionRow(content, "icon:audio", "Crear audio", "Página, rango o todo el PDF", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAudioExportDialog();
            }
        });
        addActionRow(content, "icon:image", "Guardar página marcada", "PNG limpio sin reglas visibles", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCurrentPageImage();
            }
        });
        addActionRow(content, "icon:pdf", "Guardar PDF marcado", "Exportar el documento con subrayados", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkedPdfExportDialog();
            }
        });

        scroll.addView(content);
        settingsScrollView = scroll;
        screen.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(62)));
        screen.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        if (screenHost == null) {
            screenHost = new FrameLayout(this);
            if (root != null) {
                screenHost.addView(root, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
        }
        if (screenHost.getParent() == null) {
            setContentView(screenHost);
        }
        if (settingsOverlay != null && settingsOverlay.getParent() == screenHost) {
            screenHost.removeView(settingsOverlay);
        }
        settingsOverlay = screen;
        screenHost.addView(settingsOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        if (settingsScrollView != null) {
            final int restoreY = settingsScrollY;
            settingsScrollView.post(new Runnable() {
                @Override
                public void run() {
                    settingsScrollView.scrollTo(0, restoreY);
                }
            });
        }
    }

    private Button makeFlatIconButton(String text) {
        Button b = new Button(this);
        b.setText(t(text));
        b.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        b.setTextSize(uiSp(24));
        b.setAllCaps(false);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private View makeNavigationButton(String direction, boolean filled) {
        FrameLayout button = new FrameLayout(this);
        button.setClickable(true);
        button.setFocusable(true);
        button.setContentDescription(t("left".equals(direction) || "back".equals(direction)
                ? "Regresar" : "Siguiente"));
        button.setBackgroundColor(filled
                ? (darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255))
                : Color.TRANSPARENT);

        SettingsIconView icon = new SettingsIconView(this);
        icon.setIconType(direction);
        icon.setIconColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        int navIconSize = filled ? 28 : 26;
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(uiDp(navIconSize), uiDp(navIconSize));
        iconLp.gravity = Gravity.CENTER;
        button.addView(icon, iconLp);
        return button;
    }


    private View makeMarkHistoryButton(String type, String description) {
        FrameLayout button = new FrameLayout(this);
        button.setClickable(true);
        button.setFocusable(true);
        button.setContentDescription(t(description));
        button.setBackgroundColor(darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255));

        ImageView icon = new ImageView(this);
        icon.setImageResource("redo".equals(type) ? R.drawable.ic_mark_redo : R.drawable.ic_mark_undo);
        icon.setColorFilter(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(30, 41, 59));
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(uiDp(25), uiDp(25));
        iconLp.gravity = Gravity.CENTER;
        button.addView(icon, iconLp);
        return button;
    }

    private TextView makeDialogTitleView(String text) {
        TextView tv = new TextView(this);
        tv.setText(t(text));
        tv.setTextSize(22);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        tv.setPadding(dp(22), dp(18), dp(22), dp(10));
        tv.setBackgroundColor(darkTheme ? Color.rgb(7, 28, 42) : Color.WHITE);
        return tv;
    }

    private LinearLayout makeDialogContainer() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(14), dp(18), dp(16));
        box.setBackgroundColor(darkTheme ? Color.rgb(10, 24, 38) : Color.WHITE);
        return box;
    }

    private void styleDialog(AlertDialog dialog) {
        if (dialog == null) return;
        if (dialog.getWindow() != null) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(18));
            bg.setColor(darkTheme ? Color.rgb(10, 24, 38) : Color.WHITE);
            dialog.getWindow().setBackgroundDrawable(bg);
        }
        int accent = Color.rgb(59, 130, 246);
        Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        Button negative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        Button neutral = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
        if (positive != null) positive.setTextColor(accent);
        if (negative != null) negative.setTextColor(accent);
        if (neutral != null) neutral.setTextColor(accent);
    }

    private void addSettingsSection(LinearLayout parent, String title) {
        TextView tv = new TextView(this);
        tv.setText(t(title));
        tv.setTextSize(uiSp(13));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(Color.rgb(59, 130, 246));
        tv.setPadding(uiDp(4), uiDp(15), uiDp(4), uiDp(6));
        parent.addView(tv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private File getAudioSaveDir() {
        return ensureDirectory(new File(new File(getStorageBase(Environment.DIRECTORY_MUSIC), "Geo_Zeta"), "Audios"));
    }

    private File getImageSaveDir() {
        return ensureDirectory(new File(new File(getStorageBase(Environment.DIRECTORY_PICTURES), "Geo_Zeta"), "Imagenes"));
    }

    private File getPdfSaveDir() {
        return ensureDirectory(new File(new File(getStorageBase(Environment.DIRECTORY_DOCUMENTS), "Geo_Zeta"), "PDF_Marcados"));
    }

    private File getStorageBase(String type) {
        File base = getExternalFilesDir(type);
        return base == null ? getFilesDir() : base;
    }

    private File ensureDirectory(File directory) {
        if (directory != null && !directory.exists()) directory.mkdirs();
        return directory;
    }

    private void addStorageDestinationCard(LinearLayout parent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(8), dp(10), dp(8));
        row.setBackgroundColor(darkTheme ? Color.rgb(12, 35, 54) : Color.WHITE);

        TextView icon = new TextView(this);
        icon.setText(t("📁"));
        icon.setTextSize(22);
        icon.setGravity(Gravity.CENTER);
        icon.setContentDescription(t("Carpetas de guardado"));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText(t("Carpetas de guardado"));
        title.setTextSize(15);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView subtitle = new TextView(this);
        subtitle.setText(t("Audios · Imágenes · PDF"));
        subtitle.setTextSize(11);
        subtitle.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        texts.addView(title);
        texts.addView(subtitle);

        TextView arrow = new TextView(this);
        arrow.setText(t("›"));
        arrow.setTextSize(25);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));

        row.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(52)));
        row.addView(texts, new LinearLayout.LayoutParams(0, dp(56), 1));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(38), dp(56)));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStorageFoldersDialog();
            }
        });
        addRowWithMargin(parent, row);
    }

    private void showStorageFoldersDialog() {
        LinearLayout box = makeDialogContainer();
        box.setPadding(dp(12), dp(10), dp(12), dp(10));

        TextView info = new TextView(this);
        info.setText(t("Cada formato se guarda en su propia carpeta y también aparece en Mis archivos."));
        info.setTextSize(13);
        info.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
        info.setPadding(dp(4), 0, dp(4), dp(8));
        box.addView(info);

        final AlertDialog[] dialogHolder = new AlertDialog[1];
        addStorageFolderRow(box, "♫", "Audios", "Geo Zeta / Audios", LIBRARY_AUDIO, dialogHolder);
        addStorageFolderRow(box, "📁", "Imágenes", "Geo Zeta / Imágenes", LIBRARY_IMAGE, dialogHolder);
        addStorageFolderRow(box, "PDF", "PDF marcados", "Geo Zeta / PDF marcados", LIBRARY_PDF, dialogHolder);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Carpetas de guardado"))
                .setView(box)
                .setNegativeButton(t("Cerrar"), null)
                .create();
        dialogHolder[0] = dialog;
        dialog.show();
        styleDialog(dialog);
    }

    private void addStorageFolderRow(LinearLayout parent, String iconText, String titleText, String pathText, final int libraryType, final AlertDialog[] dialogHolder) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(10), dp(10));

        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(dp(14));
        background.setColor(darkTheme ? Color.rgb(12, 35, 54) : Color.rgb(248, 250, 252));
        row.setBackground(background);

        TextView icon = new TextView(this);
        icon.setText(iconText);
        icon.setTextSize(iconText.equals("PDF") ? 16 : 24);
        icon.setTypeface(Typeface.DEFAULT_BOLD);
        icon.setGravity(Gravity.CENTER);
        icon.setTextColor(Color.WHITE);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(Color.rgb(37, 99, 235));
        icon.setBackground(iconBg);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(12), 0, dp(8), 0);

        TextView title = new TextView(this);
        title.setText(t(titleText));
        title.setTextSize(15);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView path = new TextView(this);
        path.setText(pathText);
        path.setTextSize(12);
        path.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        texts.addView(title);
        texts.addView(path);

        TextView arrow = new TextView(this);
        arrow.setText(t("›"));
        arrow.setTextSize(26);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.WHITE : Color.rgb(71, 85, 105));

        row.addView(icon, new LinearLayout.LayoutParams(dp(52), dp(52)));
        row.addView(texts, new LinearLayout.LayoutParams(0, dp(54), 1));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(32), dp(54)));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dialogHolder != null && dialogHolder.length > 0 && dialogHolder[0] != null) {
                    dialogHolder[0].dismiss();
                }
                showFileLibrary(libraryType);
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(4));
        parent.addView(row, lp);
    }

    private LinearLayout makeCardRow(String icon, String title, String sub) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(12), uiDp(8), uiDp(10), uiDp(8));
        row.setBackgroundColor(darkTheme ? Color.rgb(12, 35, 54) : Color.WHITE);

        View iconView;
        if (icon != null && icon.startsWith("icon:")) {
            SettingsIconView customIcon = new SettingsIconView(this);
            customIcon.setIconType(icon.substring(5));
            iconView = customIcon;
        } else {
            TextView textIcon = new TextView(this);
            textIcon.setText(icon);
            textIcon.setTextSize(uiSp(24));
            textIcon.setGravity(Gravity.CENTER);
            textIcon.setTextColor(Color.rgb(59, 130, 246));
            iconView = textIcon;
        }

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);

        TextView titleView = new TextView(this);
        titleView.setText(t(title));
        titleView.setTextSize(uiSp(16));
        titleView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView subView = new TextView(this);
        subView.setText(sub == null ? "" : t(sub));
        subView.setTextSize(uiSp(11));
        subView.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        texts.addView(titleView);
        if (sub != null && sub.length() > 0) texts.addView(subView);

        row.addView(iconView, new LinearLayout.LayoutParams(uiDp(44), uiDp(48)));
        row.addView(texts, new LinearLayout.LayoutParams(0, uiDp(50), 1));
        return row;
    }

    private void addChoiceRow(LinearLayout parent, String icon, String title, String sub, boolean selected, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        TextView check = new TextView(this);
        check.setText(selected ? "◉" : "○");
        check.setTextSize(uiSp(24));
        check.setTextColor(selected ? Color.rgb(59, 130, 246) : Color.rgb(148, 163, 184));
        check.setGravity(Gravity.CENTER);
        row.addView(check, new LinearLayout.LayoutParams(uiDp(46), uiDp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private Switch addSwitchRow(LinearLayout parent, String icon, String title, String sub, boolean checked, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        Switch sw = new Switch(this);
        sw.setChecked(checked);
        sw.setEnabled(listener != null);
        if (listener != null) {
            sw.setOnClickListener(listener);
            row.setOnClickListener(listener);
        }
        row.addView(sw, new LinearLayout.LayoutParams(uiDp(64), uiDp(56)));
        addRowWithMargin(parent, row);
        return sw;
    }

    private void addActionRow(LinearLayout parent, String icon, String title, String sub, String right, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        TextView arrow = new TextView(this);
        arrow.setText(right == null ? "" : right);
        arrow.setTextSize(uiSp(25));
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(uiDp(38), uiDp(56)));
        if (listener != null) row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private void addMarkStyleRow(LinearLayout parent, String icon, String title, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, "");
        View sample = createInlineMarkStylePreview(markStyle);
        row.addView(sample, new LinearLayout.LayoutParams(uiDp(92), uiDp(56)));
        TextView arrow = new TextView(this);
        arrow.setText(t("›"));
        arrow.setTextSize(uiSp(25));
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(uiDp(32), uiDp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private void addMarkThicknessRow(LinearLayout parent, String icon, String title, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, "");
        View sample = createInlineThicknessPreview(markThicknessLevel);
        row.addView(sample, new LinearLayout.LayoutParams(uiDp(92), uiDp(56)));
        TextView arrow = new TextView(this);
        arrow.setText(t("›"));
        arrow.setTextSize(uiSp(25));
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(uiDp(32), uiDp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private View createInlineThicknessPreview(int level) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(6), 0, dp(6), 0);
        int thickness = getPreviewLineThickness(level);
        int color = darkTheme ? Color.WHITE : Color.rgb(15, 23, 42);
        View line = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(3));
        line.setBackground(d);
        box.addView(line, new LinearLayout.LayoutParams(dp(54), thickness));
        return box;
    }

    private View createInlineMarkStylePreview(int style) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(4), dp(2), dp(4), dp(2));
        View line = createPreviewUnderlineView(style, markThicknessLevel, getCurrentMarkColor(), dp(58));
        box.addView(line);
        return box;
    }

    private int getPreviewLineThickness(int level) {
        if (level <= 0) return dp(2);
        if (level >= 2) return dp(6);
        return dp(4);
    }

    private int getPreviewLineColor(int color) {
        return 0xFF000000 | (color & 0x00FFFFFF);
    }

    private void applySampleDecoration(TextView sample, int style, int color) {
        sample.setBackground(null);
        sample.setPadding(dp(6), dp(2), dp(6), dp(2));
        int lineColor = getPreviewLineColor(color);

        if (style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(4));
            int alpha = style == MARK_STYLE_HIGHLIGHT_INTENSE ? 0xA8 : 0x62;
            bg.setColor((alpha << 24) | (lineColor & 0x00FFFFFF));
            sample.setBackground(bg);
        }
    }

    private View createPreviewUnderlineView(int style, int thicknessLevel, int color, int width) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        int lineColor = getPreviewLineColor(color);
        int thickness = getPreviewLineThickness(thicknessLevel);

        if (style == MARK_STYLE_UNDERLINE_DOUBLE) {
            for (int i = 0; i < 2; i++) {
                View line = new View(this);
                GradientDrawable d = new GradientDrawable();
                d.setColor(lineColor);
                d.setCornerRadius(dp(3));
                line.setBackground(d);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, Math.max(dp(2), thickness - dp(1)));
                lp.setMargins(0, i == 0 ? 0 : dp(3), 0, 0);
                box.addView(line, lp);
            }
            return box;
        }

        if (style == MARK_STYLE_UNDERLINE_DOTTED) {
            LinearLayout dots = new LinearLayout(this);
            dots.setOrientation(LinearLayout.HORIZONTAL);
            dots.setGravity(Gravity.CENTER);
            int dot = Math.max(dp(3), thickness);
            for (int i = 0; i < 7; i++) {
                View v = new View(this);
                GradientDrawable d = new GradientDrawable();
                d.setShape(GradientDrawable.OVAL);
                d.setColor(lineColor);
                v.setBackground(d);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dot, dot);
                lp.setMargins(dp(1), 0, dp(1), 0);
                dots.addView(v, lp);
            }
            box.addView(dots);
            return box;
        }

        if (style == MARK_STYLE_UNDERLINE_WAVY) {
            TextView wave = new TextView(this);
            wave.setText(t("﹏﹏﹏﹏"));
            wave.setTextSize(16);
            wave.setTextColor(lineColor);
            wave.setGravity(Gravity.CENTER);
            box.addView(wave, new LinearLayout.LayoutParams(width, LinearLayout.LayoutParams.WRAP_CONTENT));
            return box;
        }

        View line = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(lineColor);
        d.setCornerRadius(dp(3));
        line.setBackground(d);
        box.addView(line, new LinearLayout.LayoutParams(width, thickness));
        return box;
    }

    private TextView addColorRow(LinearLayout parent, String icon, String title, int color, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, "");

        TextView swatch = new TextView(this);
        swatch.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF000000 | (color & 0x00FFFFFF));
        circle.setStroke(uiDp(2), darkTheme ? Color.WHITE : Color.rgb(71, 85, 105));
        swatch.setBackground(circle);
        swatch.setContentDescription(t("Color seleccionado"));

        LinearLayout.LayoutParams swatchParams = new LinearLayout.LayoutParams(uiDp(30), uiDp(30));
        swatchParams.setMargins(uiDp(4), uiDp(13), uiDp(6), uiDp(13));
        row.addView(swatch, swatchParams);

        TextView arrow = new TextView(this);
        arrow.setText(t("›"));
        arrow.setTextSize(uiSp(25));
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(uiDp(32), uiDp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
        return swatch;
    }

    private void updateReadingMarkerSettingsSwatch() {
        if (readingMarkerSettingsSwatch == null) return;
        int color = getUtilityColorRgb(COLOR_TARGET_READING_MARKER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF000000 | (color & 0x00FFFFFF));
        circle.setStroke(dp(2), darkTheme ? Color.WHITE : Color.rgb(71, 85, 105));
        readingMarkerSettingsSwatch.setBackground(circle);
    }

    private void addRowWithMargin(LinearLayout parent, View row) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(58));
        lp.setMargins(0, uiDp(3), 0, uiDp(3));
        parent.addView(row, lp);
    }

    private String formatReadingBrightness() {
        if (readingBrightness < 0f) return "Brillo del sistema";
        return Math.round(readingBrightness * 100f) + "%";
    }

    private void applyReadingBrightness() {
        try {
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.screenBrightness = readingBrightness < 0f ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE : readingBrightness;
            getWindow().setAttributes(params);
        } catch (Exception ignored) {
        }
    }

    private void showReadingBrightnessDialog() {
        final float original = readingBrightness;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(uiDp(24), uiDp(10), uiDp(24), uiDp(6));

        final SeekBar seek = new SeekBar(this);
        seek.setMax(90);
        int current = readingBrightness < 0f ? 60 : Math.round(readingBrightness * 100f) - 10;
        seek.setProgress(Math.max(0, Math.min(90, current)));
        box.addView(seek, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(58)));

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                readingBrightness = (progress + 10) / 100f;
                applyReadingBrightness();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t("Brillo de lectura"))
                .setView(box)
                .setNegativeButton(t("Cancelar"), null)
                .setNeutralButton(t("Sistema"), null)
                .setPositiveButton(t("Guardar"), null)
                .create();

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface ignored) {
                readingBrightness = original;
                applyReadingBrightness();
            }
        });

        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(final DialogInterface ignored) {
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        readingBrightness = original;
                        applyReadingBrightness();
                        dialog.dismiss();
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        readingBrightness = -1f;
                        prefs.edit().putFloat(PREF_READING_BRIGHTNESS, readingBrightness).apply();
                        applyReadingBrightness();
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (readingBrightness < 0f) {
                            readingBrightness = (seek.getProgress() + 10) / 100f;
                        }
                        prefs.edit().putFloat(PREF_READING_BRIGHTNESS, readingBrightness).apply();
                        applyReadingBrightness();
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                });
            }
        });
        dialog.show();
    }

    private void toggleTheme() {
        darkTheme = !darkTheme;
        prefs.edit().putBoolean("dark_theme", darkTheme).apply();

        if (settingsMode) {
            settingsNeedsMainRebuild = true;
            buildSettingsScreen();
            return;
        }

        File file = currentFile;
        String title = currentTitle;
        int page = currentPage;

        buildUi();

        if (file != null && file.exists()) {
            openLocalPdfAtPage(file, title, page);
        }

        Toast.makeText(this, darkTheme ? t("Tema oscuro activado") : t("Tema claro activado"), Toast.LENGTH_SHORT).show();
    }

    private void showFileLibrary(boolean showAudio) {
        showFileLibrary(showAudio ? LIBRARY_AUDIO : LIBRARY_IMAGE);
    }

    private void showFileLibrary(int libraryType) {
        if (!libraryMode) {
            libraryReturnToSettings = settingsMode;
        }
        libraryMode = true;
        settingsMode = false;
        libraryShowingType = Math.max(LIBRARY_AUDIO, Math.min(libraryType, LIBRARY_PDF));
        stopFilePreview();

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        View back = makeNavigationButton("back", false);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFileLibrary();
            }
        });

        TextView title = new TextView(this);
        title.setText(t("Mis archivos"));
        title.setTextSize(uiSp(28));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);

        Button actionButton = makeFlatIconButton(libraryShowingType == LIBRARY_IMAGE
                ? (imageLibraryGridMode ? "☰" : "▦")
                : "↻");
        actionButton.setTextSize(libraryShowingType == LIBRARY_IMAGE ? 22 : 26);
        actionButton.setContentDescription(t(libraryShowingType == LIBRARY_IMAGE
                ? (imageLibraryGridMode ? "Ver imágenes en lista" : "Ver imágenes en cuadrícula")
                : "Actualizar archivos"));
        actionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (libraryShowingType == LIBRARY_IMAGE) {
                    imageLibraryGridMode = !imageLibraryGridMode;
                    prefs.edit().putBoolean(PREF_IMAGE_LIBRARY_GRID, imageLibraryGridMode).apply();
                }
                showFileLibrary(libraryShowingType);
            }
        });

        top.addView(back, new LinearLayout.LayoutParams(uiDp(52), uiDp(56)));
        top.addView(title, new LinearLayout.LayoutParams(0, uiDp(56), 1));
        top.addView(actionButton, new LinearLayout.LayoutParams(uiDp(52), uiDp(56)));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(uiDp(10), uiDp(6), uiDp(10), uiDp(8));
        tabs.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));

        final ArrayList<File> audioFiles = getLibraryFiles(LIBRARY_AUDIO);
        final ArrayList<File> imageFiles = getLibraryFiles(LIBRARY_IMAGE);
        final ArrayList<File> pdfFiles = getLibraryFiles(LIBRARY_PDF);

        Button audioTab = makeButton("Audios\n" + audioFiles.size());
        Button imageTab = makeButton("Imágenes\n" + imageFiles.size());
        Button pdfTab = makeButton("PDF\n" + pdfFiles.size());
        audioTab.setTextSize(uiSp(12));
        imageTab.setTextSize(uiSp(12));
        pdfTab.setTextSize(uiSp(12));
        audioTab.setAlpha(libraryShowingType == LIBRARY_AUDIO ? 1f : 0.52f);
        imageTab.setAlpha(libraryShowingType == LIBRARY_IMAGE ? 1f : 0.52f);
        pdfTab.setAlpha(libraryShowingType == LIBRARY_PDF ? 1f : 0.52f);
        audioTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(LIBRARY_AUDIO);
            }
        });
        imageTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(LIBRARY_IMAGE);
            }
        });
        pdfTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(LIBRARY_PDF);
            }
        });
        tabs.addView(audioTab, new LinearLayout.LayoutParams(0, uiDp(54), 1));
        tabs.addView(imageTab, new LinearLayout.LayoutParams(0, uiDp(54), 1));
        tabs.addView(pdfTab, new LinearLayout.LayoutParams(0, uiDp(54), 1));

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(uiDp(12), uiDp(6), uiDp(12), uiDp(24));

        addLibraryFoldersRow(list);

        ArrayList<File> files = libraryShowingType == LIBRARY_AUDIO
                ? audioFiles
                : (libraryShowingType == LIBRARY_IMAGE ? imageFiles : pdfFiles);
        if (files.isEmpty()) {
            TextView empty = new TextView(this);
            String message;
            if (libraryShowingType == LIBRARY_AUDIO) {
                message = "Todavía no hay audios guardados.\nCrea uno desde Ajustes > Crear audio.";
            } else if (libraryShowingType == LIBRARY_IMAGE) {
                message = "Todavía no hay imágenes guardadas.\nGuarda una página marcada desde Ajustes.";
            } else {
                message = "Todavía no hay PDF marcados.\nUsa Guardar PDF marcado desde Ajustes.";
            }
            empty.setText(t(message));
            empty.setTextSize(uiSp(17));
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(uiDp(20), uiDp(80), uiDp(20), uiDp(40));
            empty.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
            list.addView(empty, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        } else if (libraryShowingType == LIBRARY_IMAGE) {
            if (imageLibraryGridMode) addImageGallery(list, imageFiles);
            else addImageList(list, imageFiles);
        } else {
            for (File file : files) {
                addLibraryFileRow(list, file, libraryShowingType);
            }
        }

        scroll.addView(list);
        screen.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(78)));
        screen.addView(tabs, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(68)));
        screen.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(screen);
    }

    private void addLibraryFoldersRow(LinearLayout parent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(12), uiDp(8), uiDp(10), uiDp(8));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(14));
        bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
        bg.setStroke(uiDp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
        row.setBackground(bg);

        TextView icon = new TextView(this);
        icon.setText(t("📁"));
        icon.setTextSize(uiSp(21));
        icon.setGravity(Gravity.CENTER);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(uiDp(12), 0, uiDp(8), 0);

        TextView title = new TextView(this);
        title.setText(t("Ver carpetas de guardado"));
        title.setTextSize(uiSp(15));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView subtitle = new TextView(this);
        subtitle.setText(t("Audios · Imágenes · PDF"));
        subtitle.setTextSize(uiSp(11));
        subtitle.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));

        texts.addView(title);
        texts.addView(subtitle);

        TextView arrow = new TextView(this);
        arrow.setText(t("›"));
        arrow.setTextSize(uiSp(25));
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));

        row.addView(icon, new LinearLayout.LayoutParams(uiDp(42), uiDp(48)));
        row.addView(texts, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row.addView(arrow, new LinearLayout.LayoutParams(uiDp(36), uiDp(48)));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStorageFoldersDialog();
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, uiDp(8));
        parent.addView(row, lp);
    }

    private void closeFileLibrary() {
        stopFilePreview();
        libraryMode = false;
        if (libraryReturnToSettings) {
            libraryReturnToSettings = false;
            settingsMode = true;
            buildSettingsScreen();
            return;
        }

        settingsMode = false;
        final File file = currentFile;
        final String title = currentTitle;
        final int page = currentPage;
        buildUi();
        if (file != null && file.exists()) {
            openLocalPdfAtPage(file, title, page);
        }
    }

    private ArrayList<File> getLibraryFiles(boolean audio) {
        return getLibraryFiles(audio ? LIBRARY_AUDIO : LIBRARY_IMAGE);
    }

    private ArrayList<File> getLibraryFiles(int type) {
        ArrayList<File> result = new ArrayList<File>();
        if (type == LIBRARY_AUDIO) {
            collectLibraryFiles(getAudioSaveDir(), LIBRARY_AUDIO, result);
            collectLibraryFiles(new File(getStorageBase(Environment.DIRECTORY_MUSIC), "PDF_Audio"), LIBRARY_AUDIO, result);
        } else if (type == LIBRARY_IMAGE) {
            collectLibraryFiles(getImageSaveDir(), LIBRARY_IMAGE, result);
            collectLibraryFiles(new File(getStorageBase(Environment.DIRECTORY_PICTURES), "PDF_Audio"), LIBRARY_IMAGE, result);
        } else {
            collectLibraryFiles(getPdfSaveDir(), LIBRARY_PDF, result);
            collectLibraryFiles(new File(getStorageBase(Environment.DIRECTORY_DOCUMENTS), "PDF_Audio"), LIBRARY_PDF, result);
        }
        Collections.sort(result, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        return result;
    }

    private void collectLibraryFiles(File directory, int type, ArrayList<File> output) {
        if (directory == null || !directory.exists()) return;
        File[] children = directory.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.isDirectory()) {
                collectLibraryFiles(child, type, output);
                continue;
            }
            String name = child.getName().toLowerCase(Locale.US);
            boolean matches;
            if (type == LIBRARY_AUDIO) {
                matches = name.endsWith(".wav") || name.endsWith(".mp3") || name.endsWith(".m4a") || name.endsWith(".ogg");
            } else if (type == LIBRARY_IMAGE) {
                matches = name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".webp");
            } else {
                matches = name.endsWith(".pdf");
            }
            if (matches && !output.contains(child)) output.add(child);
        }
    }

    private void addImageGallery(LinearLayout parent, final ArrayList<File> imageFiles) {
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setUseDefaultMargins(false);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setPadding(0, uiDp(4), 0, uiDp(12));

        for (final File file : imageFiles) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setPadding(uiDp(6), uiDp(6), uiDp(6), uiDp(8));

            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(uiDp(14));
            bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
            bg.setStroke(uiDp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
            card.setBackground(bg);

            ImageView thumb = new ImageView(this);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumb.setAdjustViewBounds(false);
            Bitmap preview = decodePreviewBitmap(file, 420, 560);
            if (preview != null) {
                thumb.setImageBitmap(preview);
                if (imagePreviewCache.get(file.getAbsolutePath()) == null) {
                    imagePreviewCache.put(file.getAbsolutePath(), preview);
                }
            }
            GradientDrawable thumbBg = new GradientDrawable();
            thumbBg.setCornerRadius(uiDp(10));
            thumbBg.setColor(Color.WHITE);
            thumb.setBackground(thumbBg);
            card.addView(thumb, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(180)));

            TextView name = new TextView(this);
            name.setText(file.getName());
            name.setTextSize(uiSp(12));
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setGravity(Gravity.CENTER);
            name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
            name.setPadding(uiDp(4), uiDp(7), uiDp(4), 0);
            card.addView(name, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(32)));

            TextView details = new TextView(this);
            details.setText(formatFileDate(file.lastModified()));
            details.setTextSize(uiSp(10));
            details.setGravity(Gravity.CENTER);
            details.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));
            card.addView(details, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(24)));

            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showImagePreview(file);
                }
            });
            card.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showFileActions(file, LIBRARY_IMAGE);
                    return true;
                }
            });

            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.height = GridLayout.LayoutParams.WRAP_CONTENT;
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            lp.setMargins(uiDp(4), uiDp(4), uiDp(4), uiDp(4));
            grid.addView(card, lp);
        }

        parent.addView(grid, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void addImageList(LinearLayout parent, final ArrayList<File> imageFiles) {
        for (final File file : imageFiles) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(uiDp(10), uiDp(8), uiDp(10), uiDp(8));

            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(uiDp(14));
            bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
            bg.setStroke(uiDp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
            row.setBackground(bg);

            ImageView thumb = new ImageView(this);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Bitmap preview = decodePreviewBitmap(file, 320, 420);
            if (preview != null) {
                thumb.setImageBitmap(preview);
                if (imagePreviewCache.get(file.getAbsolutePath()) == null) {
                    imagePreviewCache.put(file.getAbsolutePath(), preview);
                }
            }
            GradientDrawable thumbBg = new GradientDrawable();
            thumbBg.setCornerRadius(uiDp(10));
            thumbBg.setColor(Color.WHITE);
            thumb.setBackground(thumbBg);
            row.addView(thumb, new LinearLayout.LayoutParams(uiDp(70), uiDp(92)));

            LinearLayout textBox = new LinearLayout(this);
            textBox.setOrientation(LinearLayout.VERTICAL);
            textBox.setGravity(Gravity.CENTER_VERTICAL);
            textBox.setPadding(uiDp(12), 0, uiDp(8), 0);

            TextView name = new TextView(this);
            name.setText(file.getName());
            name.setTextSize(uiSp(14));
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

            TextView details = new TextView(this);
            details.setText(formatFileSizePretty(file.length()) + "   " + formatFileDate(file.lastModified()));
            details.setTextSize(uiSp(11));
            details.setSingleLine(true);
            details.setEllipsize(TextUtils.TruncateAt.END);
            details.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));
            details.setPadding(0, uiDp(3), 0, 0);

            textBox.addView(name);
            textBox.addView(details);
            row.addView(textBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

            Button menu = makeFlatIconButton("⋮");
            menu.setTextSize(uiSp(24));
            menu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showFileActions(file, LIBRARY_IMAGE);
                }
            });
            row.addView(menu, new LinearLayout.LayoutParams(uiDp(40), uiDp(52)));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showImagePreview(file);
                }
            });
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showFileActions(file, LIBRARY_IMAGE);
                    return true;
                }
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, uiDp(5), 0, uiDp(5));
            parent.addView(row, lp);
        }
    }

    private void addLibraryFileRow(LinearLayout parent, final File file, final int type) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(uiDp(12), uiDp(10), uiDp(6), uiDp(10));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(14));
        bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
        bg.setStroke(uiDp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
        row.setBackground(bg);

        TextView icon = new TextView(this);
        icon.setText(type == LIBRARY_AUDIO ? "♫" : "PDF");
        icon.setTextSize(type == LIBRARY_AUDIO ? 26 : 15);
        icon.setTypeface(Typeface.DEFAULT_BOLD);
        icon.setTextColor(Color.WHITE);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setCornerRadius(uiDp(12));
        iconBg.setColor(type == LIBRARY_AUDIO ? Color.rgb(37, 99, 235) : Color.rgb(220, 38, 38));
        icon.setBackground(iconBg);
        row.addView(icon, new LinearLayout.LayoutParams(uiDp(50), uiDp(50)));

        LinearLayout textBox = new LinearLayout(this);
        textBox.setOrientation(LinearLayout.VERTICAL);
        textBox.setGravity(Gravity.CENTER_VERTICAL);
        textBox.setPadding(uiDp(10), 0, uiDp(8), 0);

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextSize(uiSp(14));
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView details = new TextView(this);
        String duration = type == LIBRARY_AUDIO ? getAudioDurationText(file) + "   " : "";
        details.setText(duration + formatFileSizePretty(file.length()) + "   " + formatFileDate(file.lastModified()));
        details.setTextSize(uiSp(11));
        details.setSingleLine(true);
        details.setEllipsize(TextUtils.TruncateAt.END);
        details.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));
        details.setPadding(0, uiDp(2), 0, 0);

        textBox.addView(name);
        textBox.addView(details);
        row.addView(textBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button menu = makeFlatIconButton("⋮");
        menu.setTextSize(uiSp(26));
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileActions(file, type);
            }
        });
        row.addView(menu, new LinearLayout.LayoutParams(uiDp(42), uiDp(54)));

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (type == LIBRARY_AUDIO) showAudioPreview(file);
                else openFileExternally(file);
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, uiDp(5), 0, uiDp(5));
        parent.addView(row, lp);
    }

    private Bitmap decodePreviewBitmap(File file, int reqWidth, int reqHeight) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            int sample = 1;
            while (bounds.outWidth / sample > reqWidth * 2 || bounds.outHeight / sample > reqHeight * 2) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = Math.max(1, sample);
            return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        } catch (Exception ignored) {
            return null;
        }
    }

    private Bitmap decodeViewerBitmap(File file, int reqWidth, int reqHeight) {
        Bitmap decoded = null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= reqWidth
                    && bounds.outHeight / (sample * 2) >= reqHeight) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = Math.max(1, sample);
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            decoded = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
            if (decoded == null) return null;

            float scale = Math.min(1f, Math.min(reqWidth / (float) decoded.getWidth(),
                    reqHeight / (float) decoded.getHeight()));
            if (scale < 0.999f) {
                int width = Math.max(1, Math.round(decoded.getWidth() * scale));
                int height = Math.max(1, Math.round(decoded.getHeight() * scale));
                Bitmap scaled = Bitmap.createScaledBitmap(decoded, width, height, true);
                if (scaled != decoded && !decoded.isRecycled()) decoded.recycle();
                decoded = scaled;
            }
            return decoded;
        } catch (Throwable ignored) {
            if (decoded != null && !decoded.isRecycled()) decoded.recycle();
            return null;
        }
    }

    private class ImagePagerAdapter extends RecyclerView.Adapter<ImagePagerAdapter.ImageHolder> {
        private final ArrayList<File> files;
        private final ZoomImageView.OnSingleTapListener tapListener;
        private final ArrayList<ImageHolder> holders = new ArrayList<ImageHolder>();
        private boolean released;

        ImagePagerAdapter(ArrayList<File> files, ZoomImageView.OnSingleTapListener tapListener) {
            this.files = files;
            this.tapListener = tapListener;
        }

        class ImageHolder extends RecyclerView.ViewHolder {
            final ZoomImageView image;
            String boundPath;

            ImageHolder(FrameLayout page, ZoomImageView image) {
                super(page);
                this.image = image;
            }

            void bindPlaceholder(String path) {
                boundPath = path;
                Bitmap hd = imageViewerCache.get(path);
                Bitmap preview = hd != null ? hd : imagePreviewCache.get(path);
                image.setImageBitmap(preview);
                image.resetZoom();
            }

            void applyBitmap(String path, Bitmap bitmap) {
                if (released || bitmap == null || boundPath == null || !boundPath.equals(path)) return;
                image.setImageBitmap(bitmap);
                image.resetZoom();
            }
        }

        @Override
        public ImageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            FrameLayout page = new FrameLayout(MainActivity.this);
            page.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
            page.setLayoutParams(new RecyclerView.LayoutParams(
                    RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));

            ZoomImageView image = new ZoomImageView(MainActivity.this);
            image.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
            image.setPadding(0, 0, 0, 0);
            image.setOnSingleTapListener(tapListener);
            page.addView(image, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

            ImageHolder holder = new ImageHolder(page, image);
            holders.add(holder);
            return holder;
        }

        @Override
        public void onBindViewHolder(final ImageHolder holder, int position) {
            final File file = files.get(position);
            final String path = file.getAbsolutePath();
            holder.bindPlaceholder(path);
            requestHighQualityImage(file, holder);
        }

        private void requestHighQualityImage(final File file, final ImageHolder holder) {
            final String path = file.getAbsolutePath();
            Bitmap cached = imageViewerCache.get(path);
            if (cached != null) {
                holder.applyBitmap(path, cached);
                return;
            }
            synchronized (imageDecodeInFlight) {
                if (imageDecodeInFlight.contains(path)) return;
                imageDecodeInFlight.add(path);
            }
            imageDecodeExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    final Bitmap decoded = decodeViewerBitmap(file, 1800, 2800);
                    synchronized (imageDecodeInFlight) {
                        imageDecodeInFlight.remove(path);
                    }
                    if (decoded != null) imageViewerCache.put(path, decoded);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!released && decoded != null) holder.applyBitmap(path, decoded);
                        }
                    });
                }
            });
        }

        void preload(int center) {
            int from = Math.max(0, center - 2);
            int to = Math.min(files.size() - 1, center + 2);
            for (int i = from; i <= to; i++) {
                final int preloadIndex = i;
                final File file = files.get(i);
                final String path = file.getAbsolutePath();
                if (imageViewerCache.get(path) != null) continue;
                synchronized (imageDecodeInFlight) {
                    if (imageDecodeInFlight.contains(path)) continue;
                    imageDecodeInFlight.add(path);
                }
                imageDecodeExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        Bitmap decoded = decodeViewerBitmap(file, 1800, 2800);
                        synchronized (imageDecodeInFlight) {
                            imageDecodeInFlight.remove(path);
                        }
                        if (decoded != null) {
                            imageViewerCache.put(path, decoded);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (!released && preloadIndex >= 0 && preloadIndex < getItemCount()) {
                                        notifyItemChanged(preloadIndex);
                                    }
                                }
                            });
                        }
                    }
                });
            }
        }

        @Override
        public int getItemCount() {
            return files.size();
        }

        @Override
        public void onViewRecycled(ImageHolder holder) {
            holder.boundPath = null;
            holder.image.setImageBitmap(null);
            super.onViewRecycled(holder);
        }

        void release() {
            released = true;
            for (ImageHolder holder : holders) {
                if (holder != null) {
                    holder.boundPath = null;
                    holder.image.setImageBitmap(null);
                }
            }
            holders.clear();
        }
    }

    private void showImagePreview(final File file) {
        showFullscreenImageViewer(file);
    }

    private ViewGroup getOverlayHost() {
        if (screenHost != null && screenHost.getParent() != null) {
            return screenHost;
        }
        View content = findViewById(android.R.id.content);
        if (content instanceof ViewGroup) {
            return (ViewGroup) content;
        }
        return null;
    }

    private void showFullscreenImageViewer(final File startFile) {
        final ArrayList<File> images = getLibraryFiles(LIBRARY_IMAGE);
        if (images.isEmpty()) {
            Toast.makeText(this, t("No hay imágenes guardadas"), Toast.LENGTH_SHORT).show();
            return;
        }

        stopFilePreview();
        imageViewerMode = true;

        int startIndex = images.indexOf(startFile);
        if (startIndex < 0) startIndex = 0;

        final FrameLayout screen = new FrameLayout(this);
        screen.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
        screen.setClickable(true);
        screen.setFocusable(true);

        final LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(uiDp(8), uiDp(8), uiDp(8), uiDp(8));
        top.setBackgroundColor(darkTheme ? 0xCC08283A : 0xDDEAF2F8);

        View close = makeNavigationButton("back", false);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setGravity(Gravity.CENTER_VERTICAL);

        final TextView counter = new TextView(this);
        counter.setTextSize(uiSp(15));
        counter.setTypeface(Typeface.DEFAULT_BOLD);
        counter.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        final TextView fileName = new TextView(this);
        fileName.setTextSize(uiSp(12));
        fileName.setSingleLine(true);
        fileName.setEllipsize(TextUtils.TruncateAt.END);
        fileName.setTextColor(darkTheme ? Color.rgb(215, 227, 244) : Color.rgb(71, 85, 105));

        titleBox.addView(counter);
        titleBox.addView(fileName);

        Button share = makeFlatIconButton("Compartir");
        share.setTextSize(uiSp(13));
        share.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        top.addView(close, new LinearLayout.LayoutParams(uiDp(52), uiDp(52)));
        top.addView(titleBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        top.addView(share, new LinearLayout.LayoutParams(uiDp(100), uiDp(52)));

        final Handler chromeHandler = new Handler(Looper.getMainLooper());
        final boolean[] chromeVisible = new boolean[]{true};
        final Runnable hideChrome = new Runnable() {
            @Override
            public void run() {
                chromeVisible[0] = false;
                top.animate().alpha(0f).setDuration(140L).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        if (!chromeVisible[0]) top.setVisibility(View.GONE);
                    }
                }).start();
            }
        };
        final Runnable showChromeNow = new Runnable() {
            @Override
            public void run() {
                chromeVisible[0] = true;
                top.setVisibility(View.VISIBLE);
                top.animate().cancel();
                top.setAlpha(1f);
                chromeHandler.removeCallbacks(hideChrome);
                chromeHandler.postDelayed(hideChrome, 2400L);
            }
        };

        imagePager = new ViewPager2(this);
        imagePager.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);
        imagePager.setOffscreenPageLimit(1);
        imagePager.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
        imagePagerAdapter = new ImagePagerAdapter(images, new ZoomImageView.OnSingleTapListener() {
            @Override
            public void onSingleTap() {
                if (chromeVisible[0]) {
                    chromeHandler.removeCallbacks(hideChrome);
                    hideChrome.run();
                } else {
                    showChromeNow.run();
                }
            }
        });
        imagePager.setAdapter(imagePagerAdapter);
        screen.addView(imagePager, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        topLp.gravity = Gravity.TOP;
        screen.addView(top, topLp);

        final Runnable updateHeader = new Runnable() {
            @Override
            public void run() {
                int position = imagePager == null ? 0 : imagePager.getCurrentItem();
                position = Math.max(0, Math.min(position, images.size() - 1));
                counter.setText((position + 1) + " / " + images.size());
                fileName.setText(images.get(position).getName());
            }
        };

        imagePager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                updateHeader.run();
                showChromeNow.run();
                if (imagePagerAdapter != null) imagePagerAdapter.preload(position);
            }
        });
        imagePager.setCurrentItem(startIndex, false);
        if (imagePagerAdapter != null) imagePagerAdapter.preload(startIndex);
        updateHeader.run();

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chromeHandler.removeCallbacks(hideChrome);
                closeFullscreenImageViewer();
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChromeNow.run();
                int position = imagePager == null ? 0 : imagePager.getCurrentItem();
                position = Math.max(0, Math.min(position, images.size() - 1));
                shareFile(images.get(position));
            }
        });

        ViewGroup host = getOverlayHost();
        if (host == null) {
            Toast.makeText(this, t("No se pudo abrir la imagen"), Toast.LENGTH_SHORT).show();
            return;
        }
        if (imageViewerOverlay != null && imageViewerOverlay.getParent() == host) {
            host.removeView(imageViewerOverlay);
        }
        imageViewerOverlay = screen;
        host.addView(imageViewerOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        showChromeNow.run();
    }

    private void closeFullscreenImageViewer() {
        if (!imageViewerMode) return;
        imageViewerMode = false;
        if (imagePager != null) {
            imagePager.setAdapter(null);
            imagePager = null;
        }
        if (imagePagerAdapter != null) {
            imagePagerAdapter.release();
            imagePagerAdapter = null;
        }
        if (imageViewerBitmap != null && !imageViewerBitmap.isRecycled()) {
            imageViewerBitmap.recycle();
            imageViewerBitmap = null;
        }
        ViewGroup host = getOverlayHost();
        if (host != null && imageViewerOverlay != null && imageViewerOverlay.getParent() == host) {
            host.removeView(imageViewerOverlay);
        }
        imageViewerOverlay = null;
    }

    private void showAudioPreview(final File file) {


        stopFilePreview();

        LinearLayout box = makeDialogContainer();

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextSize(uiSp(18));
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        name.setPadding(0, 0, 0, uiDp(10));
        box.addView(name);

        final TextView time = new TextView(this);
        time.setText(t("00:00 / 00:00"));
        time.setGravity(Gravity.CENTER);
        time.setTextSize(uiSp(14));
        time.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(15, 23, 42));

        final SeekBar seek = new SeekBar(this);
        seek.setMax(1000);

        final Button play = makeButton("▶ Reproducir");
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (previewPlayer == null) return;
                if (previewPlayer.isPlaying()) {
                    previewPlayer.pause();
                    play.setText(t("▶ Reproducir"));
                } else {
                    previewPlayer.start();
                    play.setText(t("Ⅱ Pausar"));
                    startPreviewProgress(seek, time, play);
                }
            }
        });

        box.addView(time, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(34)));
        box.addView(seek, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(48)));
        box.addView(play, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(52)));

        try {
            previewPlayer = new MediaPlayer();
            previewPlayer.setDataSource(file.getAbsolutePath());
            previewPlayer.prepare();
            updatePreviewTime(seek, time);
            previewPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    play.setText(t("▶ Reproducir"));
                    updatePreviewTime(seek, time);
                }
            });
        } catch (Exception e) {
            stopFilePreview();
            Toast.makeText(this, t("No se pudo abrir el audio"), Toast.LENGTH_LONG).show();
            return;
        }

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && previewPlayer != null) {
                    int duration = previewPlayer.getDuration();
                    previewPlayer.seekTo((int) (duration * (progress / 1000f)));
                    updatePreviewTime(seek, time);
                }
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(box)
                .setPositiveButton(t("Compartir"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        shareFile(file);
                    }
                })
                .setNegativeButton(t("Cerrar"), null)
                .create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                stopFilePreview();
            }
        });
        dialog.show();
        styleDialog(dialog);
    }

    private void startPreviewProgress(final SeekBar seek, final TextView time, final Button play) {
        if (previewProgressTask != null) previewHandler.removeCallbacks(previewProgressTask);
        previewProgressTask = new Runnable() {
            @Override
            public void run() {
                if (previewPlayer == null) return;
                updatePreviewTime(seek, time);
                if (previewPlayer.isPlaying()) {
                    play.setText(t("Ⅱ Pausar"));
                    previewHandler.postDelayed(this, 400L);
                }
            }
        };
        previewHandler.post(previewProgressTask);
    }

    private void updatePreviewTime(SeekBar seek, TextView time) {
        if (previewPlayer == null) return;
        int duration = Math.max(0, previewPlayer.getDuration());
        int position = Math.max(0, previewPlayer.getCurrentPosition());
        seek.setProgress(duration == 0 ? 0 : Math.min(1000, Math.round(position * 1000f / duration)));
        time.setText(formatDuration(position) + " / " + formatDuration(duration));
    }

    private void stopFilePreview() {
        if (previewProgressTask != null) {
            previewHandler.removeCallbacks(previewProgressTask);
            previewProgressTask = null;
        }
        if (previewPlayer != null) {
            try { previewPlayer.stop(); } catch (Exception ignored) { }
            try { previewPlayer.release(); } catch (Exception ignored) { }
            previewPlayer = null;
        }
    }

    private void showFileActions(final File file, final int type) {
        final String[] actions = new String[]{t("Abrir"), t("Compartir"), t("Cambiar nombre"), t("Eliminar")};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(file.getName())
                .setItems(actions, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            if (type == LIBRARY_AUDIO) showAudioPreview(file);
                            else if (type == LIBRARY_IMAGE) showImagePreview(file);
                            else openFileExternally(file);
                        } else if (which == 1) {
                            shareFile(file);
                        } else if (which == 2) {
                            renameLibraryFile(file);
                        } else {
                            deleteLibraryFile(file);
                        }
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void shareFile(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(getMimeType(file));
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, t("Compartir archivo")));
        } catch (Exception e) {
            Toast.makeText(this, t("No se pudo compartir el archivo"), Toast.LENGTH_LONG).show();
        }
    }

    private String getMimeType(File file) {
        String name = file.getName();
        int dot = name.lastIndexOf('.');
        String extension = dot >= 0 ? name.substring(dot + 1).toLowerCase(Locale.US) : "";
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        if (mime != null) return mime;
        if (extension.equals("wav") || extension.equals("mp3") || extension.equals("m4a") || extension.equals("ogg")) return "audio/*";
        if (extension.equals("pdf")) return "application/pdf";
        return "image/*";
    }

    private void openFileExternally(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, getMimeType(file));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Abrir archivo"));
        } catch (Exception e) {
            Toast.makeText(this, t("No se pudo abrir el archivo"), Toast.LENGTH_LONG).show();
        }
    }

    private void renameLibraryFile(final File file) {
        final EditText input = new EditText(this);
        String name = file.getName();
        final int dot = name.lastIndexOf('.');
        final String extension = dot >= 0 ? name.substring(dot) : "";
        input.setText(dot >= 0 ? name.substring(0, dot) : name);
        input.setSelection(input.getText().length());

        new AlertDialog.Builder(this)
                .setTitle(t("Cambiar nombre"))
                .setView(input)
                .setNegativeButton(t("Cancelar"), null)
                .setPositiveButton(t("Guardar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String clean = input.getText().toString().trim().replaceAll("[\\/:*?\"<>|]", "_");
                        if (clean.length() == 0) {
                            Toast.makeText(MainActivity.this, t("Nombre inválido"), Toast.LENGTH_SHORT).show();
                            return;
                        }
                        File renamed = new File(file.getParentFile(), clean + extension);
                        if (renamed.exists()) {
                            Toast.makeText(MainActivity.this, t("Ya existe un archivo con ese nombre"), Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (file.renameTo(renamed)) {
                            Toast.makeText(MainActivity.this, t("Nombre actualizado"), Toast.LENGTH_SHORT).show();
                            showFileLibrary(libraryShowingType);
                        } else {
                            Toast.makeText(MainActivity.this, t("No se pudo cambiar el nombre"), Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .show();
    }

    private void deleteLibraryFile(final File file) {
        new AlertDialog.Builder(this)
                .setTitle(t("Eliminar archivo"))
                .setMessage(t("¿Eliminar " + file.getName() + "?"))
                .setNegativeButton(t("Cancelar"), null)
                .setPositiveButton(t("Eliminar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        stopFilePreview();
                        if (file.delete()) {
                            removeEmptyParentFolders(file.getParentFile());
                            Toast.makeText(MainActivity.this, t("Archivo eliminado"), Toast.LENGTH_SHORT).show();
                            showFileLibrary(libraryShowingType);
                        } else {
                            Toast.makeText(MainActivity.this, t("No se pudo eliminar"), Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .show();
    }

    private void removeEmptyParentFolders(File folder) {
        if (folder == null) return;
        File audioRoot = getAudioSaveDir();
        File imageRoot = getImageSaveDir();
        File pdfRoot = getPdfSaveDir();
        File legacyAudioRoot = new File(getStorageBase(Environment.DIRECTORY_MUSIC), "PDF_Audio");
        File legacyImageRoot = new File(getStorageBase(Environment.DIRECTORY_PICTURES), "PDF_Audio");
        File legacyPdfRoot = new File(getStorageBase(Environment.DIRECTORY_DOCUMENTS), "PDF_Audio");
        if (folder.equals(audioRoot) || folder.equals(imageRoot) || folder.equals(pdfRoot)
                || folder.equals(legacyAudioRoot) || folder.equals(legacyImageRoot) || folder.equals(legacyPdfRoot)) return;
        File[] children = folder.listFiles();
        if (children != null && children.length == 0) {
            File parent = folder.getParentFile();
            folder.delete();
            removeEmptyParentFolders(parent);
        }
    }

    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L * 1024L) return String.format(Locale.US, "%.1f KB", bytes / 1024f);
        return String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f));
    }

    private String formatFileSizePretty(long bytes) {
        if (bytes <= 0) return t("Tamaño pendiente");
        return formatFileSize(bytes);
    }

    private String formatFileDate(long time) {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date(time));
    }

    private String getAudioDurationText(File file) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(file.getAbsolutePath());
            String duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (duration != null) return formatDuration(Integer.parseInt(duration));
        } catch (Exception ignored) {
        } finally {
            try { retriever.release(); } catch (Exception ignored) { }
        }
        return "--:--";
    }

    private String formatDuration(int milliseconds) {
        int totalSeconds = Math.max(0, milliseconds / 1000);
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;
        if (hours > 0) return String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds);
        return String.format(Locale.US, "%02d:%02d", minutes, seconds);
    }

    private void showSavedFileActions(final File file, final boolean audio) {
        LinearLayout box = makeDialogContainer();

        TextView title = new TextView(this);
        title.setText(audio ? t("Audio guardado") : t("Imagen guardada"));
        title.setTextSize(uiSp(20));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        box.addView(title);

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextSize(uiSp(14));
        name.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(71, 85, 105));
        name.setPadding(0, uiDp(6), 0, 0);
        box.addView(name);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(box)
                .setPositiveButton(audio ? t("Reproducir") : t("Galería"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (audio) showAudioPreview(file);
                        else showFileLibrary(false);
                    }
                })
                .setNeutralButton(t("Compartir"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        shareFile(file);
                    }
                })
                .setNegativeButton(t("Cerrar"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void showSavedPdfActions(final File file) {
        LinearLayout box = makeDialogContainer();

        TextView title = new TextView(this);
        title.setText(t("PDF guardado"));
        title.setTextSize(uiSp(20));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        box.addView(title);

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextSize(uiSp(14));
        name.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(71, 85, 105));
        name.setPadding(0, uiDp(6), 0, 0);
        box.addView(name);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(box)
                .setPositiveButton(t("Abrir"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openFileExternally(file);
                    }
                })
                .setNeutralButton(t("Compartir"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        shareFile(file);
                    }
                })
                .setNegativeButton(t("Cerrar"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void showAudioExportCompleted() {
        if (exportSavedCount == 1 && lastExportedAudioFile != null && lastExportedAudioFile.exists()) {
            showSavedFileActions(lastExportedAudioFile, true);
            return;
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Audio terminado"))
                .setMessage(t(exportSavedCount + " archivo(s) guardado(s) en Mis archivos"))
                .setPositiveButton(t("Ver audios"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showFileLibrary(true);
                    }
                })
                .setNegativeButton(t("Cerrar"), null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void saveCurrentPageImage() {
        if (currentFile == null || pdfView == null || pageCount <= 0) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }

        final int pageToSave = currentPage;
        final String titleToSave = currentTitle;
        final File dir = getImageSaveDir();
        final String clean = titleToSave == null ? "pdf"
                : titleToSave.replaceAll("[^a-zA-Z0-9._-]", "_");
        final File out = new File(dir, clean + "_pagina_" + (pageToSave + 1) + ".png");

        imageExportExecutor.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = null;
                try {
                    bitmap = pdfView.exportPageBitmapHd(pageToSave, false);
                    if (bitmap == null) throw new IllegalStateException("bitmap null");

                    try (FileOutputStream fos = new FileOutputStream(out)) {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                        fos.flush();
                    }
                    bitmap.recycle();
                    bitmap = null;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showFullscreenImageViewer(out);
                        }
                    });
                } catch (Exception e) {
                    if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this,
                                    t("No se pudo guardar la imagen"), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }

    private void showMarkedPdfExportDialog() {
        if (currentFile == null || pdfView == null || pageCount <= 0) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout box = makeDialogContainer();
        TextView info = new TextView(this);
        info.setText(t("Guardar un PDF nuevo con los subrayados y resaltados actuales."));
        info.setTextSize(uiSp(14));
        info.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
        info.setPadding(0, 0, 0, uiDp(10));
        box.addView(info);

        Button current = makeButton("Solo página actual");
        Button range = makeButton("Elegir rango");
        Button full = makeButton("Todo el PDF");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(50));
        lp.setMargins(0, uiDp(6), 0, 0);
        box.addView(current, lp);
        box.addView(range, lp);
        box.addView(full, lp);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Guardar PDF marcado"))
                .setView(box)
                .setNegativeButton(t("Cerrar"), null)
                .create();

        current.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                exportMarkedPdf(currentPage, currentPage);
            }
        });
        range.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                showMarkedPdfRangeDialog();
            }
        });
        full.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                exportMarkedPdf(0, pageCount - 1);
            }
        });

        dialog.show();
        styleDialog(dialog);
    }


    private void showMarkedPdfRangeDialog() {
        LinearLayout box = makeDialogContainer();
        final EditText from = new EditText(this);
        from.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        from.setHint(t("Desde (1 - " + pageCount + ")"));
        from.setText(String.valueOf(currentPage + 1));
        from.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        from.setHintTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        final EditText to = new EditText(this);
        to.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        to.setHint(t("Hasta (1 - " + pageCount + ")"));
        to.setText(String.valueOf(currentPage + 1));
        to.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        to.setHintTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        box.addView(from); box.addView(to);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Rango de páginas"))
                .setView(box)
                .setNegativeButton(t("Cancelar"), null)
                .setPositiveButton(t("Guardar"), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        try {
                            int start = Integer.parseInt(from.getText().toString().trim());
                            int end = Integer.parseInt(to.getText().toString().trim());
                            if (start < 1 || end < 1 || start > pageCount || end > pageCount || start > end) {
                                Toast.makeText(MainActivity.this, t("Rango inválido"), Toast.LENGTH_LONG).show();
                                return;
                            }
                            exportMarkedPdf(start - 1, end - 1);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, t("Completa correctamente el rango"), Toast.LENGTH_LONG).show();
                        }
                    }
                }).create();
        dialog.show(); styleDialog(dialog);
    }

    private void exportMarkedPdf(final int startPage, final int endPage) {
        if (currentFile == null || pdfView == null || pageCount <= 0) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, t("Exportando PDF marcado..."), Toast.LENGTH_SHORT).show();
        final MainActivity self = this;
        new Thread(new Runnable() {
            @Override
            public void run() {
                PdfDocument document = new PdfDocument();
                FileOutputStream fos = null;
                File out = null;
                String error = null;
                int exportedPages = 0;
                try {
                    File dir = getPdfSaveDir();

                    String clean = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
                    String suffix;
                    if (startPage == endPage) suffix = "_pagina_" + (startPage + 1) + "_marcada.pdf";
                    else if (startPage == 0 && endPage == pageCount - 1) suffix = "_completo_marcado.pdf";
                    else suffix = "_paginas_" + (startPage + 1) + "-" + (endPage + 1) + "_marcado.pdf";
                    out = new File(dir, clean + suffix);

                    for (int page = startPage; page <= endPage; page++) {
                        Bitmap bitmap = pdfView.exportPageBitmap(page, false);
                        if (bitmap == null) continue;

                        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(bitmap.getWidth(), bitmap.getHeight(), exportedPages + 1).create();
                        PdfDocument.Page pdfPage = document.startPage(pageInfo);
                        pdfPage.getCanvas().drawColor(Color.WHITE);
                        pdfPage.getCanvas().drawBitmap(bitmap, 0f, 0f, null);
                        document.finishPage(pdfPage);
                        bitmap.recycle();
                        exportedPages++;
                    }

                    if (exportedPages == 0) {
                        throw new IllegalStateException("No se pudo renderizar ninguna página");
                    }

                    fos = new FileOutputStream(out);
                    document.writeTo(fos);
                    fos.flush();
                } catch (Exception e) {
                    error = e.getMessage();
                } finally {
                    try { if (fos != null) fos.close(); } catch (Exception ignored) { }
                    try { document.close(); } catch (Exception ignored) { }
                }

                final File finalOut = out;
                final String finalError = error;
                final int finalExportedPages = exportedPages;
                self.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (finalOut != null && finalError == null && finalExportedPages > 0 && finalOut.exists()) {
                            showSavedPdfActions(finalOut);
                        } else {
                            Toast.makeText(MainActivity.this,
                                    t("No se pudo guardar el PDF") + (finalError == null || finalError.length() == 0 ? "" : ": " + t(finalError)),
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void exportCurrentPageAudio() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }
        startAudioExportRange(currentPage, currentPage);
    }

    private void cancelTtsWarmup() {
        if (ttsWarmupRunnable != null) {
            audioStartHandler.removeCallbacks(ttsWarmupRunnable);
            ttsWarmupRunnable = null;
        }
    }

    private void scheduleTtsWarmup(long delayMs) {
        cancelTtsWarmup();
        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        if (manager.isReady() && (currentPdfLanguage.length() == 0
                || (currentPdfLanguage.equals(manager.getPreferredLanguage())
                && manager.isPreferredLanguageAvailable()))) return;
        // Do not warm an arbitrary language while a PDF is still being detected.
        // That only creates work that may have to be discarded a moment later.
        if (currentFile != null && currentPdfLanguage.length() == 0) return;
        ttsWarmupRunnable = new Runnable() {
            @Override
            public void run() {
                ttsWarmupRunnable = null;
                if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                if (currentPdfLanguage.length() > 0) {
                    manager.ensureLanguage(currentPdfLanguage, appRegion, null);
                } else {
                    manager.initialize(null);
                }
            }
        };
        audioStartHandler.postDelayed(ttsWarmupRunnable, Math.max(0L, delayMs));
    }

    private void choosePdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        startActivityForResult(intent, REQ_OPEN_PDF);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OPEN_PDF && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            copyAndOpen(uri);
        }
    }

    private void copyAndOpen(final Uri uri) {
        if (uri == null) return;
        stopAudioOnly();
        final int requestToken = ++pdfOpenRequestToken;

        new Thread(new Runnable() {
            @Override
            public void run() {
                final File temp = new File(getFilesDir(), "last.pdf.tmp");
                try {
                    if (textRepository != null) textRepository.close();
                    if (selectionRepository != null) selectionRepository.close();

                    final String name = getDisplayName(uri);
                    try (InputStream input = getContentResolver().openInputStream(uri);
                         FileOutputStream output = new FileOutputStream(temp, false)) {
                        if (input == null) throw new IOException("No se pudo abrir el PDF");
                        byte[] buffer = new byte[65536];
                        int read;
                        while ((read = input.read(buffer)) != -1) {
                            if (requestToken != pdfOpenRequestToken) {
                                temp.delete();
                                return;
                            }
                            output.write(buffer, 0, read);
                        }
                        output.flush();
                    }

                    if (requestToken != pdfOpenRequestToken) {
                        temp.delete();
                        return;
                    }

                    final File target = new File(getFilesDir(), "last.pdf");
                    if (target.exists() && !target.delete()) {
                        throw new IOException("No se pudo reemplazar el PDF anterior");
                    }
                    if (!temp.renameTo(target)) {
                        try (InputStream input = new FileInputStream(temp);
                             FileOutputStream output = new FileOutputStream(target, false)) {
                            byte[] buffer = new byte[65536];
                            int read;
                            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                            output.flush();
                        }
                        temp.delete();
                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (requestToken != pdfOpenRequestToken
                                    || isFinishing()
                                    || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
                            prefs.edit().putString("last_title", name).putInt("last_page", 0).apply();
                            openLocalPdf(target, name, false);
                        }
                    });
                } catch (final Exception e) {
                    temp.delete();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (requestToken != pdfOpenRequestToken) return;
                            Toast.makeText(MainActivity.this, t("No se pudo abrir el PDF"), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }, "PdfOpenCopy").start();
    }

    private void openLocalPdf(final File file, String title, boolean restore) {
        final int preferredPage = Math.max(0, restore ? prefs.getInt("last_page", 0) : 0);
        openLocalPdfAtPage(file, title, preferredPage);
    }

    private void openLocalPdfAtPage(final File file, String title, final int preferredPage) {
        if (file == null || pdfView == null) return;
        cancelTtsWarmup();
        try {
            currentFile = file;
            currentTitle = title == null ? "PDF" : title;
            currentBookmarkKey = buildBookmarkKey(file);
            languageDetectionToken++;
            languageSamplingToken = -1;
            currentPdfLanguage = PdfLanguageDetector.normalizeCode(
                    prefs.getString(pdfLanguagePreferenceKey(currentBookmarkKey), ""));
            currentPdfLanguageConfidence = currentPdfLanguage.length() > 0 ? 1.0f : 0f;
            TtsEngineManager.getInstance(this).setPreferredLanguage(currentPdfLanguage, appRegion);
            titleView.setText(currentTitle);
            if (titleScroller != null) {
                titleScroller.post(new Runnable() {
                    @Override
                    public void run() {
                        titleScroller.scrollTo(0, 0);
                    }
                });
            }
            fullIndexRequested = false;
            pageCount = 0;
            currentPage = Math.max(0, preferredPage);
            updatePageLabel();

            // Text extraction is already asynchronous. Give the visible/saved page
            // priority immediately while PdfRenderer opens on its own worker.
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
            textRepository.open(file);
            TtsForegroundService.clearPages();

            preparePageForInstantPlay(preferredPage, false);

            // Coordinate extraction is deliberately deferred until the visible
            // page text is ready; it must not compete with first render / Play.
            selectionRepository.close();
            loadedSelectionPage = -1;
            loadingSelectionPage = -1;

            String savedHighlights = prefs.getString(highlightKey(), "");
            if ((savedHighlights == null || savedHighlights.length() == 0) && currentTitle != null) {
                savedHighlights = prefs.getString(legacyHighlightKey(), "");
            }
            final String deferredHighlights = savedHighlights;
            final File highlightFile = file;

            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
            pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
            pdfView.setReadingMarkerEnabled(readingMarkerEnabled);
            pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));

            pdfView.openFileAsync(file, new PdfPageView.DocumentOpenCallback() {
                @Override
                public void onOpened(int totalPages) {
                    if (currentFile == null || !currentFile.equals(file)) return;
                    pageCount = Math.max(0, totalPages);
                    if (pageCount <= 0) {
                        Toast.makeText(MainActivity.this, t("Error al cargar PDF"), Toast.LENGTH_LONG).show();
                        return;
                    }

                    final int p = Math.max(0, Math.min(preferredPage, pageCount - 1));
                    if (p != preferredPage) {
                        preparePageForInstantPlay(p, false);
                    }

                    final File selectionFile = file;
                    primeAudioPageForPlayback(p, new Runnable() {
                        @Override
                        public void run() {
                            if (currentFile == null || !currentFile.equals(selectionFile)) return;
                            if (currentPdfLanguage.length() == 0) {
                                maybeDetectPdfLanguageFromCachedPage(p);
                            }
                            selectionRepository.open(selectionFile);
                            loadedSelectionPage = -1;
                            loadingSelectionPage = -1;
                            loadSelectionForPage(p);
                            if (markMode || readingMarkerEnabled) {
                                prefetchAroundPage(p);
                            }
                        }
                    });

                    pdfView.showPage(p);
                    updatePageLabel();

                    // Large marker sets are loaded after the first render request.
                    pdfView.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (currentFile == null || !currentFile.equals(highlightFile)) return;
                            pdfView.loadHighlights(deferredHighlights);
                        }
                    }, 60L);
                }

                @Override
                public void onError(Exception error) {
                    if (currentFile == null || !currentFile.equals(file)) return;
                    pageCount = 0;
                    updatePageLabel();
                    Toast.makeText(MainActivity.this, t("Error al cargar PDF"), Toast.LENGTH_LONG).show();
                    scheduleTtsWarmup(500L);
                }
            });
        } catch (Exception e) {
            Toast.makeText(this, t("Error al cargar PDF"), Toast.LENGTH_LONG).show();
            scheduleTtsWarmup(500L);
        }
    }

    private String pdfLanguagePreferenceKey(String bookmarkKey) {
        return PREF_PDF_LANGUAGE_PREFIX + (bookmarkKey == null ? "unknown" : bookmarkKey);
    }

    private boolean isCurrentLanguageDetection(int token, File file, String documentKey) {
        return token == languageDetectionToken
                && currentFile != null && currentFile.equals(file)
                && currentBookmarkKey != null && currentBookmarkKey.equals(documentKey);
    }

    private void saveCurrentPdfLanguage(String languageCode, float confidence) {
        String language = PdfLanguageDetector.normalizeCode(languageCode);
        if (!PdfLanguageDetector.isSupported(language) || currentBookmarkKey == null) return;
        currentPdfLanguage = language;
        currentPdfLanguageConfidence = Math.max(0f, Math.min(1f, confidence));
        languageSamplingToken = -1;
        prefs.edit().putString(pdfLanguagePreferenceKey(currentBookmarkKey), language).apply();
        TtsEngineManager.getInstance(this).setPreferredLanguage(language, appRegion);
        // Warm the correct language only after detection. This avoids initializing
        // a voice that immediately has to be replaced when Play is pressed.
        scheduleTtsWarmup(120L);
    }

    private void maybeDetectPdfLanguageFromCachedPage(final int page) {
        if (currentPdfLanguage.length() > 0 || currentFile == null
                || currentBookmarkKey == null || textRepository == null) return;
        final int token = languageDetectionToken;
        final File file = currentFile;
        final String documentKey = currentBookmarkKey;

        // Use several pages for the stored decision instead of trusting a cover
        // page or a short heading. The sampling runs after the visible page text
        // is already ready, so it does not block the first render or Play.
        audioStartHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isCurrentLanguageDetection(token, file, documentKey)
                        || currentPdfLanguage.length() > 0) return;
                schedulePdfLanguageSampling(page, token, file, documentKey);
            }
        }, 450L);
    }

    private void schedulePdfLanguageSampling(final int anchorPage, final int token,
                                             final File file, final String documentKey) {
        if (!isCurrentLanguageDetection(token, file, documentKey)
                || currentPdfLanguage.length() > 0 || languageSamplingToken == token
                || textRepository == null || pageCount <= 0) return;
        languageSamplingToken = token;
        final ArrayList<Integer> pages = new ArrayList<Integer>();
        int safeAnchor = Math.max(0, Math.min(anchorPage, pageCount - 1));
        int[] candidates = new int[]{safeAnchor, 0, pageCount / 2, pageCount - 1};
        for (int candidate : candidates) {
            int safe = Math.max(0, Math.min(candidate, pageCount - 1));
            if (!pages.contains(safe)) pages.add(safe);
        }
        collectPdfLanguageSamples(pages, 0, new StringBuilder(), token, file, documentKey);
    }

    private void collectPdfLanguageSamples(final ArrayList<Integer> pages, final int index,
                                           final StringBuilder sample, final int token,
                                           final File file, final String documentKey) {
        if (!isCurrentLanguageDetection(token, file, documentKey)
                || currentPdfLanguage.length() > 0 || textRepository == null) {
            if (languageSamplingToken == token) languageSamplingToken = -1;
            return;
        }
        if (index >= pages.size() || sample.length() >= 5000) {
            finishPdfLanguageSampling(sample.toString(), token, file, documentKey);
            return;
        }

        final int page = pages.get(index);
        textRepository.getPageText(page, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                if (!isCurrentLanguageDetection(token, file, documentKey)
                        || currentPdfLanguage.length() > 0) {
                    if (languageSamplingToken == token) languageSamplingToken = -1;
                    return;
                }
                String value = text == null ? "" : text.trim();
                if (value.length() > 0 && sample.length() < 5000) {
                    int remaining = 5000 - sample.length();
                    if (sample.length() > 0) sample.append('\n');
                    sample.append(value, 0, Math.min(value.length(), remaining));
                }
                collectPdfLanguageSamples(pages, index + 1, sample, token, file, documentKey);
            }
        });
    }

    private void finishPdfLanguageSampling(final String sample, final int token,
                                           final File file, final String documentKey) {
        if (!isCurrentLanguageDetection(token, file, documentKey)) {
            if (languageSamplingToken == token) languageSamplingToken = -1;
            return;
        }
        if (sample == null || sample.trim().length() < 24) {
            if (languageSamplingToken == token) languageSamplingToken = -1;
            return;
        }
        try {
            languageDetectionExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    final PdfLanguageDetector.Result result = PdfLanguageDetector.detect(
                            getApplicationContext(), sample);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentLanguageDetection(token, file, documentKey)) return;
                            if (languageSamplingToken == token) languageSamplingToken = -1;
                            if (currentPdfLanguage.length() == 0 && result.isConfident()) {
                                saveCurrentPdfLanguage(result.languageCode, result.confidence);
                            }
                        }
                    });
                }
            });
        } catch (Exception ignored) {
            if (languageSamplingToken == token) languageSamplingToken = -1;
        }
    }

    private String getDisplayName(Uri uri) {
        String result = "PDF";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return result == null ? "PDF" : result;
    }



    private void requestManualPageChange(int targetPage) {
        if (pageCount <= 0) return;

        final int nextPage = Math.max(0, Math.min(targetPage, pageCount - 1));
        restartAudioAfterRender = false;
        currentPage = nextPage;
        updatePageLabel();

        // La página elegida por el usuario gana prioridad incluso antes de que
        // termine el nuevo render. Así Play/cambio durante lectura puede usar el
        // texto ya cacheado o iniciar una sola extracción urgente compartida.
        primeAudioPageForPlayback(nextPage);

        if (pdfView != null) {
            pdfView.clearReadingMarker();
            pdfView.showPage(nextPage);
        }

        loadedSelectionPage = -1;
        loadingSelectionPage = -1;
        scheduleVisiblePageWork(nextPage, false);

        if (playbackState == TtsForegroundService.STATE_PLAYING
                || playbackState == TtsForegroundService.STATE_PREPARING) {
            seekAudioToPage(nextPage, true);
        }
        // Si estaba pausado, no mover la sesion pausada del TTS a una pagina
        // nueva y vacia. La pagina visible queda precargada y el siguiente Play
        // inicia por la misma ruta rapida que un PDF recien abierto.
    }

    private void scheduleVisiblePageWork(final int page, final boolean requestFullIndex) {
        final int token = ++pageWorkToken;
        if (pageWorkRunnable != null) {
            pageWorkHandler.removeCallbacks(pageWorkRunnable);
        }
        pageWorkRunnable = new Runnable() {
            @Override
            public void run() {
                if (token != pageWorkToken || page != currentPage || currentFile == null) return;
                // El texto audible gana la carrera. Las coordenadas visuales se
                // procesan inmediatamente después, nunca al mismo tiempo.
                primeAudioPageForPlayback(page, new Runnable() {
                    @Override
                    public void run() {
                        if (token != pageWorkToken || page != currentPage || currentFile == null) return;
                        loadSelectionForPage(page);
                        if (markMode || readingMarkerEnabled) {
                            prefetchAroundPage(page);
                        }
                        if (readingMarkerEnabled && pendingReadingPage == page) {
                            schedulePendingReadingMarker();
                        }
                    }
                });
            }
        };
        pageWorkHandler.postDelayed(pageWorkRunnable, 120L);
    }

    private void seekAudioToPage(int page, boolean playNow) {
        if (pageCount <= 0) return;
        int safePage = Math.max(0, Math.min(page, pageCount - 1));
        if (currentPdfLanguage.length() == 0) {
            if (playNow) {
                startAudioFromPage(safePage);
            } else {
                audioRequestToken++;
                requestedAudioPage = -1;
                requestedAudioPageConfirmed = false;
                applyPlaybackState(TtsForegroundService.STATE_PAUSED, safePage, "Pausado", false);
            }
            return;
        }
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = safePage;
        requestedAudioPageConfirmed = false;
        applyPlaybackState(playNow
                        ? TtsForegroundService.STATE_PREPARING
                        : TtsForegroundService.STATE_PAUSED,
                safePage, playNow ? "" : "Pausado", false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_SEEK_PAGE);
        intent.putExtra(TtsForegroundService.EXTRA_PAGE, safePage);
        intent.putExtra(TtsForegroundService.EXTRA_AUTOPLAY, playNow);
        intent.putExtra("title", currentTitle);
        intent.putExtra("totalPages", pageCount);
        intent.putExtra("rate", speechRate);
        intent.putExtra("pitch", 1.0f);
        intent.putExtra(TtsForegroundService.EXTRA_TTS_LANGUAGE, currentPdfLanguage);
        intent.putExtra(TtsForegroundService.EXTRA_TTS_REGION, appRegion);

        String cachedPageText = textRepository == null ? null : textRepository.getCachedText(safePage);
        if (cachedPageText != null) {
            TtsForegroundService.setPageText(safePage, cachedPageText);
            intent.putExtra(TtsForegroundService.EXTRA_PAGE_TEXT, cachedPageText);
        } else {
            String fastText = textRepository == null ? null : textRepository.getFastStartText(safePage);
            if (fastText != null && fastText.trim().length() > 0) {
                TtsForegroundService.setPageFastText(safePage, fastText);
            }
            primeAudioPageForPlayback(safePage);
        }
        startService(intent);
    }

    private void preparePageForInstantPlay(final int page, final boolean requestFullIndex) {
        primeAudioPageForPlayback(page);
    }

    private void primeAudioPageForPlayback(final int page) {
        primeAudioPageForPlayback(page, null);
    }

    private void primeAudioPageForPlayback(final int page, final Runnable afterPrime) {
        if (textRepository == null || currentFile == null || page < 0) return;
        final File requestedFile = currentFile;

        // Cualquier navegación del usuario corta el indexado de baja prioridad,
        // incluso si esta página ya está en RAM/disco y no necesita extracción.
        textRepository.noteInteractivePage(page);
        String cached = textRepository.getCachedText(page);
        if (cached != null) {
            TtsForegroundService.setPageText(page, cached);
            if (page == currentPage) prepareFastResumeAudioForPage(page, cached);
            if (afterPrime != null) afterPrime.run();
            scheduleAudioNeighborPreload(page);
            scheduleAudioIdleIndex(page);
            return;
        }

        textRepository.getPageTextFastStart(page, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                if (currentFile == null || !currentFile.equals(requestedFile)) return;
                if (text != null && text.trim().length() > 0) {
                    TtsForegroundService.setPageFastText(page, text);
                }
            }
        }, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                if (currentFile == null || !currentFile.equals(requestedFile)) return;
                TtsForegroundService.setPageText(page, text == null ? "" : text);
                if (page == currentPage) {
                    prepareFastResumeAudioForPage(page, text == null ? "" : text);
                }
                if (afterPrime != null) afterPrime.run();
                scheduleAudioNeighborPreload(page);
                scheduleAudioIdleIndex(page);
            }
        });
    }

    private void scheduleAudioNeighborPreload(final int page) {
        if (pageCount <= 0) return;
        if (audioNeighborPreloadRunnable != null) {
            audioStartHandler.removeCallbacks(audioNeighborPreloadRunnable);
        }
        audioNeighborPreloadRunnable = new Runnable() {
            @Override
            public void run() {
                audioNeighborPreloadRunnable = null;
                if (textRepository != null && pageCount > 0 && page == currentPage) {
                    // Mantiene listas la anterior y las tres siguientes. La cola
                    // es de fondo y siempre cede ante la página visible/Play.
                    textRepository.preloadAudioWindow(page, 3, pageCount);
                }
            }
        };
        audioStartHandler.postDelayed(audioNeighborPreloadRunnable, 220L);
    }

    private void scheduleAudioIdleIndex(final int page) {
        if (audioIdleIndexRunnable != null) {
            audioStartHandler.removeCallbacks(audioIdleIndexRunnable);
        }
        audioIdleIndexRunnable = new Runnable() {
            @Override
            public void run() {
                audioIdleIndexRunnable = null;
                if (textRepository == null || currentFile == null || pageCount <= 0
                        || page != currentPage) return;
                // Tras unos segundos sin cambiar de página, completa la caché en
                // baja prioridad. Una nueva petición urgente hace que el indexado
                // se abandone de forma cooperativa y se reanude más adelante.
                textRepository.startFullPreload(page, pageCount);
            }
        };
        audioStartHandler.postDelayed(audioIdleIndexRunnable, 1100L);
    }

    private void prefetchAroundCurrentPage() {
        prefetchAroundPage(currentPage);
    }

    private void prefetchAroundPage(int page) {
        if (pageCount <= 0) return;
        int start = Math.max(0, page);
        selectionRepository.prefetch(start, 1, pageCount);
    }




    private void loadSelectionForPage(final int page) {
        if (pageCount <= 0 || selectionRepository == null || page < 0) return;
        if (loadedSelectionPage == page) {
            schedulePendingReadingMarker();
            return;
        }
        if (loadingSelectionPage == page) return;
        loadingSelectionPage = page;

        selectionRepository.getChars(page, new SelectionTextRepository.CharCallback() {
            @Override
            public void onChars(java.util.ArrayList<CharBox> chars) {
                loadingSelectionPage = -1;
                if (page == currentPage && pdfView != null) {
                    loadedSelectionPage = page;
                    pdfView.setSelectionChars(chars);
                    schedulePendingReadingMarker();
                }
            }
        });
    }

    private void loadRules() {
        rulesEnabled = prefs.getBoolean("rules_enabled", true);
        ruleTop = prefs.getFloat("rule_top", 0.08f);
        ruleBottom = prefs.getFloat("rule_bottom", 0.92f);
        if (ruleBottom <= ruleTop + 0.05f) {
            ruleTop = 0.08f;
            ruleBottom = 0.92f;
        }

        if (pdfView != null) {
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
            pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
        }

        if (textRepository != null) {
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        updateRulesButton();
    }

    private void toggleRules() {
        rulesEnabled = !rulesEnabled;
        saveRules(rulesEnabled, ruleTop, ruleBottom);

        if (pdfView != null) {
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        if (textRepository != null) {
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
            refreshTextCacheForRules();
        }

        updateRulesButton();
        Toast.makeText(this, rulesEnabled ? t("Reglas activadas. Arrastra las líneas.") : t("Reglas desactivadas"), Toast.LENGTH_SHORT).show();
    }


    private void refreshTextCacheForRules() {
        if (textRepository == null || currentFile == null || pageCount <= 0) return;
        fullIndexRequested = false;
        final int page = Math.max(0, Math.min(currentPage, pageCount - 1));
        TtsForegroundService.clearPages();
        // Mantiene exactamente el recorte entre las dos reglas, pero vuelve a dar
        // prioridad a la pagina visible antes de reconstruir el resto del cache.
        preparePageForInstantPlay(page, true);
    }

    private void saveRules(boolean enabled, float top, float bottom) {
        rulesEnabled = enabled;
        ruleTop = top;
        ruleBottom = bottom;
        prefs.edit()
                .putBoolean("rules_enabled", enabled)
                .putFloat("rule_top", top)
                .putFloat("rule_bottom", bottom)
                .apply();
        updateRulesButton();
    }

    private void updateRulesButton() {
        if (rulesButton != null) {
            rulesButton.setText(rulesEnabled ? t("Reglas ON") : t("Reglas OFF"));
        }
    }


    private void toggleReadingMarker() {
        readingMarkerEnabled = !readingMarkerEnabled;
        prefs.edit().putBoolean(PREF_READING_MARKER_ENABLED, readingMarkerEnabled).apply();
        if (pdfView != null) {
            pdfView.setReadingMarkerEnabled(readingMarkerEnabled);
            pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
        }
        if (readingMarkerEnabled) {
            if (selectionRepository != null && currentFile != null) selectionRepository.open(currentFile);
            loadSelectionForPage(currentPage);
            if (pdfView != null) pdfView.clearReadingMarker();

            // Si la lectura ya estaba a mitad de página, solicita al servicio la
            // frase/rango actual en vez de reutilizar una posición antigua o esperar
            // al siguiente cambio de página.
            if (playbackState == TtsForegroundService.STATE_PLAYING
                    || playbackState == TtsForegroundService.STATE_PAUSED
                    || playbackState == TtsForegroundService.STATE_PREPARING) {
                Intent report = new Intent(this, TtsForegroundService.class);
                report.setAction(TtsForegroundService.ACTION_REPORT_RANGE);
                startService(report);
            }
        } else {
            cancelPendingReadingMarker();
            if (pdfView != null) pdfView.clearReadingMarker();
            // Las coordenadas de la página se conservan para que Subrayar ON
            // responda inmediatamente aunque el seguimiento esté apagado.
        }
    }

    private void schedulePendingReadingMarker() {
        if (!readingMarkerEnabled || pdfView == null) return;
        if (readingMarkerUpdateTask == null) {
            readingMarkerUpdateTask = new Runnable() {
                @Override
                public void run() {
                    readingMarkerUpdateScheduled = false;
                    applyPendingReadingMarker();
                }
            };
        }
        if (readingMarkerUpdateScheduled) return;
        readingMarkerUpdateScheduled = true;
        readingMarkerHandler.postDelayed(readingMarkerUpdateTask, 16L);
    }

    private void cancelPendingReadingMarker() {
        if (readingMarkerUpdateTask != null) {
            readingMarkerHandler.removeCallbacks(readingMarkerUpdateTask);
        }
        readingMarkerUpdateScheduled = false;
    }

    private void applyPendingReadingMarker() {
        if (!readingMarkerEnabled || pdfView == null || pendingReadingPage < 0
                || pendingReadingChunk == null || pendingReadingChunk.length() == 0) return;
        if (pendingReadingPage != currentPage) return;
        pdfView.setReadingMarkerEnabled(true);
        pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
        pdfView.updateReadingMarker(pendingReadingPage, pendingReadingChunk, pendingReadingChunkIndex,
                pendingReadingRangeStart, pendingReadingRangeEnd);
    }

    private int getUtilityColorRgb(int target) {
        if (target == COLOR_TARGET_RULE) {
            return useCustomRuleColor ? customRuleRgb : MARK_COLOR_RGB[safeMarkColorIndex(ruleColorIndex)];
        }
        if (target == COLOR_TARGET_READING_MARKER) {
            return useCustomReadingMarkerColor ? customReadingMarkerRgb : MARK_COLOR_RGB[safeMarkColorIndex(readingMarkerColorIndex)];
        }
        return MARK_COLOR_RGB[3];
    }

    private String getUtilityQuickPrefix(int target) {
        return target == COLOR_TARGET_RULE ? "quick_rule_color_" : "quick_tracking_color_";
    }

    private boolean hasQuickUtilityColor(int target, int slot) {
        return prefs.getBoolean(getUtilityQuickPrefix(target) + "set_" + slot, false);
    }

    private int getQuickUtilityColor(int target, int slot) {
        return prefs.getInt(getUtilityQuickPrefix(target) + slot, 0x003B82F6) & 0x00FFFFFF;
    }

    private void saveQuickUtilityColor(int target, int slot, int color) {
        prefs.edit()
                .putInt(getUtilityQuickPrefix(target) + slot, color & 0x00FFFFFF)
                .putBoolean(getUtilityQuickPrefix(target) + "set_" + slot, true)
                .apply();
    }

    private void applyUtilityCustomColor(int target, int color) {
        color &= 0x00FFFFFF;
        SharedPreferences.Editor editor = prefs.edit();
        if (target == COLOR_TARGET_RULE) {
            customRuleRgb = color;
            useCustomRuleColor = true;
            editor.putInt(PREF_CUSTOM_RULE_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_RULE_COLOR, true);
            if (pdfView != null) pdfView.setRuleColor(color);
        } else {
            customReadingMarkerRgb = color;
            useCustomReadingMarkerColor = true;
            editor.putInt(PREF_CUSTOM_READING_MARKER_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_READING_MARKER_COLOR, true);
            if (pdfView != null) {
                pdfView.setReadingMarkerColor(color);
                schedulePendingReadingMarker();
            }
        }
        editor.apply();
        if (target == COLOR_TARGET_READING_MARKER) updateReadingMarkerSettingsSwatch();
    }

    private void showUtilityColorDialog(final int target, String title) {
        final int selected = target == COLOR_TARGET_RULE ? ruleColorIndex : readingMarkerColorIndex;
        final boolean usingCustom = target == COLOR_TARGET_RULE ? useCustomRuleColor : useCustomReadingMarkerColor;
        final int currentCustom = target == COLOR_TARGET_RULE ? customRuleRgb : customReadingMarkerRgb;

        LinearLayout container = makeDialogContainer();
        container.setGravity(Gravity.CENTER_HORIZONTAL);
        container.setPadding(uiDp(16), uiDp(10), uiDp(16), uiDp(12));

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView(title))
                .setView(container)
                .setNegativeButton(t("Cancelar"), null)
                .create();

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(4);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setUseDefaultMargins(false);

        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                TextView swatch = new TextView(this);
                swatch.setGravity(Gravity.CENTER);
                swatch.setTypeface(Typeface.DEFAULT_BOLD);
                swatch.setTextSize(uiSp(18));

                if (col == 0) {
                    final int quickSlot = row;
                    final boolean hasQuick = hasQuickUtilityColor(target, quickSlot);
                    final int quickColor = getQuickUtilityColor(target, quickSlot);
                    final boolean selectedQuick = usingCustom && hasQuick && currentCustom == quickColor;
                    swatch.setText(hasQuick ? (selectedQuick ? "✓" : "") : "+");
                    swatch.setTextColor(hasQuick
                            ? (isDarkSwatch(quickColor) ? Color.WHITE : Color.BLACK)
                            : (darkTheme ? Color.WHITE : Color.rgb(30, 41, 59)));
                    swatch.setContentDescription(hasQuick
                            ? t("Color personalizado " + (quickSlot + 1))
                            : t("Crear color personalizado " + (quickSlot + 1)));
                    swatch.setBackground(buildMarkSwatchDrawable(hasQuick ? quickColor : -1, selectedQuick));
                    swatch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            if (hasQuick) applyUtilityCustomColor(target, quickColor);
                            else showCustomUtilityColorDialog(target, quickSlot);
                        }
                    });
                    swatch.setOnLongClickListener(new View.OnLongClickListener() {
                        @Override
                        public boolean onLongClick(View v) {
                            dialog.dismiss();
                            showCustomUtilityColorDialog(target, quickSlot);
                            return true;
                        }
                    });
                } else {
                    final int presetIndex = row * 3 + (col - 1);
                    final int presetColor = MARK_COLOR_RGB[presetIndex];
                    final boolean selectedPreset = !usingCustom && presetIndex == selected;
                    swatch.setText(selectedPreset ? "✓" : "");
                    swatch.setTextColor(isDarkSwatch(presetColor) ? Color.WHITE : Color.BLACK);
                    swatch.setBackground(buildMarkSwatchDrawable(presetColor, selectedPreset));
                    swatch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            SharedPreferences.Editor editor = prefs.edit();
                            if (target == COLOR_TARGET_RULE) {
                                ruleColorIndex = safeMarkColorIndex(presetIndex);
                                useCustomRuleColor = false;
                                editor.putInt(PREF_RULE_COLOR, ruleColorIndex)
                                        .putBoolean(PREF_USE_CUSTOM_RULE_COLOR, false);
                                if (pdfView != null) pdfView.setRuleColor(presetColor);
                            } else {
                                readingMarkerColorIndex = safeMarkColorIndex(presetIndex);
                                useCustomReadingMarkerColor = false;
                                editor.putInt(PREF_READING_MARKER_COLOR, readingMarkerColorIndex)
                                        .putBoolean(PREF_USE_CUSTOM_READING_MARKER_COLOR, false);
                                if (pdfView != null) {
                                    pdfView.setReadingMarkerColor(presetColor);
                                    schedulePendingReadingMarker();
                                }
                            }
                            editor.apply();
                            if (target == COLOR_TARGET_READING_MARKER) updateReadingMarkerSettingsSwatch();
                            dialog.dismiss();
                        }
                    });
                }

                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = uiDp(60);
                lp.height = uiDp(60);
                lp.setMargins(uiDp(6), uiDp(6), uiDp(6), uiDp(6));
                grid.addView(swatch, lp);
            }
        }

        container.addView(grid, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        dialog.show();
        styleDialog(dialog);
    }

    private void showCustomUtilityColorDialog(final int target) {
        showCustomUtilityColorDialog(target, -1);
    }

    private void showCustomUtilityColorDialog(final int target, final int quickSlot) {
        final int initial = quickSlot >= 0 && hasQuickUtilityColor(target, quickSlot)
                ? getQuickUtilityColor(target, quickSlot)
                : (target == COLOR_TARGET_RULE ? customRuleRgb : customReadingMarkerRgb);

        LinearLayout box = makeDialogContainer();
        box.setPadding(uiDp(16), uiDp(12), uiDp(16), uiDp(14));

        final ProfessionalColorPickerView picker = new ProfessionalColorPickerView(this);
        picker.setColor(initial);
        box.addView(picker, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(205)));

        final HueSliderView hueSlider = new HueSliderView(this);
        hueSlider.setHue(picker.getHue());
        LinearLayout.LayoutParams hueLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(30));
        hueLp.setMargins(0, uiDp(10), 0, 0);
        box.addView(hueSlider, hueLp);

        final TextView sample = new TextView(this);
        sample.setTextSize(uiSp(20));
        sample.setTypeface(Typeface.DEFAULT_BOLD);
        sample.setGravity(Gravity.CENTER);
        sample.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(10));
        LinearLayout.LayoutParams sampleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(60));
        sampleLp.setMargins(0, uiDp(10), 0, 0);
        box.addView(sample, sampleLp);

        final GradientDrawable sampleBg = new GradientDrawable();
        sampleBg.setCornerRadius(uiDp(14));
        sampleBg.setStroke(uiDp(1), darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        sample.setBackground(sampleBg);

        final boolean[] sampleUpdatePending = new boolean[]{false};
        final Runnable update = new Runnable() {
            @Override
            public void run() {
                sampleUpdatePending[0] = false;
                int color = picker.getSelectedColor() & 0x00FFFFFF;
                sample.setText(String.format(Locale.US, "#%06X", color));
                sample.setTextColor(isDarkSwatch(color) ? Color.WHITE : Color.BLACK);
                sampleBg.setColor(0xFF000000 | color);
            }
        };

        picker.setOnColorChangedListener(new ProfessionalColorPickerView.OnColorChangedListener() {
            @Override
            public void onColorChanged(int color) {
                if (!sampleUpdatePending[0]) {
                    sampleUpdatePending[0] = true;
                    sample.postOnAnimation(update);
                }
            }
        });
        hueSlider.setOnHueChangedListener(new HueSliderView.OnHueChangedListener() {
            @Override
            public void onHueChanged(float hue) {
                picker.setHue(hue);
            }
        });
        update.run();

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Color personalizado"))
                .setView(box)
                .setNegativeButton(t("Cancelar"), null)
                .setPositiveButton(t("Guardar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int color = picker.getSelectedColor() & 0x00FFFFFF;
                        if (quickSlot >= 0) saveQuickUtilityColor(target, quickSlot, color);
                        applyUtilityCustomColor(target, color);
                    }
                }).create();
        dialog.show();
        styleDialog(dialog);
    }

    private void toggleMarkMode() {
        markMode = !markMode;
        if (pdfView != null) pdfView.setMarkMode(markMode);
        if (markMode) {
            if (selectionRepository != null && currentFile != null) {
                selectionRepository.open(currentFile);
            }
            loadSelectionForPage(currentPage);
            prefetchAroundCurrentPage();
        } else {
            // El repositorio permanece abierto para que un nuevo ON sea inmediato.
            // Solo se cancela una selección incompleta dentro de PdfPageView.
        }
        updateMarkControls();

        String message;
        if (!markMode) {
            message = "Marcado apagado";
        } else if (isHighlightStyle(markStyle)) {
            message = "Resaltado activo. Arrastra sobre el texto";
        } else {
            message = "Subrayado activo. Arrastra sobre el texto";
        }
        Toast.makeText(this, t(message), Toast.LENGTH_SHORT).show();
    }

    private void showMarkStyleDialog() {
        if (settingsScrollView != null) settingsScrollY = settingsScrollView.getScrollY();

        final int[] styles = new int[]{
                MARK_STYLE_UNDERLINE_FINE,
                MARK_STYLE_UNDERLINE_DOUBLE,
                MARK_STYLE_UNDERLINE_WAVY,
                MARK_STYLE_UNDERLINE_DOTTED,
                MARK_STYLE_HIGHLIGHT_SOFT,
                MARK_STYLE_HIGHLIGHT_INTENSE
        };

        LinearLayout container = makeDialogContainer();
        container.setPadding(uiDp(10), uiDp(8), uiDp(10), uiDp(4));

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Tipo de marcado"))
                .setView(container)
                .setNegativeButton(t("Cancelar"), null)
                .create();

        for (int i = 0; i < styles.length; i++) {
            final int style = styles[i];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(uiDp(10), uiDp(8), uiDp(8), uiDp(8));
            GradientDrawable rowBg = new GradientDrawable();
            rowBg.setCornerRadius(uiDp(14));
            rowBg.setColor(darkTheme ? Color.rgb(9, 31, 47) : Color.rgb(248, 250, 252));
            row.setBackground(rowBg);

            View preview = createDialogMarkStylePreview(style);

            TextView check = new TextView(this);
            check.setText(style == markStyle ? "◉" : "○");
            check.setTextSize(uiSp(24));
            check.setTextColor(style == markStyle ? Color.rgb(59, 130, 246) : Color.rgb(148, 163, 184));
            check.setGravity(Gravity.CENTER);

            row.addView(preview, new LinearLayout.LayoutParams(0, uiDp(84), 1));
            row.addView(check, new LinearLayout.LayoutParams(uiDp(44), uiDp(44)));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    setMarkStyle(style);
                    dialog.dismiss();
                    if (settingsMode) buildSettingsScreen();
                }
            });
            addRowWithMargin(container, row);
        }

        dialog.show();
        styleDialog(dialog);
    }

    private String getMarkStyleNameForDialog(int style) {
        switch (style) {
            case MARK_STYLE_UNDERLINE_DOUBLE: return "Subrayado doble";
            case MARK_STYLE_UNDERLINE_WAVY: return "Subrayado ondulado";
            case MARK_STYLE_UNDERLINE_DOTTED: return "Subrayado punteado";
            case MARK_STYLE_UNDERLINE_FINE:
            default: return "Subrayado simple";
        }
    }

    private void showMarkThicknessDialog() {
        if (settingsScrollView != null) settingsScrollY = settingsScrollView.getScrollY();

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(uiDp(10), uiDp(8), uiDp(10), uiDp(4));

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Grosor del subrayado"))
                .setView(container)
                .setNegativeButton(t("Cancelar"), null)
                .create();

        for (int level = 0; level <= 2; level++) {
            final int selectedLevel = level;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(10));
            GradientDrawable rowBg = new GradientDrawable();
            rowBg.setCornerRadius(uiDp(12));
            rowBg.setColor(darkTheme ? Color.rgb(9, 31, 47) : Color.rgb(248, 250, 252));
            row.setBackground(rowBg);

            LinearLayout preview = createDialogSampleCard();
            View line = new View(this);
            GradientDrawable lineShape = new GradientDrawable();
            lineShape.setColor(Color.BLACK);
            lineShape.setCornerRadius(uiDp(3));
            line.setBackground(lineShape);
            preview.addView(line, new LinearLayout.LayoutParams(uiDp(132), getPreviewLineThickness(level)));

            TextView check = new TextView(this);
            check.setText(level == markThicknessLevel ? "◉" : "○");
            check.setTextSize(uiSp(24));
            check.setTextColor(level == markThicknessLevel ? Color.rgb(59, 130, 246) : Color.rgb(148, 163, 184));
            check.setGravity(Gravity.CENTER);

            row.addView(preview, new LinearLayout.LayoutParams(0, uiDp(70), 1));
            row.addView(check, new LinearLayout.LayoutParams(uiDp(44), uiDp(44)));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    markThicknessLevel = safeThicknessLevel(selectedLevel);
                    prefs.edit().putInt(PREF_MARK_THICKNESS, markThicknessLevel).apply();
                    applyMarkAppearance();
                    dialog.dismiss();
                    if (settingsMode) buildSettingsScreen();
                }
            });
            addRowWithMargin(container, row);
        }

        dialog.show();
        styleDialog(dialog);
    }

    private LinearLayout createDialogSampleCard() {
        LinearLayout preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.VERTICAL);
        preview.setGravity(Gravity.CENTER);
        preview.setPadding(uiDp(14), uiDp(10), uiDp(14), uiDp(10));
        GradientDrawable previewBg = new GradientDrawable();
        previewBg.setCornerRadius(uiDp(10));
        previewBg.setColor(Color.WHITE);
        previewBg.setStroke(uiDp(1), Color.rgb(226, 232, 240));
        preview.setBackground(previewBg);
        return preview;
    }

    private View createDialogMarkStylePreview(int style) {
        LinearLayout preview = createDialogSampleCard();

        if (style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE) {
            TextView sample = new TextView(this);
            sample.setText(t("Ejemplo"));
            sample.setTextSize(uiSp(17));
            sample.setTypeface(Typeface.DEFAULT_BOLD);
            sample.setTextColor(Color.BLACK);
            sample.setGravity(Gravity.CENTER);
            applySampleDecoration(sample, style, getPreviewColorForStyle(style));
            preview.addView(sample, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            return preview;
        }

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView sample = new TextView(this);
        sample.setText(t("Ejemplo"));
        sample.setTextSize(uiSp(17));
        sample.setTypeface(Typeface.DEFAULT_BOLD);
        sample.setTextColor(Color.BLACK);
        sample.setGravity(Gravity.CENTER);
        content.addView(sample, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        View line = createPreviewUnderlineView(style, markThicknessLevel, getPreviewColorForStyle(style), uiDp(118));
        LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lineParams.topMargin = uiDp(2);
        content.addView(line, lineParams);

        preview.addView(content, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return preview;
    }

    private int getPreviewColorForStyle(int style) {
        int target = isHighlightStyle(style) ? COLOR_TARGET_HIGHLIGHT : COLOR_TARGET_UNDERLINE;
        int index = target == COLOR_TARGET_HIGHLIGHT ? highlightColorIndex : underlineColorIndex;
        return getMarkColor(target, index);
    }

    private void showAudioExportDialog() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout box = makeDialogContainer();
        box.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView recordButton = new TextView(this);
        recordButton.setText(t("●"));
        recordButton.setTextSize(uiSp(48));
        recordButton.setGravity(Gravity.CENTER);
        recordButton.setTextColor(Color.WHITE);
        GradientDrawable recordBg = new GradientDrawable();
        recordBg.setShape(GradientDrawable.OVAL);
        recordBg.setColor(Color.rgb(220, 38, 38));
        recordBg.setStroke(uiDp(5), Color.rgb(254, 202, 202));
        recordButton.setBackground(recordBg);
        recordButton.setContentDescription(t("Crear audio"));
        box.addView(recordButton, new LinearLayout.LayoutParams(uiDp(92), uiDp(92)));

        TextView info = new TextView(this);
        info.setText(t("Toca el botón para la página actual o elige otra opción"));
        info.setTextSize(uiSp(15));
        info.setTypeface(Typeface.DEFAULT_BOLD);
        info.setGravity(Gravity.CENTER);
        info.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        info.setPadding(0, uiDp(10), 0, uiDp(3));
        box.addView(info);

        TextView folder = new TextView(this);
        folder.setText(t("Se guardará en  Geo Zeta / Audios"));
        folder.setTextSize(uiSp(12));
        folder.setGravity(Gravity.CENTER);
        folder.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        folder.setPadding(0, 0, 0, uiDp(10));
        box.addView(folder);

        Button current = makeRecorderOptionButton("Página actual", "Crear un audio de la página visible");
        Button full = makeRecorderOptionButton("Todo el PDF", "Crear audios organizados por páginas");
        Button range = makeRecorderOptionButton("Elegir rango", "Por ejemplo: páginas 14 a 300");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(64));
        lp.setMargins(0, uiDp(5), 0, uiDp(5));
        box.addView(current, lp);
        box.addView(full, lp);
        box.addView(range, lp);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Crear audio"))
                .setView(box)
                .setNegativeButton(t("Cerrar"), null)
                .create();

        recordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                startAudioExportRange(currentPage, currentPage);
            }
        });

        current.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                startAudioExportRange(currentPage, currentPage);
            }
        });
        full.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                startAudioExportRange(0, pageCount - 1);
            }
        });
        range.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                showAudioRangeDialog();
            }
        });

        dialog.show();
        styleDialog(dialog);
    }

    private Button makeRecorderOptionButton(String title, String subtitle) {
        Button button = new Button(this);
        button.setText(t(title) + "\n" + t(subtitle));
        button.setTextSize(uiSp(13));
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        button.setPadding(uiDp(16), uiDp(6), uiDp(12), uiDp(6));
        button.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(uiDp(14));
        bg.setColor(darkTheme ? Color.rgb(12, 35, 54) : Color.rgb(248, 250, 252));
        bg.setStroke(uiDp(1), darkTheme ? Color.rgb(24, 72, 101) : Color.rgb(203, 213, 225));
        button.setBackground(bg);
        return button;
    }

    private void showAudioRangeDialog() {
        LinearLayout box = makeDialogContainer();

        final EditText startInput = new EditText(this);
        startInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        startInput.setHint(t("Desde (1 - " + pageCount + ")"));
        startInput.setText(String.valueOf(currentPage + 1));
        startInput.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        startInput.setHintTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        final EditText endInput = new EditText(this);
        endInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        endInput.setHint(t("Hasta (1 - " + pageCount + ")"));
        endInput.setText(String.valueOf(currentPage + 1));
        endInput.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        endInput.setHintTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        box.addView(startInput);
        box.addView(endInput);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Elegir rango"))
                .setView(box)
                .setNegativeButton(t("Cancelar"), null)
                .setPositiveButton(t("Crear"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int start;
                        int end;
                        try {
                            start = Integer.parseInt(startInput.getText().toString().trim()) - 1;
                            end = Integer.parseInt(endInput.getText().toString().trim()) - 1;
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, t("Rango inválido"), Toast.LENGTH_SHORT).show();
                            return;
                        }
                        startAudioExportRange(start, end);
                    }
                })
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void startAudioExportRange(int startPage, int endPage) {
        if (currentFile == null || pageCount <= 0) return;

        int start = Math.max(0, Math.min(startPage, pageCount - 1));
        int end = Math.max(0, Math.min(endPage, pageCount - 1));
        if (end < start) {
            int tmp = start;
            start = end;
            end = tmp;
        }

        audioExportSessionToken++;
        if (exportTts != null) {
            try { exportTts.stop(); } catch (Exception ignored) { }
        }
        clearActiveExportState(true);
        clearExportTempDirectory();

        exportStartPage = start;
        exportEndPage = end;
        exportCurrentPage = start;
        exportSavedCount = 0;
        lastExportedAudioFile = null;
        exportAudioBase = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
        exportAudioDir = new File(getAudioSaveDir(), exportAudioBase + "_P" + (start + 1) + "_a_" + (end + 1));
        if (!exportAudioDir.exists()) exportAudioDir.mkdirs();

        Toast.makeText(this, t("Preparando exportación de audio..."), Toast.LENGTH_SHORT).show();
        ensureExportTtsAndExportNext();
    }

    private void ensureExportTtsAndExportNext() {
        if (exportTts != null) {
            if (!exportTtsReady) return;
            configureExportTtsListener();
            exportNextPageAudio();
            return;
        }

        exportTtsReady = false;
        exportTts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.SUCCESS) {
                    exportTtsReady = false;
                    if (exportTts != null) {
                        try { exportTts.shutdown(); } catch (Exception ignored) { }
                        exportTts = null;
                    }
                    Toast.makeText(MainActivity.this, t("No se pudo iniciar voz"), Toast.LENGTH_LONG).show();
                    return;
                }
                exportTtsReady = true;
                exportTts.setLanguage(new Locale("es", "PE"));
                exportTts.setSpeechRate(speechRate);
                configureExportTtsListener();
                exportNextPageAudio();
            }
        });
    }

    private void configureExportTtsListener() {
        if (exportTts == null) return;
        exportTts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) { }

            @Override
            public void onDone(final String utteranceId) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handleExportChunkDone(utteranceId);
                    }
                });
            }

            @Override
            public void onError(final String utteranceId) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handleExportChunkError(utteranceId);
                    }
                });
            }

            @Override
            public void onError(final String utteranceId, int errorCode) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handleExportChunkError(utteranceId);
                    }
                });
            }
        });
    }

    private void exportNextPageAudio() {
        if (exportCurrentPage < 0 || exportCurrentPage > exportEndPage) {
            showAudioExportCompleted();
            return;
        }

        final int sessionToken = audioExportSessionToken;
        final int page = exportCurrentPage;
        textRepository.getPageText(page, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                if (sessionToken != audioExportSessionToken || page != exportCurrentPage) return;
                if (text == null || text.trim().length() == 0) {
                    exportCurrentPage++;
                    exportNextPageAudio();
                    return;
                }
                beginPageAudioExport(page, text.trim(), sessionToken);
            }
        });
    }

    private void beginPageAudioExport(int page, String text, int sessionToken) {
        if (sessionToken != audioExportSessionToken || exportTts == null) return;

        ArrayList<String> chunks = splitTextForTtsExport(text);
        if (chunks.isEmpty()) {
            exportCurrentPage++;
            exportNextPageAudio();
            return;
        }

        clearActiveExportState(true);
        activeExportChunks.addAll(chunks);
        activeExportChunkIndex = 0;
        activeExportPage = page;
        activeExportOutputFile = new File(exportAudioDir, exportAudioBase + "_pagina_" + (page + 1) + ".wav");
        synthesizeActiveExportChunk(sessionToken);
    }

    private ArrayList<String> splitTextForTtsExport(String text) {
        ArrayList<String> chunks = new ArrayList<>();
        if (text == null) return chunks;

        String source = text.trim();
        if (source.length() == 0) return chunks;

        int engineLimit;
        try {
            engineLimit = TextToSpeech.getMaxSpeechInputLength();
        } catch (Exception ignored) {
            engineLimit = 4000;
        }
        int limit = Math.max(256, Math.min(3600, engineLimit - 64));
        int start = 0;
        while (start < source.length()) {
            int end = Math.min(source.length(), start + limit);
            if (end < source.length()) {
                int minimumBreak = start + Math.max(64, limit / 2);
                int sentenceBreak = findExportBreak(source, minimumBreak, end, true);
                int whitespaceBreak = findExportBreak(source, minimumBreak, end, false);
                if (sentenceBreak > start) {
                    end = sentenceBreak;
                } else if (whitespaceBreak > start) {
                    end = whitespaceBreak;
                }
            }

            if (end <= start) end = Math.min(source.length(), start + limit);
            String chunk = source.substring(start, end).trim();
            if (chunk.length() > 0) chunks.add(chunk);
            start = end;
            while (start < source.length() && Character.isWhitespace(source.charAt(start))) start++;
        }
        return chunks;
    }

    private int findExportBreak(String text, int minimum, int end, boolean sentenceOnly) {
        int lower = Math.max(0, minimum);
        for (int i = end - 1; i >= lower; i--) {
            char c = text.charAt(i);
            if (sentenceOnly) {
                if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':' || c == '\n') return i + 1;
            } else if (Character.isWhitespace(c) || c == ',') {
                return i + 1;
            }
        }
        return -1;
    }

    private void synthesizeActiveExportChunk(int sessionToken) {
        if (sessionToken != audioExportSessionToken || exportTts == null) return;
        if (activeExportChunkIndex < 0 || activeExportChunkIndex >= activeExportChunks.size()) {
            finishActiveExportPage(sessionToken);
            return;
        }

        File tempDir = new File(getCacheDir(), "tts_export_chunks");
        if (!tempDir.exists()) tempDir.mkdirs();
        File tempFile = new File(tempDir,
                "export_" + sessionToken + "_p" + activeExportPage + "_c" + activeExportChunkIndex + "_" + System.nanoTime() + ".wav");
        activeExportChunkFiles.add(tempFile);

        activeExportUtteranceId = "EXPORT_" + sessionToken + "_" + activeExportPage + "_" + activeExportChunkIndex + "_" + System.nanoTime();
        Bundle params = new Bundle();
        int result;
        try {
            result = exportTts.synthesizeToFile(
                    activeExportChunks.get(activeExportChunkIndex),
                    params,
                    tempFile,
                    activeExportUtteranceId);
        } catch (Exception e) {
            result = TextToSpeech.ERROR;
        }
        if (result != TextToSpeech.SUCCESS) {
            handleExportChunkError(activeExportUtteranceId);
        }
    }

    private void handleExportChunkDone(String utteranceId) {
        if (utteranceId == null || !utteranceId.equals(activeExportUtteranceId)) return;
        int sessionToken = audioExportSessionToken;
        activeExportUtteranceId = null;
        activeExportChunkIndex++;
        if (activeExportChunkIndex < activeExportChunks.size()) {
            synthesizeActiveExportChunk(sessionToken);
        } else {
            finishActiveExportPage(sessionToken);
        }
    }

    private void handleExportChunkError(String utteranceId) {
        if (utteranceId == null || !utteranceId.equals(activeExportUtteranceId)) return;
        activeExportUtteranceId = null;
        final int sessionToken = audioExportSessionToken;
        final int failedPage = activeExportPage;
        clearActiveExportState(true);
        if (failedPage == exportCurrentPage && sessionToken == audioExportSessionToken) {
            exportCurrentPage++;
            Toast.makeText(this, t("No se pudo exportar la página " + (failedPage + 1)), Toast.LENGTH_SHORT).show();
            exportNextPageAudio();
        }
    }

    private void finishActiveExportPage(final int sessionToken) {
        if (sessionToken != audioExportSessionToken) return;
        final int page = activeExportPage;
        final File output = activeExportOutputFile;
        final ArrayList<File> parts = new ArrayList<>(activeExportChunkFiles);
        activeExportUtteranceId = null;

        audioExportExecutor.execute(new Runnable() {
            @Override
            public void run() {
                boolean ok = false;
                try {
                    ok = mergeExportWavParts(parts, output);
                } catch (Exception ignored) { }
                final boolean success = ok;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        deleteExportFiles(parts);
                        if (sessionToken != audioExportSessionToken || page != exportCurrentPage) return;
                        clearActiveExportState(false);
                        if (success && output != null && output.exists() && output.length() > 44) {
                            exportSavedCount++;
                            lastExportedAudioFile = output;
                        } else {
                            if (output != null && output.exists()) output.delete();
                            Toast.makeText(MainActivity.this,
                                    t("No se pudo exportar la página " + (page + 1)), Toast.LENGTH_SHORT).show();
                        }
                        exportCurrentPage++;
                        exportNextPageAudio();
                    }
                });
            }
        });
    }

    private void clearActiveExportState(boolean deleteTempFiles) {
        if (deleteTempFiles) deleteExportFiles(activeExportChunkFiles);
        activeExportChunks.clear();
        activeExportChunkFiles.clear();
        activeExportChunkIndex = -1;
        activeExportPage = -1;
        activeExportOutputFile = null;
        activeExportUtteranceId = null;
    }

    private void deleteExportFiles(ArrayList<File> files) {
        if (files == null) return;
        for (File file : files) {
            if (file != null && file.exists()) {
                try { file.delete(); } catch (Exception ignored) { }
            }
        }
    }

    private void clearExportTempDirectory() {
        File dir = new File(getCacheDir(), "tts_export_chunks");
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file != null && file.isFile()) {
                try { file.delete(); } catch (Exception ignored) { }
            }
        }
    }

    private boolean mergeExportWavParts(ArrayList<File> parts, File output) throws IOException {
        if (parts == null || parts.isEmpty() || output == null) return false;
        if (parts.size() == 1) return copyExportFile(parts.get(0), output);

        ArrayList<WavChunkInfo> infos = new ArrayList<>();
        long totalData = 0L;
        byte[] expectedFormat = null;
        for (File part : parts) {
            WavChunkInfo info = readWavChunkInfo(part);
            if (info == null || info.formatChunk == null || info.dataLength <= 0) return false;
            if (expectedFormat == null) {
                expectedFormat = info.formatChunk;
            } else if (!Arrays.equals(expectedFormat, info.formatChunk)) {
                return false;
            }
            totalData += info.dataLength;
            if (totalData > 0xFFFFFFFFL) return false;
            infos.add(info);
        }

        WavChunkInfo first = infos.get(0);
        byte[] header = Arrays.copyOf(first.headerBeforeData, first.headerBeforeData.length);
        int pad = (int) (totalData & 1L);
        long riffSize = header.length + totalData + pad - 8L;
        if (riffSize < 0 || riffSize > 0xFFFFFFFFL || first.dataSizeFieldOffset < 0
                || first.dataSizeFieldOffset + 4 > header.length) return false;

        writeUInt32Le(header, 4, riffSize);
        writeUInt32Le(header, (int) first.dataSizeFieldOffset, totalData);

        File parent = output.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (FileOutputStream out = new FileOutputStream(output, false)) {
            out.write(header);
            byte[] buffer = new byte[32 * 1024];
            for (WavChunkInfo info : infos) {
                try (RandomAccessFile in = new RandomAccessFile(info.file, "r")) {
                    in.seek(info.dataOffset);
                    long remaining = info.dataLength;
                    while (remaining > 0) {
                        int count = in.read(buffer, 0, (int) Math.min(buffer.length, remaining));
                        if (count < 0) return false;
                        out.write(buffer, 0, count);
                        remaining -= count;
                    }
                }
            }
            if (pad != 0) out.write(0);
            out.flush();
        }
        return output.exists() && output.length() > header.length;
    }

    private boolean copyExportFile(File source, File output) throws IOException {
        if (source == null || !source.exists() || source.length() == 0 || output == null) return false;
        File parent = output.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(output, false)) {
            byte[] buffer = new byte[32 * 1024];
            int count;
            while ((count = in.read(buffer)) >= 0) {
                if (count > 0) out.write(buffer, 0, count);
            }
            out.flush();
        }
        return output.exists() && output.length() > 0;
    }

    private WavChunkInfo readWavChunkInfo(File file) throws IOException {
        if (file == null || !file.exists() || file.length() < 44) return null;
        try (RandomAccessFile in = new RandomAccessFile(file, "r")) {
            if (!"RIFF".equals(readFourCc(in))) return null;
            readUInt32Le(in);
            if (!"WAVE".equals(readFourCc(in))) return null;

            byte[] format = null;
            long dataOffset = -1L;
            long dataLength = -1L;
            long dataSizeFieldOffset = -1L;
            while (in.getFilePointer() + 8L <= in.length()) {
                String chunkId = readFourCc(in);
                long chunkSize = readUInt32Le(in);
                long chunkDataStart = in.getFilePointer();
                if (chunkSize < 0 || chunkDataStart + chunkSize > in.length()) return null;

                if ("fmt ".equals(chunkId)) {
                    if (chunkSize <= 0 || chunkSize > 1024L) return null;
                    format = new byte[(int) chunkSize];
                    in.readFully(format);
                } else if ("data".equals(chunkId)) {
                    dataOffset = chunkDataStart;
                    dataLength = Math.min(chunkSize, in.length() - chunkDataStart);
                    dataSizeFieldOffset = chunkDataStart - 4L;
                    break;
                }

                long next = chunkDataStart + chunkSize + (chunkSize & 1L);
                if (next > in.length()) return null;
                in.seek(next);
            }
            if (format == null || dataOffset < 0 || dataLength <= 0 || dataOffset > Integer.MAX_VALUE) return null;

            byte[] header = new byte[(int) dataOffset];
            in.seek(0L);
            in.readFully(header);
            return new WavChunkInfo(file, format, dataOffset, dataLength, dataSizeFieldOffset, header);
        }
    }

    private String readFourCc(RandomAccessFile in) throws IOException {
        byte[] bytes = new byte[4];
        in.readFully(bytes);
        return new String(bytes, java.nio.charset.StandardCharsets.US_ASCII);
    }

    private long readUInt32Le(RandomAccessFile in) throws IOException {
        long b0 = in.readUnsignedByte();
        long b1 = in.readUnsignedByte();
        long b2 = in.readUnsignedByte();
        long b3 = in.readUnsignedByte();
        return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24);
    }

    private void writeUInt32Le(byte[] data, int offset, long value) {
        data[offset] = (byte) (value & 0xFF);
        data[offset + 1] = (byte) ((value >> 8) & 0xFF);
        data[offset + 2] = (byte) ((value >> 16) & 0xFF);
        data[offset + 3] = (byte) ((value >> 24) & 0xFF);
    }

    private static final class WavChunkInfo {
        final File file;
        final byte[] formatChunk;
        final long dataOffset;
        final long dataLength;
        final long dataSizeFieldOffset;
        final byte[] headerBeforeData;

        WavChunkInfo(File file, byte[] formatChunk, long dataOffset, long dataLength,
                     long dataSizeFieldOffset, byte[] headerBeforeData) {
            this.file = file;
            this.formatChunk = formatChunk;
            this.dataOffset = dataOffset;
            this.dataLength = dataLength;
            this.dataSizeFieldOffset = dataSizeFieldOffset;
            this.headerBeforeData = headerBeforeData;
        }
    }

    private void showMarkColorDialog(final int target) {
        final int selected = target == COLOR_TARGET_HIGHLIGHT ? highlightColorIndex : underlineColorIndex;
        final boolean usingCustom = target == COLOR_TARGET_HIGHLIGHT ? useCustomHighlightColor : useCustomUnderlineColor;
        final int currentCustom = target == COLOR_TARGET_HIGHLIGHT ? customHighlightRgb : customUnderlineRgb;
        final String title = target == COLOR_TARGET_HIGHLIGHT ? "Color del resaltado" : "Color del subrayado";

        LinearLayout container = makeDialogContainer();
        container.setGravity(Gravity.CENTER_HORIZONTAL);
        container.setPadding(uiDp(16), uiDp(10), uiDp(16), uiDp(12));


        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView(title))
                .setView(container)
                .setNegativeButton(t("Cancelar"), null)
                .create();

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(4);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setUseDefaultMargins(false);

        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                TextView swatch = new TextView(this);
                swatch.setGravity(Gravity.CENTER);
                swatch.setTypeface(Typeface.DEFAULT_BOLD);
                swatch.setTextSize(uiSp(18));

                if (col == 0) {
                    if (row < QUICK_MARK_SLOT_COUNT) {
                        final int quickSlot = row;
                        final boolean hasQuick = hasQuickMarkColor(quickSlot);
                        final int quickColor = getQuickMarkColor(quickSlot);
                        final boolean selectedQuick = usingCustom && hasQuick && currentCustom == quickColor;
                        swatch.setText(hasQuick ? (selectedQuick ? "✓" : "") : "+");
                        swatch.setTextColor(hasQuick
                                ? (isDarkSwatch(quickColor) ? Color.WHITE : Color.BLACK)
                                : (darkTheme ? Color.WHITE : Color.rgb(30, 41, 59)));
                        swatch.setContentDescription(hasQuick
                                ? t("Color personalizado " + (quickSlot + 1))
                                : t("Crear color personalizado " + (quickSlot + 1)));
                        swatch.setBackground(buildMarkSwatchDrawable(hasQuick ? quickColor : -1, selectedQuick));
                        swatch.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                                if (hasQuick) applyQuickMarkColor(target, quickColor);
                                else showCustomColorDialog(target, quickSlot);
                            }
                        });
                        swatch.setOnLongClickListener(new View.OnLongClickListener() {
                            @Override
                            public boolean onLongClick(View v) {
                                dialog.dismiss();
                                showCustomColorDialog(target, quickSlot);
                                return true;
                            }
                        });
                    }
                } else {
                    final int presetIndex = row * 3 + (col - 1);
                    final int presetColor = MARK_COLOR_RGB[presetIndex];
                    final boolean selectedPreset = !usingCustom && presetIndex == selected;
                    swatch.setText(selectedPreset ? "✓" : "");
                    swatch.setTextColor(isDarkSwatch(presetColor) ? Color.WHITE : Color.BLACK);
                    swatch.setContentDescription(t("Color base " + (presetIndex + 1)));
                    swatch.setBackground(buildMarkSwatchDrawable(presetColor, selectedPreset));
                    swatch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int safe = safeMarkColorIndex(presetIndex);
                            SharedPreferences.Editor editor = prefs.edit();
                            if (target == COLOR_TARGET_HIGHLIGHT) {
                                highlightColorIndex = safe;
                                useCustomHighlightColor = false;
                                editor.putInt(PREF_HIGHLIGHT_COLOR, safe)
                                        .putBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, false);
                            } else {
                                underlineColorIndex = safe;
                                useCustomUnderlineColor = false;
                                editor.putInt(PREF_UNDERLINE_COLOR, safe)
                                        .putBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, false);
                            }
                            editor.apply();
                            applyMarkAppearance();
                            dialog.dismiss();
                        }
                    });
                }

                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = uiDp(60);
                lp.height = uiDp(60);
                lp.setMargins(uiDp(6), uiDp(6), uiDp(6), uiDp(6));
                grid.addView(swatch, lp);
            }
        }

        container.addView(grid, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        dialog.show();
        styleDialog(dialog);
    }

    private GradientDrawable buildMarkSwatchDrawable(int color, boolean selected) {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.OVAL);
        if (color >= 0) {
            shape.setColor(0xFF000000 | (color & 0x00FFFFFF));
        } else {
            shape.setColor(darkTheme ? Color.rgb(16, 45, 66) : Color.rgb(226, 239, 255));
        }
        shape.setStroke(uiDp(selected ? 3 : 1), selected
                ? Color.rgb(59, 130, 246)
                : (darkTheme ? Color.WHITE : Color.rgb(71, 85, 105)));
        return shape;
    }

    private boolean hasQuickMarkColor(int slot) {
        return prefs.getBoolean("quick_mark_color_set_" + slot, false);
    }

    private int getQuickMarkColor(int slot) {
        return prefs.getInt("quick_mark_color_" + slot, 0x00FFD400) & 0x00FFFFFF;
    }

    private void saveQuickMarkColor(int slot, int color) {
        prefs.edit()
                .putInt("quick_mark_color_" + slot, color & 0x00FFFFFF)
                .putBoolean("quick_mark_color_set_" + slot, true)
                .apply();
    }

    private void applyQuickMarkColor(int target, int color) {
        color &= 0x00FFFFFF;
        SharedPreferences.Editor editor = prefs.edit();
        if (target == COLOR_TARGET_HIGHLIGHT) {
            customHighlightRgb = color;
            useCustomHighlightColor = true;
            editor.putInt(PREF_CUSTOM_HIGHLIGHT_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, true);
        } else {
            customUnderlineRgb = color;
            useCustomUnderlineColor = true;
            editor.putInt(PREF_CUSTOM_UNDERLINE_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, true);
        }
        editor.apply();
        applyMarkAppearance();
    }

    private void showCustomColorDialog(final int target) {
        showCustomColorDialog(target, -1);
    }

    private void showCustomColorDialog(final int target, final int quickSlot) {
        final int initial = quickSlot >= 0 && hasQuickMarkColor(quickSlot)
                ? getQuickMarkColor(quickSlot)
                : (target == COLOR_TARGET_HIGHLIGHT ? customHighlightRgb : customUnderlineRgb);

        LinearLayout box = makeDialogContainer();
        box.setPadding(uiDp(16), uiDp(12), uiDp(16), uiDp(14));

        final ProfessionalColorPickerView picker = new ProfessionalColorPickerView(this);
        picker.setColor(initial);
        box.addView(picker, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(205)));

        final HueSliderView hueSlider = new HueSliderView(this);
        hueSlider.setHue(picker.getHue());
        LinearLayout.LayoutParams hueLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(30));
        hueLp.setMargins(0, uiDp(10), 0, 0);
        box.addView(hueSlider, hueLp);

        final TextView sample = new TextView(this);
        sample.setTextSize(uiSp(20));
        sample.setTypeface(Typeface.DEFAULT_BOLD);
        sample.setGravity(Gravity.CENTER);
        sample.setPadding(uiDp(12), uiDp(10), uiDp(12), uiDp(10));
        LinearLayout.LayoutParams sampleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, uiDp(60));
        sampleLp.setMargins(0, uiDp(10), 0, 0);
        box.addView(sample, sampleLp);

        final GradientDrawable sampleBg = new GradientDrawable();
        sampleBg.setCornerRadius(uiDp(14));
        sampleBg.setStroke(uiDp(1), darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        sample.setBackground(sampleBg);

        final boolean[] sampleUpdatePending = new boolean[]{false};
        final Runnable update = new Runnable() {
            @Override
            public void run() {
                sampleUpdatePending[0] = false;
                int color = picker.getSelectedColor() & 0x00FFFFFF;
                sample.setText(String.format(Locale.US, "#%06X", color));
                sample.setTextColor(isDarkSwatch(color) ? Color.WHITE : Color.BLACK);
                sampleBg.setColor(0xFF000000 | color);
            }
        };

        picker.setOnColorChangedListener(new ProfessionalColorPickerView.OnColorChangedListener() {
            @Override
            public void onColorChanged(int color) {
                if (!sampleUpdatePending[0]) {
                    sampleUpdatePending[0] = true;
                    sample.postOnAnimation(update);
                }
            }
        });
        hueSlider.setOnHueChangedListener(new HueSliderView.OnHueChangedListener() {
            @Override
            public void onHueChanged(float hue) {
                picker.setHue(hue);
            }
        });
        update.run();

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Color personalizado"))
                .setView(box)
                .setNegativeButton(t("Cancelar"), null)
                .setPositiveButton(t("Guardar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int color = picker.getSelectedColor() & 0x00FFFFFF;
                        SharedPreferences.Editor editor = prefs.edit();
                        if (quickSlot >= 0) {
                            saveQuickMarkColor(quickSlot, color);
                        }
                        if (target == COLOR_TARGET_HIGHLIGHT) {
                            customHighlightRgb = color;
                            useCustomHighlightColor = true;
                            editor.putInt(PREF_CUSTOM_HIGHLIGHT_COLOR, color)
                                    .putBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, true);
                        } else {
                            customUnderlineRgb = color;
                            useCustomUnderlineColor = true;
                            editor.putInt(PREF_CUSTOM_UNDERLINE_COLOR, color)
                                    .putBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, true);
                        }
                        editor.apply();
                        applyMarkAppearance();
                    }
                }).create();
        dialog.show();
        styleDialog(dialog);
    }

    private SeekBar createColorSeekBar(LinearLayout parent, String label, int value) {
        TextView title = new TextView(this);
        title.setText(t(label));
        title.setTextSize(uiSp(13));
        title.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
        parent.addView(title);

        SeekBar seek = new SeekBar(this);
        seek.setMax(255);
        seek.setProgress(Math.max(0, Math.min(255, value)));
        parent.addView(seek, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, uiDp(42)));
        return seek;
    }

    private boolean isDarkSwatch(int rgb) {
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        return (r * 299 + g * 587 + b * 114) / 1000 < 145;
    }

    private void setMarkStyle(int style) {
        markStyle = safeMarkStyle(style);
        prefs.edit().putInt(PREF_MARK_STYLE, markStyle).apply();
        applyMarkAppearance();
    }

    private void applyMarkAppearance() {
        if (pdfView != null) {
            pdfView.setMarkStyle(markStyle);
            pdfView.setMarkThickness(markThicknessLevel);
            pdfView.setMarkColor(getCurrentMarkColor());
        }
        updateMarkControls();
    }

    private void updateMarkControls() {
        if (markButton != null) {
            markButton.setText(markMode ? t("Subrayar ON") : t("Subrayar OFF"));
            markButton.setAlpha(markMode ? 1f : 0.78f);
            markButton.setContentDescription(markMode
                    ? t("Subrayado activado: un dedo marca y dos dedos mueven")
                    : t("Subrayado desactivado"));
        }
        if (colorButton != null) {
            colorButton.setText(t("●"));
            colorButton.setTextColor(0xFF000000 | (getCurrentMarkColor() & 0x00FFFFFF));
            colorButton.setAlpha(1f);
        }
    }

    private String getMarkStyleName() {
        switch (markStyle) {
            case MARK_STYLE_UNDERLINE_DOUBLE: return "Subrayado doble";
            case MARK_STYLE_UNDERLINE_WAVY: return "Subrayado ondulado";
            case MARK_STYLE_UNDERLINE_DOTTED: return "Subrayado punteado";
            case MARK_STYLE_HIGHLIGHT_SOFT: return "Resaltado suave";
            case MARK_STYLE_HIGHLIGHT_INTENSE: return "Resaltado intenso";
            case MARK_STYLE_UNDERLINE_FINE:
            default: return "Subrayado fino";
        }
    }

    private String getThicknessName() {
        if (markThicknessLevel == 0) return "Fino";
        if (markThicknessLevel == 2) return "Grueso";
        return "Medio";
    }

    private boolean isHighlightStyle(int style) {
        return style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE;
    }

    private int getCurrentMarkColor() {
        int target = isHighlightStyle(markStyle) ? COLOR_TARGET_HIGHLIGHT : COLOR_TARGET_UNDERLINE;
        int index = target == COLOR_TARGET_HIGHLIGHT ? highlightColorIndex : underlineColorIndex;
        return getMarkColor(target, index);
    }

    private int getMarkColor(int target, int index) {
        int rgb;
        if (target == COLOR_TARGET_HIGHLIGHT && useCustomHighlightColor) {
            rgb = customHighlightRgb;
        } else if (target == COLOR_TARGET_UNDERLINE && useCustomUnderlineColor) {
            rgb = customUnderlineRgb;
        } else {
            rgb = MARK_COLOR_RGB[safeMarkColorIndex(index)];
        }
        int alpha;
        if (target == COLOR_TARGET_HIGHLIGHT) {
            alpha = markStyle == MARK_STYLE_HIGHLIGHT_INTENSE ? 0xA8 : 0x62;
        } else {
            alpha = 0xEE;
        }
        return (alpha << 24) | (rgb & 0x00FFFFFF);
    }

    private int safeMarkStyle(int style) {
        if (style == MARK_STYLE_TEXT_BOX) return MARK_STYLE_UNDERLINE_FINE;
        if (style < MARK_STYLE_UNDERLINE_FINE || style > MARK_STYLE_HIGHLIGHT_INTENSE) {
            return MARK_STYLE_UNDERLINE_FINE;
        }
        return style;
    }

    private int safeThicknessLevel(int level) {
        if (level < 0 || level > 2) return 1;
        return level;
    }

    private int migrateV71ColorIndex(int oldIndex) {
        switch (oldIndex) {
            case 1: return 3; // azul
            case 2: return 4; // verde
            case 3: return 1; // rojo
            case 4: return 6; // morado
            case 5: return 7; // celeste
            case 0:
            default: return 0;
        }
    }

    private int safeMarkColorIndex(int index) {
        if (index < 0 || index >= MARK_COLOR_RGB.length) return 0;
        return index;
    }

    private String highlightKey() {
        String safeTitle = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
        String safeFile = currentFile == null ? "nofile" : String.valueOf(currentFile.getAbsolutePath().hashCode());
        return "text_selection_markers_" + safeTitle + "_" + safeFile;
    }

    private String legacyHighlightKey() {
        return "text_selection_markers_" + currentTitle;
    }

    private void saveHighlights(String serialized) {
        prefs.edit().putString(highlightKey(), serialized == null ? "" : serialized).apply();
    }

    private void repairBrokenPlaybackStateOnce() {
        if (prefs.getBoolean(PREF_AUDIO_STATE_REPAIRED_V69, false)) return;

        try {
            stopService(new Intent(this, TtsForegroundService.class));
        } catch (Exception ignored) {
        }

        TtsForegroundService.clearPages();
        prefs.edit()
                .putBoolean(PREF_TTS_ACTIVE, false)
                .putBoolean(PREF_TTS_PAUSED, false)
                .putInt(PREF_TTS_CURRENT_PAGE, -1)
                .putInt(PREF_TTS_STATE, TtsForegroundService.STATE_STOPPED)
                .putString(PREF_TTS_MESSAGE, "")
                .remove("tts_service_preparing")
                .putBoolean(PREF_AUDIO_STATE_REPAIRED_V69, true)
                .apply();

        playbackState = TtsForegroundService.STATE_STOPPED;
        audioStarted = false;
        audioPaused = false;
        audioPreparing = false;
        requestedAudioPage = -1;
        requestedAudioPageConfirmed = false;
        audioRequestToken++;
    }

    private void toggleAudio() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }

        if (playbackState == TtsForegroundService.STATE_PREPARING || audioPreparing) {
            // El segundo toque funciona como Pausa incluso si el motor aún está
            // preparando la primera frase. No se muestra un estado intermedio.
            seekAudioToPage(currentPage, false);
            return;
        }

        if (playbackState == TtsForegroundService.STATE_PLAYING) {
            Intent intent = new Intent(this, TtsForegroundService.class);
            intent.setAction(TtsForegroundService.ACTION_TOGGLE);
            startService(intent);
            return;
        }

        if (playbackState == TtsForegroundService.STATE_PAUSED) {
            // Solo reanudar si el servicio conserva de verdad una sesion pausada
            // con fragmentos preparados para esta misma pagina. Un estado PAUSED
            // guardado en preferencias, o una pagina cambiada mientras estaba en
            // pausa, debe arrancar por ACTION_START para usar el fast-start normal.
            if (TtsForegroundService.canResumePausedPage(currentPage)) {
                Intent intent = new Intent(this, TtsForegroundService.class);
                intent.setAction(TtsForegroundService.ACTION_TOGGLE);
                startService(intent);
            } else {
                startAudioFromPage(currentPage);
            }
            return;
        }

        startAudioFromPage(currentPage);
    }

    private void startAudioFromPage(final int pageToRead) {
        if (currentFile == null || pageCount <= 0) return;

        ensureNotificationPermission();
        cancelAudioPreparationTimeout();

        final int safePage = Math.max(0, Math.min(pageToRead, pageCount - 1));
        final int token = ++audioRequestToken;
        requestedAudioPage = safePage;
        requestedAudioPageConfirmed = false;

        if (currentPdfLanguage.length() > 0) {
            startAudioFromPageResolved(safePage, token);
            return;
        }

        applyPlaybackState(TtsForegroundService.STATE_PREPARING, safePage,
                "Detectando idioma del PDF...", false);
        ensurePdfLanguageForPlayback(safePage, token, new Runnable() {
            @Override
            public void run() {
                if (token != audioRequestToken || requestedAudioPage != safePage
                        || currentPdfLanguage.length() == 0) return;
                startAudioFromPageResolved(safePage, token);
            }
        });
    }

    private void startAudioFromPageResolved(final int safePage, final int token) {
        if (token != audioRequestToken || requestedAudioPage != safePage
                || currentPdfLanguage.length() == 0) return;
        applyPlaybackState(TtsForegroundService.STATE_PREPARING, safePage,
                "Preparando pagina " + (safePage + 1), false);

        String cached = textRepository == null ? null : textRepository.getCachedText(safePage);
        if (cached != null) {
            beginTtsWithText(safePage, cached, token);
            return;
        }

        String fast = textRepository == null ? null : textRepository.getFastStartText(safePage);
        if (fast != null && fast.trim().length() > 0) {
            TtsForegroundService.setPageFastText(safePage, fast);
        }

        // Once the language is resolved, keep the existing fast-start path: the
        // service may speak the short prefix while the full page finishes loading.
        beginTtsForPage(safePage, null, false, token);
    }

    private void ensurePdfLanguageForPlayback(final int page, final int requestToken,
                                              final Runnable afterResolved) {
        if (currentPdfLanguage.length() > 0) {
            if (afterResolved != null) afterResolved.run();
            return;
        }
        if (textRepository == null || currentFile == null || currentBookmarkKey == null) {
            showPdfLanguageChooser(requestToken, afterResolved);
            return;
        }

        final File file = currentFile;
        final String documentKey = currentBookmarkKey;
        final int detectionGeneration = languageDetectionToken;
        textRepository.getPageTextPriority(page, new TextRepository.TextCallback() {
            @Override
            public void onText(final String text) {
                if (requestToken != audioRequestToken
                        || !isCurrentLanguageDetection(detectionGeneration, file, documentKey)) return;
                if (currentPdfLanguage.length() > 0) {
                    if (afterResolved != null) afterResolved.run();
                    return;
                }
                final String sample = text == null ? "" : text.trim();
                if (sample.length() < 24) {
                    showPdfLanguageChooser(requestToken, afterResolved);
                    return;
                }
                try {
                    languageDetectionExecutor.execute(new Runnable() {
                        @Override
                        public void run() {
                            final PdfLanguageDetector.Result result = PdfLanguageDetector.detect(
                                    getApplicationContext(), sample.length() > 5000
                                            ? sample.substring(0, 5000) : sample);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (requestToken != audioRequestToken
                                            || !isCurrentLanguageDetection(detectionGeneration,
                                            file, documentKey)) return;
                                    if (currentPdfLanguage.length() > 0) {
                                        if (afterResolved != null) afterResolved.run();
                                        return;
                                    }
                                    if (result.isConfident()) {
                                        saveCurrentPdfLanguage(result.languageCode, result.confidence);
                                        if (afterResolved != null) afterResolved.run();
                                    } else {
                                        showPdfLanguageChooser(requestToken, afterResolved);
                                    }
                                }
                            });
                        }
                    });
                } catch (Exception ignored) {
                    showPdfLanguageChooser(requestToken, afterResolved);
                }
            }
        });
    }

    private void showPdfLanguageChooser(final int requestToken, final Runnable afterResolved) {
        if (requestToken != audioRequestToken || isFinishing()
                || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        if (currentPdfLanguage.length() > 0) {
            if (afterResolved != null) afterResolved.run();
            return;
        }
        if (pdfLanguageDialogVisible) return;
        pdfLanguageDialogVisible = true;
        final String[] codes = new String[]{UiStrings.ES, UiStrings.EN, UiStrings.PT,
                UiStrings.HI, UiStrings.ID};
        final String[] labels = new String[]{"Español", "English", "Português (Brasil)",
                "हिन्दी — Hindi", "Bahasa Indonesia"};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t("Idioma del PDF"))
                .setMessage(t("No pudimos detectar con seguridad el idioma de este PDF. Elige el idioma para leerlo."))
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        pdfLanguageDialogVisible = false;
                        if (requestToken != audioRequestToken || which < 0 || which >= codes.length) return;
                        saveCurrentPdfLanguage(codes[which], 1.0f);
                        if (afterResolved != null) afterResolved.run();
                    }
                })
                .setNegativeButton(t("Cancelar"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        pdfLanguageDialogVisible = false;
                        if (requestToken == audioRequestToken) {
                            audioRequestToken++;
                            requestedAudioPage = -1;
                            requestedAudioPageConfirmed = false;
                            applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1,
                                    "Detenido", false);
                        }
                    }
                })
                .create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                pdfLanguageDialogVisible = false;
            }
        });
        dialog.show();
        styleDialog(dialog);
    }

    private void beginTtsWithText(final int safePage, String text, final int token) {
        beginTtsForPage(safePage, text, false, token);
    }

    private void beginTtsForPage(final int safePage, String text, boolean fastOnly,
                                 final int token) {
        if (token != audioRequestToken || requestedAudioPage != safePage) return;
        cancelAudioPreparationTimeout();
        if (text != null) {
            if (fastOnly) TtsForegroundService.setPageFastText(safePage, text);
            else TtsForegroundService.setPageText(safePage, text);
        }

        Intent intent = new Intent(MainActivity.this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_START);
        intent.putExtra("title", currentTitle);
        intent.putExtra("pageOffset", safePage);
        intent.putExtra("totalPages", pageCount);
        intent.putExtra("startIndex", 0);
        intent.putExtra("rate", speechRate);
        intent.putExtra("pitch", 1.0f);
        intent.putExtra(TtsForegroundService.EXTRA_TTS_LANGUAGE, currentPdfLanguage);
        intent.putExtra(TtsForegroundService.EXTRA_TTS_REGION, appRegion);

        String availableForBridge = text;
        if (availableForBridge == null || availableForBridge.trim().length() == 0) {
            String fullCached = textRepository == null ? null : textRepository.getCachedText(safePage);
            availableForBridge = fullCached != null ? fullCached
                    : (textRepository == null ? null : textRepository.getFastStartText(safePage));
        }
        FastResumeBridge bridge = findFastResumeBridge(safePage, availableForBridge);
        if (bridge != null) {
            intent.putExtra(TtsForegroundService.EXTRA_FAST_RESUME_AUDIO, bridge.file.getAbsolutePath());
            intent.putExtra(TtsForegroundService.EXTRA_FAST_RESUME_TEXT, bridge.text);
        }

        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);

        // La precarga vecina empieza después de entregar la página actual al
        // servicio, y una nueva navegación cancela el trabajo anterior.
        applyPlaybackState(TtsForegroundService.STATE_PREPARING, safePage,
                "Iniciando pagina " + (safePage + 1), false);
        scheduleAudioNeighborPreload(safePage);
    }

    private void prepareFastResumeAudioForCurrentPage() {
        if (textRepository == null || currentFile == null || currentPage < 0) return;
        String text = textRepository.getCachedText(currentPage);
        if (text == null || text.trim().length() == 0) {
            text = textRepository.getFastStartText(currentPage);
        }
        prepareFastResumeAudioForPage(currentPage, text);
    }

    private void prepareFastResumeAudioForPage(final int page, String sourceText) {
        if (prefs == null || currentFile == null || currentBookmarkKey == null
                || currentPdfLanguage.length() == 0 || page < 0 || page != currentPage) return;
        if (playbackState == TtsForegroundService.STATE_PLAYING
                || playbackState == TtsForegroundService.STATE_PREPARING) return;

        final String bridgeText = buildFastResumeBridgeText(sourceText);
        if (bridgeText.length() < 12) return;
        final String documentKey = currentBookmarkKey;
        final float requestedRate = speechRate;
        final File finalFile = getFastResumeAudioFile();

        if (isFastResumeMetadataMatch(documentKey, page, bridgeText, requestedRate)
                && finalFile.exists() && finalFile.length() > 64L) {
            return;
        }

        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        if (!manager.isReady() || !currentPdfLanguage.equals(manager.getPreferredLanguage())
                || !manager.isPreferredLanguageAvailable()) {
            if (fastResumeWaitingForEngine) return;
            fastResumeWaitingForEngine = true;
            manager.ensureLanguage(currentPdfLanguage, appRegion, new TtsEngineManager.ReadyCallback() {
                @Override
                public void onReady(String enginePackage) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            fastResumeWaitingForEngine = false;
                            prepareFastResumeAudioForCurrentPage();
                        }
                    });
                }

                @Override
                public void onError(String message) {
                    fastResumeWaitingForEngine = false;
                }
            });
            return;
        }

        final int token = ++fastResumeSynthesisToken;
        final File dir = finalFile.getParentFile();
        if (dir != null && !dir.exists()) dir.mkdirs();
        final File tempFile = new File(dir, "fast_resume_" + token + ".tmp.wav");
        if (tempFile.exists()) tempFile.delete();

        manager.setSpeechRate(requestedRate);
        manager.setPitch(1.0f);
        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
        final String utteranceId = "FAST_RESUME_" + token + "_P" + page;
        int result = manager.synthesizeToFile(bridgeText, params, tempFile, utteranceId,
                new TtsEngineManager.FileSynthesisCallback() {
                    @Override
                    public void onCompleted() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (token != fastResumeSynthesisToken
                                        || currentBookmarkKey == null
                                        || !currentBookmarkKey.equals(documentKey)
                                        || page != currentPage) {
                                    tempFile.delete();
                                    return;
                                }
                                if (!tempFile.exists() || tempFile.length() <= 64L) {
                                    tempFile.delete();
                                    return;
                                }
                                if (finalFile.exists()) finalFile.delete();
                                boolean saved = tempFile.renameTo(finalFile);
                                if (!saved) {
                                    saved = copyFastResumeFile(tempFile, finalFile);
                                    tempFile.delete();
                                }
                                if (!saved || !finalFile.exists() || finalFile.length() <= 64L) return;
                                prefs.edit()
                                        .putString(PREF_FAST_RESUME_DOC, documentKey)
                                        .putInt(PREF_FAST_RESUME_PAGE, page)
                                        .putString(PREF_FAST_RESUME_TEXT, bridgeText)
                                        .putFloat(PREF_FAST_RESUME_RATE, requestedRate)
                                        .putString(PREF_FAST_RESUME_ENGINE,
                                                manager.getActiveEnginePackage())
                                        .putString(PREF_FAST_RESUME_LANGUAGE, currentPdfLanguage)
                                        .apply();
                            }
                        });
                    }

                    @Override
                    public void onError(String message) {
                        tempFile.delete();
                    }
                });
        if (result == TextToSpeech.ERROR) tempFile.delete();
    }

    private FastResumeBridge findFastResumeBridge(int page, String availableText) {
        if (prefs == null || currentBookmarkKey == null || page < 0) return null;
        File file = getFastResumeAudioFile();
        if (!file.exists() || file.length() <= 64L) return null;
        String document = prefs.getString(PREF_FAST_RESUME_DOC, "");
        int storedPage = prefs.getInt(PREF_FAST_RESUME_PAGE, -1);
        String bridgeText = prefs.getString(PREF_FAST_RESUME_TEXT, "");
        float storedRate = prefs.getFloat(PREF_FAST_RESUME_RATE, -1f);
        String storedEngine = prefs.getString(PREF_FAST_RESUME_ENGINE, "");
        String storedLanguage = PdfLanguageDetector.normalizeCode(
                prefs.getString(PREF_FAST_RESUME_LANGUAGE, ""));
        if (!currentBookmarkKey.equals(document) || storedPage != page
                || bridgeText == null || bridgeText.trim().length() == 0
                || Math.abs(storedRate - speechRate) > 0.01f
                || (currentPdfLanguage.length() > 0 && !currentPdfLanguage.equals(storedLanguage))) return null;
        TtsEngineManager manager = TtsEngineManager.getInstance(this);
        String activeEngine = manager.getActiveEnginePackage();
        if (manager.isReady() && storedEngine != null && storedEngine.length() > 0
                && activeEngine != null && activeEngine.length() > 0
                && !storedEngine.equals(activeEngine)) return null;

        String available = normalizeFastResumeText(availableText);
        String bridge = normalizeFastResumeText(bridgeText);
        if (available.length() > 0) {
            boolean samePrefix = available.startsWith(bridge) || bridge.startsWith(available);
            if (!samePrefix) return null;
        }
        return new FastResumeBridge(file, bridgeText);
    }

    private File getFastResumeAudioFile() {
        File dir = new File(getFilesDir(), "fast_resume_audio");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, FAST_RESUME_FILE_NAME);
    }

    private boolean isFastResumeMetadataMatch(String documentKey, int page,
                                               String bridgeText, float rate) {
        if (prefs == null) return false;
        return documentKey.equals(prefs.getString(PREF_FAST_RESUME_DOC, ""))
                && page == prefs.getInt(PREF_FAST_RESUME_PAGE, -1)
                && bridgeText.equals(prefs.getString(PREF_FAST_RESUME_TEXT, ""))
                && Math.abs(rate - prefs.getFloat(PREF_FAST_RESUME_RATE, -1f)) <= 0.01f
                && (currentPdfLanguage.length() == 0 || currentPdfLanguage.equals(
                PdfLanguageDetector.normalizeCode(prefs.getString(PREF_FAST_RESUME_LANGUAGE, ""))));
    }

    private String buildFastResumeBridgeText(String sourceText) {
        String text = normalizeFastResumeText(sourceText);
        if (text.length() <= FAST_RESUME_TARGET_CHARS) return text;
        int maximum = Math.min(FAST_RESUME_TARGET_CHARS, text.length());
        int minimum = Math.min(FAST_RESUME_MIN_CHARS, maximum);
        for (int i = minimum; i < maximum; i++) {
            char c = text.charAt(i);
            if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':') {
                return text.substring(0, i + 1).trim();
            }
        }
        for (int i = maximum - 1; i >= minimum; i--) {
            if (Character.isWhitespace(text.charAt(i))) {
                return text.substring(0, i).trim();
            }
        }
        return text.substring(0, maximum).trim();
    }

    private String normalizeFastResumeText(String value) {
        if (value == null) return "";
        String text = value.replace('\u00A0', ' ').replace('\r', ' ').replace('\n', ' ');
        text = text.replaceAll("\\s+", " ");
        return text.trim();
    }

    private boolean copyFastResumeFile(File source, File target) {
        FileInputStream input = null;
        FileOutputStream output = null;
        try {
            input = new FileInputStream(source);
            output = new FileOutputStream(target);
            byte[] buffer = new byte[16384];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            output.flush();
            return true;
        } catch (Exception ignored) {
            if (target.exists()) target.delete();
            return false;
        } finally {
            if (input != null) {
                try { input.close(); } catch (Exception ignored) {}
            }
            if (output != null) {
                try { output.close(); } catch (Exception ignored) {}
            }
        }
    }

    private void failAudioPreparation(String message) {
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = -1;
        requestedAudioPageConfirmed = false;
        applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1, message, false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
        Toast.makeText(this, t(message), Toast.LENGTH_LONG).show();
    }

    private void cancelAudioPreparation() {
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = -1;
        requestedAudioPageConfirmed = false;
        applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1, "Detenido", false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
    }

    private void cancelAudioPreparationTimeout() {
        if (audioStartTimeout != null) {
            audioStartHandler.removeCallbacks(audioStartTimeout);
            audioStartTimeout = null;
        }
    }

    private void stopAudioOnly() {
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = -1;
        requestedAudioPageConfirmed = false;
        applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1, "Detenido", false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
    }

    private void showGoto() {
        if (pageCount <= 0) return;

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setHint(t("Página 1 - " + pageCount));

        new AlertDialog.Builder(this)
                .setTitle(t("Ir a página"))
                .setView(input)
                .setPositiveButton(t("Ir"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            int p = Integer.parseInt(input.getText().toString()) - 1;
                            p = Math.max(0, Math.min(p, pageCount - 1));
                            requestManualPageChange(p);
                        } catch (Exception ignored) {
                        }
                    }
                })
                .setNegativeButton(t("Cancelar"), null)
                .show();
    }

    private String buildBookmarkKey(File file) {
        if (file == null) return null;
        long hash = 1469598103934665603L;
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(file, "r");
            long length = raf.length();
            byte[] buffer = new byte[4096];
            int read = raf.read(buffer);
            for (int i = 0; i < read; i++) {
                hash ^= (buffer[i] & 0xFF);
                hash *= 1099511628211L;
            }
            if (length > buffer.length) {
                raf.seek(Math.max(0L, length - buffer.length));
                read = raf.read(buffer);
                for (int i = 0; i < read; i++) {
                    hash ^= (buffer[i] & 0xFF);
                    hash *= 1099511628211L;
                }
            }
            String identity = length + "|" + Long.toHexString(hash);
            return "pdf_bookmarks_v1_" + Integer.toHexString(identity.hashCode()) + "_" + Long.toHexString(hash);
        } catch (Exception e) {
            return "pdf_bookmarks_v1_" + Integer.toHexString((file.getName() + "|" + file.length()).hashCode());
        } finally {
            if (raf != null) {
                try {
                    raf.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private ArrayList<Integer> getBookmarkPages() {
        ArrayList<Integer> pages = new ArrayList<Integer>();
        if (prefs == null || currentBookmarkKey == null) return pages;
        java.util.Set<String> stored = prefs.getStringSet(currentBookmarkKey, null);
        if (stored == null || stored.isEmpty()) return pages;
        for (String value : stored) {
            try {
                int page = Integer.parseInt(value);
                if (page >= 0 && (pageCount <= 0 || page < pageCount)) pages.add(page);
            } catch (Exception ignored) {
            }
        }
        Collections.sort(pages);
        return pages;
    }

    private boolean isBookmarked(int page) {
        if (prefs == null || currentBookmarkKey == null || page < 0) return false;
        java.util.Set<String> stored = prefs.getStringSet(currentBookmarkKey, null);
        return stored != null && stored.contains(String.valueOf(page));
    }

    private void setBookmarked(int page, boolean bookmarked) {
        if (prefs == null || currentBookmarkKey == null || page < 0) return;
        java.util.Set<String> stored = prefs.getStringSet(currentBookmarkKey, null);
        HashSet<String> updated = stored == null
                ? new HashSet<String>()
                : new HashSet<String>(stored);
        String value = String.valueOf(page);
        if (bookmarked) updated.add(value);
        else updated.remove(value);
        prefs.edit().putStringSet(currentBookmarkKey, updated).apply();
        updateBookmarkButton();
    }

    private void updateBookmarkButton() {
        if (bookmarkButton == null) return;
        boolean ready = currentFile != null && pageCount > 0;
        bookmarkButton.setEnabled(ready);
        bookmarkButton.setAlpha(ready ? 1.0f : 0.45f);
        boolean marked = ready && isBookmarked(currentPage);
        bookmarkButton.setText(marked ? "★" : "☆");
        bookmarkButton.setContentDescription(marked
                ? t("Marcadores. Página actual guardada")
                : t("Marcadores"));
    }

    private void showBookmarksDialog() {
        if (currentFile == null || pageCount <= 0 || currentBookmarkKey == null) {
            Toast.makeText(this, t("Abre un PDF primero"), Toast.LENGTH_SHORT).show();
            return;
        }

        final AlertDialog[] holder = new AlertDialog[1];
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(8), dp(14), dp(8));

        final int currentBookmarkPage = currentPage;
        final boolean currentMarked = isBookmarked(currentBookmarkPage);
        Button currentAction = makeButton(currentMarked
                ? "★ Quitar página " + (currentBookmarkPage + 1)
                : "☆ Guardar página " + (currentBookmarkPage + 1));
        currentAction.setTextSize(14);
        currentAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setBookmarked(currentBookmarkPage, !currentMarked);
                if (holder[0] != null) holder[0].dismiss();
                showBookmarksDialog();
            }
        });
        content.addView(currentAction, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        ArrayList<Integer> pages = getBookmarkPages();
        if (pages.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(t("Todavía no hay páginas guardadas"));
            empty.setTextSize(14);
            empty.setTextColor(darkTheme ? Color.LTGRAY : Color.DKGRAY);
            empty.setGravity(Gravity.CENTER);
            content.addView(empty, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(64)));
        } else {
            for (final int page : pages) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);

                Button jump = makeButton("Página " + (page + 1));
                jump.setTextSize(14);
                jump.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (holder[0] != null) holder[0].dismiss();
                        requestManualPageChange(page);
                    }
                });

                Button remove = makeButton("✕");
                remove.setTextSize(18);
                remove.setContentDescription(t("Eliminar marcador de página " + (page + 1)));
                remove.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        setBookmarked(page, false);
                        if (holder[0] != null) holder[0].dismiss();
                        showBookmarksDialog();
                    }
                });

                row.addView(jump, new LinearLayout.LayoutParams(0, dp(48), 1));
                row.addView(remove, new LinearLayout.LayoutParams(dp(52), dp(48)));
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
                rowLp.topMargin = dp(4);
                content.addView(row, rowLp);
            }
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t("Marcadores"))
                .setView(scroll)
                .setNegativeButton(t("Cerrar"), null)
                .create();
        holder[0] = dialog;
        dialog.show();
    }

    private void updatePageLabel() {
        if (pageCount <= 0) pageView.setText(t("0/0"));
        else pageView.setText((currentPage + 1) + "/" + pageCount);
        updateBookmarkButton();
    }

    private void applyPlaybackState(int state, int readingPage, String message, boolean fromBroadcast) {
        if ((state == TtsForegroundService.STATE_PREPARING
                || state == TtsForegroundService.STATE_PLAYING)
                && requestedAudioPage >= 0 && readingPage >= 0
                && readingPage != requestedAudioPage
                && !requestedAudioPageConfirmed) {
            // Ignora estados antiguos mientras el servicio confirma la última
            // página elegida por el usuario.
            return;
        }

        playbackState = state;
        if (message == null) message = "";

        if (state == TtsForegroundService.STATE_PREPARING) {
            audioPreparing = true;
            audioStarted = false;
            audioPaused = false;
            if (playButton != null) playButton.setText(t("Ⅱ"));
        } else if (state == TtsForegroundService.STATE_PLAYING) {
            cancelAudioPreparationTimeout();
            audioPreparing = false;
            audioStarted = true;
            audioPaused = false;
            if (playButton != null) playButton.setText(t("Ⅱ"));
        } else if (state == TtsForegroundService.STATE_PAUSED) {
            cancelAudioPreparationTimeout();
            audioPreparing = false;
            audioStarted = true;
            audioPaused = true;
            if (playButton != null) playButton.setText(t("▶"));
            if (readingPage == currentPage) prepareFastResumeAudioForCurrentPage();
        } else {
            cancelAudioPreparationTimeout();
            audioPreparing = false;
            audioStarted = false;
            audioPaused = false;
            requestedAudioPage = -1;
            requestedAudioPageConfirmed = false;
            if (playButton != null) playButton.setText(t("▶"));
        }

        if (state == TtsForegroundService.STATE_ERROR && fromBroadcast) {
            audioRequestToken++;
            requestedAudioPage = -1;
            requestedAudioPageConfirmed = false;
        }
        if (state == TtsForegroundService.STATE_PLAYING || state == TtsForegroundService.STATE_PREPARING || state == TtsForegroundService.STATE_PAUSED) {
            if (readingMarkerEnabled) loadSelectionForPage(Math.max(0, readingPage));
        } else if (pdfView != null) {
            pdfView.clearReadingMarker();
        }

        if (state == TtsForegroundService.STATE_ERROR && fromBroadcast
                && message.length() > 0 && !message.equals(lastPlaybackError)) {
            lastPlaybackError = message;
            if (message.startsWith(TtsForegroundService.ERROR_MISSING_VOICE_PREFIX)) {
                String language = message.substring(
                        TtsForegroundService.ERROR_MISSING_VOICE_PREFIX.length());
                showMissingVoiceDialog(language);
            } else {
                Toast.makeText(this, t(message), Toast.LENGTH_LONG).show();
            }
        } else if (state != TtsForegroundService.STATE_ERROR) {
            lastPlaybackError = "";
        }

        if ((state == TtsForegroundService.STATE_PREPARING
                || state == TtsForegroundService.STATE_PLAYING)
                && requestedAudioPage >= 0 && readingPage >= 0) {
            if (readingPage != requestedAudioPage) {
                if (!requestedAudioPageConfirmed) {
                    return;
                }
                // La página solicitada ya fue confirmada por el servicio. Un
                // cambio posterior puede ser el salto silencioso de una ilustración.
                requestedAudioPage = -1;
                requestedAudioPageConfirmed = false;
            } else if (fromBroadcast) {
                requestedAudioPageConfirmed = true;
                if (state == TtsForegroundService.STATE_PLAYING) {
                    requestedAudioPage = -1;
                    requestedAudioPageConfirmed = false;
                }
            }
        }

        boolean readerOwnsPage = state == TtsForegroundService.STATE_PREPARING
                || state == TtsForegroundService.STATE_PLAYING;
        if (!readerOwnsPage || readingPage < 0 || currentFile == null || pageCount <= 0 || pdfView == null) {
            return;
        }

        final int safePage = Math.max(0, Math.min(readingPage, pageCount - 1));
        if (safePage == currentPage) return;

        restartAudioAfterRender = false;
        // El lector ya cambió de página: prepara únicamente la visible con
        // prioridad y una ventana pequeña. Evita indexar ocho páginas mientras
        // intenta empezar la siguiente frase.
        primeAudioPageForPlayback(safePage);
        currentPage = safePage;
        updatePageLabel();
        pdfView.showPage(safePage);
    }

    private void syncVisiblePageWithReader() {
        if (prefs == null) return;

        int state = prefs.getInt(PREF_TTS_STATE, -1);
        if (state < 0) {
            boolean active = prefs.getBoolean(PREF_TTS_ACTIVE, false);
            boolean paused = prefs.getBoolean(PREF_TTS_PAUSED, false);
            state = !active ? TtsForegroundService.STATE_STOPPED
                    : (paused ? TtsForegroundService.STATE_PAUSED : TtsForegroundService.STATE_PLAYING);
        }
        int readingPage = prefs.getInt(PREF_TTS_CURRENT_PAGE, -1);
        String message = prefs.getString(PREF_TTS_MESSAGE, "");
        applyPlaybackState(state, readingPage, message, false);
    }

    private void saveProgress() {
        prefs.edit().putInt("last_page", currentPage).putString("last_title", currentTitle).apply();
    }

    /**
     * Scales programmatic UI geometry for common phone sizes without changing
     * PDF rendering, TTS, playback or stored coordinates. Android dp still
     * handles density; this extra factor only compensates for very small/large
     * phone viewports.
     */
    private float responsiveUiScale() {
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        float density = Math.max(0.1f, metrics.density);
        float widthDp = metrics.widthPixels / density;
        float heightDp = metrics.heightPixels / density;
        float widthScale = widthDp / 360f;
        float heightScale = heightDp / 740f;
        float scale = Math.min(widthScale, heightScale);
        return Math.max(0.88f, Math.min(1.08f, scale));
    }

    private int uiDp(int value) {
        return Math.max(1, Math.round(dp(value) * responsiveUiScale()));
    }

    private float uiSp(float value) {
        float geometryScale = responsiveUiScale();
        float textScale = 1f + ((geometryScale - 1f) * 0.40f);
        textScale = Math.max(0.95f, Math.min(1.04f, textScale));
        return value * textScale;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        if (onboardingMode) {
            if (onboardingStep == 2) {
                showOnboardingWelcome();
            } else {
                super.onBackPressed();
            }
            return;
        }
        if (imageViewerMode) {
            closeFullscreenImageViewer();
            return;
        }
        if (libraryMode) {
            closeFileLibrary();
            return;
        }
        if (settingsMode) {
            if (settingsSubscreen == 2 || settingsSubscreen == 3) {
                showLanguageRegionSettingsScreen();
            } else if (settingsSubscreen == 1 || settingsSubscreen == 4) {
                buildSettingsScreen();
            } else {
                closeSettings();
            }
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        pdfOpenRequestToken++;
        pageWorkToken++;
        if (pageWorkRunnable != null) pageWorkHandler.removeCallbacks(pageWorkRunnable);
        if (audioNeighborPreloadRunnable != null) {
            audioStartHandler.removeCallbacks(audioNeighborPreloadRunnable);
            audioNeighborPreloadRunnable = null;
        }
        if (audioIdleIndexRunnable != null) {
            audioStartHandler.removeCallbacks(audioIdleIndexRunnable);
            audioIdleIndexRunnable = null;
        }
        imageExportExecutor.shutdownNow();
        audioExportSessionToken++;
        clearActiveExportState(true);
        audioExportExecutor.shutdownNow();
        imageDecodeExecutor.shutdownNow();
        languageDetectionToken++;
        languageDetectionExecutor.shutdownNow();
        if (imagePager != null) {
            imagePager.setAdapter(null);
            imagePager = null;
        }
        if (imagePagerAdapter != null) {
            imagePagerAdapter.release();
            imagePagerAdapter = null;
        }
        if (imageViewerBitmap != null && !imageViewerBitmap.isRecycled()) {
            imageViewerBitmap.recycle();
            imageViewerBitmap = null;
        }
        cancelAudioPreparationTimeout();
        cancelTtsWarmup();
        stopFilePreview();
        stopPageSyncLoop();
        cancelPendingReadingMarker();
        unregisterPlaybackReceiver();
        super.onDestroy();
        saveProgress();
        // Si el audio sigue activo, el servicio conserva este repositorio para obtener
        // las paginas siguientes con la pantalla apagada.
        if (!prefs.getBoolean(PREF_TTS_ACTIVE, false) && textRepository != null) {
            textRepository.close();
        }
        if (selectionRepository != null) selectionRepository.close();
        if (exportTts != null) {
            try { exportTts.shutdown(); } catch (Exception ignored) {}
            exportTts = null;
        }
        exportTtsReady = false;
    }
}
