package com.geozeta.pdfaudio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.pdf.PdfDocument;
import android.media.MediaPlayer;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.LruCache;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.GridLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.graphics.Typeface;
import android.widget.Toast;
import android.view.View;
import android.view.WindowManager;
import android.content.DialogInterface;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.text.SimpleDateFormat;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_OPEN_PDF = 1001;
    private static final String PREF_TTS_ACTIVE = "tts_service_active";
    private static final String PREF_TTS_PAUSED = "tts_service_paused";
    private static final String PREF_TTS_CURRENT_PAGE = "tts_current_page";
    private static final String PREF_TTS_STATE = "tts_service_state";
    private static final String PREF_TTS_MESSAGE = "tts_service_message";
    private static final String PREF_AUDIO_STATE_REPAIRED_V69 = "audio_state_repaired_v69";
    private static final String PREF_MARK_STYLE = "mark_style";
    private static final String PREF_MARK_STYLE_V72_MIGRATED = "mark_style_v72_migrated";
    private static final String PREF_MARK_COLORS_V72_MIGRATED = "mark_colors_v72_migrated";
    private static final String PREF_MARK_THICKNESS = "mark_thickness_level";
    private static final String PREF_UNDERLINE_COLOR = "underline_color_index";
    private static final String PREF_HIGHLIGHT_COLOR = "highlight_color_index";
    private static final String PREF_CUSTOM_UNDERLINE_COLOR = "custom_underline_color";
    private static final String PREF_CUSTOM_HIGHLIGHT_COLOR = "custom_highlight_color";
    private static final String PREF_USE_CUSTOM_UNDERLINE_COLOR = "use_custom_underline_color";
    private static final String PREF_USE_CUSTOM_HIGHLIGHT_COLOR = "use_custom_highlight_color";
    private static final String PREF_RULE_COLOR = "rule_color_index";
    private static final String PREF_CUSTOM_RULE_COLOR = "custom_rule_color";
    private static final String PREF_USE_CUSTOM_RULE_COLOR = "use_custom_rule_color";
    private static final String PREF_READING_MARKER_ENABLED = "reading_marker_enabled";
    private static final String PREF_READING_MARKER_COLOR = "reading_marker_color_index";
    private static final String PREF_CUSTOM_READING_MARKER_COLOR = "custom_reading_marker_color";
    private static final String PREF_USE_CUSTOM_READING_MARKER_COLOR = "use_custom_reading_marker_color";
    private static final String PREF_READING_MARKER_V81_RESET = "reading_marker_v81_reset";
    private static final String PREF_READING_BRIGHTNESS = "reading_brightness";
    private static final String PREF_IMAGE_LIBRARY_GRID = "image_library_grid";
    private static final int QUICK_MARK_SLOT_COUNT = 4;

    private static final int MARK_STYLE_UNDERLINE_FINE = 0;
    private static final int MARK_STYLE_UNDERLINE_DOUBLE = 1;
    private static final int MARK_STYLE_UNDERLINE_WAVY = 2;
    private static final int MARK_STYLE_UNDERLINE_DOTTED = 3;
    private static final int MARK_STYLE_HIGHLIGHT_SOFT = 4;
    private static final int MARK_STYLE_HIGHLIGHT_INTENSE = 5;
    private static final int MARK_STYLE_TEXT_BOX = 6;

    private static final int COLOR_TARGET_UNDERLINE = 0;
    private static final int COLOR_TARGET_HIGHLIGHT = 1;
    private static final int COLOR_TARGET_RULE = 2;
    private static final int COLOR_TARGET_READING_MARKER = 3;

    private static final int LIBRARY_AUDIO = 0;
    private static final int LIBRARY_IMAGE = 1;
    private static final int LIBRARY_PDF = 2;

    // Colores mostrados como muestras reales. Sus nombres no aparecen en la interfaz.
    private static final int[] MARK_COLOR_RGB = new int[]{
            0x00FFD400, 0x00EF4444, 0x00EC4899, 0x003B82F6,
            0x0022C55E, 0x00F97316, 0x00A855F7, 0x0006B6D4,
            0x0084CC16, 0x0092400E, 0x00111111, 0x00FFFFFF
    };

    private PdfPageView pdfView;
    private TextRepository textRepository;
    private SelectionTextRepository selectionRepository;
    private TextView titleView;
    private HorizontalScrollView titleScroller;
    private TextView pageView;
    private Button playButton;
    private File currentFile;
    private String currentTitle;
    private int currentPage;
    private int pageCount;
    private boolean audioStarted;
    private boolean audioPaused;
    private boolean audioPreparing;
    private boolean markMode;
    private int markStyle;
    private int underlineColorIndex;
    private int highlightColorIndex;
    private int customUnderlineRgb;
    private int customHighlightRgb;
    private boolean useCustomUnderlineColor;
    private boolean useCustomHighlightColor;
    private int markThicknessLevel;
    private float readingBrightness;
    private Button markButton;
    private Button colorButton;
    private Button rulesButton;
    private TextView readingMarkerSettingsSwatch;
    private boolean rulesEnabled;
    private int ruleColorIndex;
    private int customRuleRgb;
    private boolean useCustomRuleColor;
    private boolean readingMarkerEnabled;
    private int readingMarkerColorIndex;
    private int customReadingMarkerRgb;
    private boolean useCustomReadingMarkerColor;
    private int pendingReadingPage = -1;
    private String pendingReadingChunk = "";
    private int pendingReadingChunkIndex = -1;
    private int pendingReadingRangeStart;
    private int pendingReadingRangeEnd;
    private int loadedSelectionPage = -1;
    private int loadingSelectionPage = -1;
    private float ruleTop;
    private float ruleBottom;
    private boolean restartAudioAfterRender;
    private int requestedAudioPage;
    private boolean requestedAudioPageConfirmed;
    private int audioRequestToken;
    private boolean darkTheme;
    private float speechRate;
    private boolean settingsMode;
    private boolean settingsNeedsMainRebuild;
    private LinearLayout root;
    private FrameLayout screenHost;
    private View settingsOverlay;
    private View imageViewerOverlay;
    private TextToSpeech exportTts;
    private SharedPreferences prefs;
    private ScrollView settingsScrollView;
    private int settingsScrollY;
    private int exportStartPage = -1;
    private int exportEndPage = -1;
    private int exportCurrentPage = -1;
    private int exportSavedCount;
    private File exportAudioDir;
    private String exportAudioBase;
    private File lastExportedAudioFile;
    private boolean libraryMode;
    private boolean imageLibraryGridMode;
    private boolean libraryReturnToSettings;
    private int libraryShowingType = LIBRARY_AUDIO;
    private boolean imageViewerMode;
    private boolean imageViewerReturnToLibrary;
    private boolean imageViewerReturnToSettings;
    private Bitmap imageViewerBitmap;
    private ViewPager2 imagePager;
    private ImagePagerAdapter imagePagerAdapter;
    private MediaPlayer previewPlayer;
    private Handler previewHandler = new Handler(Looper.getMainLooper());
    private Runnable previewProgressTask;
    private final Handler readingMarkerHandler = new Handler(Looper.getMainLooper());
    private Runnable readingMarkerUpdateTask;
    private boolean readingMarkerUpdateScheduled;
    private Handler pageSyncHandler;
    private Runnable pageSyncRunnable;
    private BroadcastReceiver playbackReceiver;
    private boolean receiverRegistered;
    private boolean notificationWarningShown;
    private final Handler audioStartHandler = new Handler(Looper.getMainLooper());
    private Runnable audioNeighborPreloadRunnable;
    private final Handler pageWorkHandler = new Handler(Looper.getMainLooper());
    private Runnable pageWorkRunnable;
    private int pageWorkToken;
    private final ExecutorService imageExportExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService imageDecodeExecutor = Executors.newFixedThreadPool(2);
    private final LruCache<String, Bitmap> imageViewerCache = new LruCache<String, Bitmap>(48 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            if (value == null) return 0;
            return Math.max(1, value.getByteCount() / 1024);
        }
    };
    private final LruCache<String, Bitmap> imagePreviewCache = new LruCache<String, Bitmap>(12 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            if (value == null) return 0;
            return Math.max(1, value.getByteCount() / 1024);
        }
    };
    private final HashSet<String> imageDecodeInFlight = new HashSet<String>();
    private Runnable audioStartTimeout;
    private int playbackState = TtsForegroundService.STATE_STOPPED;
    private String lastPlaybackError = "";
    private boolean fullIndexRequested;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        currentTitle = "PDF a Audio";
        prefs = getSharedPreferences("pdf_audio_prefs", MODE_PRIVATE);
        darkTheme = prefs.getBoolean("dark_theme", true);
        speechRate = prefs.getFloat("speech_rate", 1.0f);
        int storedMarkStyle = prefs.getInt(PREF_MARK_STYLE, MARK_STYLE_UNDERLINE_FINE);
        if (!prefs.getBoolean(PREF_MARK_STYLE_V72_MIGRATED, false)) {
            // V71 usaba 0=subrayado y 1=resaltado. Se conserva la eleccion al migrar.
            storedMarkStyle = storedMarkStyle == 1 ? MARK_STYLE_HIGHLIGHT_SOFT : MARK_STYLE_UNDERLINE_FINE;
            prefs.edit()
                    .putInt(PREF_MARK_STYLE, storedMarkStyle)
                    .putBoolean(PREF_MARK_STYLE_V72_MIGRATED, true)
                    .apply();
        }
        markStyle = safeMarkStyle(storedMarkStyle);
        if (storedMarkStyle == MARK_STYLE_TEXT_BOX) {
            markStyle = MARK_STYLE_UNDERLINE_FINE;
            prefs.edit().putInt(PREF_MARK_STYLE, markStyle).apply();
        }
        markThicknessLevel = safeThicknessLevel(prefs.getInt(PREF_MARK_THICKNESS, 1));

        int storedUnderlineColor = prefs.getInt(PREF_UNDERLINE_COLOR, 0);
        int storedHighlightColor = prefs.getInt(PREF_HIGHLIGHT_COLOR, 0);
        if (!prefs.getBoolean(PREF_MARK_COLORS_V72_MIGRATED, false)) {
            storedUnderlineColor = migrateV71ColorIndex(storedUnderlineColor);
            storedHighlightColor = migrateV71ColorIndex(storedHighlightColor);
            prefs.edit()
                    .putInt(PREF_UNDERLINE_COLOR, storedUnderlineColor)
                    .putInt(PREF_HIGHLIGHT_COLOR, storedHighlightColor)
                    .putBoolean(PREF_MARK_COLORS_V72_MIGRATED, true)
                    .apply();
        }
        underlineColorIndex = safeMarkColorIndex(storedUnderlineColor);
        highlightColorIndex = safeMarkColorIndex(storedHighlightColor);
        customUnderlineRgb = prefs.getInt(PREF_CUSTOM_UNDERLINE_COLOR, 0x00FFD400) & 0x00FFFFFF;
        customHighlightRgb = prefs.getInt(PREF_CUSTOM_HIGHLIGHT_COLOR, 0x00FFD400) & 0x00FFFFFF;
        useCustomUnderlineColor = prefs.getBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, false);
        useCustomHighlightColor = prefs.getBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, false);
        ruleColorIndex = safeMarkColorIndex(prefs.getInt(PREF_RULE_COLOR, 3));
        customRuleRgb = prefs.getInt(PREF_CUSTOM_RULE_COLOR, 0x003B82F6) & 0x00FFFFFF;
        useCustomRuleColor = prefs.getBoolean(PREF_USE_CUSTOM_RULE_COLOR, false);
        readingMarkerEnabled = prefs.getBoolean(PREF_READING_MARKER_ENABLED, false);
        if (!prefs.getBoolean(PREF_READING_MARKER_V81_RESET, false)) {
            readingMarkerEnabled = false;
            prefs.edit().putBoolean(PREF_READING_MARKER_ENABLED, false)
                    .putBoolean(PREF_READING_MARKER_V81_RESET, true).apply();
        }
        readingMarkerColorIndex = safeMarkColorIndex(prefs.getInt(PREF_READING_MARKER_COLOR, 3));
        customReadingMarkerRgb = prefs.getInt(PREF_CUSTOM_READING_MARKER_COLOR, 0x003B82F6) & 0x00FFFFFF;
        useCustomReadingMarkerColor = prefs.getBoolean(PREF_USE_CUSTOM_READING_MARKER_COLOR, false);
        readingBrightness = prefs.getFloat(PREF_READING_BRIGHTNESS, -1f);
        imageLibraryGridMode = prefs.getBoolean(PREF_IMAGE_LIBRARY_GRID, true);
        applyReadingBrightness();
        repairBrokenPlaybackStateOnce();
        setupPlaybackSync();
        textRepository = new TextRepository(this);
        selectionRepository = new SelectionTextRepository(this);
        TtsForegroundService.setPageProvider(new TtsForegroundService.PageProvider() {
            @Override
            public void requestPageText(final int page, final TtsForegroundService.PageTextCallback callback) {
                textRepository.getPageTextPriority(page, new TextRepository.TextCallback() {
                    @Override
                    public void onText(String text) {
                        callback.onText(text);
                    }
                });
            }
        });
        buildUi();
        warmUpAudioEngine();

        ensureNotificationPermission();

        File last = new File(getFilesDir(), "last.pdf");
        if (last.exists()) {
            openLocalPdf(last, prefs.getString("last_title", "PDF guardado"), true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerPlaybackReceiver();
        startPageSyncLoop();
        syncVisiblePageWithReader();
    }

    @Override
    protected void onPause() {
        stopPageSyncLoop();
        cancelPendingReadingMarker();
        unregisterPlaybackReceiver();
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        syncVisiblePageWithReader();
    }

    private void setupPlaybackSync() {
        pageSyncHandler = new Handler(Looper.getMainLooper());
        pageSyncRunnable = new Runnable() {
            @Override
            public void run() {
                syncVisiblePageWithReader();
                if (pageSyncHandler != null) {
                    pageSyncHandler.postDelayed(this, 700);
                }
            }
        };
        playbackReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !TtsForegroundService.ACTION_PAGE_CHANGED.equals(intent.getAction())) return;
                int state = intent.getIntExtra(TtsForegroundService.EXTRA_STATE,
                        TtsForegroundService.STATE_STOPPED);
                int page = intent.getIntExtra(TtsForegroundService.EXTRA_PAGE, -1);
                String message = intent.getStringExtra(TtsForegroundService.EXTRA_MESSAGE);
                String chunk = intent.getStringExtra(TtsForegroundService.EXTRA_CHUNK_TEXT);
                boolean rangeOnlyUpdate = chunk != null && chunk.length() > 0
                        && state == playbackState && (page < 0 || page == currentPage);
                if (!rangeOnlyUpdate) {
                    applyPlaybackState(state, page, message, true);
                }
                if (readingMarkerEnabled && chunk != null && chunk.length() > 0) {
                    pendingReadingPage = page;
                    pendingReadingChunk = chunk;
                    pendingReadingChunkIndex = intent.getIntExtra(TtsForegroundService.EXTRA_CHUNK_INDEX, 0);
                    pendingReadingRangeStart = intent.getIntExtra(TtsForegroundService.EXTRA_RANGE_START, 0);
                    pendingReadingRangeEnd = intent.getIntExtra(TtsForegroundService.EXTRA_RANGE_END, 1);
                    schedulePendingReadingMarker();
                }
            }
        };
    }

    private void registerPlaybackReceiver() {
        if (receiverRegistered || playbackReceiver == null) return;
        IntentFilter filter = new IntentFilter(TtsForegroundService.ACTION_PAGE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(playbackReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(playbackReceiver, filter);
        }
        receiverRegistered = true;
    }

    private void unregisterPlaybackReceiver() {
        if (!receiverRegistered || playbackReceiver == null) return;
        try {
            unregisterReceiver(playbackReceiver);
        } catch (Exception ignored) {
        }
        receiverRegistered = false;
    }

    private void startPageSyncLoop() {
        if (pageSyncHandler == null || pageSyncRunnable == null) return;
        pageSyncHandler.removeCallbacks(pageSyncRunnable);
        pageSyncHandler.postDelayed(pageSyncRunnable, 700);
    }

    private void stopPageSyncLoop() {
        if (pageSyncHandler != null && pageSyncRunnable != null) {
            pageSyncHandler.removeCallbacks(pageSyncRunnable);
        }
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33) return;
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return;

        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 33);
        if (!notificationWarningShown) {
            notificationWarningShown = true;
            Toast.makeText(this, "Acepta el permiso de notificaciones para ver los controles del audio", Toast.LENGTH_LONG).show();
        }
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(12, 12, 12, 8);
        top.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        Button openButton = makeButton("Abrir");
        
openButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        choosePdf();
    }
});

        titleScroller = new HorizontalScrollView(this);
        titleScroller.setHorizontalScrollBarEnabled(false);
        titleScroller.setFillViewport(false);
        titleScroller.setOverScrollMode(View.OVER_SCROLL_NEVER);
        titleScroller.setClipToPadding(false);
        titleScroller.setPadding(0, 0, dp(8), 0);

        titleView = new TextView(this);
        titleView.setText("PDF a Audio");
        titleView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        titleView.setTextSize(18);
        titleView.setSingleLine(true);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        titleView.setPadding(0, 0, dp(20), 0);
        titleView.setHorizontallyScrolling(true);
        titleScroller.addView(titleView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, dp(48)));

        pageView = new TextView(this);
        pageView.setText("0/0");
        pageView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        pageView.setTextSize(15);
        pageView.setSingleLine(true);
        pageView.setGravity(Gravity.CENTER);

        Button gotoButton = makeButton("#");
        
gotoButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        showGoto();
    }
});

        Button filesButton = makeButton("📁");
        filesButton.setTextSize(22);
        filesButton.setContentDescription("Mis archivos");
        filesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(true);
            }
        });

        rulesButton = makeButton("Reglas");
        rulesButton.setTextSize(12);
        rulesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleRules();
            }
        });
        rulesButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showUtilityColorDialog(COLOR_TARGET_RULE, "Color de las reglas");
                return true;
            }
        });

        top.addView(openButton, new LinearLayout.LayoutParams(dp(72), dp(48)));
        top.addView(titleScroller, new LinearLayout.LayoutParams(0, dp(48), 1));
        top.addView(pageView, new LinearLayout.LayoutParams(dp(68), dp(48)));
        top.addView(rulesButton, new LinearLayout.LayoutParams(dp(72), dp(48)));
        top.addView(filesButton, new LinearLayout.LayoutParams(dp(48), dp(48)));
        top.addView(gotoButton, new LinearLayout.LayoutParams(dp(44), dp(48)));

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(getPdfWorkspaceColor());
        pdfView = new PdfPageView(this);
        pdfView.setPageChangeListener(new PdfPageView.PageChangeListener() {
            @Override
            public void onPageRendered(final int pageIndex, int total) {
                currentPage = pageIndex;
                pageCount = total;
                updatePageLabel();
                saveProgress();

                // El render visible termina primero. El texto, las coordenadas y
                // la precarga se agrupan y se retrasan unos milisegundos para que
                // varios toques seguidos no bloqueen ni hagan regresar páginas.
                scheduleVisiblePageWork(pageIndex, true);
                if (readingMarkerEnabled && pendingReadingPage == pageIndex) {
                    schedulePendingReadingMarker();
                }
                if (restartAudioAfterRender) {
                    restartAudioAfterRender = false;
                    startAudioFromPage(currentPage);
                }
            }

            @Override
            public void onError(String message) {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onHighlightsChanged(String serialized) {
                saveHighlights(serialized);
            }

            @Override
            public void onRulesChanged(boolean enabled, float top, float bottom) {
                saveRules(enabled, top, bottom);
                textRepository.setRules(enabled, top, bottom);
                refreshTextCacheForRules();
            }
        });
        pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
        pdfView.setReadingMarkerEnabled(readingMarkerEnabled);
        pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
        pdfView.setWorkspaceColor(getPdfWorkspaceColor());
        frame.addView(pdfView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(8, 8, 8, 8);
        controls.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        View prevButton = makeNavigationButton("left", true);
        
prevButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) requestManualPageChange(currentPage - 1);
    }
});

        playButton = makeButton("▶");
        playButton.setTextSize(23);
        
playButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        toggleAudio();
    }
});

        View nextButton = makeNavigationButton("right", true);
        
nextButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) requestManualPageChange(currentPage + 1);
    }
});

        Button fitButton = makeButton("Ajustes");
        
fitButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        showSettings();
    }
});

        controls.addView(prevButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        controls.addView(playButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        controls.addView(nextButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        controls.addView(fitButton, new LinearLayout.LayoutParams(0, dp(48), 1));

        LinearLayout markControls = new LinearLayout(this);
        markControls.setOrientation(LinearLayout.HORIZONTAL);
        markControls.setGravity(Gravity.CENTER);
        markControls.setPadding(dp(8), dp(2), dp(8), dp(2));
        markControls.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        markButton = makeButton("Subrayar OFF");
        markButton.setTextSize(10);
        markButton.setSingleLine(true);
        markButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleMarkMode();
            }
        });

        colorButton = makeButton("●");
        colorButton.setTextSize(22);
        colorButton.setContentDescription("Elegir color del marcado");
        colorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkColorDialog(isHighlightStyle(markStyle) ? COLOR_TARGET_HIGHLIGHT : COLOR_TARGET_UNDERLINE);
            }
        });

        View undoButton = makeMarkHistoryButton("undo", "Deshacer marca");
        undoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.undoLastHighlight();
            }
        });

        View redoButton = makeMarkHistoryButton("redo", "Rehacer marca");
        redoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.redoLastHighlight();
            }
        });

        Button clearButton = makeButton("Limpiar");
        clearButton.setTextSize(12);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.clearPageHighlights();
            }
        });

        markControls.addView(markButton, new LinearLayout.LayoutParams(0, dp(44), 1.35f));
        markControls.addView(colorButton, new LinearLayout.LayoutParams(0, dp(44), 0.70f));
        markControls.addView(undoButton, new LinearLayout.LayoutParams(0, dp(44), 0.75f));
        markControls.addView(redoButton, new LinearLayout.LayoutParams(0, dp(44), 0.75f));
        markControls.addView(clearButton, new LinearLayout.LayoutParams(0, dp(44), 1.0f));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.addView(controls, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)));
        bottom.addView(markControls, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));

        root.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)));
        root.addView(frame, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        root.addView(bottom, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(104)));

        screenHost = new FrameLayout(this);
        screenHost.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
        screenHost.addView(root, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(screenHost);
        settingsOverlay = null;

        pdfView.setMarkStyle(markStyle);
        pdfView.setMarkThickness(markThicknessLevel);
        pdfView.setMarkColor(getCurrentMarkColor());
        pdfView.setMarkMode(markMode);
        updateMarkControls();
        loadRules();
    }

    private int getPdfWorkspaceColor() {
        // El espacio libre del visor se mantiene blanco. Más adelante podrá
        // reutilizarse para banners sin alterar el tamaño ni el render del PDF.
        return Color.WHITE;
    }

    private Button makeButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        button.setTextSize(16);
        button.setAllCaps(false);
        button.setBackgroundColor(darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255));
        return button;
    }



    private void showSettings() {
        settingsMode = true;
        settingsNeedsMainRebuild = false;
        buildSettingsScreen();
    }

    private String formatSpeed() {
        return String.format(Locale.US, "%.2fx", speechRate);
    }


    private String getVoiceSummary() {
        TtsEngineManager manager = TtsEngineManager.getInstance(this);
        String engine = manager.getActiveEnginePackage();
        if (engine != null && engine.length() > 0 && manager.isReady()) {
            return "Listo: " + engine;
        }
        String status = manager.getStatusText();
        return status == null || status.length() == 0 ? "Preparando motor" : status;
    }

    private void showVoiceEngineDialog() {
        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        final java.util.List<TtsEngineManager.EngineChoice> engines = manager.getInstalledEngines();
        final String[] labels = new String[engines.size() + 1];
        final String[] packages = new String[engines.size() + 1];
        labels[0] = "Automatico (recomendado)";
        packages[0] = "";
        for (int i = 0; i < engines.size(); i++) {
            TtsEngineManager.EngineChoice item = engines.get(i);
            labels[i + 1] = item.label + "\n" + item.packageName;
            packages[i + 1] = item.packageName;
        }

        String selectedPackage = prefs.getString(TtsEngineManager.PREF_ENGINE_PACKAGE, "");
        int selected = 0;
        for (int i = 1; i < packages.length; i++) {
            if (packages[i].equals(selectedPackage)) {
                selected = i;
                break;
            }
        }

        new AlertDialog.Builder(this)
                .setTitle("Motor de voz")
                .setSingleChoiceItems(labels, selected, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        manager.selectEngine(packages[which]);
                        Toast.makeText(MainActivity.this,
                                "Preparando " + labels[which].replace("\n", " "),
                                Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                })
                .setNeutralButton("Reintentar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        manager.retryInitialization();
                        Toast.makeText(MainActivity.this,
                                "Reiniciando el motor de voz", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void testSystemVoice() {
        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        Toast.makeText(this, "Preparando prueba de voz", Toast.LENGTH_SHORT).show();
        manager.testVoice("Prueba de voz correcta. El lector esta listo para leer el PDF.",
                new TtsEngineManager.TestCallback() {
                    @Override
                    public void onStarted() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this,
                                        "La voz comenzo correctamente", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

                    @Override
                    public void onCompleted() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (settingsMode) buildSettingsScreen();
                            }
                        });
                    }

                    @Override
                    public void onError(final String message) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, message,
                                        Toast.LENGTH_LONG).show();
                                if (settingsMode) buildSettingsScreen();
                            }
                        });
                    }
                });
    }

    private void showSpeedDialog() {
        final String[] labels = new String[]{"0.75x", "1.0x", "1.25x", "1.5x", "1.75x", "2.0x"};
        final float[] values = new float[]{0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f};

        int selected = 1;
        for (int i = 0; i < values.length; i++) {
            if (Math.abs(values[i] - speechRate) < 0.01f) {
                selected = i;
                break;
            }
        }

        new AlertDialog.Builder(this)
                .setTitle("Velocidad de lectura")
                .setSingleChoiceItems(labels, selected, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        speechRate = values[which];
                        prefs.edit().putFloat("speech_rate", speechRate).apply();
                        Toast.makeText(MainActivity.this, "Velocidad: " + labels[which], Toast.LENGTH_SHORT).show();

                        if (audioStarted && !audioPaused) {
                            startAudioFromPage(currentPage);
                        }

                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void closeSettings() {
        settingsMode = false;

        if (!settingsNeedsMainRebuild && screenHost != null) {
            if (settingsOverlay != null && settingsOverlay.getParent() == screenHost) {
                screenHost.removeView(settingsOverlay);
            }
            settingsOverlay = null;
            if (screenHost.getParent() == null) {
                setContentView(screenHost);
            }
            if (pdfView != null) {
                pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
                pdfView.setReadingMarkerEnabled(readingMarkerEnabled);
                pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
                pdfView.setWorkspaceColor(getPdfWorkspaceColor());
                pdfView.setMarkStyle(markStyle);
                pdfView.setMarkThickness(markThicknessLevel);
                pdfView.setMarkColor(getCurrentMarkColor());
                pdfView.setMarkMode(markMode);
                pdfView.invalidate();
            }
            updatePageLabel();
            updateMarkControls();
            applyReadingBrightness();
            return;
        }

        settingsNeedsMainRebuild = false;
        File file = currentFile;
        String title = currentTitle;
        int page = currentPage;
        buildUi();
        if (file != null && file.exists()) {
            openLocalPdf(file, title, false);
            if (pageCount > 0) {
                pdfView.showPage(Math.max(0, Math.min(page, pageCount - 1)));
            }
        }
    }

    private void buildSettingsScreen() {
        if (settingsScrollView != null) {
            settingsScrollY = settingsScrollView.getScrollY();
        }

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), dp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        View back = makeNavigationButton("back", false);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeSettings();
            }
        });

        TextView title = new TextView(this);
        title.setText("Ajustes");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);

        View topSpacer = new View(this);

        top.addView(back, new LinearLayout.LayoutParams(dp(48), dp(52)));
        top.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1));
        top.addView(topSpacer, new LinearLayout.LayoutParams(dp(48), dp(52)));

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(8), dp(14), dp(22));

        addSettingsSection(content, "APARIENCIA");
        addChoiceRow(content, "☀", "Tema claro", "Fondo blanco", !darkTheme, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (darkTheme) toggleTheme();
            }
        });
        addChoiceRow(content, "☾", "Tema oscuro", "Fondo oscuro", darkTheme, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!darkTheme) toggleTheme();
            }
        });
        addSettingsSection(content, "LECTURA Y AUDIO");
        addActionRow(content, "♬", "Motor de voz", getVoiceSummary(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showVoiceEngineDialog();
            }
        });
        addActionRow(content, "♪", "Probar voz", "Escuchar una muestra", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testSystemVoice();
            }
        });
        addActionRow(content, "◴", "Velocidad", formatSpeed(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSpeedDialog();
            }
        });
        addSettingsSection(content, "SEGUIMIENTO VISUAL");
        final Switch[] trackingSwitchHolder = new Switch[1];
        View.OnClickListener trackingToggle = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleReadingMarker();
                if (trackingSwitchHolder[0] != null) {
                    trackingSwitchHolder[0].setChecked(readingMarkerEnabled);
                }
            }
        };
        trackingSwitchHolder[0] = addSwitchRow(content, "icon:tracking", "Marcar la línea que se lee",
                "Durante la reproducción", readingMarkerEnabled, trackingToggle);
        readingMarkerSettingsSwatch = addColorRow(content, "●", "Color del seguimiento",
                getUtilityColorRgb(COLOR_TARGET_READING_MARKER), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showUtilityColorDialog(COLOR_TARGET_READING_MARKER, "Color del seguimiento");
                    }
                });

        addSettingsSection(content, "MARCADO");
        addMarkStyleRow(content, "icon:mark", "Tipo de marcado", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkStyleDialog();
            }
        });
        addMarkThicknessRow(content, "icon:thickness", "Grosor del subrayado", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkThicknessDialog();
            }
        });
        addSettingsSection(content, "ARCHIVOS Y EXPORTACIÓN");
        addActionRow(content, "icon:files", "Mis archivos", "Ver audios, imágenes y PDF guardados", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(LIBRARY_AUDIO);
            }
        });
        addActionRow(content, "icon:audio", "Crear audio", "Página, rango o todo el PDF", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAudioExportDialog();
            }
        });
        addActionRow(content, "icon:image", "Guardar página marcada", "PNG limpio sin reglas visibles", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCurrentPageImage();
            }
        });
        addActionRow(content, "icon:pdf", "Guardar PDF marcado", "Exportar el documento con subrayados", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkedPdfExportDialog();
            }
        });

        scroll.addView(content);
        settingsScrollView = scroll;
        screen.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(72)));
        screen.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        if (screenHost == null) {
            screenHost = new FrameLayout(this);
            if (root != null) {
                screenHost.addView(root, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
        }
        if (screenHost.getParent() == null) {
            setContentView(screenHost);
        }
        if (settingsOverlay != null && settingsOverlay.getParent() == screenHost) {
            screenHost.removeView(settingsOverlay);
        }
        settingsOverlay = screen;
        screenHost.addView(settingsOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        if (settingsScrollView != null) {
            final int restoreY = settingsScrollY;
            settingsScrollView.post(new Runnable() {
                @Override
                public void run() {
                    settingsScrollView.scrollTo(0, restoreY);
                }
            });
        }
    }

    private Button makeFlatIconButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        b.setTextSize(24);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private View makeNavigationButton(String direction, boolean filled) {
        FrameLayout button = new FrameLayout(this);
        button.setClickable(true);
        button.setFocusable(true);
        button.setContentDescription("left".equals(direction) || "back".equals(direction)
                ? "Regresar" : "Siguiente");
        button.setBackgroundColor(filled
                ? (darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255))
                : Color.TRANSPARENT);

        SettingsIconView icon = new SettingsIconView(this);
        icon.setIconType(direction);
        icon.setIconColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        int navIconSize = filled ? 28 : 26;
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dp(navIconSize), dp(navIconSize));
        iconLp.gravity = Gravity.CENTER;
        button.addView(icon, iconLp);
        return button;
    }


    private View makeMarkHistoryButton(String type, String description) {
        FrameLayout button = new FrameLayout(this);
        button.setClickable(true);
        button.setFocusable(true);
        button.setContentDescription(description);
        button.setBackgroundColor(darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255));

        SettingsIconView icon = new SettingsIconView(this);
        icon.setIconType(type);
        icon.setIconColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(30, 41, 59));
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dp(22), dp(22));
        iconLp.gravity = Gravity.CENTER;
        button.addView(icon, iconLp);
        return button;
    }

    private TextView makeDialogTitleView(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(22);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        tv.setPadding(dp(22), dp(18), dp(22), dp(10));
        tv.setBackgroundColor(darkTheme ? Color.rgb(7, 28, 42) : Color.WHITE);
        return tv;
    }

    private LinearLayout makeDialogContainer() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(14), dp(18), dp(16));
        box.setBackgroundColor(darkTheme ? Color.rgb(10, 24, 38) : Color.WHITE);
        return box;
    }

    private void styleDialog(AlertDialog dialog) {
        if (dialog == null) return;
        if (dialog.getWindow() != null) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(18));
            bg.setColor(darkTheme ? Color.rgb(10, 24, 38) : Color.WHITE);
            dialog.getWindow().setBackgroundDrawable(bg);
        }
        int accent = Color.rgb(59, 130, 246);
        Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        Button negative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        Button neutral = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
        if (positive != null) positive.setTextColor(accent);
        if (negative != null) negative.setTextColor(accent);
        if (neutral != null) neutral.setTextColor(accent);
    }

    private void addSettingsSection(LinearLayout parent, String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(14);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(Color.rgb(59, 130, 246));
        tv.setPadding(dp(4), dp(18), dp(4), dp(7));
        parent.addView(tv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private File getAudioSaveDir() {
        return ensureDirectory(new File(new File(getStorageBase(Environment.DIRECTORY_MUSIC), "Geo_Zeta"), "Audios"));
    }

    private File getImageSaveDir() {
        return ensureDirectory(new File(new File(getStorageBase(Environment.DIRECTORY_PICTURES), "Geo_Zeta"), "Imagenes"));
    }

    private File getPdfSaveDir() {
        return ensureDirectory(new File(new File(getStorageBase(Environment.DIRECTORY_DOCUMENTS), "Geo_Zeta"), "PDF_Marcados"));
    }

    private File getStorageBase(String type) {
        File base = getExternalFilesDir(type);
        return base == null ? getFilesDir() : base;
    }

    private File ensureDirectory(File directory) {
        if (directory != null && !directory.exists()) directory.mkdirs();
        return directory;
    }

    private void addStorageDestinationCard(LinearLayout parent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(8), dp(10), dp(8));
        row.setBackgroundColor(darkTheme ? Color.rgb(12, 35, 54) : Color.WHITE);

        TextView icon = new TextView(this);
        icon.setText("📁");
        icon.setTextSize(22);
        icon.setGravity(Gravity.CENTER);
        icon.setContentDescription("Carpetas de guardado");

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Carpetas de guardado");
        title.setTextSize(16);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView subtitle = new TextView(this);
        subtitle.setText("Audios · Imágenes · PDF");
        subtitle.setTextSize(11);
        subtitle.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        texts.addView(title);
        texts.addView(subtitle);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(25);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));

        row.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(52)));
        row.addView(texts, new LinearLayout.LayoutParams(0, dp(56), 1));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(38), dp(56)));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStorageFoldersDialog();
            }
        });
        addRowWithMargin(parent, row);
    }

    private void showStorageFoldersDialog() {
        LinearLayout box = makeDialogContainer();
        box.setPadding(dp(12), dp(10), dp(12), dp(10));

        TextView info = new TextView(this);
        info.setText("Cada formato se guarda en su propia carpeta y también aparece en Mis archivos.");
        info.setTextSize(13);
        info.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
        info.setPadding(dp(4), 0, dp(4), dp(8));
        box.addView(info);

        final AlertDialog[] dialogHolder = new AlertDialog[1];
        addStorageFolderRow(box, "♫", "Audios", "Geo Zeta / Audios", LIBRARY_AUDIO, dialogHolder);
        addStorageFolderRow(box, "📁", "Imágenes", "Geo Zeta / Imágenes", LIBRARY_IMAGE, dialogHolder);
        addStorageFolderRow(box, "PDF", "PDF marcados", "Geo Zeta / PDF marcados", LIBRARY_PDF, dialogHolder);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Carpetas de guardado"))
                .setView(box)
                .setNegativeButton("Cerrar", null)
                .create();
        dialogHolder[0] = dialog;
        dialog.show();
        styleDialog(dialog);
    }

    private void addStorageFolderRow(LinearLayout parent, String iconText, String titleText, String pathText, final int libraryType, final AlertDialog[] dialogHolder) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(10), dp(10));

        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(dp(14));
        background.setColor(darkTheme ? Color.rgb(12, 35, 54) : Color.rgb(248, 250, 252));
        row.setBackground(background);

        TextView icon = new TextView(this);
        icon.setText(iconText);
        icon.setTextSize(iconText.equals("PDF") ? 16 : 24);
        icon.setTypeface(Typeface.DEFAULT_BOLD);
        icon.setGravity(Gravity.CENTER);
        icon.setTextColor(Color.WHITE);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(Color.rgb(37, 99, 235));
        icon.setBackground(iconBg);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(12), 0, dp(8), 0);

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextSize(16);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView path = new TextView(this);
        path.setText(pathText);
        path.setTextSize(12);
        path.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        texts.addView(title);
        texts.addView(path);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(26);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.WHITE : Color.rgb(71, 85, 105));

        row.addView(icon, new LinearLayout.LayoutParams(dp(52), dp(52)));
        row.addView(texts, new LinearLayout.LayoutParams(0, dp(54), 1));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(32), dp(54)));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dialogHolder != null && dialogHolder.length > 0 && dialogHolder[0] != null) {
                    dialogHolder[0].dismiss();
                }
                showFileLibrary(libraryType);
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(4));
        parent.addView(row, lp);
    }

    private LinearLayout makeCardRow(String icon, String title, String sub) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(8), dp(10), dp(8));
        row.setBackgroundColor(darkTheme ? Color.rgb(12, 35, 54) : Color.WHITE);

        View iconView;
        if (icon != null && icon.startsWith("icon:")) {
            SettingsIconView customIcon = new SettingsIconView(this);
            customIcon.setIconType(icon.substring(5));
            iconView = customIcon;
        } else {
            TextView textIcon = new TextView(this);
            textIcon.setText(icon);
            textIcon.setTextSize(24);
            textIcon.setGravity(Gravity.CENTER);
            textIcon.setTextColor(Color.rgb(59, 130, 246));
            iconView = textIcon;
        }

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextSize(17);
        titleView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView subView = new TextView(this);
        subView.setText(sub == null ? "" : sub);
        subView.setTextSize(12);
        subView.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        texts.addView(titleView);
        if (sub != null && sub.length() > 0) texts.addView(subView);

        row.addView(iconView, new LinearLayout.LayoutParams(dp(48), dp(52)));
        row.addView(texts, new LinearLayout.LayoutParams(0, dp(56), 1));
        return row;
    }

    private void addChoiceRow(LinearLayout parent, String icon, String title, String sub, boolean selected, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        TextView check = new TextView(this);
        check.setText(selected ? "◉" : "○");
        check.setTextSize(24);
        check.setTextColor(selected ? Color.rgb(59, 130, 246) : Color.rgb(148, 163, 184));
        check.setGravity(Gravity.CENTER);
        row.addView(check, new LinearLayout.LayoutParams(dp(46), dp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private Switch addSwitchRow(LinearLayout parent, String icon, String title, String sub, boolean checked, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        Switch sw = new Switch(this);
        sw.setChecked(checked);
        sw.setEnabled(listener != null);
        if (listener != null) {
            sw.setOnClickListener(listener);
            row.setOnClickListener(listener);
        }
        row.addView(sw, new LinearLayout.LayoutParams(dp(64), dp(56)));
        addRowWithMargin(parent, row);
        return sw;
    }

    private void addActionRow(LinearLayout parent, String icon, String title, String sub, String right, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        TextView arrow = new TextView(this);
        arrow.setText(right == null ? "" : right);
        arrow.setTextSize(25);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(38), dp(56)));
        if (listener != null) row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private void addMarkStyleRow(LinearLayout parent, String icon, String title, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, "");
        View sample = createInlineMarkStylePreview(markStyle);
        row.addView(sample, new LinearLayout.LayoutParams(dp(92), dp(56)));
        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(25);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(32), dp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private void addMarkThicknessRow(LinearLayout parent, String icon, String title, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, "");
        View sample = createInlineThicknessPreview(markThicknessLevel);
        row.addView(sample, new LinearLayout.LayoutParams(dp(92), dp(56)));
        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(25);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(32), dp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private View createInlineThicknessPreview(int level) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(6), 0, dp(6), 0);
        int thickness = getPreviewLineThickness(level);
        int color = darkTheme ? Color.WHITE : Color.rgb(15, 23, 42);
        View line = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(3));
        line.setBackground(d);
        box.addView(line, new LinearLayout.LayoutParams(dp(54), thickness));
        return box;
    }

    private View createInlineMarkStylePreview(int style) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(4), dp(2), dp(4), dp(2));
        View line = createPreviewUnderlineView(style, markThicknessLevel, getCurrentMarkColor(), dp(58));
        box.addView(line);
        return box;
    }

    private int getPreviewLineThickness(int level) {
        if (level <= 0) return dp(2);
        if (level >= 2) return dp(6);
        return dp(4);
    }

    private int getPreviewLineColor(int color) {
        return 0xFF000000 | (color & 0x00FFFFFF);
    }

    private void applySampleDecoration(TextView sample, int style, int color) {
        sample.setBackground(null);
        sample.setPadding(dp(6), dp(2), dp(6), dp(2));
        int lineColor = getPreviewLineColor(color);

        if (style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(4));
            int alpha = style == MARK_STYLE_HIGHLIGHT_INTENSE ? 0xA8 : 0x62;
            bg.setColor((alpha << 24) | (lineColor & 0x00FFFFFF));
            sample.setBackground(bg);
        }
    }

    private View createPreviewUnderlineView(int style, int thicknessLevel, int color, int width) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        int lineColor = getPreviewLineColor(color);
        int thickness = getPreviewLineThickness(thicknessLevel);

        if (style == MARK_STYLE_UNDERLINE_DOUBLE) {
            for (int i = 0; i < 2; i++) {
                View line = new View(this);
                GradientDrawable d = new GradientDrawable();
                d.setColor(lineColor);
                d.setCornerRadius(dp(3));
                line.setBackground(d);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, Math.max(dp(2), thickness - dp(1)));
                lp.setMargins(0, i == 0 ? 0 : dp(3), 0, 0);
                box.addView(line, lp);
            }
            return box;
        }

        if (style == MARK_STYLE_UNDERLINE_DOTTED) {
            LinearLayout dots = new LinearLayout(this);
            dots.setOrientation(LinearLayout.HORIZONTAL);
            dots.setGravity(Gravity.CENTER);
            int dot = Math.max(dp(3), thickness);
            for (int i = 0; i < 7; i++) {
                View v = new View(this);
                GradientDrawable d = new GradientDrawable();
                d.setShape(GradientDrawable.OVAL);
                d.setColor(lineColor);
                v.setBackground(d);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dot, dot);
                lp.setMargins(dp(1), 0, dp(1), 0);
                dots.addView(v, lp);
            }
            box.addView(dots);
            return box;
        }

        if (style == MARK_STYLE_UNDERLINE_WAVY) {
            TextView wave = new TextView(this);
            wave.setText("﹏﹏﹏﹏");
            wave.setTextSize(16);
            wave.setTextColor(lineColor);
            wave.setGravity(Gravity.CENTER);
            box.addView(wave, new LinearLayout.LayoutParams(width, LinearLayout.LayoutParams.WRAP_CONTENT));
            return box;
        }

        View line = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setColor(lineColor);
        d.setCornerRadius(dp(3));
        line.setBackground(d);
        box.addView(line, new LinearLayout.LayoutParams(width, thickness));
        return box;
    }

    private TextView addColorRow(LinearLayout parent, String icon, String title, int color, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, "");

        TextView swatch = new TextView(this);
        swatch.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF000000 | (color & 0x00FFFFFF));
        circle.setStroke(dp(2), darkTheme ? Color.WHITE : Color.rgb(71, 85, 105));
        swatch.setBackground(circle);
        swatch.setContentDescription("Color seleccionado");

        LinearLayout.LayoutParams swatchParams = new LinearLayout.LayoutParams(dp(30), dp(30));
        swatchParams.setMargins(dp(4), dp(13), dp(6), dp(13));
        row.addView(swatch, swatchParams);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(25);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(32), dp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
        return swatch;
    }

    private void updateReadingMarkerSettingsSwatch() {
        if (readingMarkerSettingsSwatch == null) return;
        int color = getUtilityColorRgb(COLOR_TARGET_READING_MARKER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF000000 | (color & 0x00FFFFFF));
        circle.setStroke(dp(2), darkTheme ? Color.WHITE : Color.rgb(71, 85, 105));
        readingMarkerSettingsSwatch.setBackground(circle);
    }

    private void addRowWithMargin(LinearLayout parent, View row) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(62));
        lp.setMargins(0, dp(3), 0, dp(3));
        parent.addView(row, lp);
    }

    private String formatReadingBrightness() {
        if (readingBrightness < 0f) return "Brillo del sistema";
        return Math.round(readingBrightness * 100f) + "%";
    }

    private void applyReadingBrightness() {
        try {
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.screenBrightness = readingBrightness < 0f ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE : readingBrightness;
            getWindow().setAttributes(params);
        } catch (Exception ignored) {
        }
    }

    private void showReadingBrightnessDialog() {
        final float original = readingBrightness;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(10), dp(24), dp(6));

        final SeekBar seek = new SeekBar(this);
        seek.setMax(90);
        int current = readingBrightness < 0f ? 60 : Math.round(readingBrightness * 100f) - 10;
        seek.setProgress(Math.max(0, Math.min(90, current)));
        box.addView(seek, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)));

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                readingBrightness = (progress + 10) / 100f;
                applyReadingBrightness();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Brillo de lectura")
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setNeutralButton("Sistema", null)
                .setPositiveButton("Guardar", null)
                .create();

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface ignored) {
                readingBrightness = original;
                applyReadingBrightness();
            }
        });

        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(final DialogInterface ignored) {
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        readingBrightness = original;
                        applyReadingBrightness();
                        dialog.dismiss();
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        readingBrightness = -1f;
                        prefs.edit().putFloat(PREF_READING_BRIGHTNESS, readingBrightness).apply();
                        applyReadingBrightness();
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (readingBrightness < 0f) {
                            readingBrightness = (seek.getProgress() + 10) / 100f;
                        }
                        prefs.edit().putFloat(PREF_READING_BRIGHTNESS, readingBrightness).apply();
                        applyReadingBrightness();
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                });
            }
        });
        dialog.show();
    }

    private void toggleTheme() {
        darkTheme = !darkTheme;
        prefs.edit().putBoolean("dark_theme", darkTheme).apply();

        if (settingsMode) {
            settingsNeedsMainRebuild = true;
            buildSettingsScreen();
            return;
        }

        File file = currentFile;
        String title = currentTitle;
        int page = currentPage;

        buildUi();

        if (file != null && file.exists()) {
            openLocalPdf(file, title, false);
            if (pageCount > 0) {
                pdfView.showPage(Math.max(0, Math.min(page, pageCount - 1)));
            }
        }

        Toast.makeText(this, darkTheme ? "Tema oscuro activado" : "Tema claro activado", Toast.LENGTH_SHORT).show();
    }

    private void showFileLibrary(boolean showAudio) {
        showFileLibrary(showAudio ? LIBRARY_AUDIO : LIBRARY_IMAGE);
    }

    private void showFileLibrary(int libraryType) {
        if (!libraryMode) {
            libraryReturnToSettings = settingsMode;
        }
        libraryMode = true;
        settingsMode = false;
        libraryShowingType = Math.max(LIBRARY_AUDIO, Math.min(libraryType, LIBRARY_PDF));
        stopFilePreview();

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), dp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        View back = makeNavigationButton("back", false);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFileLibrary();
            }
        });

        TextView title = new TextView(this);
        title.setText("Mis archivos");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);

        Button actionButton = makeFlatIconButton(libraryShowingType == LIBRARY_IMAGE
                ? (imageLibraryGridMode ? "☰" : "▦")
                : "↻");
        actionButton.setTextSize(libraryShowingType == LIBRARY_IMAGE ? 22 : 26);
        actionButton.setContentDescription(libraryShowingType == LIBRARY_IMAGE
                ? (imageLibraryGridMode ? "Ver imágenes en lista" : "Ver imágenes en cuadrícula")
                : "Actualizar archivos");
        actionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (libraryShowingType == LIBRARY_IMAGE) {
                    imageLibraryGridMode = !imageLibraryGridMode;
                    prefs.edit().putBoolean(PREF_IMAGE_LIBRARY_GRID, imageLibraryGridMode).apply();
                }
                showFileLibrary(libraryShowingType);
            }
        });

        top.addView(back, new LinearLayout.LayoutParams(dp(52), dp(56)));
        top.addView(title, new LinearLayout.LayoutParams(0, dp(56), 1));
        top.addView(actionButton, new LinearLayout.LayoutParams(dp(52), dp(56)));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(10), dp(6), dp(10), dp(8));
        tabs.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));

        final ArrayList<File> audioFiles = getLibraryFiles(LIBRARY_AUDIO);
        final ArrayList<File> imageFiles = getLibraryFiles(LIBRARY_IMAGE);
        final ArrayList<File> pdfFiles = getLibraryFiles(LIBRARY_PDF);

        Button audioTab = makeButton("Audios\n" + audioFiles.size());
        Button imageTab = makeButton("Imágenes\n" + imageFiles.size());
        Button pdfTab = makeButton("PDF\n" + pdfFiles.size());
        audioTab.setTextSize(12);
        imageTab.setTextSize(12);
        pdfTab.setTextSize(12);
        audioTab.setAlpha(libraryShowingType == LIBRARY_AUDIO ? 1f : 0.52f);
        imageTab.setAlpha(libraryShowingType == LIBRARY_IMAGE ? 1f : 0.52f);
        pdfTab.setAlpha(libraryShowingType == LIBRARY_PDF ? 1f : 0.52f);
        audioTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(LIBRARY_AUDIO);
            }
        });
        imageTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(LIBRARY_IMAGE);
            }
        });
        pdfTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileLibrary(LIBRARY_PDF);
            }
        });
        tabs.addView(audioTab, new LinearLayout.LayoutParams(0, dp(54), 1));
        tabs.addView(imageTab, new LinearLayout.LayoutParams(0, dp(54), 1));
        tabs.addView(pdfTab, new LinearLayout.LayoutParams(0, dp(54), 1));

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(6), dp(12), dp(24));

        addLibraryFoldersRow(list);

        ArrayList<File> files = libraryShowingType == LIBRARY_AUDIO
                ? audioFiles
                : (libraryShowingType == LIBRARY_IMAGE ? imageFiles : pdfFiles);
        if (files.isEmpty()) {
            TextView empty = new TextView(this);
            String message;
            if (libraryShowingType == LIBRARY_AUDIO) {
                message = "Todavía no hay audios guardados.\nCrea uno desde Ajustes > Crear audio.";
            } else if (libraryShowingType == LIBRARY_IMAGE) {
                message = "Todavía no hay imágenes guardadas.\nGuarda una página marcada desde Ajustes.";
            } else {
                message = "Todavía no hay PDF marcados.\nUsa Guardar PDF marcado desde Ajustes.";
            }
            empty.setText(message);
            empty.setTextSize(17);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(20), dp(80), dp(20), dp(40));
            empty.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
            list.addView(empty, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        } else if (libraryShowingType == LIBRARY_IMAGE) {
            if (imageLibraryGridMode) addImageGallery(list, imageFiles);
            else addImageList(list, imageFiles);
        } else {
            for (File file : files) {
                addLibraryFileRow(list, file, libraryShowingType);
            }
        }

        scroll.addView(list);
        screen.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(78)));
        screen.addView(tabs, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(68)));
        screen.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(screen);
    }

    private void addLibraryFoldersRow(LinearLayout parent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(8), dp(10), dp(8));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
        bg.setStroke(dp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
        row.setBackground(bg);

        TextView icon = new TextView(this);
        icon.setText("📁");
        icon.setTextSize(21);
        icon.setGravity(Gravity.CENTER);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(12), 0, dp(8), 0);

        TextView title = new TextView(this);
        title.setText("Ver carpetas de guardado");
        title.setTextSize(15);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView subtitle = new TextView(this);
        subtitle.setText("Audios · Imágenes · PDF");
        subtitle.setTextSize(11);
        subtitle.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));

        texts.addView(title);
        texts.addView(subtitle);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(25);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));

        row.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(48)));
        row.addView(texts, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(36), dp(48)));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStorageFoldersDialog();
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(8));
        parent.addView(row, lp);
    }

    private void closeFileLibrary() {
        stopFilePreview();
        libraryMode = false;
        if (libraryReturnToSettings) {
            libraryReturnToSettings = false;
            settingsMode = true;
            buildSettingsScreen();
            return;
        }

        settingsMode = false;
        final File file = currentFile;
        final String title = currentTitle;
        final int page = currentPage;
        buildUi();
        if (file != null && file.exists()) {
            openLocalPdf(file, title, false);
            if (pageCount > 0 && pdfView != null) {
                pdfView.showPage(Math.max(0, Math.min(page, pageCount - 1)));
            }
        }
    }

    private ArrayList<File> getLibraryFiles(boolean audio) {
        return getLibraryFiles(audio ? LIBRARY_AUDIO : LIBRARY_IMAGE);
    }

    private ArrayList<File> getLibraryFiles(int type) {
        ArrayList<File> result = new ArrayList<File>();
        if (type == LIBRARY_AUDIO) {
            collectLibraryFiles(getAudioSaveDir(), LIBRARY_AUDIO, result);
            collectLibraryFiles(new File(getStorageBase(Environment.DIRECTORY_MUSIC), "PDF_Audio"), LIBRARY_AUDIO, result);
        } else if (type == LIBRARY_IMAGE) {
            collectLibraryFiles(getImageSaveDir(), LIBRARY_IMAGE, result);
            collectLibraryFiles(new File(getStorageBase(Environment.DIRECTORY_PICTURES), "PDF_Audio"), LIBRARY_IMAGE, result);
        } else {
            collectLibraryFiles(getPdfSaveDir(), LIBRARY_PDF, result);
            collectLibraryFiles(new File(getStorageBase(Environment.DIRECTORY_DOCUMENTS), "PDF_Audio"), LIBRARY_PDF, result);
        }
        Collections.sort(result, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        return result;
    }

    private void collectLibraryFiles(File directory, int type, ArrayList<File> output) {
        if (directory == null || !directory.exists()) return;
        File[] children = directory.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.isDirectory()) {
                collectLibraryFiles(child, type, output);
                continue;
            }
            String name = child.getName().toLowerCase(Locale.US);
            boolean matches;
            if (type == LIBRARY_AUDIO) {
                matches = name.endsWith(".wav") || name.endsWith(".mp3") || name.endsWith(".m4a") || name.endsWith(".ogg");
            } else if (type == LIBRARY_IMAGE) {
                matches = name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".webp");
            } else {
                matches = name.endsWith(".pdf");
            }
            if (matches && !output.contains(child)) output.add(child);
        }
    }

    private void addImageGallery(LinearLayout parent, final ArrayList<File> imageFiles) {
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setUseDefaultMargins(false);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setPadding(0, dp(4), 0, dp(12));

        for (final File file : imageFiles) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setPadding(dp(6), dp(6), dp(6), dp(8));

            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(14));
            bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
            bg.setStroke(dp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
            card.setBackground(bg);

            ImageView thumb = new ImageView(this);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumb.setAdjustViewBounds(false);
            Bitmap preview = decodePreviewBitmap(file, 420, 560);
            if (preview != null) {
                thumb.setImageBitmap(preview);
                if (imagePreviewCache.get(file.getAbsolutePath()) == null) {
                    imagePreviewCache.put(file.getAbsolutePath(), preview);
                }
            }
            GradientDrawable thumbBg = new GradientDrawable();
            thumbBg.setCornerRadius(dp(10));
            thumbBg.setColor(Color.WHITE);
            thumb.setBackground(thumbBg);
            card.addView(thumb, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(180)));

            TextView name = new TextView(this);
            name.setText(file.getName());
            name.setTextSize(12);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setGravity(Gravity.CENTER);
            name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
            name.setPadding(dp(4), dp(7), dp(4), 0);
            card.addView(name, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(32)));

            TextView details = new TextView(this);
            details.setText(formatFileDate(file.lastModified()));
            details.setTextSize(10);
            details.setGravity(Gravity.CENTER);
            details.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));
            card.addView(details, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(24)));

            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showImagePreview(file);
                }
            });
            card.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showFileActions(file, LIBRARY_IMAGE);
                    return true;
                }
            });

            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.height = GridLayout.LayoutParams.WRAP_CONTENT;
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            grid.addView(card, lp);
        }

        parent.addView(grid, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void addImageList(LinearLayout parent, final ArrayList<File> imageFiles) {
        for (final File file : imageFiles) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(8), dp(10), dp(8));

            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(14));
            bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
            bg.setStroke(dp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
            row.setBackground(bg);

            ImageView thumb = new ImageView(this);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Bitmap preview = decodePreviewBitmap(file, 320, 420);
            if (preview != null) {
                thumb.setImageBitmap(preview);
                if (imagePreviewCache.get(file.getAbsolutePath()) == null) {
                    imagePreviewCache.put(file.getAbsolutePath(), preview);
                }
            }
            GradientDrawable thumbBg = new GradientDrawable();
            thumbBg.setCornerRadius(dp(10));
            thumbBg.setColor(Color.WHITE);
            thumb.setBackground(thumbBg);
            row.addView(thumb, new LinearLayout.LayoutParams(dp(70), dp(92)));

            LinearLayout textBox = new LinearLayout(this);
            textBox.setOrientation(LinearLayout.VERTICAL);
            textBox.setGravity(Gravity.CENTER_VERTICAL);
            textBox.setPadding(dp(12), 0, dp(8), 0);

            TextView name = new TextView(this);
            name.setText(file.getName());
            name.setTextSize(14);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

            TextView details = new TextView(this);
            details.setText(formatFileSizePretty(file.length()) + "   " + formatFileDate(file.lastModified()));
            details.setTextSize(11);
            details.setSingleLine(true);
            details.setEllipsize(TextUtils.TruncateAt.END);
            details.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));
            details.setPadding(0, dp(3), 0, 0);

            textBox.addView(name);
            textBox.addView(details);
            row.addView(textBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

            Button menu = makeFlatIconButton("⋮");
            menu.setTextSize(24);
            menu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showFileActions(file, LIBRARY_IMAGE);
                }
            });
            row.addView(menu, new LinearLayout.LayoutParams(dp(40), dp(52)));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showImagePreview(file);
                }
            });
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showFileActions(file, LIBRARY_IMAGE);
                    return true;
                }
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, dp(5), 0, dp(5));
            parent.addView(row, lp);
        }
    }

    private void addLibraryFileRow(LinearLayout parent, final File file, final int type) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(6), dp(10));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(darkTheme ? Color.rgb(10, 34, 52) : Color.WHITE);
        bg.setStroke(dp(1), darkTheme ? Color.rgb(20, 56, 82) : Color.rgb(226, 232, 240));
        row.setBackground(bg);

        TextView icon = new TextView(this);
        icon.setText(type == LIBRARY_AUDIO ? "♫" : "PDF");
        icon.setTextSize(type == LIBRARY_AUDIO ? 26 : 15);
        icon.setTypeface(Typeface.DEFAULT_BOLD);
        icon.setTextColor(Color.WHITE);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setCornerRadius(dp(12));
        iconBg.setColor(type == LIBRARY_AUDIO ? Color.rgb(37, 99, 235) : Color.rgb(220, 38, 38));
        icon.setBackground(iconBg);
        row.addView(icon, new LinearLayout.LayoutParams(dp(50), dp(50)));

        LinearLayout textBox = new LinearLayout(this);
        textBox.setOrientation(LinearLayout.VERTICAL);
        textBox.setGravity(Gravity.CENTER_VERTICAL);
        textBox.setPadding(dp(10), 0, dp(8), 0);

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextSize(14);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView details = new TextView(this);
        String duration = type == LIBRARY_AUDIO ? getAudioDurationText(file) + "   " : "";
        details.setText(duration + formatFileSizePretty(file.length()) + "   " + formatFileDate(file.lastModified()));
        details.setTextSize(11);
        details.setSingleLine(true);
        details.setEllipsize(TextUtils.TruncateAt.END);
        details.setTextColor(darkTheme ? Color.rgb(186, 200, 214) : Color.rgb(100, 116, 139));
        details.setPadding(0, dp(2), 0, 0);

        textBox.addView(name);
        textBox.addView(details);
        row.addView(textBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button menu = makeFlatIconButton("⋮");
        menu.setTextSize(26);
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFileActions(file, type);
            }
        });
        row.addView(menu, new LinearLayout.LayoutParams(dp(42), dp(54)));

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (type == LIBRARY_AUDIO) showAudioPreview(file);
                else openFileExternally(file);
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(5), 0, dp(5));
        parent.addView(row, lp);
    }

    private Bitmap decodePreviewBitmap(File file, int reqWidth, int reqHeight) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            int sample = 1;
            while (bounds.outWidth / sample > reqWidth * 2 || bounds.outHeight / sample > reqHeight * 2) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = Math.max(1, sample);
            return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        } catch (Exception ignored) {
            return null;
        }
    }

    private Bitmap decodeViewerBitmap(File file, int reqWidth, int reqHeight) {
        Bitmap decoded = null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= reqWidth
                    && bounds.outHeight / (sample * 2) >= reqHeight) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = Math.max(1, sample);
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            decoded = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
            if (decoded == null) return null;

            float scale = Math.min(1f, Math.min(reqWidth / (float) decoded.getWidth(),
                    reqHeight / (float) decoded.getHeight()));
            if (scale < 0.999f) {
                int width = Math.max(1, Math.round(decoded.getWidth() * scale));
                int height = Math.max(1, Math.round(decoded.getHeight() * scale));
                Bitmap scaled = Bitmap.createScaledBitmap(decoded, width, height, true);
                if (scaled != decoded && !decoded.isRecycled()) decoded.recycle();
                decoded = scaled;
            }
            return decoded;
        } catch (Throwable ignored) {
            if (decoded != null && !decoded.isRecycled()) decoded.recycle();
            return null;
        }
    }

    private class ImagePagerAdapter extends RecyclerView.Adapter<ImagePagerAdapter.ImageHolder> {
        private final ArrayList<File> files;
        private final ZoomImageView.OnSingleTapListener tapListener;
        private final ArrayList<ImageHolder> holders = new ArrayList<ImageHolder>();
        private boolean released;

        ImagePagerAdapter(ArrayList<File> files, ZoomImageView.OnSingleTapListener tapListener) {
            this.files = files;
            this.tapListener = tapListener;
        }

        class ImageHolder extends RecyclerView.ViewHolder {
            final ZoomImageView image;
            String boundPath;

            ImageHolder(FrameLayout page, ZoomImageView image) {
                super(page);
                this.image = image;
            }

            void bindPlaceholder(String path) {
                boundPath = path;
                Bitmap hd = imageViewerCache.get(path);
                Bitmap preview = hd != null ? hd : imagePreviewCache.get(path);
                image.setImageBitmap(preview);
                image.resetZoom();
            }

            void applyBitmap(String path, Bitmap bitmap) {
                if (released || bitmap == null || boundPath == null || !boundPath.equals(path)) return;
                image.setImageBitmap(bitmap);
                image.resetZoom();
            }
        }

        @Override
        public ImageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            FrameLayout page = new FrameLayout(MainActivity.this);
            page.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
            page.setLayoutParams(new RecyclerView.LayoutParams(
                    RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));

            ZoomImageView image = new ZoomImageView(MainActivity.this);
            image.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
            image.setPadding(0, 0, 0, 0);
            image.setOnSingleTapListener(tapListener);
            page.addView(image, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

            ImageHolder holder = new ImageHolder(page, image);
            holders.add(holder);
            return holder;
        }

        @Override
        public void onBindViewHolder(final ImageHolder holder, int position) {
            final File file = files.get(position);
            final String path = file.getAbsolutePath();
            holder.bindPlaceholder(path);
            requestHighQualityImage(file, holder);
        }

        private void requestHighQualityImage(final File file, final ImageHolder holder) {
            final String path = file.getAbsolutePath();
            Bitmap cached = imageViewerCache.get(path);
            if (cached != null) {
                holder.applyBitmap(path, cached);
                return;
            }
            synchronized (imageDecodeInFlight) {
                if (imageDecodeInFlight.contains(path)) return;
                imageDecodeInFlight.add(path);
            }
            imageDecodeExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    final Bitmap decoded = decodeViewerBitmap(file, 1800, 2800);
                    synchronized (imageDecodeInFlight) {
                        imageDecodeInFlight.remove(path);
                    }
                    if (decoded != null) imageViewerCache.put(path, decoded);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!released && decoded != null) holder.applyBitmap(path, decoded);
                        }
                    });
                }
            });
        }

        void preload(int center) {
            int from = Math.max(0, center - 2);
            int to = Math.min(files.size() - 1, center + 2);
            for (int i = from; i <= to; i++) {
                final int preloadIndex = i;
                final File file = files.get(i);
                final String path = file.getAbsolutePath();
                if (imageViewerCache.get(path) != null) continue;
                synchronized (imageDecodeInFlight) {
                    if (imageDecodeInFlight.contains(path)) continue;
                    imageDecodeInFlight.add(path);
                }
                imageDecodeExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        Bitmap decoded = decodeViewerBitmap(file, 1800, 2800);
                        synchronized (imageDecodeInFlight) {
                            imageDecodeInFlight.remove(path);
                        }
                        if (decoded != null) {
                            imageViewerCache.put(path, decoded);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (!released && preloadIndex >= 0 && preloadIndex < getItemCount()) {
                                        notifyItemChanged(preloadIndex);
                                    }
                                }
                            });
                        }
                    }
                });
            }
        }

        @Override
        public int getItemCount() {
            return files.size();
        }

        @Override
        public void onViewRecycled(ImageHolder holder) {
            holder.boundPath = null;
            holder.image.setImageBitmap(null);
            super.onViewRecycled(holder);
        }

        void release() {
            released = true;
            for (ImageHolder holder : holders) {
                if (holder != null) {
                    holder.boundPath = null;
                    holder.image.setImageBitmap(null);
                }
            }
            holders.clear();
        }
    }

    private void showImagePreview(final File file) {
        showFullscreenImageViewer(file);
    }

    private ViewGroup getOverlayHost() {
        if (screenHost != null && screenHost.getParent() != null) {
            return screenHost;
        }
        View content = findViewById(android.R.id.content);
        if (content instanceof ViewGroup) {
            return (ViewGroup) content;
        }
        return null;
    }

    private void showFullscreenImageViewer(final File startFile) {
        final ArrayList<File> images = getLibraryFiles(LIBRARY_IMAGE);
        if (images.isEmpty()) {
            Toast.makeText(this, "No hay imágenes guardadas", Toast.LENGTH_SHORT).show();
            return;
        }

        stopFilePreview();
        imageViewerMode = true;

        int startIndex = images.indexOf(startFile);
        if (startIndex < 0) startIndex = 0;

        final FrameLayout screen = new FrameLayout(this);
        screen.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
        screen.setClickable(true);
        screen.setFocusable(true);

        final LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), dp(8), dp(8), dp(8));
        top.setBackgroundColor(darkTheme ? 0xCC08283A : 0xDDEAF2F8);

        View close = makeNavigationButton("back", false);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setGravity(Gravity.CENTER_VERTICAL);

        final TextView counter = new TextView(this);
        counter.setTextSize(15);
        counter.setTypeface(Typeface.DEFAULT_BOLD);
        counter.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        final TextView fileName = new TextView(this);
        fileName.setTextSize(12);
        fileName.setSingleLine(true);
        fileName.setEllipsize(TextUtils.TruncateAt.END);
        fileName.setTextColor(darkTheme ? Color.rgb(215, 227, 244) : Color.rgb(71, 85, 105));

        titleBox.addView(counter);
        titleBox.addView(fileName);

        Button share = makeFlatIconButton("Compartir");
        share.setTextSize(13);
        share.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        top.addView(close, new LinearLayout.LayoutParams(dp(52), dp(52)));
        top.addView(titleBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        top.addView(share, new LinearLayout.LayoutParams(dp(100), dp(52)));

        final Handler chromeHandler = new Handler(Looper.getMainLooper());
        final boolean[] chromeVisible = new boolean[]{true};
        final Runnable hideChrome = new Runnable() {
            @Override
            public void run() {
                chromeVisible[0] = false;
                top.animate().alpha(0f).setDuration(140L).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        if (!chromeVisible[0]) top.setVisibility(View.GONE);
                    }
                }).start();
            }
        };
        final Runnable showChromeNow = new Runnable() {
            @Override
            public void run() {
                chromeVisible[0] = true;
                top.setVisibility(View.VISIBLE);
                top.animate().cancel();
                top.setAlpha(1f);
                chromeHandler.removeCallbacks(hideChrome);
                chromeHandler.postDelayed(hideChrome, 2400L);
            }
        };

        imagePager = new ViewPager2(this);
        imagePager.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);
        imagePager.setOffscreenPageLimit(1);
        imagePager.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(232, 240, 248));
        imagePagerAdapter = new ImagePagerAdapter(images, new ZoomImageView.OnSingleTapListener() {
            @Override
            public void onSingleTap() {
                if (chromeVisible[0]) {
                    chromeHandler.removeCallbacks(hideChrome);
                    hideChrome.run();
                } else {
                    showChromeNow.run();
                }
            }
        });
        imagePager.setAdapter(imagePagerAdapter);
        screen.addView(imagePager, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        topLp.gravity = Gravity.TOP;
        screen.addView(top, topLp);

        final Runnable updateHeader = new Runnable() {
            @Override
            public void run() {
                int position = imagePager == null ? 0 : imagePager.getCurrentItem();
                position = Math.max(0, Math.min(position, images.size() - 1));
                counter.setText((position + 1) + " / " + images.size());
                fileName.setText(images.get(position).getName());
            }
        };

        imagePager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                updateHeader.run();
                showChromeNow.run();
                if (imagePagerAdapter != null) imagePagerAdapter.preload(position);
            }
        });
        imagePager.setCurrentItem(startIndex, false);
        if (imagePagerAdapter != null) imagePagerAdapter.preload(startIndex);
        updateHeader.run();

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chromeHandler.removeCallbacks(hideChrome);
                closeFullscreenImageViewer();
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChromeNow.run();
                int position = imagePager == null ? 0 : imagePager.getCurrentItem();
                position = Math.max(0, Math.min(position, images.size() - 1));
                shareFile(images.get(position));
            }
        });

        ViewGroup host = getOverlayHost();
        if (host == null) {
            Toast.makeText(this, "No se pudo abrir la imagen", Toast.LENGTH_SHORT).show();
            return;
        }
        if (imageViewerOverlay != null && imageViewerOverlay.getParent() == host) {
            host.removeView(imageViewerOverlay);
        }
        imageViewerOverlay = screen;
        host.addView(imageViewerOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        showChromeNow.run();
    }

    private void closeFullscreenImageViewer() {
        if (!imageViewerMode) return;
        imageViewerMode = false;
        if (imagePager != null) {
            imagePager.setAdapter(null);
            imagePager = null;
        }
        if (imagePagerAdapter != null) {
            imagePagerAdapter.release();
            imagePagerAdapter = null;
        }
        if (imageViewerBitmap != null && !imageViewerBitmap.isRecycled()) {
            imageViewerBitmap.recycle();
            imageViewerBitmap = null;
        }
        ViewGroup host = getOverlayHost();
        if (host != null && imageViewerOverlay != null && imageViewerOverlay.getParent() == host) {
            host.removeView(imageViewerOverlay);
        }
        imageViewerOverlay = null;
    }

    private void showAudioPreview(final File file) {


        stopFilePreview();

        LinearLayout box = makeDialogContainer();

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextSize(18);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        name.setPadding(0, 0, 0, dp(10));
        box.addView(name);

        final TextView time = new TextView(this);
        time.setText("00:00 / 00:00");
        time.setGravity(Gravity.CENTER);
        time.setTextSize(14);
        time.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(15, 23, 42));

        final SeekBar seek = new SeekBar(this);
        seek.setMax(1000);

        final Button play = makeButton("▶ Reproducir");
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (previewPlayer == null) return;
                if (previewPlayer.isPlaying()) {
                    previewPlayer.pause();
                    play.setText("▶ Reproducir");
                } else {
                    previewPlayer.start();
                    play.setText("Ⅱ Pausar");
                    startPreviewProgress(seek, time, play);
                }
            }
        });

        box.addView(time, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34)));
        box.addView(seek, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));
        box.addView(play, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        try {
            previewPlayer = new MediaPlayer();
            previewPlayer.setDataSource(file.getAbsolutePath());
            previewPlayer.prepare();
            updatePreviewTime(seek, time);
            previewPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    play.setText("▶ Reproducir");
                    updatePreviewTime(seek, time);
                }
            });
        } catch (Exception e) {
            stopFilePreview();
            Toast.makeText(this, "No se pudo abrir el audio", Toast.LENGTH_LONG).show();
            return;
        }

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && previewPlayer != null) {
                    int duration = previewPlayer.getDuration();
                    previewPlayer.seekTo((int) (duration * (progress / 1000f)));
                    updatePreviewTime(seek, time);
                }
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(box)
                .setPositiveButton("Compartir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        shareFile(file);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                stopFilePreview();
            }
        });
        dialog.show();
        styleDialog(dialog);
    }

    private void startPreviewProgress(final SeekBar seek, final TextView time, final Button play) {
        if (previewProgressTask != null) previewHandler.removeCallbacks(previewProgressTask);
        previewProgressTask = new Runnable() {
            @Override
            public void run() {
                if (previewPlayer == null) return;
                updatePreviewTime(seek, time);
                if (previewPlayer.isPlaying()) {
                    play.setText("Ⅱ Pausar");
                    previewHandler.postDelayed(this, 400L);
                }
            }
        };
        previewHandler.post(previewProgressTask);
    }

    private void updatePreviewTime(SeekBar seek, TextView time) {
        if (previewPlayer == null) return;
        int duration = Math.max(0, previewPlayer.getDuration());
        int position = Math.max(0, previewPlayer.getCurrentPosition());
        seek.setProgress(duration == 0 ? 0 : Math.min(1000, Math.round(position * 1000f / duration)));
        time.setText(formatDuration(position) + " / " + formatDuration(duration));
    }

    private void stopFilePreview() {
        if (previewProgressTask != null) {
            previewHandler.removeCallbacks(previewProgressTask);
            previewProgressTask = null;
        }
        if (previewPlayer != null) {
            try { previewPlayer.stop(); } catch (Exception ignored) { }
            try { previewPlayer.release(); } catch (Exception ignored) { }
            previewPlayer = null;
        }
    }

    private void showFileActions(final File file, final int type) {
        final String[] actions = new String[]{"Abrir", "Compartir", "Cambiar nombre", "Eliminar"};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(file.getName())
                .setItems(actions, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            if (type == LIBRARY_AUDIO) showAudioPreview(file);
                            else if (type == LIBRARY_IMAGE) showImagePreview(file);
                            else openFileExternally(file);
                        } else if (which == 1) {
                            shareFile(file);
                        } else if (which == 2) {
                            renameLibraryFile(file);
                        } else {
                            deleteLibraryFile(file);
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void shareFile(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(getMimeType(file));
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "Compartir archivo"));
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo compartir el archivo", Toast.LENGTH_LONG).show();
        }
    }

    private String getMimeType(File file) {
        String name = file.getName();
        int dot = name.lastIndexOf('.');
        String extension = dot >= 0 ? name.substring(dot + 1).toLowerCase(Locale.US) : "";
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        if (mime != null) return mime;
        if (extension.equals("wav") || extension.equals("mp3") || extension.equals("m4a") || extension.equals("ogg")) return "audio/*";
        if (extension.equals("pdf")) return "application/pdf";
        return "image/*";
    }

    private void openFileExternally(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, getMimeType(file));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Abrir archivo"));
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir el archivo", Toast.LENGTH_LONG).show();
        }
    }

    private void renameLibraryFile(final File file) {
        final EditText input = new EditText(this);
        String name = file.getName();
        final int dot = name.lastIndexOf('.');
        final String extension = dot >= 0 ? name.substring(dot) : "";
        input.setText(dot >= 0 ? name.substring(0, dot) : name);
        input.setSelection(input.getText().length());

        new AlertDialog.Builder(this)
                .setTitle("Cambiar nombre")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String clean = input.getText().toString().trim().replaceAll("[\\/:*?\"<>|]", "_");
                        if (clean.length() == 0) {
                            Toast.makeText(MainActivity.this, "Nombre inválido", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        File renamed = new File(file.getParentFile(), clean + extension);
                        if (renamed.exists()) {
                            Toast.makeText(MainActivity.this, "Ya existe un archivo con ese nombre", Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (file.renameTo(renamed)) {
                            Toast.makeText(MainActivity.this, "Nombre actualizado", Toast.LENGTH_SHORT).show();
                            showFileLibrary(libraryShowingType);
                        } else {
                            Toast.makeText(MainActivity.this, "No se pudo cambiar el nombre", Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .show();
    }

    private void deleteLibraryFile(final File file) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar archivo")
                .setMessage("¿Eliminar " + file.getName() + "?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        stopFilePreview();
                        if (file.delete()) {
                            removeEmptyParentFolders(file.getParentFile());
                            Toast.makeText(MainActivity.this, "Archivo eliminado", Toast.LENGTH_SHORT).show();
                            showFileLibrary(libraryShowingType);
                        } else {
                            Toast.makeText(MainActivity.this, "No se pudo eliminar", Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .show();
    }

    private void removeEmptyParentFolders(File folder) {
        if (folder == null) return;
        File audioRoot = getAudioSaveDir();
        File imageRoot = getImageSaveDir();
        File pdfRoot = getPdfSaveDir();
        File legacyAudioRoot = new File(getStorageBase(Environment.DIRECTORY_MUSIC), "PDF_Audio");
        File legacyImageRoot = new File(getStorageBase(Environment.DIRECTORY_PICTURES), "PDF_Audio");
        File legacyPdfRoot = new File(getStorageBase(Environment.DIRECTORY_DOCUMENTS), "PDF_Audio");
        if (folder.equals(audioRoot) || folder.equals(imageRoot) || folder.equals(pdfRoot)
                || folder.equals(legacyAudioRoot) || folder.equals(legacyImageRoot) || folder.equals(legacyPdfRoot)) return;
        File[] children = folder.listFiles();
        if (children != null && children.length == 0) {
            File parent = folder.getParentFile();
            folder.delete();
            removeEmptyParentFolders(parent);
        }
    }

    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L * 1024L) return String.format(Locale.US, "%.1f KB", bytes / 1024f);
        return String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f));
    }

    private String formatFileSizePretty(long bytes) {
        if (bytes <= 0) return "Tamaño pendiente";
        return formatFileSize(bytes);
    }

    private String formatFileDate(long time) {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date(time));
    }

    private String getAudioDurationText(File file) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(file.getAbsolutePath());
            String duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (duration != null) return formatDuration(Integer.parseInt(duration));
        } catch (Exception ignored) {
        } finally {
            try { retriever.release(); } catch (Exception ignored) { }
        }
        return "--:--";
    }

    private String formatDuration(int milliseconds) {
        int totalSeconds = Math.max(0, milliseconds / 1000);
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;
        if (hours > 0) return String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds);
        return String.format(Locale.US, "%02d:%02d", minutes, seconds);
    }

    private void showSavedFileActions(final File file, final boolean audio) {
        LinearLayout box = makeDialogContainer();

        TextView title = new TextView(this);
        title.setText(audio ? "Audio guardado" : "Imagen guardada");
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        box.addView(title);

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextSize(14);
        name.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(71, 85, 105));
        name.setPadding(0, dp(6), 0, 0);
        box.addView(name);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(box)
                .setPositiveButton(audio ? "Reproducir" : "Galería", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (audio) showAudioPreview(file);
                        else showFileLibrary(false);
                    }
                })
                .setNeutralButton("Compartir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        shareFile(file);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void showSavedPdfActions(final File file) {
        LinearLayout box = makeDialogContainer();

        TextView title = new TextView(this);
        title.setText("PDF guardado");
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        box.addView(title);

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextSize(14);
        name.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(71, 85, 105));
        name.setPadding(0, dp(6), 0, 0);
        box.addView(name);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(box)
                .setPositiveButton("Abrir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openFileExternally(file);
                    }
                })
                .setNeutralButton("Compartir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        shareFile(file);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void showAudioExportCompleted() {
        if (exportSavedCount == 1 && lastExportedAudioFile != null && lastExportedAudioFile.exists()) {
            showSavedFileActions(lastExportedAudioFile, true);
            return;
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Audio terminado"))
                .setMessage(exportSavedCount + " archivo(s) guardado(s) en Mis archivos")
                .setPositiveButton("Ver audios", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showFileLibrary(true);
                    }
                })
                .setNegativeButton("Cerrar", null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void saveCurrentPageImage() {
        if (currentFile == null || pdfView == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        final int pageToSave = currentPage;
        final String titleToSave = currentTitle;
        final File dir = getImageSaveDir();
        final String clean = titleToSave == null ? "pdf"
                : titleToSave.replaceAll("[^a-zA-Z0-9._-]", "_");
        final File out = new File(dir, clean + "_pagina_" + (pageToSave + 1) + ".png");

        imageExportExecutor.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = null;
                try {
                    bitmap = pdfView.exportPageBitmapHd(pageToSave, false);
                    if (bitmap == null) throw new IllegalStateException("bitmap null");

                    try (FileOutputStream fos = new FileOutputStream(out)) {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                        fos.flush();
                    }
                    bitmap.recycle();
                    bitmap = null;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showFullscreenImageViewer(out);
                        }
                    });
                } catch (Exception e) {
                    if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this,
                                    "No se pudo guardar la imagen", Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }

    private void showMarkedPdfExportDialog() {
        if (currentFile == null || pdfView == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout box = makeDialogContainer();
        TextView info = new TextView(this);
        info.setText("Guardar un PDF nuevo con los subrayados y resaltados actuales.");
        info.setTextSize(14);
        info.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
        info.setPadding(0, 0, 0, dp(10));
        box.addView(info);

        Button current = makeButton("Solo página actual");
        Button range = makeButton("Elegir rango");
        Button full = makeButton("Todo el PDF");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        lp.setMargins(0, dp(6), 0, 0);
        box.addView(current, lp);
        box.addView(range, lp);
        box.addView(full, lp);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Guardar PDF marcado"))
                .setView(box)
                .setNegativeButton("Cerrar", null)
                .create();

        current.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                exportMarkedPdf(currentPage, currentPage);
            }
        });
        range.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                showMarkedPdfRangeDialog();
            }
        });
        full.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                exportMarkedPdf(0, pageCount - 1);
            }
        });

        dialog.show();
        styleDialog(dialog);
    }


    private void showMarkedPdfRangeDialog() {
        LinearLayout box = makeDialogContainer();
        final EditText from = new EditText(this);
        from.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        from.setHint("Desde (1 - " + pageCount + ")");
        from.setText(String.valueOf(currentPage + 1));
        from.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        from.setHintTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        final EditText to = new EditText(this);
        to.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        to.setHint("Hasta (1 - " + pageCount + ")");
        to.setText(String.valueOf(currentPage + 1));
        to.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        to.setHintTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        box.addView(from); box.addView(to);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Rango de páginas"))
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        try {
                            int start = Integer.parseInt(from.getText().toString().trim());
                            int end = Integer.parseInt(to.getText().toString().trim());
                            if (start < 1 || end < 1 || start > pageCount || end > pageCount || start > end) {
                                Toast.makeText(MainActivity.this, "Rango inválido", Toast.LENGTH_LONG).show();
                                return;
                            }
                            exportMarkedPdf(start - 1, end - 1);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Completa correctamente el rango", Toast.LENGTH_LONG).show();
                        }
                    }
                }).create();
        dialog.show(); styleDialog(dialog);
    }

    private void exportMarkedPdf(final int startPage, final int endPage) {
        if (currentFile == null || pdfView == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Exportando PDF marcado...", Toast.LENGTH_SHORT).show();
        final MainActivity self = this;
        new Thread(new Runnable() {
            @Override
            public void run() {
                PdfDocument document = new PdfDocument();
                FileOutputStream fos = null;
                File out = null;
                String error = null;
                int exportedPages = 0;
                try {
                    File dir = getPdfSaveDir();

                    String clean = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
                    String suffix;
                    if (startPage == endPage) suffix = "_pagina_" + (startPage + 1) + "_marcada.pdf";
                    else if (startPage == 0 && endPage == pageCount - 1) suffix = "_completo_marcado.pdf";
                    else suffix = "_paginas_" + (startPage + 1) + "-" + (endPage + 1) + "_marcado.pdf";
                    out = new File(dir, clean + suffix);

                    for (int page = startPage; page <= endPage; page++) {
                        Bitmap bitmap = pdfView.exportPageBitmap(page, false);
                        if (bitmap == null) continue;

                        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(bitmap.getWidth(), bitmap.getHeight(), exportedPages + 1).create();
                        PdfDocument.Page pdfPage = document.startPage(pageInfo);
                        pdfPage.getCanvas().drawColor(Color.WHITE);
                        pdfPage.getCanvas().drawBitmap(bitmap, 0f, 0f, null);
                        document.finishPage(pdfPage);
                        bitmap.recycle();
                        exportedPages++;
                    }

                    if (exportedPages == 0) {
                        throw new IllegalStateException("No se pudo renderizar ninguna página");
                    }

                    fos = new FileOutputStream(out);
                    document.writeTo(fos);
                    fos.flush();
                } catch (Exception e) {
                    error = e.getMessage();
                } finally {
                    try { if (fos != null) fos.close(); } catch (Exception ignored) { }
                    try { document.close(); } catch (Exception ignored) { }
                }

                final File finalOut = out;
                final String finalError = error;
                final int finalExportedPages = exportedPages;
                self.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (finalOut != null && finalError == null && finalExportedPages > 0 && finalOut.exists()) {
                            showSavedPdfActions(finalOut);
                        } else {
                            Toast.makeText(MainActivity.this,
                                    "No se pudo guardar el PDF" + (finalError == null || finalError.length() == 0 ? "" : ": " + finalError),
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void exportCurrentPageAudio() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Preparando audio...", Toast.LENGTH_SHORT).show();

        textRepository.getPageText(currentPage, new TextRepository.TextCallback() {
            @Override
            public void onText(final String text) {
                if (text == null || text.trim().length() == 0) {
                    Toast.makeText(MainActivity.this, "No hay texto para exportar", Toast.LENGTH_LONG).show();
                    return;
                }

                if (exportTts != null) {
                    try { exportTts.shutdown(); } catch (Exception ignored) {}
                    exportTts = null;
                }

                exportTts = new TextToSpeech(MainActivity.this, new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int status) {
                        if (status != TextToSpeech.SUCCESS) {
                            Toast.makeText(MainActivity.this, "No se pudo iniciar voz", Toast.LENGTH_LONG).show();
                            return;
                        }

                        try {
                            exportTts.setLanguage(new Locale("es", "PE"));
                            exportTts.setSpeechRate(speechRate);

                            File dir = getAudioSaveDir();

                            String clean = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
                            File out = new File(dir, clean + "_pagina_" + (currentPage + 1) + ".wav");

                            String safeText = text;
                            if (safeText.length() > 12000) safeText = safeText.substring(0, 12000);

                            int result;
                            if (Build.VERSION.SDK_INT >= 21) {
                                result = exportTts.synthesizeToFile(safeText, null, out, "EXPORT_PAGE_AUDIO");
                            } else {
                                result = TextToSpeech.ERROR;
                            }

                            if (result == TextToSpeech.SUCCESS) {
                                Toast.makeText(MainActivity.this, "Audio guardado: " + out.getName(), Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(MainActivity.this, "No se pudo guardar el audio", Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Error al exportar audio", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }

    private void choosePdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        startActivityForResult(intent, REQ_OPEN_PDF);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OPEN_PDF && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            copyAndOpen(uri);
        }
    }

    private void copyAndOpen(Uri uri) {
        try {
            stopAudioOnly();
            if (textRepository != null) textRepository.close();
            if (selectionRepository != null) selectionRepository.close();
            String name = getDisplayName(uri);
            File target = new File(getFilesDir(), "last.pdf");

            InputStream input = getContentResolver().openInputStream(uri);
            FileOutputStream output = new FileOutputStream(target);
            byte[] buffer = new byte[65536];
            int read;
            while (input != null && (read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
            if (input != null) input.close();
            output.close();

            prefs.edit().putString("last_title", name).putInt("last_page", 0).apply();
            openLocalPdf(target, name, false);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir el PDF", Toast.LENGTH_LONG).show();
        }
    }

    private void openLocalPdf(File file, String title, boolean restore) {
        try {
            currentFile = file;
            currentTitle = title == null ? "PDF" : title;
            titleView.setText(currentTitle);
            if (titleScroller != null) {
                titleScroller.post(new Runnable() {
                    @Override
                    public void run() {
                        titleScroller.scrollTo(0, 0);
                    }
                });
            }
            fullIndexRequested = false;

            // Las reglas se fijan antes de abrir para que el cache persistente use
            // exactamente la misma zona de lectura que se ve en pantalla.
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
            textRepository.open(file);
            TtsForegroundService.clearPages();
            warmUpAudioEngine();

            // La pagina guardada entra en la cola urgente antes de abrir el repositorio
            // de marcado y antes de terminar el render del visor.
            final int preferredPage = Math.max(0,
                    restore ? prefs.getInt("last_page", 0) : 0);
            preparePageForInstantPlay(preferredPage, false);

            // V98: no abrir el segundo documento PDFBox todavía. Primero se
            // prepara el texto de la página visible para que Play tenga prioridad
            // real y no compita con la extracción de coordenadas del subrayado.
            selectionRepository.close();
            loadedSelectionPage = -1;
            loadingSelectionPage = -1;
            pdfView.openFile(file);
            String savedHighlights = prefs.getString(highlightKey(), "");
            if ((savedHighlights == null || savedHighlights.length() == 0) && currentTitle != null) {
                savedHighlights = prefs.getString(legacyHighlightKey(), "");
            }
            pdfView.loadHighlights(savedHighlights);
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
            pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
            pdfView.setReadingMarkerEnabled(readingMarkerEnabled);
            pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
            pageCount = pdfView.getPageCount();
            final int p = Math.max(0, Math.min(preferredPage,
                    Math.max(0, pageCount - 1)));

            if (p != preferredPage) {
                preparePageForInstantPlay(p, false);
            }

            // Una vez listo el texto urgente, se abre el repositorio de posiciones.
            // Así el primer Play no comparte CPU/disco con otro PDDocument.load().
            final File selectionFile = file;
            primeAudioPageForPlayback(p, new Runnable() {
                @Override
                public void run() {
                    if (currentFile == null || !currentFile.equals(selectionFile)) return;
                    selectionRepository.open(selectionFile);
                    loadedSelectionPage = -1;
                    loadingSelectionPage = -1;
                    loadSelectionForPage(p);
                    if (markMode || readingMarkerEnabled) {
                        prefetchAroundPage(p);
                    }
                }
            });

            pdfView.showPage(p);
            updatePageLabel();
        } catch (Exception e) {
            Toast.makeText(this, "Error al cargar PDF", Toast.LENGTH_LONG).show();
        }
    }

    private String getDisplayName(Uri uri) {
        String result = "PDF";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return result == null ? "PDF" : result;
    }



    private void requestManualPageChange(int targetPage) {
        if (pageCount <= 0) return;

        final int nextPage = Math.max(0, Math.min(targetPage, pageCount - 1));
        restartAudioAfterRender = false;
        currentPage = nextPage;
        updatePageLabel();

        // La página elegida por el usuario gana prioridad incluso antes de que
        // termine el nuevo render. Así Play/cambio durante lectura puede usar el
        // texto ya cacheado o iniciar una sola extracción urgente compartida.
        primeAudioPageForPlayback(nextPage);

        if (pdfView != null) {
            pdfView.clearReadingMarker();
            pdfView.showPage(nextPage);
        }

        loadedSelectionPage = -1;
        loadingSelectionPage = -1;
        scheduleVisiblePageWork(nextPage, false);

        if (playbackState == TtsForegroundService.STATE_PLAYING
                || playbackState == TtsForegroundService.STATE_PREPARING) {
            seekAudioToPage(nextPage, true);
        } else if (playbackState == TtsForegroundService.STATE_PAUSED) {
            seekAudioToPage(nextPage, false);
        }
    }

    private void scheduleVisiblePageWork(final int page, final boolean requestFullIndex) {
        final int token = ++pageWorkToken;
        if (pageWorkRunnable != null) {
            pageWorkHandler.removeCallbacks(pageWorkRunnable);
        }
        pageWorkRunnable = new Runnable() {
            @Override
            public void run() {
                if (token != pageWorkToken || page != currentPage || currentFile == null) return;
                // El texto audible gana la carrera. Las coordenadas visuales se
                // procesan inmediatamente después, nunca al mismo tiempo.
                primeAudioPageForPlayback(page, new Runnable() {
                    @Override
                    public void run() {
                        if (token != pageWorkToken || page != currentPage || currentFile == null) return;
                        loadSelectionForPage(page);
                        if (markMode || readingMarkerEnabled) {
                            prefetchAroundPage(page);
                        }
                        if (readingMarkerEnabled && pendingReadingPage == page) {
                            schedulePendingReadingMarker();
                        }
                    }
                });
            }
        };
        pageWorkHandler.postDelayed(pageWorkRunnable, 120L);
    }

    private void seekAudioToPage(int page, boolean playNow) {
        if (pageCount <= 0) return;
        int safePage = Math.max(0, Math.min(page, pageCount - 1));
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = safePage;
        requestedAudioPageConfirmed = false;
        applyPlaybackState(playNow
                        ? TtsForegroundService.STATE_PREPARING
                        : TtsForegroundService.STATE_PAUSED,
                safePage, playNow ? "" : "Pausado", false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_SEEK_PAGE);
        intent.putExtra(TtsForegroundService.EXTRA_PAGE, safePage);
        intent.putExtra(TtsForegroundService.EXTRA_AUTOPLAY, playNow);
        intent.putExtra("title", currentTitle);
        intent.putExtra("totalPages", pageCount);
        intent.putExtra("rate", speechRate);
        intent.putExtra("pitch", 1.0f);

        String cachedPageText = textRepository == null ? null : textRepository.getCachedText(safePage);
        if (cachedPageText != null) {
            TtsForegroundService.setPageText(safePage, cachedPageText);
            intent.putExtra(TtsForegroundService.EXTRA_PAGE_TEXT, cachedPageText);
        } else {
            primeAudioPageForPlayback(safePage);
        }
        startService(intent);
    }

    private void preparePageForInstantPlay(final int page, final boolean requestFullIndex) {
        primeAudioPageForPlayback(page);
    }

    private void primeAudioPageForPlayback(final int page) {
        primeAudioPageForPlayback(page, null);
    }

    private void primeAudioPageForPlayback(final int page, final Runnable afterPrime) {
        if (textRepository == null || currentFile == null || page < 0) return;
        final File requestedFile = currentFile;

        String cached = textRepository.getCachedText(page);
        if (cached != null) {
            TtsForegroundService.setPageText(page, cached);
            if (afterPrime != null) afterPrime.run();
            scheduleAudioNeighborPreload(page);
            return;
        }

        textRepository.prepareVisiblePage(page, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                if (currentFile == null || !currentFile.equals(requestedFile)) return;
                TtsForegroundService.setPageText(page, text == null ? "" : text);
                if (afterPrime != null) afterPrime.run();
                scheduleAudioNeighborPreload(page);
            }
        });
    }

    private void scheduleAudioNeighborPreload(final int page) {
        if (pageCount <= 0) return;
        if (audioNeighborPreloadRunnable != null) {
            audioStartHandler.removeCallbacks(audioNeighborPreloadRunnable);
        }
        audioNeighborPreloadRunnable = new Runnable() {
            @Override
            public void run() {
                audioNeighborPreloadRunnable = null;
                if (textRepository != null && pageCount > 0) {
                    // Mantiene lista la página siguiente sin acumular trabajos viejos
                    // cuando el usuario pasa varias páginas rápidamente.
                    textRepository.preloadAudioWindow(page, 1, pageCount);
                }
            }
        };
        audioStartHandler.postDelayed(audioNeighborPreloadRunnable, 900L);
    }

    private void prefetchAroundCurrentPage() {
        prefetchAroundPage(currentPage);
    }

    private void prefetchAroundPage(int page) {
        if (pageCount <= 0) return;
        int start = Math.max(0, page);
        selectionRepository.prefetch(start, 1, pageCount);
    }




    private void loadSelectionForPage(final int page) {
        if (pageCount <= 0 || selectionRepository == null || page < 0) return;
        if (loadedSelectionPage == page) {
            schedulePendingReadingMarker();
            return;
        }
        if (loadingSelectionPage == page) return;
        loadingSelectionPage = page;

        selectionRepository.getChars(page, new SelectionTextRepository.CharCallback() {
            @Override
            public void onChars(java.util.ArrayList<CharBox> chars) {
                loadingSelectionPage = -1;
                if (page == currentPage && pdfView != null) {
                    loadedSelectionPage = page;
                    pdfView.setSelectionChars(chars);
                    schedulePendingReadingMarker();
                }
            }
        });
    }

    private void loadRules() {
        rulesEnabled = prefs.getBoolean("rules_enabled", true);
        ruleTop = prefs.getFloat("rule_top", 0.08f);
        ruleBottom = prefs.getFloat("rule_bottom", 0.92f);
        if (ruleBottom <= ruleTop + 0.05f) {
            ruleTop = 0.08f;
            ruleBottom = 0.92f;
        }

        if (pdfView != null) {
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
            pdfView.setRuleColor(getUtilityColorRgb(COLOR_TARGET_RULE));
        }

        if (textRepository != null) {
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        updateRulesButton();
    }

    private void toggleRules() {
        rulesEnabled = !rulesEnabled;
        saveRules(rulesEnabled, ruleTop, ruleBottom);

        if (pdfView != null) {
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        if (textRepository != null) {
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
            refreshTextCacheForRules();
        }

        updateRulesButton();
        Toast.makeText(this, rulesEnabled ? "Reglas activadas. Arrastra las líneas." : "Reglas desactivadas", Toast.LENGTH_SHORT).show();
    }


    private void refreshTextCacheForRules() {
        if (textRepository == null || currentFile == null || pageCount <= 0) return;
        fullIndexRequested = false;
        final int page = Math.max(0, Math.min(currentPage, pageCount - 1));
        TtsForegroundService.clearPages();
        // Mantiene exactamente el recorte entre las dos reglas, pero vuelve a dar
        // prioridad a la pagina visible antes de reconstruir el resto del cache.
        preparePageForInstantPlay(page, true);
    }

    private void saveRules(boolean enabled, float top, float bottom) {
        rulesEnabled = enabled;
        ruleTop = top;
        ruleBottom = bottom;
        prefs.edit()
                .putBoolean("rules_enabled", enabled)
                .putFloat("rule_top", top)
                .putFloat("rule_bottom", bottom)
                .apply();
        updateRulesButton();
    }

    private void updateRulesButton() {
        if (rulesButton != null) {
            rulesButton.setText(rulesEnabled ? "Reglas ON" : "Reglas OFF");
        }
    }


    private void toggleReadingMarker() {
        readingMarkerEnabled = !readingMarkerEnabled;
        prefs.edit().putBoolean(PREF_READING_MARKER_ENABLED, readingMarkerEnabled).apply();
        if (pdfView != null) {
            pdfView.setReadingMarkerEnabled(readingMarkerEnabled);
            pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
        }
        if (readingMarkerEnabled) {
            if (selectionRepository != null && currentFile != null) selectionRepository.open(currentFile);
            loadSelectionForPage(currentPage);
            if (pdfView != null) pdfView.clearReadingMarker();

            // Si la lectura ya estaba a mitad de página, solicita al servicio la
            // frase/rango actual en vez de reutilizar una posición antigua o esperar
            // al siguiente cambio de página.
            if (playbackState == TtsForegroundService.STATE_PLAYING
                    || playbackState == TtsForegroundService.STATE_PAUSED
                    || playbackState == TtsForegroundService.STATE_PREPARING) {
                Intent report = new Intent(this, TtsForegroundService.class);
                report.setAction(TtsForegroundService.ACTION_REPORT_RANGE);
                startService(report);
            }
        } else {
            cancelPendingReadingMarker();
            if (pdfView != null) pdfView.clearReadingMarker();
            // Las coordenadas de la página se conservan para que Subrayar ON
            // responda inmediatamente aunque el seguimiento esté apagado.
        }
    }

    private void schedulePendingReadingMarker() {
        if (!readingMarkerEnabled || pdfView == null) return;
        if (readingMarkerUpdateTask == null) {
            readingMarkerUpdateTask = new Runnable() {
                @Override
                public void run() {
                    readingMarkerUpdateScheduled = false;
                    applyPendingReadingMarker();
                }
            };
        }
        if (readingMarkerUpdateScheduled) return;
        readingMarkerUpdateScheduled = true;
        readingMarkerHandler.postDelayed(readingMarkerUpdateTask, 16L);
    }

    private void cancelPendingReadingMarker() {
        if (readingMarkerUpdateTask != null) {
            readingMarkerHandler.removeCallbacks(readingMarkerUpdateTask);
        }
        readingMarkerUpdateScheduled = false;
    }

    private void applyPendingReadingMarker() {
        if (!readingMarkerEnabled || pdfView == null || pendingReadingPage < 0
                || pendingReadingChunk == null || pendingReadingChunk.length() == 0) return;
        if (pendingReadingPage != currentPage) return;
        pdfView.setReadingMarkerEnabled(true);
        pdfView.setReadingMarkerColor(getUtilityColorRgb(COLOR_TARGET_READING_MARKER));
        pdfView.updateReadingMarker(pendingReadingPage, pendingReadingChunk, pendingReadingChunkIndex,
                pendingReadingRangeStart, pendingReadingRangeEnd);
    }

    private int getUtilityColorRgb(int target) {
        if (target == COLOR_TARGET_RULE) {
            return useCustomRuleColor ? customRuleRgb : MARK_COLOR_RGB[safeMarkColorIndex(ruleColorIndex)];
        }
        if (target == COLOR_TARGET_READING_MARKER) {
            return useCustomReadingMarkerColor ? customReadingMarkerRgb : MARK_COLOR_RGB[safeMarkColorIndex(readingMarkerColorIndex)];
        }
        return MARK_COLOR_RGB[3];
    }

    private String getUtilityQuickPrefix(int target) {
        return target == COLOR_TARGET_RULE ? "quick_rule_color_" : "quick_tracking_color_";
    }

    private boolean hasQuickUtilityColor(int target, int slot) {
        return prefs.getBoolean(getUtilityQuickPrefix(target) + "set_" + slot, false);
    }

    private int getQuickUtilityColor(int target, int slot) {
        return prefs.getInt(getUtilityQuickPrefix(target) + slot, 0x003B82F6) & 0x00FFFFFF;
    }

    private void saveQuickUtilityColor(int target, int slot, int color) {
        prefs.edit()
                .putInt(getUtilityQuickPrefix(target) + slot, color & 0x00FFFFFF)
                .putBoolean(getUtilityQuickPrefix(target) + "set_" + slot, true)
                .apply();
    }

    private void applyUtilityCustomColor(int target, int color) {
        color &= 0x00FFFFFF;
        SharedPreferences.Editor editor = prefs.edit();
        if (target == COLOR_TARGET_RULE) {
            customRuleRgb = color;
            useCustomRuleColor = true;
            editor.putInt(PREF_CUSTOM_RULE_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_RULE_COLOR, true);
            if (pdfView != null) pdfView.setRuleColor(color);
        } else {
            customReadingMarkerRgb = color;
            useCustomReadingMarkerColor = true;
            editor.putInt(PREF_CUSTOM_READING_MARKER_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_READING_MARKER_COLOR, true);
            if (pdfView != null) {
                pdfView.setReadingMarkerColor(color);
                schedulePendingReadingMarker();
            }
        }
        editor.apply();
        if (target == COLOR_TARGET_READING_MARKER) updateReadingMarkerSettingsSwatch();
    }

    private void showUtilityColorDialog(final int target, String title) {
        final int selected = target == COLOR_TARGET_RULE ? ruleColorIndex : readingMarkerColorIndex;
        final boolean usingCustom = target == COLOR_TARGET_RULE ? useCustomRuleColor : useCustomReadingMarkerColor;
        final int currentCustom = target == COLOR_TARGET_RULE ? customRuleRgb : customReadingMarkerRgb;

        LinearLayout container = makeDialogContainer();
        container.setGravity(Gravity.CENTER_HORIZONTAL);
        container.setPadding(dp(16), dp(10), dp(16), dp(12));

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView(title))
                .setView(container)
                .setNegativeButton("Cancelar", null)
                .create();

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(4);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setUseDefaultMargins(false);

        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                TextView swatch = new TextView(this);
                swatch.setGravity(Gravity.CENTER);
                swatch.setTypeface(Typeface.DEFAULT_BOLD);
                swatch.setTextSize(18);

                if (col == 0) {
                    final int quickSlot = row;
                    final boolean hasQuick = hasQuickUtilityColor(target, quickSlot);
                    final int quickColor = getQuickUtilityColor(target, quickSlot);
                    final boolean selectedQuick = usingCustom && hasQuick && currentCustom == quickColor;
                    swatch.setText(hasQuick ? (selectedQuick ? "✓" : "") : "+");
                    swatch.setTextColor(hasQuick
                            ? (isDarkSwatch(quickColor) ? Color.WHITE : Color.BLACK)
                            : (darkTheme ? Color.WHITE : Color.rgb(30, 41, 59)));
                    swatch.setContentDescription(hasQuick
                            ? "Color personalizado " + (quickSlot + 1)
                            : "Crear color personalizado " + (quickSlot + 1));
                    swatch.setBackground(buildMarkSwatchDrawable(hasQuick ? quickColor : -1, selectedQuick));
                    swatch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            if (hasQuick) applyUtilityCustomColor(target, quickColor);
                            else showCustomUtilityColorDialog(target, quickSlot);
                        }
                    });
                    swatch.setOnLongClickListener(new View.OnLongClickListener() {
                        @Override
                        public boolean onLongClick(View v) {
                            dialog.dismiss();
                            showCustomUtilityColorDialog(target, quickSlot);
                            return true;
                        }
                    });
                } else {
                    final int presetIndex = row * 3 + (col - 1);
                    final int presetColor = MARK_COLOR_RGB[presetIndex];
                    final boolean selectedPreset = !usingCustom && presetIndex == selected;
                    swatch.setText(selectedPreset ? "✓" : "");
                    swatch.setTextColor(isDarkSwatch(presetColor) ? Color.WHITE : Color.BLACK);
                    swatch.setBackground(buildMarkSwatchDrawable(presetColor, selectedPreset));
                    swatch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            SharedPreferences.Editor editor = prefs.edit();
                            if (target == COLOR_TARGET_RULE) {
                                ruleColorIndex = safeMarkColorIndex(presetIndex);
                                useCustomRuleColor = false;
                                editor.putInt(PREF_RULE_COLOR, ruleColorIndex)
                                        .putBoolean(PREF_USE_CUSTOM_RULE_COLOR, false);
                                if (pdfView != null) pdfView.setRuleColor(presetColor);
                            } else {
                                readingMarkerColorIndex = safeMarkColorIndex(presetIndex);
                                useCustomReadingMarkerColor = false;
                                editor.putInt(PREF_READING_MARKER_COLOR, readingMarkerColorIndex)
                                        .putBoolean(PREF_USE_CUSTOM_READING_MARKER_COLOR, false);
                                if (pdfView != null) {
                                    pdfView.setReadingMarkerColor(presetColor);
                                    schedulePendingReadingMarker();
                                }
                            }
                            editor.apply();
                            if (target == COLOR_TARGET_READING_MARKER) updateReadingMarkerSettingsSwatch();
                            dialog.dismiss();
                        }
                    });
                }

                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = dp(60);
                lp.height = dp(60);
                lp.setMargins(dp(6), dp(6), dp(6), dp(6));
                grid.addView(swatch, lp);
            }
        }

        container.addView(grid, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        dialog.show();
        styleDialog(dialog);
    }

    private void showCustomUtilityColorDialog(final int target) {
        showCustomUtilityColorDialog(target, -1);
    }

    private void showCustomUtilityColorDialog(final int target, final int quickSlot) {
        final int initial = quickSlot >= 0 && hasQuickUtilityColor(target, quickSlot)
                ? getQuickUtilityColor(target, quickSlot)
                : (target == COLOR_TARGET_RULE ? customRuleRgb : customReadingMarkerRgb);

        LinearLayout box = makeDialogContainer();
        box.setPadding(dp(16), dp(12), dp(16), dp(14));

        final ProfessionalColorPickerView picker = new ProfessionalColorPickerView(this);
        picker.setColor(initial);
        box.addView(picker, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(205)));

        final HueSliderView hueSlider = new HueSliderView(this);
        hueSlider.setHue(picker.getHue());
        LinearLayout.LayoutParams hueLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(30));
        hueLp.setMargins(0, dp(10), 0, 0);
        box.addView(hueSlider, hueLp);

        final TextView sample = new TextView(this);
        sample.setTextSize(20);
        sample.setTypeface(Typeface.DEFAULT_BOLD);
        sample.setGravity(Gravity.CENTER);
        sample.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams sampleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(60));
        sampleLp.setMargins(0, dp(10), 0, 0);
        box.addView(sample, sampleLp);

        final GradientDrawable sampleBg = new GradientDrawable();
        sampleBg.setCornerRadius(dp(14));
        sampleBg.setStroke(dp(1), darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        sample.setBackground(sampleBg);

        final boolean[] sampleUpdatePending = new boolean[]{false};
        final Runnable update = new Runnable() {
            @Override
            public void run() {
                sampleUpdatePending[0] = false;
                int color = picker.getSelectedColor() & 0x00FFFFFF;
                sample.setText(String.format(Locale.US, "#%06X", color));
                sample.setTextColor(isDarkSwatch(color) ? Color.WHITE : Color.BLACK);
                sampleBg.setColor(0xFF000000 | color);
            }
        };

        picker.setOnColorChangedListener(new ProfessionalColorPickerView.OnColorChangedListener() {
            @Override
            public void onColorChanged(int color) {
                if (!sampleUpdatePending[0]) {
                    sampleUpdatePending[0] = true;
                    sample.postOnAnimation(update);
                }
            }
        });
        hueSlider.setOnHueChangedListener(new HueSliderView.OnHueChangedListener() {
            @Override
            public void onHueChanged(float hue) {
                picker.setHue(hue);
            }
        });
        update.run();

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Color personalizado"))
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int color = picker.getSelectedColor() & 0x00FFFFFF;
                        if (quickSlot >= 0) saveQuickUtilityColor(target, quickSlot, color);
                        applyUtilityCustomColor(target, color);
                    }
                }).create();
        dialog.show();
        styleDialog(dialog);
    }

    private void toggleMarkMode() {
        markMode = !markMode;
        if (pdfView != null) pdfView.setMarkMode(markMode);
        if (markMode) {
            if (selectionRepository != null && currentFile != null) {
                selectionRepository.open(currentFile);
            }
            loadSelectionForPage(currentPage);
            prefetchAroundCurrentPage();
        } else {
            // El repositorio permanece abierto para que un nuevo ON sea inmediato.
            // Solo se cancela una selección incompleta dentro de PdfPageView.
        }
        updateMarkControls();

        String message;
        if (!markMode) {
            message = "Marcado apagado";
        } else if (isHighlightStyle(markStyle)) {
            message = "Resaltado activo. Arrastra sobre el texto";
        } else {
            message = "Subrayado activo. Arrastra sobre el texto";
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void showMarkStyleDialog() {
        if (settingsScrollView != null) settingsScrollY = settingsScrollView.getScrollY();

        final int[] styles = new int[]{
                MARK_STYLE_UNDERLINE_FINE,
                MARK_STYLE_UNDERLINE_DOUBLE,
                MARK_STYLE_UNDERLINE_WAVY,
                MARK_STYLE_UNDERLINE_DOTTED,
                MARK_STYLE_HIGHLIGHT_SOFT,
                MARK_STYLE_HIGHLIGHT_INTENSE
        };

        LinearLayout container = makeDialogContainer();
        container.setPadding(dp(10), dp(8), dp(10), dp(4));

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Tipo de marcado"))
                .setView(container)
                .setNegativeButton("Cancelar", null)
                .create();

        for (int i = 0; i < styles.length; i++) {
            final int style = styles[i];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(8), dp(8), dp(8));
            GradientDrawable rowBg = new GradientDrawable();
            rowBg.setCornerRadius(dp(14));
            rowBg.setColor(darkTheme ? Color.rgb(9, 31, 47) : Color.rgb(248, 250, 252));
            row.setBackground(rowBg);

            View preview = createDialogMarkStylePreview(style);

            TextView check = new TextView(this);
            check.setText(style == markStyle ? "◉" : "○");
            check.setTextSize(24);
            check.setTextColor(style == markStyle ? Color.rgb(59, 130, 246) : Color.rgb(148, 163, 184));
            check.setGravity(Gravity.CENTER);

            row.addView(preview, new LinearLayout.LayoutParams(0, dp(84), 1));
            row.addView(check, new LinearLayout.LayoutParams(dp(44), dp(44)));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    setMarkStyle(style);
                    dialog.dismiss();
                    if (settingsMode) buildSettingsScreen();
                }
            });
            addRowWithMargin(container, row);
        }

        dialog.show();
        styleDialog(dialog);
    }

    private String getMarkStyleNameForDialog(int style) {
        switch (style) {
            case MARK_STYLE_UNDERLINE_DOUBLE: return "Subrayado doble";
            case MARK_STYLE_UNDERLINE_WAVY: return "Subrayado ondulado";
            case MARK_STYLE_UNDERLINE_DOTTED: return "Subrayado punteado";
            case MARK_STYLE_UNDERLINE_FINE:
            default: return "Subrayado simple";
        }
    }

    private void showMarkThicknessDialog() {
        if (settingsScrollView != null) settingsScrollY = settingsScrollView.getScrollY();

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(10), dp(8), dp(10), dp(4));

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Grosor del subrayado"))
                .setView(container)
                .setNegativeButton("Cancelar", null)
                .create();

        for (int level = 0; level <= 2; level++) {
            final int selectedLevel = level;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            GradientDrawable rowBg = new GradientDrawable();
            rowBg.setCornerRadius(dp(12));
            rowBg.setColor(darkTheme ? Color.rgb(9, 31, 47) : Color.rgb(248, 250, 252));
            row.setBackground(rowBg);

            LinearLayout preview = createDialogSampleCard();
            View line = new View(this);
            GradientDrawable lineShape = new GradientDrawable();
            lineShape.setColor(Color.BLACK);
            lineShape.setCornerRadius(dp(3));
            line.setBackground(lineShape);
            preview.addView(line, new LinearLayout.LayoutParams(dp(132), getPreviewLineThickness(level)));

            TextView check = new TextView(this);
            check.setText(level == markThicknessLevel ? "◉" : "○");
            check.setTextSize(24);
            check.setTextColor(level == markThicknessLevel ? Color.rgb(59, 130, 246) : Color.rgb(148, 163, 184));
            check.setGravity(Gravity.CENTER);

            row.addView(preview, new LinearLayout.LayoutParams(0, dp(70), 1));
            row.addView(check, new LinearLayout.LayoutParams(dp(44), dp(44)));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    markThicknessLevel = safeThicknessLevel(selectedLevel);
                    prefs.edit().putInt(PREF_MARK_THICKNESS, markThicknessLevel).apply();
                    applyMarkAppearance();
                    dialog.dismiss();
                    if (settingsMode) buildSettingsScreen();
                }
            });
            addRowWithMargin(container, row);
        }

        dialog.show();
        styleDialog(dialog);
    }

    private LinearLayout createDialogSampleCard() {
        LinearLayout preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.VERTICAL);
        preview.setGravity(Gravity.CENTER);
        preview.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable previewBg = new GradientDrawable();
        previewBg.setCornerRadius(dp(10));
        previewBg.setColor(Color.WHITE);
        previewBg.setStroke(dp(1), Color.rgb(226, 232, 240));
        preview.setBackground(previewBg);
        return preview;
    }

    private View createDialogMarkStylePreview(int style) {
        LinearLayout preview = createDialogSampleCard();

        if (style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE) {
            TextView sample = new TextView(this);
            sample.setText("Ejemplo");
            sample.setTextSize(17);
            sample.setTypeface(Typeface.DEFAULT_BOLD);
            sample.setTextColor(Color.BLACK);
            sample.setGravity(Gravity.CENTER);
            applySampleDecoration(sample, style, getPreviewColorForStyle(style));
            preview.addView(sample, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            return preview;
        }

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView sample = new TextView(this);
        sample.setText("Ejemplo");
        sample.setTextSize(17);
        sample.setTypeface(Typeface.DEFAULT_BOLD);
        sample.setTextColor(Color.BLACK);
        sample.setGravity(Gravity.CENTER);
        content.addView(sample, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        View line = createPreviewUnderlineView(style, markThicknessLevel, getPreviewColorForStyle(style), dp(118));
        LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lineParams.topMargin = dp(2);
        content.addView(line, lineParams);

        preview.addView(content, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return preview;
    }

    private int getPreviewColorForStyle(int style) {
        int target = isHighlightStyle(style) ? COLOR_TARGET_HIGHLIGHT : COLOR_TARGET_UNDERLINE;
        int index = target == COLOR_TARGET_HIGHLIGHT ? highlightColorIndex : underlineColorIndex;
        return getMarkColor(target, index);
    }

    private void showAudioExportDialog() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout box = makeDialogContainer();
        box.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView recordButton = new TextView(this);
        recordButton.setText("●");
        recordButton.setTextSize(48);
        recordButton.setGravity(Gravity.CENTER);
        recordButton.setTextColor(Color.WHITE);
        GradientDrawable recordBg = new GradientDrawable();
        recordBg.setShape(GradientDrawable.OVAL);
        recordBg.setColor(Color.rgb(220, 38, 38));
        recordBg.setStroke(dp(5), Color.rgb(254, 202, 202));
        recordButton.setBackground(recordBg);
        recordButton.setContentDescription("Crear audio");
        box.addView(recordButton, new LinearLayout.LayoutParams(dp(92), dp(92)));

        TextView info = new TextView(this);
        info.setText("Toca el botón para la página actual o elige otra opción");
        info.setTextSize(15);
        info.setTypeface(Typeface.DEFAULT_BOLD);
        info.setGravity(Gravity.CENTER);
        info.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        info.setPadding(0, dp(10), 0, dp(3));
        box.addView(info);

        TextView folder = new TextView(this);
        folder.setText("Se guardará en  Geo Zeta / Audios");
        folder.setTextSize(12);
        folder.setGravity(Gravity.CENTER);
        folder.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        folder.setPadding(0, 0, 0, dp(10));
        box.addView(folder);

        Button current = makeRecorderOptionButton("Página actual", "Crear un audio de la página visible");
        Button full = makeRecorderOptionButton("Todo el PDF", "Crear audios organizados por páginas");
        Button range = makeRecorderOptionButton("Elegir rango", "Por ejemplo: páginas 14 a 300");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64));
        lp.setMargins(0, dp(5), 0, dp(5));
        box.addView(current, lp);
        box.addView(full, lp);
        box.addView(range, lp);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Crear audio"))
                .setView(box)
                .setNegativeButton("Cerrar", null)
                .create();

        recordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                startAudioExportRange(currentPage, currentPage);
            }
        });

        current.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                startAudioExportRange(currentPage, currentPage);
            }
        });
        full.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                startAudioExportRange(0, pageCount - 1);
            }
        });
        range.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                showAudioRangeDialog();
            }
        });

        dialog.show();
        styleDialog(dialog);
    }

    private Button makeRecorderOptionButton(String title, String subtitle) {
        Button button = new Button(this);
        button.setText(title + "\n" + subtitle);
        button.setTextSize(13);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        button.setPadding(dp(16), dp(6), dp(12), dp(6));
        button.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(darkTheme ? Color.rgb(12, 35, 54) : Color.rgb(248, 250, 252));
        bg.setStroke(dp(1), darkTheme ? Color.rgb(24, 72, 101) : Color.rgb(203, 213, 225));
        button.setBackground(bg);
        return button;
    }

    private void showAudioRangeDialog() {
        LinearLayout box = makeDialogContainer();

        final EditText startInput = new EditText(this);
        startInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        startInput.setHint("Desde (1 - " + pageCount + ")");
        startInput.setText(String.valueOf(currentPage + 1));
        startInput.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        startInput.setHintTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        final EditText endInput = new EditText(this);
        endInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        endInput.setHint("Hasta (1 - " + pageCount + ")");
        endInput.setText(String.valueOf(currentPage + 1));
        endInput.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        endInput.setHintTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        box.addView(startInput);
        box.addView(endInput);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Elegir rango"))
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Crear", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int start;
                        int end;
                        try {
                            start = Integer.parseInt(startInput.getText().toString().trim()) - 1;
                            end = Integer.parseInt(endInput.getText().toString().trim()) - 1;
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Rango inválido", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        startAudioExportRange(start, end);
                    }
                })
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void startAudioExportRange(int startPage, int endPage) {
        if (currentFile == null || pageCount <= 0) return;

        int start = Math.max(0, Math.min(startPage, pageCount - 1));
        int end = Math.max(0, Math.min(endPage, pageCount - 1));
        if (end < start) {
            int tmp = start;
            start = end;
            end = tmp;
        }

        exportStartPage = start;
        exportEndPage = end;
        exportCurrentPage = start;
        exportSavedCount = 0;
        lastExportedAudioFile = null;
        exportAudioBase = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
        exportAudioDir = new File(getAudioSaveDir(), exportAudioBase + "_P" + (start + 1) + "_a_" + (end + 1));
        if (!exportAudioDir.exists()) exportAudioDir.mkdirs();

        Toast.makeText(this, "Preparando exportación de audio...", Toast.LENGTH_SHORT).show();
        ensureExportTtsAndExportNext();
    }

    private void ensureExportTtsAndExportNext() {
        if (exportTts != null) {
            exportNextPageAudio();
            return;
        }

        exportTts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.SUCCESS) {
                    Toast.makeText(MainActivity.this, "No se pudo iniciar voz", Toast.LENGTH_LONG).show();
                    return;
                }
                exportTts.setLanguage(new Locale("es", "PE"));
                exportTts.setSpeechRate(speechRate);
                exportTts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) { }

                    @Override
                    public void onDone(String utteranceId) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                exportSavedCount++;
                                exportCurrentPage++;
                                exportNextPageAudio();
                            }
                        });
                    }

                    @Override
                    public void onError(String utteranceId) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                exportCurrentPage++;
                                exportNextPageAudio();
                            }
                        });
                    }
                });
                exportNextPageAudio();
            }
        });
    }

    private void exportNextPageAudio() {
        if (exportCurrentPage < 0 || exportCurrentPage > exportEndPage) {
            showAudioExportCompleted();
            return;
        }

        final int page = exportCurrentPage;
        textRepository.getPageText(page, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                if (text == null || text.trim().length() == 0) {
                    exportCurrentPage++;
                    exportNextPageAudio();
                    return;
                }

                String safeText = text.trim();
                if (safeText.length() > 12000) safeText = safeText.substring(0, 12000);
                File out = new File(exportAudioDir, exportAudioBase + "_pagina_" + (page + 1) + ".wav");
                lastExportedAudioFile = out;
                String utteranceId = "EXPORT_" + page + "_" + System.currentTimeMillis();
                int result;
                if (Build.VERSION.SDK_INT >= 21) {
                    result = exportTts.synthesizeToFile(safeText, null, out, utteranceId);
                } else {
                    result = TextToSpeech.ERROR;
                }
                if (result != TextToSpeech.SUCCESS) {
                    exportCurrentPage++;
                    exportNextPageAudio();
                }
            }
        });
    }

    private void showMarkColorDialog(final int target) {
        final int selected = target == COLOR_TARGET_HIGHLIGHT ? highlightColorIndex : underlineColorIndex;
        final boolean usingCustom = target == COLOR_TARGET_HIGHLIGHT ? useCustomHighlightColor : useCustomUnderlineColor;
        final int currentCustom = target == COLOR_TARGET_HIGHLIGHT ? customHighlightRgb : customUnderlineRgb;
        final String title = target == COLOR_TARGET_HIGHLIGHT ? "Color del resaltado" : "Color del subrayado";

        LinearLayout container = makeDialogContainer();
        container.setGravity(Gravity.CENTER_HORIZONTAL);
        container.setPadding(dp(16), dp(10), dp(16), dp(12));


        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView(title))
                .setView(container)
                .setNegativeButton("Cancelar", null)
                .create();

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(4);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setUseDefaultMargins(false);

        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                TextView swatch = new TextView(this);
                swatch.setGravity(Gravity.CENTER);
                swatch.setTypeface(Typeface.DEFAULT_BOLD);
                swatch.setTextSize(18);

                if (col == 0) {
                    if (row < QUICK_MARK_SLOT_COUNT) {
                        final int quickSlot = row;
                        final boolean hasQuick = hasQuickMarkColor(quickSlot);
                        final int quickColor = getQuickMarkColor(quickSlot);
                        final boolean selectedQuick = usingCustom && hasQuick && currentCustom == quickColor;
                        swatch.setText(hasQuick ? (selectedQuick ? "✓" : "") : "+");
                        swatch.setTextColor(hasQuick
                                ? (isDarkSwatch(quickColor) ? Color.WHITE : Color.BLACK)
                                : (darkTheme ? Color.WHITE : Color.rgb(30, 41, 59)));
                        swatch.setContentDescription(hasQuick
                                ? "Color personalizado " + (quickSlot + 1)
                                : "Crear color personalizado " + (quickSlot + 1));
                        swatch.setBackground(buildMarkSwatchDrawable(hasQuick ? quickColor : -1, selectedQuick));
                        swatch.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                                if (hasQuick) applyQuickMarkColor(target, quickColor);
                                else showCustomColorDialog(target, quickSlot);
                            }
                        });
                        swatch.setOnLongClickListener(new View.OnLongClickListener() {
                            @Override
                            public boolean onLongClick(View v) {
                                dialog.dismiss();
                                showCustomColorDialog(target, quickSlot);
                                return true;
                            }
                        });
                    }
                } else {
                    final int presetIndex = row * 3 + (col - 1);
                    final int presetColor = MARK_COLOR_RGB[presetIndex];
                    final boolean selectedPreset = !usingCustom && presetIndex == selected;
                    swatch.setText(selectedPreset ? "✓" : "");
                    swatch.setTextColor(isDarkSwatch(presetColor) ? Color.WHITE : Color.BLACK);
                    swatch.setContentDescription("Color base " + (presetIndex + 1));
                    swatch.setBackground(buildMarkSwatchDrawable(presetColor, selectedPreset));
                    swatch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int safe = safeMarkColorIndex(presetIndex);
                            SharedPreferences.Editor editor = prefs.edit();
                            if (target == COLOR_TARGET_HIGHLIGHT) {
                                highlightColorIndex = safe;
                                useCustomHighlightColor = false;
                                editor.putInt(PREF_HIGHLIGHT_COLOR, safe)
                                        .putBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, false);
                            } else {
                                underlineColorIndex = safe;
                                useCustomUnderlineColor = false;
                                editor.putInt(PREF_UNDERLINE_COLOR, safe)
                                        .putBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, false);
                            }
                            editor.apply();
                            applyMarkAppearance();
                            dialog.dismiss();
                        }
                    });
                }

                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = dp(60);
                lp.height = dp(60);
                lp.setMargins(dp(6), dp(6), dp(6), dp(6));
                grid.addView(swatch, lp);
            }
        }

        container.addView(grid, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        dialog.show();
        styleDialog(dialog);
    }

    private GradientDrawable buildMarkSwatchDrawable(int color, boolean selected) {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.OVAL);
        if (color >= 0) {
            shape.setColor(0xFF000000 | (color & 0x00FFFFFF));
        } else {
            shape.setColor(darkTheme ? Color.rgb(16, 45, 66) : Color.rgb(226, 239, 255));
        }
        shape.setStroke(dp(selected ? 3 : 1), selected
                ? Color.rgb(59, 130, 246)
                : (darkTheme ? Color.WHITE : Color.rgb(71, 85, 105)));
        return shape;
    }

    private boolean hasQuickMarkColor(int slot) {
        return prefs.getBoolean("quick_mark_color_set_" + slot, false);
    }

    private int getQuickMarkColor(int slot) {
        return prefs.getInt("quick_mark_color_" + slot, 0x00FFD400) & 0x00FFFFFF;
    }

    private void saveQuickMarkColor(int slot, int color) {
        prefs.edit()
                .putInt("quick_mark_color_" + slot, color & 0x00FFFFFF)
                .putBoolean("quick_mark_color_set_" + slot, true)
                .apply();
    }

    private void applyQuickMarkColor(int target, int color) {
        color &= 0x00FFFFFF;
        SharedPreferences.Editor editor = prefs.edit();
        if (target == COLOR_TARGET_HIGHLIGHT) {
            customHighlightRgb = color;
            useCustomHighlightColor = true;
            editor.putInt(PREF_CUSTOM_HIGHLIGHT_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, true);
        } else {
            customUnderlineRgb = color;
            useCustomUnderlineColor = true;
            editor.putInt(PREF_CUSTOM_UNDERLINE_COLOR, color)
                    .putBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, true);
        }
        editor.apply();
        applyMarkAppearance();
    }

    private void showCustomColorDialog(final int target) {
        showCustomColorDialog(target, -1);
    }

    private void showCustomColorDialog(final int target, final int quickSlot) {
        final int initial = quickSlot >= 0 && hasQuickMarkColor(quickSlot)
                ? getQuickMarkColor(quickSlot)
                : (target == COLOR_TARGET_HIGHLIGHT ? customHighlightRgb : customUnderlineRgb);

        LinearLayout box = makeDialogContainer();
        box.setPadding(dp(16), dp(12), dp(16), dp(14));

        final ProfessionalColorPickerView picker = new ProfessionalColorPickerView(this);
        picker.setColor(initial);
        box.addView(picker, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(205)));

        final HueSliderView hueSlider = new HueSliderView(this);
        hueSlider.setHue(picker.getHue());
        LinearLayout.LayoutParams hueLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(30));
        hueLp.setMargins(0, dp(10), 0, 0);
        box.addView(hueSlider, hueLp);

        final TextView sample = new TextView(this);
        sample.setTextSize(20);
        sample.setTypeface(Typeface.DEFAULT_BOLD);
        sample.setGravity(Gravity.CENTER);
        sample.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams sampleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(60));
        sampleLp.setMargins(0, dp(10), 0, 0);
        box.addView(sample, sampleLp);

        final GradientDrawable sampleBg = new GradientDrawable();
        sampleBg.setCornerRadius(dp(14));
        sampleBg.setStroke(dp(1), darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));
        sample.setBackground(sampleBg);

        final boolean[] sampleUpdatePending = new boolean[]{false};
        final Runnable update = new Runnable() {
            @Override
            public void run() {
                sampleUpdatePending[0] = false;
                int color = picker.getSelectedColor() & 0x00FFFFFF;
                sample.setText(String.format(Locale.US, "#%06X", color));
                sample.setTextColor(isDarkSwatch(color) ? Color.WHITE : Color.BLACK);
                sampleBg.setColor(0xFF000000 | color);
            }
        };

        picker.setOnColorChangedListener(new ProfessionalColorPickerView.OnColorChangedListener() {
            @Override
            public void onColorChanged(int color) {
                if (!sampleUpdatePending[0]) {
                    sampleUpdatePending[0] = true;
                    sample.postOnAnimation(update);
                }
            }
        });
        hueSlider.setOnHueChangedListener(new HueSliderView.OnHueChangedListener() {
            @Override
            public void onHueChanged(float hue) {
                picker.setHue(hue);
            }
        });
        update.run();

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setCustomTitle(makeDialogTitleView("Color personalizado"))
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int color = picker.getSelectedColor() & 0x00FFFFFF;
                        SharedPreferences.Editor editor = prefs.edit();
                        if (quickSlot >= 0) {
                            saveQuickMarkColor(quickSlot, color);
                        }
                        if (target == COLOR_TARGET_HIGHLIGHT) {
                            customHighlightRgb = color;
                            useCustomHighlightColor = true;
                            editor.putInt(PREF_CUSTOM_HIGHLIGHT_COLOR, color)
                                    .putBoolean(PREF_USE_CUSTOM_HIGHLIGHT_COLOR, true);
                        } else {
                            customUnderlineRgb = color;
                            useCustomUnderlineColor = true;
                            editor.putInt(PREF_CUSTOM_UNDERLINE_COLOR, color)
                                    .putBoolean(PREF_USE_CUSTOM_UNDERLINE_COLOR, true);
                        }
                        editor.apply();
                        applyMarkAppearance();
                    }
                }).create();
        dialog.show();
        styleDialog(dialog);
    }

    private SeekBar createColorSeekBar(LinearLayout parent, String label, int value) {
        TextView title = new TextView(this);
        title.setText(label);
        title.setTextSize(13);
        title.setTextColor(darkTheme ? Color.rgb(203, 213, 225) : Color.rgb(71, 85, 105));
        parent.addView(title);

        SeekBar seek = new SeekBar(this);
        seek.setMax(255);
        seek.setProgress(Math.max(0, Math.min(255, value)));
        parent.addView(seek, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)));
        return seek;
    }

    private boolean isDarkSwatch(int rgb) {
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        return (r * 299 + g * 587 + b * 114) / 1000 < 145;
    }

    private void setMarkStyle(int style) {
        markStyle = safeMarkStyle(style);
        prefs.edit().putInt(PREF_MARK_STYLE, markStyle).apply();
        applyMarkAppearance();
    }

    private void applyMarkAppearance() {
        if (pdfView != null) {
            pdfView.setMarkStyle(markStyle);
            pdfView.setMarkThickness(markThicknessLevel);
            pdfView.setMarkColor(getCurrentMarkColor());
        }
        updateMarkControls();
    }

    private void updateMarkControls() {
        if (markButton != null) {
            markButton.setText(markMode ? "Subrayar ON" : "Subrayar OFF");
            markButton.setAlpha(markMode ? 1f : 0.78f);
            markButton.setContentDescription(markMode
                    ? "Subrayado activado: un dedo marca y dos dedos mueven"
                    : "Subrayado desactivado");
        }
        if (colorButton != null) {
            colorButton.setText("●");
            colorButton.setTextColor(0xFF000000 | (getCurrentMarkColor() & 0x00FFFFFF));
            colorButton.setAlpha(1f);
        }
    }

    private String getMarkStyleName() {
        switch (markStyle) {
            case MARK_STYLE_UNDERLINE_DOUBLE: return "Subrayado doble";
            case MARK_STYLE_UNDERLINE_WAVY: return "Subrayado ondulado";
            case MARK_STYLE_UNDERLINE_DOTTED: return "Subrayado punteado";
            case MARK_STYLE_HIGHLIGHT_SOFT: return "Resaltado suave";
            case MARK_STYLE_HIGHLIGHT_INTENSE: return "Resaltado intenso";
            case MARK_STYLE_UNDERLINE_FINE:
            default: return "Subrayado fino";
        }
    }

    private String getThicknessName() {
        if (markThicknessLevel == 0) return "Fino";
        if (markThicknessLevel == 2) return "Grueso";
        return "Medio";
    }

    private boolean isHighlightStyle(int style) {
        return style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE;
    }

    private int getCurrentMarkColor() {
        int target = isHighlightStyle(markStyle) ? COLOR_TARGET_HIGHLIGHT : COLOR_TARGET_UNDERLINE;
        int index = target == COLOR_TARGET_HIGHLIGHT ? highlightColorIndex : underlineColorIndex;
        return getMarkColor(target, index);
    }

    private int getMarkColor(int target, int index) {
        int rgb;
        if (target == COLOR_TARGET_HIGHLIGHT && useCustomHighlightColor) {
            rgb = customHighlightRgb;
        } else if (target == COLOR_TARGET_UNDERLINE && useCustomUnderlineColor) {
            rgb = customUnderlineRgb;
        } else {
            rgb = MARK_COLOR_RGB[safeMarkColorIndex(index)];
        }
        int alpha;
        if (target == COLOR_TARGET_HIGHLIGHT) {
            alpha = markStyle == MARK_STYLE_HIGHLIGHT_INTENSE ? 0xA8 : 0x62;
        } else {
            alpha = 0xEE;
        }
        return (alpha << 24) | (rgb & 0x00FFFFFF);
    }

    private int safeMarkStyle(int style) {
        if (style == MARK_STYLE_TEXT_BOX) return MARK_STYLE_UNDERLINE_FINE;
        if (style < MARK_STYLE_UNDERLINE_FINE || style > MARK_STYLE_HIGHLIGHT_INTENSE) {
            return MARK_STYLE_UNDERLINE_FINE;
        }
        return style;
    }

    private int safeThicknessLevel(int level) {
        if (level < 0 || level > 2) return 1;
        return level;
    }

    private int migrateV71ColorIndex(int oldIndex) {
        switch (oldIndex) {
            case 1: return 3; // azul
            case 2: return 4; // verde
            case 3: return 1; // rojo
            case 4: return 6; // morado
            case 5: return 7; // celeste
            case 0:
            default: return 0;
        }
    }

    private int safeMarkColorIndex(int index) {
        if (index < 0 || index >= MARK_COLOR_RGB.length) return 0;
        return index;
    }

    private String highlightKey() {
        String safeTitle = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
        String safeFile = currentFile == null ? "nofile" : String.valueOf(currentFile.getAbsolutePath().hashCode());
        return "text_selection_markers_" + safeTitle + "_" + safeFile;
    }

    private String legacyHighlightKey() {
        return "text_selection_markers_" + currentTitle;
    }

    private void saveHighlights(String serialized) {
        prefs.edit().putString(highlightKey(), serialized == null ? "" : serialized).apply();
    }

    private void repairBrokenPlaybackStateOnce() {
        if (prefs.getBoolean(PREF_AUDIO_STATE_REPAIRED_V69, false)) return;

        try {
            stopService(new Intent(this, TtsForegroundService.class));
        } catch (Exception ignored) {
        }

        TtsForegroundService.clearPages();
        prefs.edit()
                .putBoolean(PREF_TTS_ACTIVE, false)
                .putBoolean(PREF_TTS_PAUSED, false)
                .putInt(PREF_TTS_CURRENT_PAGE, -1)
                .putInt(PREF_TTS_STATE, TtsForegroundService.STATE_STOPPED)
                .putString(PREF_TTS_MESSAGE, "")
                .remove("tts_service_preparing")
                .putBoolean(PREF_AUDIO_STATE_REPAIRED_V69, true)
                .apply();

        playbackState = TtsForegroundService.STATE_STOPPED;
        audioStarted = false;
        audioPaused = false;
        audioPreparing = false;
        requestedAudioPage = -1;
        requestedAudioPageConfirmed = false;
        audioRequestToken++;
    }

    private void warmUpAudioEngine() {
        TtsEngineManager.getInstance(this).initialize(null);
        try {
            Intent warmup = new Intent(this, TtsForegroundService.class);
            warmup.setAction(TtsForegroundService.ACTION_WARMUP);
            startService(warmup);
        } catch (Exception ignored) {
        }
    }

    private void toggleAudio() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        if (playbackState == TtsForegroundService.STATE_PREPARING || audioPreparing) {
            // El segundo toque funciona como Pausa incluso si el motor aún está
            // preparando la primera frase. No se muestra un estado intermedio.
            seekAudioToPage(currentPage, false);
            return;
        }

        if (playbackState == TtsForegroundService.STATE_PLAYING) {
            Intent intent = new Intent(this, TtsForegroundService.class);
            intent.setAction(TtsForegroundService.ACTION_TOGGLE);
            startService(intent);
            return;
        }

        if (playbackState == TtsForegroundService.STATE_PAUSED) {
            int readingPage = prefs.getInt(PREF_TTS_CURRENT_PAGE, -1);
            if (readingPage == currentPage) {
                Intent intent = new Intent(this, TtsForegroundService.class);
                intent.setAction(TtsForegroundService.ACTION_TOGGLE);
                startService(intent);
            } else {
                seekAudioToPage(currentPage, true);
            }
            return;
        }

        startAudioFromPage(currentPage);
    }

    private void startAudioFromPage(final int pageToRead) {
        if (currentFile == null || pageCount <= 0) return;

        ensureNotificationPermission();
        cancelAudioPreparationTimeout();

        final int safePage = Math.max(0, Math.min(pageToRead, pageCount - 1));
        final int token = ++audioRequestToken;
        requestedAudioPage = safePage;
        requestedAudioPageConfirmed = false;
        applyPlaybackState(TtsForegroundService.STATE_PREPARING, safePage,
                "Preparando pagina " + (safePage + 1), false);

        String cached = textRepository.getCachedText(safePage);
        if (cached != null) {
            beginTtsWithText(safePage, cached, token);
            return;
        }

        // La extraccion urgente no se mezcla con una orden PREPARE adicional.
        // El motor ya se mantiene caliente desde que abre la app.
        textRepository.getPageTextPriority(safePage, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                if (token != audioRequestToken || requestedAudioPage != safePage) return;
                beginTtsWithText(safePage, text == null ? "" : text, token);
            }
        });

        audioStartTimeout = new Runnable() {
            @Override
            public void run() {
                if (token != audioRequestToken || !audioPreparing) return;
                failAudioPreparation("El PDF tardo demasiado en preparar esta pagina");
            }
        };
        audioStartHandler.postDelayed(audioStartTimeout, 12000L);
    }

    private void beginTtsWithText(final int safePage, String text, final int token) {
        if (token != audioRequestToken || requestedAudioPage != safePage) return;
        cancelAudioPreparationTimeout();
        TtsForegroundService.setPageText(safePage, text == null ? "" : text);

        Intent intent = new Intent(MainActivity.this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_START);
        intent.putExtra("title", currentTitle);
        intent.putExtra("pageOffset", safePage);
        intent.putExtra("totalPages", pageCount);
        intent.putExtra("startIndex", 0);
        intent.putExtra("rate", speechRate);
        intent.putExtra("pitch", 1.0f);

        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);

        // La precarga vecina empieza después de entregar la página actual al
        // servicio, y una nueva navegación cancela el trabajo anterior.
        applyPlaybackState(TtsForegroundService.STATE_PREPARING, safePage,
                "Iniciando pagina " + (safePage + 1), false);
        scheduleAudioNeighborPreload(safePage);
    }

    private void failAudioPreparation(String message) {
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = -1;
        requestedAudioPageConfirmed = false;
        applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1, message, false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void cancelAudioPreparation() {
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = -1;
        requestedAudioPageConfirmed = false;
        applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1, "Detenido", false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
    }

    private void cancelAudioPreparationTimeout() {
        if (audioStartTimeout != null) {
            audioStartHandler.removeCallbacks(audioStartTimeout);
            audioStartTimeout = null;
        }
    }

    private void stopAudioOnly() {
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = -1;
        requestedAudioPageConfirmed = false;
        applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1, "Detenido", false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
    }

    private void showGoto() {
        if (pageCount <= 0) return;

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setHint("Página 1 - " + pageCount);

        new AlertDialog.Builder(this)
                .setTitle("Ir a página")
                .setView(input)
                .setPositiveButton("Ir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            int p = Integer.parseInt(input.getText().toString()) - 1;
                            p = Math.max(0, Math.min(p, pageCount - 1));
                            requestManualPageChange(p);
                        } catch (Exception ignored) {
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void updatePageLabel() {
        if (pageCount <= 0) pageView.setText("0/0");
        else pageView.setText((currentPage + 1) + "/" + pageCount);
    }

    private void applyPlaybackState(int state, int readingPage, String message, boolean fromBroadcast) {
        if ((state == TtsForegroundService.STATE_PREPARING
                || state == TtsForegroundService.STATE_PLAYING)
                && requestedAudioPage >= 0 && readingPage >= 0
                && readingPage != requestedAudioPage
                && !requestedAudioPageConfirmed) {
            // Ignora estados antiguos mientras el servicio confirma la última
            // página elegida por el usuario.
            return;
        }

        playbackState = state;
        if (message == null) message = "";

        if (state == TtsForegroundService.STATE_PREPARING) {
            audioPreparing = true;
            audioStarted = false;
            audioPaused = false;
            if (playButton != null) playButton.setText("Ⅱ");
        } else if (state == TtsForegroundService.STATE_PLAYING) {
            cancelAudioPreparationTimeout();
            audioPreparing = false;
            audioStarted = true;
            audioPaused = false;
            if (playButton != null) playButton.setText("Ⅱ");
        } else if (state == TtsForegroundService.STATE_PAUSED) {
            cancelAudioPreparationTimeout();
            audioPreparing = false;
            audioStarted = true;
            audioPaused = true;
            if (playButton != null) playButton.setText("▶");
        } else {
            cancelAudioPreparationTimeout();
            audioPreparing = false;
            audioStarted = false;
            audioPaused = false;
            requestedAudioPage = -1;
            requestedAudioPageConfirmed = false;
            if (playButton != null) playButton.setText("▶");
        }

        if (state == TtsForegroundService.STATE_ERROR && fromBroadcast) {
            audioRequestToken++;
            requestedAudioPage = -1;
            requestedAudioPageConfirmed = false;
        }
        if (state == TtsForegroundService.STATE_PLAYING || state == TtsForegroundService.STATE_PREPARING || state == TtsForegroundService.STATE_PAUSED) {
            if (readingMarkerEnabled) loadSelectionForPage(Math.max(0, readingPage));
        } else if (pdfView != null) {
            pdfView.clearReadingMarker();
        }

        if (state == TtsForegroundService.STATE_ERROR && fromBroadcast
                && message.length() > 0 && !message.equals(lastPlaybackError)) {
            lastPlaybackError = message;
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        } else if (state != TtsForegroundService.STATE_ERROR) {
            lastPlaybackError = "";
        }

        if ((state == TtsForegroundService.STATE_PREPARING
                || state == TtsForegroundService.STATE_PLAYING)
                && requestedAudioPage >= 0 && readingPage >= 0) {
            if (readingPage != requestedAudioPage) {
                if (!requestedAudioPageConfirmed) {
                    return;
                }
                // La página solicitada ya fue confirmada por el servicio. Un
                // cambio posterior puede ser el salto silencioso de una ilustración.
                requestedAudioPage = -1;
                requestedAudioPageConfirmed = false;
            } else if (fromBroadcast) {
                requestedAudioPageConfirmed = true;
                if (state == TtsForegroundService.STATE_PLAYING) {
                    requestedAudioPage = -1;
                    requestedAudioPageConfirmed = false;
                }
            }
        }

        boolean readerOwnsPage = state == TtsForegroundService.STATE_PREPARING
                || state == TtsForegroundService.STATE_PLAYING;
        if (!readerOwnsPage || readingPage < 0 || currentFile == null || pageCount <= 0 || pdfView == null) {
            return;
        }

        final int safePage = Math.max(0, Math.min(readingPage, pageCount - 1));
        if (safePage == currentPage) return;

        restartAudioAfterRender = false;
        // El lector ya cambió de página: prepara únicamente la visible con
        // prioridad y una ventana pequeña. Evita indexar ocho páginas mientras
        // intenta empezar la siguiente frase.
        primeAudioPageForPlayback(safePage);
        currentPage = safePage;
        updatePageLabel();
        pdfView.showPage(safePage);
    }

    private void syncVisiblePageWithReader() {
        if (prefs == null) return;

        int state = prefs.getInt(PREF_TTS_STATE, -1);
        if (state < 0) {
            boolean active = prefs.getBoolean(PREF_TTS_ACTIVE, false);
            boolean paused = prefs.getBoolean(PREF_TTS_PAUSED, false);
            state = !active ? TtsForegroundService.STATE_STOPPED
                    : (paused ? TtsForegroundService.STATE_PAUSED : TtsForegroundService.STATE_PLAYING);
        }
        int readingPage = prefs.getInt(PREF_TTS_CURRENT_PAGE, -1);
        String message = prefs.getString(PREF_TTS_MESSAGE, "");
        applyPlaybackState(state, readingPage, message, false);
    }

    private void saveProgress() {
        prefs.edit().putInt("last_page", currentPage).putString("last_title", currentTitle).apply();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        if (imageViewerMode) {
            closeFullscreenImageViewer();
            return;
        }
        if (libraryMode) {
            closeFileLibrary();
            return;
        }
        if (settingsMode) {
            closeSettings();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        pageWorkToken++;
        if (pageWorkRunnable != null) pageWorkHandler.removeCallbacks(pageWorkRunnable);
        if (audioNeighborPreloadRunnable != null) {
            audioStartHandler.removeCallbacks(audioNeighborPreloadRunnable);
            audioNeighborPreloadRunnable = null;
        }
        imageExportExecutor.shutdownNow();
        imageDecodeExecutor.shutdownNow();
        if (imagePager != null) {
            imagePager.setAdapter(null);
            imagePager = null;
        }
        if (imagePagerAdapter != null) {
            imagePagerAdapter.release();
            imagePagerAdapter = null;
        }
        if (imageViewerBitmap != null && !imageViewerBitmap.isRecycled()) {
            imageViewerBitmap.recycle();
            imageViewerBitmap = null;
        }
        cancelAudioPreparationTimeout();
        stopFilePreview();
        stopPageSyncLoop();
        cancelPendingReadingMarker();
        unregisterPlaybackReceiver();
        super.onDestroy();
        saveProgress();
        // Si el audio sigue activo, el servicio conserva este repositorio para obtener
        // las paginas siguientes con la pantalla apagada.
        if (!prefs.getBoolean(PREF_TTS_ACTIVE, false) && textRepository != null) {
            textRepository.close();
        }
        if (selectionRepository != null) selectionRepository.close();
        if (exportTts != null) {
            try { exportTts.shutdown(); } catch (Exception ignored) {}
        }
    }
}
