package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/** Small consistent line icons for the Settings cards. */
public class SettingsIconView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private String iconType = "files";
    private int iconColor = Color.rgb(59, 130, 246);

    public SettingsIconView(Context context) {
        this(context, null);
    }

    public SettingsIconView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint.setColor(iconColor);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(dp(1.8f));
    }

    public void setIconType(String type) {
        iconType = type == null ? "files" : type;
        invalidate();
    }

    public void setIconColor(int color) {
        iconColor = color;
        paint.setColor(iconColor);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float s = Math.min(w, h) * 0.34f;
        paint.setStrokeWidth(Math.max(dp(1.5f), s * 0.11f));
        path.reset();
        paint.setColor(iconColor);

        if ("back".equals(iconType) || "left".equals(iconType)) {
            float nav = Math.min(w, h) * 0.48f;
            paint.setStrokeWidth(Math.max(dp(2.2f), nav * 0.13f));
            path.moveTo(cx + nav * 0.34f, cy - nav * 0.70f);
            path.lineTo(cx - nav * 0.36f, cy);
            path.lineTo(cx + nav * 0.34f, cy + nav * 0.70f);
            canvas.drawPath(path, paint);
            return;
        }

        if ("right".equals(iconType)) {
            float nav = Math.min(w, h) * 0.48f;
            paint.setStrokeWidth(Math.max(dp(2.2f), nav * 0.13f));
            path.moveTo(cx - nav * 0.34f, cy - nav * 0.70f);
            path.lineTo(cx + nav * 0.36f, cy);
            path.lineTo(cx - nav * 0.34f, cy + nav * 0.70f);
            canvas.drawPath(path, paint);
            return;
        }

        if ("undo".equals(iconType) || "redo".equals(iconType)) {
            // V98: open curved arrows instead of almost-complete circles.
            boolean redo = "redo".equals(iconType);
            float r = Math.min(w, h) * 0.30f;
            paint.setStrokeWidth(Math.max(dp(1.9f), r * 0.17f));

            path.reset();
            if (redo) {
                path.moveTo(cx - r * 0.95f, cy + r * 0.55f);
                path.cubicTo(cx - r * 0.48f, cy - r * 0.78f,
                        cx + r * 0.55f, cy - r * 0.78f,
                        cx + r * 0.94f, cy - r * 0.18f);
                canvas.drawPath(path, paint);

                path.reset();
                path.moveTo(cx + r * 0.94f, cy - r * 0.18f);
                path.lineTo(cx + r * 0.43f, cy - r * 0.40f);
                path.moveTo(cx + r * 0.94f, cy - r * 0.18f);
                path.lineTo(cx + r * 0.68f, cy + r * 0.28f);
            } else {
                path.moveTo(cx + r * 0.95f, cy + r * 0.55f);
                path.cubicTo(cx + r * 0.48f, cy - r * 0.78f,
                        cx - r * 0.55f, cy - r * 0.78f,
                        cx - r * 0.94f, cy - r * 0.18f);
                canvas.drawPath(path, paint);

                path.reset();
                path.moveTo(cx - r * 0.94f, cy - r * 0.18f);
                path.lineTo(cx - r * 0.43f, cy - r * 0.40f);
                path.moveTo(cx - r * 0.94f, cy - r * 0.18f);
                path.lineTo(cx - r * 0.68f, cy + r * 0.28f);
            }
            canvas.drawPath(path, paint);
            return;
        }

        if ("tracking".equals(iconType)) {
            RectF eye = new RectF(cx - s, cy - s * 0.48f, cx + s, cy + s * 0.48f);
            path.moveTo(eye.left, cy);
            path.quadTo(cx, eye.top - s * 0.25f, eye.right, cy);
            path.quadTo(cx, eye.bottom + s * 0.25f, eye.left, cy);
            canvas.drawPath(path, paint);
            canvas.drawCircle(cx, cy, s * 0.22f, paint);
            canvas.drawLine(cx - s * 0.72f, cy + s * 0.72f, cx + s * 0.72f, cy + s * 0.72f, paint);
            return;
        }

        if ("mark".equals(iconType)) {
            path.moveTo(cx - s * 0.62f, cy + s * 0.42f);
            path.lineTo(cx + s * 0.42f, cy - s * 0.62f);
            path.lineTo(cx + s * 0.73f, cy - s * 0.31f);
            path.lineTo(cx - s * 0.31f, cy + s * 0.73f);
            path.close();
            canvas.drawPath(path, paint);
            canvas.drawLine(cx - s * 0.82f, cy + s * 0.9f, cx + s * 0.82f, cy + s * 0.9f, paint);
            return;
        }

        if ("thickness".equals(iconType)) {
            float left = cx - s * 0.78f;
            float right = cx + s * 0.78f;
            paint.setStrokeWidth(Math.max(dp(1.2f), s * 0.08f));
            canvas.drawLine(left, cy - s * 0.55f, right, cy - s * 0.55f, paint);
            paint.setStrokeWidth(Math.max(dp(2f), s * 0.16f));
            canvas.drawLine(left, cy, right, cy, paint);
            paint.setStrokeWidth(Math.max(dp(3f), s * 0.25f));
            canvas.drawLine(left, cy + s * 0.58f, right, cy + s * 0.58f, paint);
            return;
        }

        if ("files".equals(iconType)) {
            path.moveTo(cx - s * 0.88f, cy - s * 0.44f);
            path.lineTo(cx - s * 0.25f, cy - s * 0.44f);
            path.lineTo(cx - s * 0.03f, cy - s * 0.72f);
            path.lineTo(cx + s * 0.84f, cy - s * 0.72f);
            path.lineTo(cx + s * 0.84f, cy + s * 0.66f);
            path.lineTo(cx - s * 0.88f, cy + s * 0.66f);
            path.close();
            canvas.drawPath(path, paint);
            return;
        }

        if ("audio".equals(iconType)) {
            canvas.drawLine(cx + s * 0.28f, cy - s * 0.72f, cx + s * 0.28f, cy + s * 0.38f, paint);
            canvas.drawLine(cx + s * 0.28f, cy - s * 0.72f, cx + s * 0.78f, cy - s * 0.54f, paint);
            canvas.drawCircle(cx + s * 0.03f, cy + s * 0.55f, s * 0.28f, paint);
            canvas.drawCircle(cx + s * 0.53f, cy + s * 0.38f, s * 0.25f, paint);
            return;
        }

        if ("image".equals(iconType)) {
            RectF frame = new RectF(cx - s * 0.82f, cy - s * 0.66f, cx + s * 0.82f, cy + s * 0.66f);
            canvas.drawRoundRect(frame, s * 0.12f, s * 0.12f, paint);
            canvas.drawCircle(cx + s * 0.42f, cy - s * 0.30f, s * 0.13f, paint);
            path.moveTo(frame.left + s * 0.16f, frame.bottom - s * 0.12f);
            path.lineTo(cx - s * 0.20f, cy + s * 0.02f);
            path.lineTo(cx + s * 0.05f, cy + s * 0.28f);
            path.lineTo(cx + s * 0.28f, cy + s * 0.02f);
            path.lineTo(frame.right - s * 0.12f, frame.bottom - s * 0.12f);
            canvas.drawPath(path, paint);
            return;
        }

        if ("pdf".equals(iconType)) {
            RectF doc = new RectF(cx - s * 0.63f, cy - s * 0.82f, cx + s * 0.63f, cy + s * 0.82f);
            canvas.drawRoundRect(doc, s * 0.1f, s * 0.1f, paint);
            canvas.drawLine(cx - s * 0.36f, cy - s * 0.18f, cx + s * 0.36f, cy - s * 0.18f, paint);
            canvas.drawLine(cx - s * 0.36f, cy + s * 0.12f, cx + s * 0.36f, cy + s * 0.12f, paint);
            canvas.drawLine(cx - s * 0.36f, cy + s * 0.42f, cx + s * 0.16f, cy + s * 0.42f, paint);
            return;
        }

        canvas.drawCircle(cx, cy, s * 0.55f, paint);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
