# Geo Zeta PDF a Audio V10

Corrección fuerte:
- La app ya no debe volver a página 1 al abrir.
- Se respeta localStorage lastPage.
- Solo sincroniza con el servicio cuando el servicio realmente está reproduciendo.
- Logo incluido como icono de APK y logo interno.
- VersionCode 10.
