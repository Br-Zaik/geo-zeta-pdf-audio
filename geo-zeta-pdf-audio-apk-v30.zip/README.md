# Geo Zeta PDF a Audio V30

Base:
- V29 limpia desde V26.
- No usa V27/V28 como base.

Mejoras:
- Iconos blancos propios, sin emojis de colores.
- Botón Play/Pausa con SVG blanco: ya no cambia a emoji/color raro.
- Colores de subrayado con puntitos, no con letras.
- Botones laterales para el PDF:
  - alinear izquierda;
  - centrar;
  - alinear derecha;
  - ajustar ancho;
  - volver al zoom inicial.
- Zoom con dos dedos usa vista previa por transformación y renderiza al soltar para reducir lag.
- Mantiene rendimiento Rápido/Balanceado/Nítido.
- Mantiene audio continuo, notificación, modo estudio, subrayado, reglas y colores.

Recomendación:
- En gama baja usa Balanceado o Rápido.
- Usa los botones laterales para centrar/ajustar sin forzar tanto el zoom con dedos.
