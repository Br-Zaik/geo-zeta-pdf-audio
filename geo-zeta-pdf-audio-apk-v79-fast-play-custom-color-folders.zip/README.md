# Geo Zeta PDF a Audio V79

Cambios principales:

- Se eliminó completamente la caja de texto del selector de marcado. Las cajas antiguas se convierten en subrayado simple para no perder la selección.
- Se quitaron de Ajustes las opciones duplicadas de color y reglas; ambas siguen disponibles en la pantalla principal.
- La paleta de color ahora incluye una opción de color personalizado con controles RGB y vista previa.
- Nuevo diseño de carpetas de guardado tipo grabadora, con accesos separados para Audios, Imágenes y PDF marcados.
- Los nuevos archivos se organizan en Geo Zeta/Audios, Geo Zeta/Imagenes y Geo Zeta/PDF_Marcados.
- Mis archivos ahora tiene tres pestañas: Audios, Imágenes y PDF.
- Crear audio usa un diseño tipo grabadora con botón circular y muestra la carpeta de destino.
- Optimización de Play: servicio TTS precalentado, una sola orden de inicio, sin ACTION_PREPARE, primera frase más corta y precargas retrasadas.
- El análisis de caracteres para subrayar solo se abre cuando la herramienta de marcado está activa, evitando competir con la reproducción.
- Se mantienen las marcas persistentes por PDF, la galería con zoom, compartir archivos y exportar PDF marcado.

Versión:
- versionCode: 79
- versionName: 79.0-fast-play-custom-color-folders
