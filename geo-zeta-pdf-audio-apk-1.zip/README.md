# Geo Zeta PDF a Audio

App Android básica para abrir un PDF, ver la página y leer el texto con voz del celular.

## Cómo generar APK

1. Sube estos archivos a un repositorio de GitHub.
2. Entra a la pestaña Actions.
3. Ejecuta el workflow **Build APK**.
4. Descarga el artifact **GeoZeta-PDF-a-Audio-APK**.
5. Instala el APK en Android.

## Nota

Funciona mejor con PDFs con texto real. Los PDFs escaneados como imagen necesitan OCR.
