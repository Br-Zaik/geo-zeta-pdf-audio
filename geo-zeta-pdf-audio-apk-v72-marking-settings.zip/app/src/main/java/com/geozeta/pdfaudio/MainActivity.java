package com.geozeta.pdfaudio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.GridLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.graphics.Typeface;
import android.widget.Toast;
import android.view.View;
import android.view.WindowManager;
import android.content.DialogInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_OPEN_PDF = 1001;
    private static final String PREF_TTS_ACTIVE = "tts_service_active";
    private static final String PREF_TTS_PAUSED = "tts_service_paused";
    private static final String PREF_TTS_CURRENT_PAGE = "tts_current_page";
    private static final String PREF_TTS_STATE = "tts_service_state";
    private static final String PREF_TTS_MESSAGE = "tts_service_message";
    private static final String PREF_AUDIO_STATE_REPAIRED_V69 = "audio_state_repaired_v69";
    private static final String PREF_MARK_STYLE = "mark_style";
    private static final String PREF_MARK_STYLE_V72_MIGRATED = "mark_style_v72_migrated";
    private static final String PREF_MARK_COLORS_V72_MIGRATED = "mark_colors_v72_migrated";
    private static final String PREF_MARK_THICKNESS = "mark_thickness_level";
    private static final String PREF_UNDERLINE_COLOR = "underline_color_index";
    private static final String PREF_HIGHLIGHT_COLOR = "highlight_color_index";
    private static final String PREF_READING_BRIGHTNESS = "reading_brightness";

    private static final int MARK_STYLE_UNDERLINE_FINE = 0;
    private static final int MARK_STYLE_UNDERLINE_DOUBLE = 1;
    private static final int MARK_STYLE_UNDERLINE_WAVY = 2;
    private static final int MARK_STYLE_UNDERLINE_DOTTED = 3;
    private static final int MARK_STYLE_HIGHLIGHT_SOFT = 4;
    private static final int MARK_STYLE_HIGHLIGHT_INTENSE = 5;
    private static final int MARK_STYLE_TEXT_BOX = 6;

    private static final int COLOR_TARGET_UNDERLINE = 0;
    private static final int COLOR_TARGET_HIGHLIGHT = 1;

    // Colores mostrados como muestras reales. Sus nombres no aparecen en la interfaz.
    private static final int[] MARK_COLOR_RGB = new int[]{
            0x00FFD400, 0x00EF4444, 0x00EC4899, 0x003B82F6,
            0x0022C55E, 0x00F97316, 0x00A855F7, 0x0006B6D4,
            0x0084CC16, 0x0092400E, 0x00111111, 0x00FFFFFF
    };

    private PdfPageView pdfView;
    private TextRepository textRepository;
    private SelectionTextRepository selectionRepository;
    private TextView titleView;
    private TextView pageView;
    private Button playButton;
    private File currentFile;
    private String currentTitle;
    private int currentPage;
    private int pageCount;
    private boolean audioStarted;
    private boolean audioPaused;
    private boolean audioPreparing;
    private boolean markMode;
    private int markStyle;
    private int underlineColorIndex;
    private int highlightColorIndex;
    private int markThicknessLevel;
    private float readingBrightness;
    private Button markButton;
    private Button colorButton;
    private Button rulesButton;
    private boolean rulesEnabled;
    private float ruleTop;
    private float ruleBottom;
    private boolean restartAudioAfterRender;
    private int requestedAudioPage;
    private int audioRequestToken;
    private boolean darkTheme;
    private float speechRate;
    private boolean settingsMode;
    private LinearLayout root;
    private TextToSpeech exportTts;
    private SharedPreferences prefs;
    private Handler pageSyncHandler;
    private Runnable pageSyncRunnable;
    private BroadcastReceiver playbackReceiver;
    private boolean receiverRegistered;
    private boolean notificationWarningShown;
    private final Handler audioStartHandler = new Handler(Looper.getMainLooper());
    private Runnable audioStartTimeout;
    private int playbackState = TtsForegroundService.STATE_STOPPED;
    private String lastPlaybackError = "";
    private boolean fullIndexRequested;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        currentTitle = "PDF a Audio";
        prefs = getSharedPreferences("pdf_audio_prefs", MODE_PRIVATE);
        darkTheme = prefs.getBoolean("dark_theme", true);
        speechRate = prefs.getFloat("speech_rate", 1.0f);
        int storedMarkStyle = prefs.getInt(PREF_MARK_STYLE, MARK_STYLE_UNDERLINE_FINE);
        if (!prefs.getBoolean(PREF_MARK_STYLE_V72_MIGRATED, false)) {
            // V71 usaba 0=subrayado y 1=resaltado. Se conserva la eleccion al migrar.
            storedMarkStyle = storedMarkStyle == 1 ? MARK_STYLE_HIGHLIGHT_SOFT : MARK_STYLE_UNDERLINE_FINE;
            prefs.edit()
                    .putInt(PREF_MARK_STYLE, storedMarkStyle)
                    .putBoolean(PREF_MARK_STYLE_V72_MIGRATED, true)
                    .apply();
        }
        markStyle = safeMarkStyle(storedMarkStyle);
        markThicknessLevel = safeThicknessLevel(prefs.getInt(PREF_MARK_THICKNESS, 1));

        int storedUnderlineColor = prefs.getInt(PREF_UNDERLINE_COLOR, 0);
        int storedHighlightColor = prefs.getInt(PREF_HIGHLIGHT_COLOR, 0);
        if (!prefs.getBoolean(PREF_MARK_COLORS_V72_MIGRATED, false)) {
            storedUnderlineColor = migrateV71ColorIndex(storedUnderlineColor);
            storedHighlightColor = migrateV71ColorIndex(storedHighlightColor);
            prefs.edit()
                    .putInt(PREF_UNDERLINE_COLOR, storedUnderlineColor)
                    .putInt(PREF_HIGHLIGHT_COLOR, storedHighlightColor)
                    .putBoolean(PREF_MARK_COLORS_V72_MIGRATED, true)
                    .apply();
        }
        underlineColorIndex = safeMarkColorIndex(storedUnderlineColor);
        highlightColorIndex = safeMarkColorIndex(storedHighlightColor);
        readingBrightness = prefs.getFloat(PREF_READING_BRIGHTNESS, -1f);
        applyReadingBrightness();
        repairBrokenPlaybackStateOnce();
        setupPlaybackSync();
        textRepository = new TextRepository(this);
        selectionRepository = new SelectionTextRepository(this);
        TtsForegroundService.setPageProvider(new TtsForegroundService.PageProvider() {
            @Override
            public void requestPageText(final int page, final TtsForegroundService.PageTextCallback callback) {
                textRepository.getPageTextPriority(page, new TextRepository.TextCallback() {
                    @Override
                    public void onText(String text) {
                        callback.onText(text);
                    }
                });
            }
        });
        buildUi();
        warmUpAudioEngine();

        ensureNotificationPermission();

        File last = new File(getFilesDir(), "last.pdf");
        if (last.exists()) {
            openLocalPdf(last, prefs.getString("last_title", "PDF guardado"), true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerPlaybackReceiver();
        startPageSyncLoop();
        syncVisiblePageWithReader();
    }

    @Override
    protected void onPause() {
        stopPageSyncLoop();
        unregisterPlaybackReceiver();
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        syncVisiblePageWithReader();
    }

    private void setupPlaybackSync() {
        pageSyncHandler = new Handler(Looper.getMainLooper());
        pageSyncRunnable = new Runnable() {
            @Override
            public void run() {
                syncVisiblePageWithReader();
                if (pageSyncHandler != null) {
                    pageSyncHandler.postDelayed(this, 700);
                }
            }
        };
        playbackReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || !TtsForegroundService.ACTION_PAGE_CHANGED.equals(intent.getAction())) return;
                int state = intent.getIntExtra(TtsForegroundService.EXTRA_STATE,
                        TtsForegroundService.STATE_STOPPED);
                int page = intent.getIntExtra(TtsForegroundService.EXTRA_PAGE, -1);
                String message = intent.getStringExtra(TtsForegroundService.EXTRA_MESSAGE);
                applyPlaybackState(state, page, message, true);
            }
        };
    }

    private void registerPlaybackReceiver() {
        if (receiverRegistered || playbackReceiver == null) return;
        IntentFilter filter = new IntentFilter(TtsForegroundService.ACTION_PAGE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(playbackReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(playbackReceiver, filter);
        }
        receiverRegistered = true;
    }

    private void unregisterPlaybackReceiver() {
        if (!receiverRegistered || playbackReceiver == null) return;
        try {
            unregisterReceiver(playbackReceiver);
        } catch (Exception ignored) {
        }
        receiverRegistered = false;
    }

    private void startPageSyncLoop() {
        if (pageSyncHandler == null || pageSyncRunnable == null) return;
        pageSyncHandler.removeCallbacks(pageSyncRunnable);
        pageSyncHandler.postDelayed(pageSyncRunnable, 700);
    }

    private void stopPageSyncLoop() {
        if (pageSyncHandler != null && pageSyncRunnable != null) {
            pageSyncHandler.removeCallbacks(pageSyncRunnable);
        }
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33) return;
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return;

        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 33);
        if (!notificationWarningShown) {
            notificationWarningShown = true;
            Toast.makeText(this, "Acepta el permiso de notificaciones para ver los controles del audio", Toast.LENGTH_LONG).show();
        }
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(darkTheme ? Color.rgb(17, 24, 39) : Color.rgb(248, 250, 252));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(12, 12, 12, 8);
        top.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        Button openButton = makeButton("Abrir");
        
openButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        choosePdf();
    }
});

        titleView = new TextView(this);
        titleView.setText("PDF a Audio");
        titleView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        titleView.setTextSize(18);
        titleView.setSingleLine(true);
        titleView.setGravity(Gravity.CENTER_VERTICAL);

        pageView = new TextView(this);
        pageView.setText("0/0");
        pageView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        pageView.setTextSize(15);
        pageView.setSingleLine(true);
        pageView.setGravity(Gravity.CENTER);

        Button gotoButton = makeButton("#");
        
gotoButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        showGoto();
    }
});

        rulesButton = makeButton("Reglas");
        rulesButton.setTextSize(12);
        rulesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleRules();
            }
        });

        top.addView(openButton, new LinearLayout.LayoutParams(dp(72), dp(48)));
        top.addView(titleView, new LinearLayout.LayoutParams(0, dp(48), 1));
        top.addView(pageView, new LinearLayout.LayoutParams(dp(72), dp(48)));
        top.addView(rulesButton, new LinearLayout.LayoutParams(dp(76), dp(48)));
        top.addView(gotoButton, new LinearLayout.LayoutParams(dp(48), dp(48)));

        FrameLayout frame = new FrameLayout(this);
        pdfView = new PdfPageView(this);
        pdfView.setPageChangeListener(new PdfPageView.PageChangeListener() {
            @Override
            public void onPageRendered(final int pageIndex, int total) {
                currentPage = pageIndex;
                pageCount = total;
                updatePageLabel();
                saveProgress();

                // Primero queda lista la pagina visible. Solo despues empieza la
                // precarga pesada, para que Play no compita con el indexado del PDF.
                preparePageForInstantPlay(pageIndex, true);

                prefetchAroundCurrentPage();
                loadSelectionForPage(pageIndex);
                if (restartAudioAfterRender) {
                    restartAudioAfterRender = false;
                    startAudioFromPage(currentPage);
                }
            }

            @Override
            public void onError(String message) {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onHighlightsChanged(String serialized) {
                saveHighlights(serialized);
            }

            @Override
            public void onRulesChanged(boolean enabled, float top, float bottom) {
                saveRules(enabled, top, bottom);
                textRepository.setRules(enabled, top, bottom);
                refreshTextCacheForRules();
            }
        });
        frame.addView(pdfView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(8, 8, 8, 8);
        controls.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        Button prevButton = makeButton("‹");
        prevButton.setTextSize(30);
        
prevButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) requestManualPageChange(currentPage - 1);
    }
});

        playButton = makeButton("▶");
        playButton.setTextSize(26);
        
playButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        toggleAudio();
    }
});

        Button nextButton = makeButton("›");
        nextButton.setTextSize(30);
        
nextButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) requestManualPageChange(currentPage + 1);
    }
});

        Button fitButton = makeButton("Ajustes");
        
fitButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        showSettings();
    }
});

        controls.addView(prevButton, new LinearLayout.LayoutParams(0, dp(56), 1));
        controls.addView(playButton, new LinearLayout.LayoutParams(0, dp(56), 1));
        controls.addView(nextButton, new LinearLayout.LayoutParams(0, dp(56), 1));
        controls.addView(fitButton, new LinearLayout.LayoutParams(0, dp(56), 1));

        LinearLayout markControls = new LinearLayout(this);
        markControls.setOrientation(LinearLayout.HORIZONTAL);
        markControls.setGravity(Gravity.CENTER);
        markControls.setPadding(8, 0, 8, 8);
        markControls.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        markButton = makeButton("Subrayar");
        markButton.setTextSize(13);
        markButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleMarkMode();
            }
        });

        colorButton = makeButton("●");
        colorButton.setTextSize(28);
        colorButton.setContentDescription("Elegir color del marcado");
        colorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkColorDialog(isHighlightStyle(markStyle) ? COLOR_TARGET_HIGHLIGHT : COLOR_TARGET_UNDERLINE);
            }
        });

        Button undoButton = makeButton("Borrar");
        undoButton.setTextSize(13);
        undoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.undoLastHighlight();
            }
        });

        Button clearButton = makeButton("Limpiar");
        clearButton.setTextSize(13);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.clearPageHighlights();
            }
        });

        markControls.addView(markButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        markControls.addView(colorButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        markControls.addView(undoButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        markControls.addView(clearButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.addView(controls, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)));
        bottom.addView(markControls, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));

        root.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)));
        root.addView(frame, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        root.addView(bottom, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(118)));

        setContentView(root);
        pdfView.setMarkStyle(markStyle);
        pdfView.setMarkThickness(markThicknessLevel);
        pdfView.setMarkColor(getCurrentMarkColor());
        pdfView.setMarkMode(markMode);
        updateMarkControls();
        loadRules();
    }

    private Button makeButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        button.setTextSize(16);
        button.setAllCaps(false);
        button.setBackgroundColor(darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255));
        return button;
    }



    private void showSettings() {
        settingsMode = true;
        buildSettingsScreen();
    }

    private String formatSpeed() {
        return String.format(Locale.US, "%.2fx", speechRate);
    }


    private String getVoiceSummary() {
        TtsEngineManager manager = TtsEngineManager.getInstance(this);
        String engine = manager.getActiveEnginePackage();
        if (engine != null && engine.length() > 0 && manager.isReady()) {
            return "Listo: " + engine;
        }
        String status = manager.getStatusText();
        return status == null || status.length() == 0 ? "Preparando motor" : status;
    }

    private void showVoiceEngineDialog() {
        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        final java.util.List<TtsEngineManager.EngineChoice> engines = manager.getInstalledEngines();
        final String[] labels = new String[engines.size() + 1];
        final String[] packages = new String[engines.size() + 1];
        labels[0] = "Automatico (recomendado)";
        packages[0] = "";
        for (int i = 0; i < engines.size(); i++) {
            TtsEngineManager.EngineChoice item = engines.get(i);
            labels[i + 1] = item.label + "\n" + item.packageName;
            packages[i + 1] = item.packageName;
        }

        String selectedPackage = prefs.getString(TtsEngineManager.PREF_ENGINE_PACKAGE, "");
        int selected = 0;
        for (int i = 1; i < packages.length; i++) {
            if (packages[i].equals(selectedPackage)) {
                selected = i;
                break;
            }
        }

        new AlertDialog.Builder(this)
                .setTitle("Motor de voz")
                .setSingleChoiceItems(labels, selected, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        manager.selectEngine(packages[which]);
                        Toast.makeText(MainActivity.this,
                                "Preparando " + labels[which].replace("\n", " "),
                                Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                })
                .setNeutralButton("Reintentar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        manager.retryInitialization();
                        Toast.makeText(MainActivity.this,
                                "Reiniciando el motor de voz", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void testSystemVoice() {
        final TtsEngineManager manager = TtsEngineManager.getInstance(this);
        Toast.makeText(this, "Preparando prueba de voz", Toast.LENGTH_SHORT).show();
        manager.testVoice("Prueba de voz correcta. El lector esta listo para leer el PDF.",
                new TtsEngineManager.TestCallback() {
                    @Override
                    public void onStarted() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this,
                                        "La voz comenzo correctamente", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

                    @Override
                    public void onCompleted() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (settingsMode) buildSettingsScreen();
                            }
                        });
                    }

                    @Override
                    public void onError(final String message) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, message,
                                        Toast.LENGTH_LONG).show();
                                if (settingsMode) buildSettingsScreen();
                            }
                        });
                    }
                });
    }

    private void showSpeedDialog() {
        final String[] labels = new String[]{"0.75x", "1.0x", "1.25x", "1.5x", "1.75x", "2.0x"};
        final float[] values = new float[]{0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f};

        int selected = 1;
        for (int i = 0; i < values.length; i++) {
            if (Math.abs(values[i] - speechRate) < 0.01f) {
                selected = i;
                break;
            }
        }

        new AlertDialog.Builder(this)
                .setTitle("Velocidad de lectura")
                .setSingleChoiceItems(labels, selected, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        speechRate = values[which];
                        prefs.edit().putFloat("speech_rate", speechRate).apply();
                        Toast.makeText(MainActivity.this, "Velocidad: " + labels[which], Toast.LENGTH_SHORT).show();

                        if (audioStarted && !audioPaused) {
                            startAudioFromPage(currentPage);
                        }

                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void closeSettings() {
        settingsMode = false;
        buildUi();

        if (currentFile != null && currentFile.exists()) {
            int page = currentPage;
            openLocalPdf(currentFile, currentTitle, false);
            if (pageCount > 0) {
                pdfView.showPage(Math.max(0, Math.min(page, pageCount - 1)));
            }
        }
    }

    private void buildSettingsScreen() {
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), dp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        Button back = makeFlatIconButton("‹");
        back.setTextSize(34);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeSettings();
            }
        });

        TextView title = new TextView(this);
        title.setText("Ajustes");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);

        Button done = makeFlatIconButton("✓");
        done.setTextSize(28);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeSettings();
            }
        });

        top.addView(back, new LinearLayout.LayoutParams(dp(52), dp(56)));
        top.addView(title, new LinearLayout.LayoutParams(0, dp(56), 1));
        top.addView(done, new LinearLayout.LayoutParams(dp(52), dp(56)));

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(8), dp(14), dp(22));

        addSettingsSection(content, "APARIENCIA");
        addChoiceRow(content, "☀", "Tema claro", "Fondo blanco", !darkTheme, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (darkTheme) toggleTheme();
            }
        });
        addChoiceRow(content, "☾", "Tema oscuro", "Fondo oscuro", darkTheme, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!darkTheme) toggleTheme();
            }
        });
        addActionRow(content, "◉", "Brillo de lectura", formatReadingBrightness(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showReadingBrightnessDialog();
            }
        });

        addSettingsSection(content, "LECTURA Y AUDIO");
        addActionRow(content, "♬", "Motor de voz", getVoiceSummary(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showVoiceEngineDialog();
            }
        });
        addActionRow(content, "♪", "Probar voz", "Escuchar una muestra", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testSystemVoice();
            }
        });
        addActionRow(content, "◴", "Velocidad", formatSpeed(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSpeedDialog();
            }
        });

        addSettingsSection(content, "MARCADO");
        addSwitchRow(content, "✎", "Herramienta de marcado", markMode ? "Activo" : "Apagado", markMode, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleMarkMode();
                buildSettingsScreen();
            }
        });
        addActionRow(content, "▱", "Tipo de marcado", getMarkStyleName(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkStyleDialog();
            }
        });
        addActionRow(content, "━", "Grosor del subrayado", getThicknessName(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkThicknessDialog();
            }
        });
        addColorRow(content, "━", "Color del subrayado", getMarkColor(COLOR_TARGET_UNDERLINE, underlineColorIndex), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkColorDialog(COLOR_TARGET_UNDERLINE);
            }
        });
        addColorRow(content, "▰", "Color del resaltado", getMarkColor(COLOR_TARGET_HIGHLIGHT, highlightColorIndex), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMarkColorDialog(COLOR_TARGET_HIGHLIGHT);
            }
        });
        addSwitchRow(content, "≡", "Reglas arriba y abajo", rulesEnabled ? "Activo" : "Apagado", rulesEnabled, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleRules();
                buildSettingsScreen();
            }
        });

        scroll.addView(content);
        screen.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(78)));
        screen.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(screen);
    }

    private Button makeFlatIconButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        b.setTextSize(24);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private void addSettingsSection(LinearLayout parent, String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(14);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(Color.rgb(59, 130, 246));
        tv.setPadding(dp(4), dp(18), dp(4), dp(7));
        parent.addView(tv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private LinearLayout makeCardRow(String icon, String title, String sub) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(8), dp(10), dp(8));
        row.setBackgroundColor(darkTheme ? Color.rgb(12, 35, 54) : Color.WHITE);

        TextView iconView = new TextView(this);
        iconView.setText(icon);
        iconView.setTextSize(24);
        iconView.setGravity(Gravity.CENTER);
        iconView.setTextColor(Color.rgb(59, 130, 246));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextSize(17);
        titleView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView subView = new TextView(this);
        subView.setText(sub == null ? "" : sub);
        subView.setTextSize(12);
        subView.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        texts.addView(titleView);
        if (sub != null && sub.length() > 0) texts.addView(subView);

        row.addView(iconView, new LinearLayout.LayoutParams(dp(48), dp(52)));
        row.addView(texts, new LinearLayout.LayoutParams(0, dp(56), 1));
        return row;
    }

    private void addChoiceRow(LinearLayout parent, String icon, String title, String sub, boolean selected, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        TextView check = new TextView(this);
        check.setText(selected ? "◉" : "○");
        check.setTextSize(24);
        check.setTextColor(selected ? Color.rgb(59, 130, 246) : Color.rgb(148, 163, 184));
        check.setGravity(Gravity.CENTER);
        row.addView(check, new LinearLayout.LayoutParams(dp(46), dp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private void addSwitchRow(LinearLayout parent, String icon, String title, String sub, boolean checked, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        Switch sw = new Switch(this);
        sw.setChecked(checked);
        sw.setEnabled(listener != null);
        if (listener != null) {
            sw.setOnClickListener(listener);
            row.setOnClickListener(listener);
        }
        row.addView(sw, new LinearLayout.LayoutParams(dp(64), dp(56)));
        addRowWithMargin(parent, row);
    }

    private void addActionRow(LinearLayout parent, String icon, String title, String sub, String right, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        TextView arrow = new TextView(this);
        arrow.setText(right == null ? "" : right);
        arrow.setTextSize(25);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(38), dp(56)));
        if (listener != null) row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private void addColorRow(LinearLayout parent, String icon, String title, int color, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, "");

        TextView swatch = new TextView(this);
        swatch.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF000000 | (color & 0x00FFFFFF));
        circle.setStroke(dp(2), darkTheme ? Color.WHITE : Color.rgb(71, 85, 105));
        swatch.setBackground(circle);
        swatch.setContentDescription("Color seleccionado");

        LinearLayout.LayoutParams swatchParams = new LinearLayout.LayoutParams(dp(30), dp(30));
        swatchParams.setMargins(dp(4), dp(13), dp(6), dp(13));
        row.addView(swatch, swatchParams);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(25);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(32), dp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private void addRowWithMargin(LinearLayout parent, View row) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(62));
        lp.setMargins(0, dp(3), 0, dp(3));
        parent.addView(row, lp);
    }

    private String formatReadingBrightness() {
        if (readingBrightness < 0f) return "Brillo del sistema";
        return Math.round(readingBrightness * 100f) + "%";
    }

    private void applyReadingBrightness() {
        try {
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.screenBrightness = readingBrightness < 0f ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE : readingBrightness;
            getWindow().setAttributes(params);
        } catch (Exception ignored) {
        }
    }

    private void showReadingBrightnessDialog() {
        final float original = readingBrightness;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(10), dp(24), dp(6));

        final SeekBar seek = new SeekBar(this);
        seek.setMax(90);
        int current = readingBrightness < 0f ? 60 : Math.round(readingBrightness * 100f) - 10;
        seek.setProgress(Math.max(0, Math.min(90, current)));
        box.addView(seek, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)));

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                readingBrightness = (progress + 10) / 100f;
                applyReadingBrightness();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Brillo de lectura")
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setNeutralButton("Sistema", null)
                .setPositiveButton("Guardar", null)
                .create();

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface ignored) {
                readingBrightness = original;
                applyReadingBrightness();
            }
        });

        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(final DialogInterface ignored) {
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        readingBrightness = original;
                        applyReadingBrightness();
                        dialog.dismiss();
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        readingBrightness = -1f;
                        prefs.edit().putFloat(PREF_READING_BRIGHTNESS, readingBrightness).apply();
                        applyReadingBrightness();
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (readingBrightness < 0f) {
                            readingBrightness = (seek.getProgress() + 10) / 100f;
                        }
                        prefs.edit().putFloat(PREF_READING_BRIGHTNESS, readingBrightness).apply();
                        applyReadingBrightness();
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                });
            }
        });
        dialog.show();
    }

    private void toggleTheme() {
        darkTheme = !darkTheme;
        prefs.edit().putBoolean("dark_theme", darkTheme).apply();

        if (settingsMode) {
            buildSettingsScreen();
            return;
        }

        File file = currentFile;
        String title = currentTitle;
        int page = currentPage;

        buildUi();

        if (file != null && file.exists()) {
            openLocalPdf(file, title, false);
            if (pageCount > 0) {
                pdfView.showPage(Math.max(0, Math.min(page, pageCount - 1)));
            }
        }

        Toast.makeText(this, darkTheme ? "Tema oscuro activado" : "Tema claro activado", Toast.LENGTH_SHORT).show();
    }

    private void saveCurrentPageImage() {
        if (currentFile == null || pdfView == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Bitmap bitmap = Bitmap.createBitmap(Math.max(1, pdfView.getWidth()), Math.max(1, pdfView.getHeight()), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            pdfView.draw(canvas);

            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "PDF_Audio");
            if (!dir.exists()) dir.mkdirs();

            String clean = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
            File out = new File(dir, clean + "_pagina_" + (currentPage + 1) + ".png");

            FileOutputStream fos = new FileOutputStream(out);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
            bitmap.recycle();

            Toast.makeText(this, "Imagen guardada: " + out.getName(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo guardar la imagen", Toast.LENGTH_LONG).show();
        }
    }

    private void exportCurrentPageAudio() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Preparando audio...", Toast.LENGTH_SHORT).show();

        textRepository.getPageText(currentPage, new TextRepository.TextCallback() {
            @Override
            public void onText(final String text) {
                if (text == null || text.trim().length() == 0) {
                    Toast.makeText(MainActivity.this, "No hay texto para exportar", Toast.LENGTH_LONG).show();
                    return;
                }

                if (exportTts != null) {
                    try { exportTts.shutdown(); } catch (Exception ignored) {}
                    exportTts = null;
                }

                exportTts = new TextToSpeech(MainActivity.this, new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int status) {
                        if (status != TextToSpeech.SUCCESS) {
                            Toast.makeText(MainActivity.this, "No se pudo iniciar voz", Toast.LENGTH_LONG).show();
                            return;
                        }

                        try {
                            exportTts.setLanguage(new Locale("es", "PE"));
                            exportTts.setSpeechRate(speechRate);

                            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "PDF_Audio");
                            if (!dir.exists()) dir.mkdirs();

                            String clean = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
                            File out = new File(dir, clean + "_pagina_" + (currentPage + 1) + ".wav");

                            String safeText = text;
                            if (safeText.length() > 12000) safeText = safeText.substring(0, 12000);

                            int result;
                            if (Build.VERSION.SDK_INT >= 21) {
                                result = exportTts.synthesizeToFile(safeText, null, out, "EXPORT_PAGE_AUDIO");
                            } else {
                                result = TextToSpeech.ERROR;
                            }

                            if (result == TextToSpeech.SUCCESS) {
                                Toast.makeText(MainActivity.this, "Audio guardado: " + out.getName(), Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(MainActivity.this, "No se pudo guardar el audio", Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Error al exportar audio", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }

    private void choosePdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        startActivityForResult(intent, REQ_OPEN_PDF);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OPEN_PDF && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            copyAndOpen(uri);
        }
    }

    private void copyAndOpen(Uri uri) {
        try {
            stopAudioOnly();
            if (textRepository != null) textRepository.close();
            if (selectionRepository != null) selectionRepository.close();
            String name = getDisplayName(uri);
            File target = new File(getFilesDir(), "last.pdf");

            InputStream input = getContentResolver().openInputStream(uri);
            FileOutputStream output = new FileOutputStream(target);
            byte[] buffer = new byte[65536];
            int read;
            while (input != null && (read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
            if (input != null) input.close();
            output.close();

            prefs.edit().putString("last_title", name).putInt("last_page", 0).apply();
            openLocalPdf(target, name, false);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir el PDF", Toast.LENGTH_LONG).show();
        }
    }

    private void openLocalPdf(File file, String title, boolean restore) {
        try {
            currentFile = file;
            currentTitle = title == null ? "PDF" : title;
            titleView.setText(currentTitle);
            fullIndexRequested = false;

            // Las reglas se fijan antes de abrir para que el cache persistente use
            // exactamente la misma zona de lectura que se ve en pantalla.
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
            textRepository.open(file);
            TtsForegroundService.clearPages();
            warmUpAudioEngine();

            // La pagina guardada entra en la cola urgente antes de abrir el repositorio
            // de marcado y antes de terminar el render del visor.
            final int preferredPage = Math.max(0,
                    restore ? prefs.getInt("last_page", 0) : 0);
            preparePageForInstantPlay(preferredPage, false);

            selectionRepository.open(file);
            pdfView.openFile(file);
            pdfView.loadHighlights(prefs.getString(highlightKey(), ""));
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
            pageCount = pdfView.getPageCount();
            final int p = Math.max(0, Math.min(preferredPage,
                    Math.max(0, pageCount - 1)));

            if (p != preferredPage) {
                preparePageForInstantPlay(p, false);
            }

            pdfView.showPage(p);
            updatePageLabel();
            prefetchAroundPage(p);
        } catch (Exception e) {
            Toast.makeText(this, "Error al cargar PDF", Toast.LENGTH_LONG).show();
        }
    }

    private String getDisplayName(Uri uri) {
        String result = "PDF";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return result == null ? "PDF" : result;
    }



    private void requestManualPageChange(int targetPage) {
        if (pageCount <= 0) return;

        final int nextPage = Math.max(0, Math.min(targetPage, pageCount - 1));
        restartAudioAfterRender = false;

        // Prioriza el texto apenas se solicita la pagina; no espera al renderizado.
        preparePageForInstantPlay(nextPage, false);
        currentPage = nextPage;
        updatePageLabel();
        pdfView.showPage(nextPage);

        if (playbackState == TtsForegroundService.STATE_PLAYING
                || playbackState == TtsForegroundService.STATE_PREPARING) {
            startAudioFromPage(nextPage);
        }
    }

    private void preparePageForInstantPlay(final int page, final boolean requestFullIndex) {
        if (textRepository == null || currentFile == null || page < 0) return;

        textRepository.prepareVisiblePage(page, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                TtsForegroundService.setPageText(page, text);

                // La pagina solicitada ya esta en RAM/servicio. A partir de aqui la
                // precarga puede trabajar sin retrasar el primer sonido de Play.
                if (pageCount > 0) {
                    textRepository.preloadAudioWindow(page, 8, pageCount);
                    if (requestFullIndex && !fullIndexRequested) {
                        fullIndexRequested = true;
                        textRepository.startFullPreload(page, pageCount);
                    }
                }
            }
        });
    }

    private void prefetchAroundCurrentPage() {
        prefetchAroundPage(currentPage);
    }

    private void prefetchAroundPage(int page) {
        if (pageCount <= 0) return;
        int start = Math.max(0, page);
        selectionRepository.prefetch(start, 1, pageCount);
    }




    private void loadSelectionForPage(final int page) {
        if (pageCount <= 0 || selectionRepository == null) return;

        selectionRepository.getChars(page, new SelectionTextRepository.CharCallback() {
            @Override
            public void onChars(java.util.ArrayList<CharBox> chars) {
                if (page == currentPage && pdfView != null) {
                    pdfView.setSelectionChars(chars);
                }
            }
        });
    }

    private void loadRules() {
        rulesEnabled = prefs.getBoolean("rules_enabled", true);
        ruleTop = prefs.getFloat("rule_top", 0.08f);
        ruleBottom = prefs.getFloat("rule_bottom", 0.92f);
        if (ruleBottom <= ruleTop + 0.05f) {
            ruleTop = 0.08f;
            ruleBottom = 0.92f;
        }

        if (pdfView != null) {
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        if (textRepository != null) {
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        updateRulesButton();
    }

    private void toggleRules() {
        rulesEnabled = !rulesEnabled;
        saveRules(rulesEnabled, ruleTop, ruleBottom);

        if (pdfView != null) {
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        if (textRepository != null) {
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
            refreshTextCacheForRules();
        }

        updateRulesButton();
        Toast.makeText(this, rulesEnabled ? "Reglas activadas. Arrastra las líneas." : "Reglas desactivadas", Toast.LENGTH_SHORT).show();
    }


    private void refreshTextCacheForRules() {
        if (textRepository == null || currentFile == null || pageCount <= 0) return;
        fullIndexRequested = false;
        final int page = Math.max(0, Math.min(currentPage, pageCount - 1));
        TtsForegroundService.clearPages();
        // Mantiene exactamente el recorte entre las dos reglas, pero vuelve a dar
        // prioridad a la pagina visible antes de reconstruir el resto del cache.
        preparePageForInstantPlay(page, true);
    }

    private void saveRules(boolean enabled, float top, float bottom) {
        rulesEnabled = enabled;
        ruleTop = top;
        ruleBottom = bottom;
        prefs.edit()
                .putBoolean("rules_enabled", enabled)
                .putFloat("rule_top", top)
                .putFloat("rule_bottom", bottom)
                .apply();
        updateRulesButton();
    }

    private void updateRulesButton() {
        if (rulesButton != null) {
            rulesButton.setText(rulesEnabled ? "Reglas ON" : "Reglas OFF");
        }
    }

    private void toggleMarkMode() {
        markMode = !markMode;
        if (pdfView != null) pdfView.setMarkMode(markMode);
        updateMarkControls();

        String message;
        if (!markMode) {
            message = "Marcado apagado";
        } else if (isHighlightStyle(markStyle)) {
            message = "Resaltado activo. Arrastra sobre el texto";
        } else if (markStyle == MARK_STYLE_TEXT_BOX) {
            message = "Caja activa. Arrastra sobre el texto";
        } else {
            message = "Subrayado activo. Arrastra sobre el texto";
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void showMarkStyleDialog() {
        final String[] styles = new String[]{
                "Subrayado fino",
                "Subrayado doble",
                "Subrayado ondulado",
                "Subrayado punteado",
                "Resaltado suave",
                "Resaltado intenso",
                "Caja de texto"
        };
        new AlertDialog.Builder(this)
                .setTitle("Tipo de marcado")
                .setSingleChoiceItems(styles, safeMarkStyle(markStyle), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        setMarkStyle(which);
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showMarkThicknessDialog() {
        final String[] levels = new String[]{"Fino", "Medio", "Grueso"};
        new AlertDialog.Builder(this)
                .setTitle("Grosor del subrayado")
                .setSingleChoiceItems(levels, markThicknessLevel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        markThicknessLevel = safeThicknessLevel(which);
                        prefs.edit().putInt(PREF_MARK_THICKNESS, markThicknessLevel).apply();
                        applyMarkAppearance();
                        dialog.dismiss();
                        if (settingsMode) buildSettingsScreen();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showMarkColorDialog(final int target) {
        final int selected = target == COLOR_TARGET_HIGHLIGHT ? highlightColorIndex : underlineColorIndex;
        String title = target == COLOR_TARGET_HIGHLIGHT ? "Color del resaltado" : "Color del subrayado";

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(18), dp(12), dp(18), dp(8));

        GridLayout palette = new GridLayout(this);
        palette.setColumnCount(4);
        palette.setRowCount((int) Math.ceil(MARK_COLOR_RGB.length / 4.0));
        palette.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        palette.setUseDefaultMargins(false);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(container)
                .setNegativeButton("Cancelar", null)
                .create();

        for (int i = 0; i < MARK_COLOR_RGB.length; i++) {
            final int index = i;
            TextView swatch = new TextView(this);
            swatch.setText(index == selected ? "✓" : "");
            swatch.setTextSize(21);
            swatch.setTypeface(Typeface.DEFAULT_BOLD);
            swatch.setGravity(Gravity.CENTER);
            swatch.setTextColor(isDarkSwatch(MARK_COLOR_RGB[index]) ? Color.WHITE : Color.BLACK);
            swatch.setContentDescription("Color " + (index + 1));

            GradientDrawable shape = new GradientDrawable();
            shape.setShape(GradientDrawable.OVAL);
            shape.setColor(0xFF000000 | MARK_COLOR_RGB[index]);
            shape.setStroke(dp(index == selected ? 4 : 2), index == selected
                    ? Color.rgb(59, 130, 246)
                    : (darkTheme ? Color.WHITE : Color.rgb(71, 85, 105)));
            swatch.setBackground(shape);
            swatch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int safe = safeMarkColorIndex(index);
                    if (target == COLOR_TARGET_HIGHLIGHT) {
                        highlightColorIndex = safe;
                        prefs.edit().putInt(PREF_HIGHLIGHT_COLOR, safe).apply();
                    } else {
                        underlineColorIndex = safe;
                        prefs.edit().putInt(PREF_UNDERLINE_COLOR, safe).apply();
                    }
                    applyMarkAppearance();
                    dialog.dismiss();
                    if (settingsMode) buildSettingsScreen();
                }
            });

            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = dp(58);
            lp.height = dp(58);
            lp.setMargins(dp(9), dp(9), dp(9), dp(9));
            palette.addView(swatch, lp);
        }

        container.addView(palette, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        dialog.show();
    }

    private boolean isDarkSwatch(int rgb) {
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        return (r * 299 + g * 587 + b * 114) / 1000 < 145;
    }

    private void setMarkStyle(int style) {
        markStyle = safeMarkStyle(style);
        prefs.edit().putInt(PREF_MARK_STYLE, markStyle).apply();
        applyMarkAppearance();
    }

    private void applyMarkAppearance() {
        if (pdfView != null) {
            pdfView.setMarkStyle(markStyle);
            pdfView.setMarkThickness(markThicknessLevel);
            pdfView.setMarkColor(getCurrentMarkColor());
        }
        updateMarkControls();
    }

    private void updateMarkControls() {
        if (markButton != null) {
            if (markMode) {
                if (isHighlightStyle(markStyle)) markButton.setText("Resaltando");
                else if (markStyle == MARK_STYLE_TEXT_BOX) markButton.setText("Marcando");
                else markButton.setText("Subrayando");
            } else {
                if (isHighlightStyle(markStyle)) markButton.setText("Resaltar");
                else if (markStyle == MARK_STYLE_TEXT_BOX) markButton.setText("Enmarcar");
                else markButton.setText("Subrayar");
            }
        }
        if (colorButton != null) {
            colorButton.setText("●");
            colorButton.setTextColor(0xFF000000 | (getCurrentMarkColor() & 0x00FFFFFF));
        }
    }

    private String getMarkStyleName() {
        switch (markStyle) {
            case MARK_STYLE_UNDERLINE_DOUBLE: return "Subrayado doble";
            case MARK_STYLE_UNDERLINE_WAVY: return "Subrayado ondulado";
            case MARK_STYLE_UNDERLINE_DOTTED: return "Subrayado punteado";
            case MARK_STYLE_HIGHLIGHT_SOFT: return "Resaltado suave";
            case MARK_STYLE_HIGHLIGHT_INTENSE: return "Resaltado intenso";
            case MARK_STYLE_TEXT_BOX: return "Caja de texto";
            case MARK_STYLE_UNDERLINE_FINE:
            default: return "Subrayado fino";
        }
    }

    private String getThicknessName() {
        if (markThicknessLevel == 0) return "Fino";
        if (markThicknessLevel == 2) return "Grueso";
        return "Medio";
    }

    private boolean isHighlightStyle(int style) {
        return style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE;
    }

    private int getCurrentMarkColor() {
        int target = isHighlightStyle(markStyle) ? COLOR_TARGET_HIGHLIGHT : COLOR_TARGET_UNDERLINE;
        int index = target == COLOR_TARGET_HIGHLIGHT ? highlightColorIndex : underlineColorIndex;
        return getMarkColor(target, index);
    }

    private int getMarkColor(int target, int index) {
        int rgb = MARK_COLOR_RGB[safeMarkColorIndex(index)];
        int alpha;
        if (target == COLOR_TARGET_HIGHLIGHT) {
            alpha = markStyle == MARK_STYLE_HIGHLIGHT_INTENSE ? 0xA8 : 0x62;
        } else {
            alpha = 0xEE;
        }
        return (alpha << 24) | rgb;
    }

    private int safeMarkStyle(int style) {
        if (style < MARK_STYLE_UNDERLINE_FINE || style > MARK_STYLE_TEXT_BOX) {
            return MARK_STYLE_UNDERLINE_FINE;
        }
        return style;
    }

    private int safeThicknessLevel(int level) {
        if (level < 0 || level > 2) return 1;
        return level;
    }

    private int migrateV71ColorIndex(int oldIndex) {
        switch (oldIndex) {
            case 1: return 3; // azul
            case 2: return 4; // verde
            case 3: return 1; // rojo
            case 4: return 6; // morado
            case 5: return 7; // celeste
            case 0:
            default: return 0;
        }
    }

    private int safeMarkColorIndex(int index) {
        if (index < 0 || index >= MARK_COLOR_RGB.length) return 0;
        return index;
    }

    private String highlightKey() {
        return "text_selection_markers_" + currentTitle;
    }

    private void saveHighlights(String serialized) {
        prefs.edit().putString(highlightKey(), serialized == null ? "" : serialized).apply();
    }

    private void repairBrokenPlaybackStateOnce() {
        if (prefs.getBoolean(PREF_AUDIO_STATE_REPAIRED_V69, false)) return;

        try {
            stopService(new Intent(this, TtsForegroundService.class));
        } catch (Exception ignored) {
        }

        TtsForegroundService.clearPages();
        prefs.edit()
                .putBoolean(PREF_TTS_ACTIVE, false)
                .putBoolean(PREF_TTS_PAUSED, false)
                .putInt(PREF_TTS_CURRENT_PAGE, -1)
                .putInt(PREF_TTS_STATE, TtsForegroundService.STATE_STOPPED)
                .putString(PREF_TTS_MESSAGE, "")
                .remove("tts_service_preparing")
                .putBoolean(PREF_AUDIO_STATE_REPAIRED_V69, true)
                .apply();

        playbackState = TtsForegroundService.STATE_STOPPED;
        audioStarted = false;
        audioPaused = false;
        audioPreparing = false;
        requestedAudioPage = -1;
        audioRequestToken++;
    }

    private void warmUpAudioEngine() {
        TtsEngineManager.getInstance(this).initialize(null);
    }

    private void toggleAudio() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        // Un segundo toque mientras se prepara no cancela la lectura por accidente.
        if (playbackState == TtsForegroundService.STATE_PREPARING || audioPreparing) {
            return;
        }

        if (playbackState == TtsForegroundService.STATE_PLAYING) {
            Intent intent = new Intent(this, TtsForegroundService.class);
            intent.setAction(TtsForegroundService.ACTION_TOGGLE);
            startService(intent);
            return;
        }

        if (playbackState == TtsForegroundService.STATE_PAUSED) {
            int readingPage = prefs.getInt(PREF_TTS_CURRENT_PAGE, -1);
            if (readingPage == currentPage) {
                Intent intent = new Intent(this, TtsForegroundService.class);
                intent.setAction(TtsForegroundService.ACTION_TOGGLE);
                startService(intent);
                return;
            }
        }

        startAudioFromPage(currentPage);
    }

    private void startAudioFromPage(final int pageToRead) {
        if (currentFile == null || pageCount <= 0) return;

        ensureNotificationPermission();
        cancelAudioPreparationTimeout();

        final int stateBeforeStart = playbackState;
        final int safePage = Math.max(0, Math.min(pageToRead, pageCount - 1));
        final int token = ++audioRequestToken;
        requestedAudioPage = safePage;
        applyPlaybackState(TtsForegroundService.STATE_PREPARING, safePage,
                "Preparando pagina " + (safePage + 1), false);

        String cached = textRepository.getCachedText(safePage);
        if (cached != null) {
            if (cached.trim().length() == 0) {
                failAudioPreparation("Esta pagina no contiene texto que Android pueda leer");
            } else {
                boolean replacingOldPlayback = stateBeforeStart == TtsForegroundService.STATE_PLAYING
                        || stateBeforeStart == TtsForegroundService.STATE_PREPARING
                        || stateBeforeStart == TtsForegroundService.STATE_PAUSED;
                if (replacingOldPlayback || !TtsEngineManager.getInstance(this).isReady()) {
                    startAudioPreparing(safePage);
                }
                beginTtsWithText(safePage, cached, token);
            }
            return;
        }

        // Mientras se extrae una pagina nueva, el servicio y el motor quedan listos.
        startAudioPreparing(safePage);
        textRepository.getPageTextPriority(safePage, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                if (token != audioRequestToken || requestedAudioPage != safePage) return;
                if (text == null || text.trim().length() == 0) {
                    failAudioPreparation("Esta pagina no contiene texto que Android pueda leer");
                    return;
                }
                beginTtsWithText(safePage, text, token);
            }
        });

        audioStartTimeout = new Runnable() {
            @Override
            public void run() {
                if (token != audioRequestToken || !audioPreparing) return;
                failAudioPreparation("El PDF tardo demasiado en preparar esta pagina");
            }
        };
        audioStartHandler.postDelayed(audioStartTimeout, 12000L);
    }

    private void startAudioPreparing(int safePage) {
        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_PREPARE);
        intent.putExtra("title", currentTitle);
        intent.putExtra("pageOffset", safePage);
        intent.putExtra("totalPages", pageCount);
        intent.putExtra("rate", speechRate);
        intent.putExtra("pitch", 1.0f);

        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);
    }

    private void beginTtsWithText(final int safePage, String text, final int token) {
        if (token != audioRequestToken || requestedAudioPage != safePage) return;
        if (text == null || text.trim().length() == 0) {
            failAudioPreparation("Esta pagina no contiene texto que Android pueda leer");
            return;
        }

        cancelAudioPreparationTimeout();
        TtsForegroundService.setPageText(safePage, text);

        Intent intent = new Intent(MainActivity.this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_START);
        intent.putExtra("title", currentTitle);
        intent.putExtra("pageOffset", safePage);
        intent.putExtra("totalPages", pageCount);
        intent.putExtra("startIndex", 0);
        intent.putExtra("rate", speechRate);
        intent.putExtra("pitch", 1.0f);

        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);

        // El boton sigue en "..." hasta recibir onStart real del motor TTS.
        applyPlaybackState(TtsForegroundService.STATE_PREPARING, safePage,
                "Preparando pagina " + (safePage + 1), false);
        textRepository.preloadAudioWindow(safePage + 1, 8, pageCount);
        textRepository.startFullPreload(safePage, pageCount);
    }

    private void failAudioPreparation(String message) {
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = -1;
        applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1, message, false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void cancelAudioPreparation() {
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = -1;
        applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1, "Detenido", false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
    }

    private void cancelAudioPreparationTimeout() {
        if (audioStartTimeout != null) {
            audioStartHandler.removeCallbacks(audioStartTimeout);
            audioStartTimeout = null;
        }
    }

    private void stopAudioOnly() {
        cancelAudioPreparationTimeout();
        audioRequestToken++;
        requestedAudioPage = -1;
        applyPlaybackState(TtsForegroundService.STATE_STOPPED, -1, "Detenido", false);

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
    }

    private void showGoto() {
        if (pageCount <= 0) return;

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setHint("Página 1 - " + pageCount);

        new AlertDialog.Builder(this)
                .setTitle("Ir a página")
                .setView(input)
                .setPositiveButton("Ir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            int p = Integer.parseInt(input.getText().toString()) - 1;
                            p = Math.max(0, Math.min(p, pageCount - 1));
                            requestManualPageChange(p);
                        } catch (Exception ignored) {
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void updatePageLabel() {
        if (pageCount <= 0) pageView.setText("0/0");
        else pageView.setText((currentPage + 1) + "/" + pageCount);
    }

    private void applyPlaybackState(int state, int readingPage, String message, boolean fromBroadcast) {
        playbackState = state;
        if (message == null) message = "";

        if (state == TtsForegroundService.STATE_PREPARING) {
            audioPreparing = true;
            audioStarted = false;
            audioPaused = false;
            if (playButton != null) playButton.setText("...");
        } else if (state == TtsForegroundService.STATE_PLAYING) {
            cancelAudioPreparationTimeout();
            audioPreparing = false;
            audioStarted = true;
            audioPaused = false;
            if (playButton != null) playButton.setText("Ⅱ");
        } else if (state == TtsForegroundService.STATE_PAUSED) {
            cancelAudioPreparationTimeout();
            audioPreparing = false;
            audioStarted = true;
            audioPaused = true;
            if (playButton != null) playButton.setText("▶");
        } else {
            cancelAudioPreparationTimeout();
            audioPreparing = false;
            audioStarted = false;
            audioPaused = false;
            requestedAudioPage = -1;
            if (playButton != null) playButton.setText("▶");
        }

        if (state == TtsForegroundService.STATE_ERROR && fromBroadcast) {
            audioRequestToken++;
            requestedAudioPage = -1;
        }

        if (state == TtsForegroundService.STATE_ERROR && fromBroadcast
                && message.length() > 0 && !message.equals(lastPlaybackError)) {
            lastPlaybackError = message;
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        } else if (state != TtsForegroundService.STATE_ERROR) {
            lastPlaybackError = "";
        }

        boolean readerOwnsPage = state == TtsForegroundService.STATE_PREPARING
                || state == TtsForegroundService.STATE_PLAYING
                || state == TtsForegroundService.STATE_PAUSED;
        if (!readerOwnsPage || readingPage < 0 || currentFile == null || pageCount <= 0 || pdfView == null) {
            return;
        }

        final int safePage = Math.max(0, Math.min(readingPage, pageCount - 1));
        if (safePage == currentPage) return;

        restartAudioAfterRender = false;
        textRepository.prepareVisiblePage(safePage, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                TtsForegroundService.setPageText(safePage, text);
            }
        });
        textRepository.preloadAudioWindow(safePage, 8, pageCount);
        pdfView.showPage(safePage);
    }

    private void syncVisiblePageWithReader() {
        if (prefs == null) return;

        int state = prefs.getInt(PREF_TTS_STATE, -1);
        if (state < 0) {
            boolean active = prefs.getBoolean(PREF_TTS_ACTIVE, false);
            boolean paused = prefs.getBoolean(PREF_TTS_PAUSED, false);
            state = !active ? TtsForegroundService.STATE_STOPPED
                    : (paused ? TtsForegroundService.STATE_PAUSED : TtsForegroundService.STATE_PLAYING);
        }
        int readingPage = prefs.getInt(PREF_TTS_CURRENT_PAGE, -1);
        String message = prefs.getString(PREF_TTS_MESSAGE, "");
        applyPlaybackState(state, readingPage, message, false);
    }

    private void saveProgress() {
        prefs.edit().putInt("last_page", currentPage).putString("last_title", currentTitle).apply();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        cancelAudioPreparationTimeout();
        stopPageSyncLoop();
        unregisterPlaybackReceiver();
        super.onDestroy();
        saveProgress();
        // Si el audio sigue activo, el servicio conserva este repositorio para obtener
        // las paginas siguientes con la pantalla apagada.
        if (!prefs.getBoolean(PREF_TTS_ACTIVE, false) && textRepository != null) {
            textRepository.close();
        }
        if (selectionRepository != null) selectionRepository.close();
        if (exportTts != null) {
            try { exportTts.shutdown(); } catch (Exception ignored) {}
        }
    }
}
