# Geo Zeta PDF a Audio V72 - Marcado y ajustes utiles

Esta version parte de V71 y conserva sin cambios la lectura rapida, el motor persistente, la reproduccion en segundo plano, la pantalla apagada, la notificacion y las reglas de lectura.

## Cambios visibles

- Ajustes simplificados: solo apariencia, voz, velocidad y marcado.
- Se ocultaron de Ajustes las funciones automaticas de segundo plano, pantalla apagada, zoom, memoria de pagina, exportacion y controles de notificacion. Las funciones siguen operativas.
- Brillo de lectura ajustable o controlado por el sistema.
- Tipos de marcado: subrayado fino, doble, ondulado, punteado, resaltado suave, resaltado intenso y caja de texto.
- Grosor del subrayado: fino, medio o grueso.
- Paleta visual de colores: se elige tocando muestras reales, sin mostrar nombres como Amarillo o Azul.
- El boton de color de la barra inferior muestra solo un circulo con el color actual.
- Compatibilidad con marcas creadas en V71.

## Version

- versionCode: 72
- versionName: 72.0-instant-play-marking-settings

El flujo de GitHub Actions genera el APK debug como artefacto descargable.
