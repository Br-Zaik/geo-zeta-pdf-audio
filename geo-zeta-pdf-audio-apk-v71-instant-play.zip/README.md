# Geo Zeta PDF a Audio V71 - Inicio rapido

Esta version conserva el funcionamiento de V69: visor PDF, lectura continua, segundo plano, pantalla apagada, notificacion, reglas de recorte y los dos tipos de marcado.

El unico objetivo de V71 es reducir la espera al pulsar Play al entrar en la app o despues de cambiar de pagina.

## Cambios de rapidez

- El motor TextToSpeech se inicia desde `Application` y recibe un calentamiento silencioso y muy corto.
- La pagina guardada se envia a la cola urgente antes de terminar de abrir el visor y el repositorio de marcado.
- Al cambiar de pagina con las flechas o con el selector `#`, el texto se prepara desde el momento del cambio, sin esperar al boton Play.
- La pagina visible obtiene prioridad frente al indexado completo del PDF.
- La precarga pesada comienza solo despues de que el texto prioritario ya fue entregado.
- Cuando la pagina y el motor ya estan listos, se evita una orden PREPARE duplicada.
- La primera orden enviada al motor contiene solo la primera frase o linea util, con un maximo aproximado de 220 caracteres.
- Los bloques siguientes permanecen grandes para conservar continuidad y evitar pausas innecesarias.

## Funciones conservadas

- Lectura en segundo plano.
- Continuidad con la pantalla apagada.
- Controles desde la notificacion.
- Motor persistente y motores alternativos.
- Cache en RAM y almacenamiento privado.
- Reglas superior e inferior: se sigue leyendo solo el texto comprendido dentro de ambas reglas cuando estan activadas.
- Subrayado y resaltado con sus colores.
- Cambio automatico de pagina durante la lectura.

## Version

- versionCode: 71
- versionName: 71.0-instant-play-persistent-engine-dual-mark

El flujo de GitHub Actions compila el proyecto directamente o el ZIP `geo-zeta-pdf-audio-apk-v71-instant-play.zip` colocado en la raiz.
