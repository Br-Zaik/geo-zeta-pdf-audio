# Geo Zeta PDF a Audio V78

Cambios principales:

- Corrección de resaltado suave e intenso para cubrir mejor las letras sin ocultarlas.
- Corrección de caja de texto para cerrar completamente el borde por cada fragmento seleccionado.
- Las marcas se separan por palabras y no cubren espacios vacíos largos.
- Las marcas siguen guardándose por PDF y reaparecen al cambiar de página o volver a abrir la app.
- Galería de imágenes en cuadrícula dentro de Mis archivos.
- Visor de imágenes con zoom por pellizco, doble toque y navegación anterior/siguiente.
- Exportación de la página actual o del PDF completo con los marcados visibles y sin las reglas de lectura.
- Se mantienen segundo plano, pantalla apagada, audio, reglas y demás funciones existentes.

Versión:
- versionCode: 78
- versionName: 78.0-marking-gallery-pdf-export
