
package com.geozeta.pdfaudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import org.json.JSONArray;
import java.util.ArrayList;
import java.util.Locale;

public class TtsForegroundService extends Service {
    public static final String ACTION_START = "com.geozeta.pdfaudio.START";
    public static final String ACTION_STOP = "com.geozeta.pdfaudio.STOP";
    public static final String ACTION_NEXT = "com.geozeta.pdfaudio.NEXT";
    public static final String ACTION_PREV = "com.geozeta.pdfaudio.PREV";
    public static final String PREFS = "GeoZetaTtsPrefs";
    private static final String CHANNEL_ID = "pdf_audio_playback";
    private static final int NOTIFICATION_ID = 72;

    private TextToSpeech tts;
    private boolean ready = false;
    private final ArrayList<String> pages = new ArrayList<>();
    private int currentIndex = 0;
    private String title = "PDF a Audio";
    private boolean reading = false;
    private String pendingJson = null;
    private int pendingStart = 0;
    private String pendingTitle = null;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("es", "PE"));
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(new Locale("es", "ES"));
                }
                tts.setSpeechRate(0.95f);
                tts.setPitch(1.0f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) {}
                    @Override public void onDone(String utteranceId) {
                        if (reading) {
                            currentIndex++;
                            if (currentIndex < pages.size()) speakCurrentPage();
                            else stopEverything();
                        }
                    }
                    @Override public void onError(String utteranceId) { stopEverything(); }
                });
                ready = true;
                if (pendingJson != null) {
                    startReading(pendingJson, pendingStart, pendingTitle);
                    pendingJson = null;
                }
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_STICKY;
        String action = intent.getAction();
        if (ACTION_START.equals(action)) {
            String json = intent.getStringExtra("pagesJson");
            int startIndex = intent.getIntExtra("startIndex", 0);
            String incomingTitle = intent.getStringExtra("title");
            if (!ready) {
                pendingJson = json;
                pendingStart = startIndex;
                pendingTitle = incomingTitle;
                startForeground(NOTIFICATION_ID, buildNotification("Preparando audio...", startIndex + 1));
            } else {
                startReading(json, startIndex, incomingTitle);
            }
        } else if (ACTION_STOP.equals(action)) {
            stopEverything();
        } else if (ACTION_NEXT.equals(action)) {
            nextPage();
        } else if (ACTION_PREV.equals(action)) {
            prevPage();
        }
        return START_STICKY;
    }

    private void startReading(String pagesJson, int startIndex, String incomingTitle) {
        try {
            pages.clear();
            JSONArray arr = new JSONArray(pagesJson);
            for (int i = 0; i < arr.length(); i++) pages.add(arr.optString(i, ""));
            currentIndex = Math.max(0, Math.min(startIndex, pages.size() - 1));
            title = incomingTitle == null || incomingTitle.trim().isEmpty() ? "PDF a Audio" : incomingTitle;
            reading = true;
            saveState();
            startForeground(NOTIFICATION_ID, buildNotification("Leyendo página " + (currentIndex + 1), currentIndex + 1));
            speakCurrentPage();
        } catch (Exception e) { stopEverything(); }
    }

    private void speakCurrentPage() {
        if (!ready || pages.isEmpty() || currentIndex < 0 || currentIndex >= pages.size()) {
            stopEverything(); return;
        }
        saveState();
        updateNotification("Leyendo página " + (currentIndex + 1), currentIndex + 1);
        String text = pages.get(currentIndex);
        if (text == null || text.trim().isEmpty()) {
            currentIndex++;
            if (currentIndex < pages.size()) speakCurrentPage();
            else stopEverything();
            return;
        }
        if (text.length() > 30000) text = text.substring(0, 30000);
        tts.stop();
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "PAGE_" + currentIndex);
    }

    private void nextPage() {
        if (pages.isEmpty()) return;
        currentIndex = Math.min(pages.size() - 1, currentIndex + 1);
        reading = true;
        speakCurrentPage();
    }

    private void prevPage() {
        if (pages.isEmpty()) return;
        currentIndex = Math.max(0, currentIndex - 1);
        reading = true;
        speakCurrentPage();
    }

    private void stopEverything() {
        reading = false;
        saveState();
        if (tts != null) tts.stop();
        stopForeground(true);
        stopSelf();
    }

    private void saveState() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit()
            .putInt("currentPage", currentIndex + 1)
            .putBoolean("isReading", reading)
            .putString("title", title)
            .apply();
    }

    private void updateNotification(String text, int page) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text, page));
    }

    private Notification buildNotification(String text, int page) {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        PendingIntent stopPending = PendingIntent.getService(this, 1,
            new Intent(this, TtsForegroundService.class).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        PendingIntent nextPending = PendingIntent.getService(this, 2,
            new Intent(this, TtsForegroundService.class).setAction(ACTION_NEXT),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        PendingIntent prevPending = PendingIntent.getService(this, 3,
            new Intent(this, TtsForegroundService.class).setAction(ACTION_PREV),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);

        builder.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(text)
            .setSubText("Página " + page)
            .setContentIntent(openPending)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_previous, "Anterior", prevPending)
            .addAction(android.R.drawable.ic_media_next, "Siguiente", nextPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPending);

        if (Build.VERSION.SDK_INT >= 21) builder.setVisibility(Notification.VISIBILITY_PUBLIC);
        return builder.build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "PDF a Audio",
                NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Reproducción de PDF a audio en segundo plano");
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
