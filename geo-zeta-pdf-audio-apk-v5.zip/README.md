# Geo Zeta PDF a Audio V5

Cambios principales:
- Reproducción en segundo plano con Foreground Service.
- Sigue leyendo con pantalla apagada.
- Notificación de reproducción con acciones: anterior, siguiente y detener.
- Guarda el último PDF y la última página.
- Al volver a la app, sincroniza la página actual.
- Filtro para encabezado, pie y número de página.
