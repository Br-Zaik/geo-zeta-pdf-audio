package com.geozeta.pdfaudio;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;

/**
 * V218. Une todos los trozos que sintetiza el motor en UN SOLO archivo de audio.
 *
 * Antes cada pagina quedaba en su propio .wav y, si se elegia un rango (por
 * ejemplo de la 4 a la 9), salian seis archivos sueltos. Ahora todo el rango
 * termina en un unico audio continuo.
 *
 * Formato: M4A (AAC) con el codificador del propio telefono (MediaCodec +
 * MediaMuxer). Ocupa unas 8 veces menos que WAV (una hora de voz son ~25 MB en
 * vez de ~170 MB) y se abre en cualquier reproductor. Si el telefono no tuviera
 * codificador AAC, se cae a WAV sin que el usuario tenga que hacer nada.
 *
 * Tambien arregla los "ticks" en las uniones. Cada trozo que entrega el motor
 * empieza y termina en un punto cualquiera de la onda; pegarlos tal cual deja
 * un salto brusco que se oye como un clic. Aqui cada trozo:
 *   1. se recorta del silencio sobrante del principio y del final,
 *   2. entra y sale con un fundido de unos milisegundos (sin clic),
 *   3. se separa del siguiente con un silencio limpio y siempre igual,
 * asi el audio largo suena parejo, como una lectura de corrido.
 *
 * Todo corre en un solo hilo de fondo (el del servicio de exportacion). No es
 * seguro llamarlo desde varios hilos a la vez.
 */
final class AudioExportWriter {

    private static final String AAC_MIME = "audio/mp4a-latm";
    private static final int AAC_BIT_RATE = 64000;
    private static final long CODEC_TIMEOUT_US = 10000L;

    /** Amplitud por debajo de la cual se considera silencio (~ -40 dB). */
    private static final int SILENCE_THRESHOLD = 330;
    private static final int KEEP_LEAD_MS = 25;
    private static final int KEEP_TAIL_MS = 60;
    private static final int FADE_IN_MS = 6;
    private static final int FADE_OUT_MS = 10;

    private final File target;
    private boolean useAac;

    private int sampleRate = -1;
    private long samplesWritten;
    private boolean finished;

    // AAC
    private MediaCodec codec;
    private MediaMuxer muxer;
    private int trackIndex = -1;
    private boolean muxerStarted;
    private long samplesQueued;
    private final MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();

    // WAV (respaldo)
    private RandomAccessFile wavOut;
    private long wavDataBytes;

    AudioExportWriter(File target, boolean preferAac) {
        this.target = target;
        this.useAac = preferAac;
    }

    boolean isAac() {
        return useAac;
    }

    long getDurationMs() {
        if (sampleRate <= 0) return 0L;
        return samplesWritten * 1000L / sampleRate;
    }

    boolean hasAudio() {
        return samplesWritten > 0;
    }

    /**
     * Agrega un trozo WAV del motor y despues un silencio de gapMs.
     * Devuelve false si el trozo no tenia audio utilizable (se ignora sin error).
     */
    boolean appendWavPart(File wav, int gapMs) throws IOException {
        if (finished) throw new IOException("writer finished");
        short[] samples = readWavAsMono16(wav);
        if (samples == null || samples.length == 0) return false;
        return appendSamples(samples, gapMs);
    }

    /** Solo silencio (por ejemplo, la pausa entre paginas). */
    void appendSilence(int ms) throws IOException {
        if (sampleRate <= 0 || ms <= 0) return;
        writeSamples(new short[(int) ((long) sampleRate * ms / 1000L)]);
    }

    private boolean appendSamples(short[] samples, int gapMs) throws IOException {
        int rate = lastPartRate;
        if (sampleRate <= 0) {
            sampleRate = rate;
            open();
        } else if (rate != sampleRate) {
            samples = resampleLinear(samples, rate, sampleRate);
        }

        int first = -1;
        int last = -1;
        for (int i = 0; i < samples.length; i++) {
            if (Math.abs(samples[i]) > SILENCE_THRESHOLD) {
                first = i;
                break;
            }
        }
        if (first < 0) return false;
        for (int i = samples.length - 1; i >= first; i--) {
            if (Math.abs(samples[i]) > SILENCE_THRESHOLD) {
                last = i;
                break;
            }
        }
        int start = Math.max(0, first - ms(KEEP_LEAD_MS));
        int end = Math.min(samples.length, last + 1 + ms(KEEP_TAIL_MS));
        int length = end - start;
        if (length <= 0) return false;

        short[] part = new short[length];
        System.arraycopy(samples, start, part, 0, length);

        int fadeIn = Math.min(length / 2, ms(FADE_IN_MS));
        for (int i = 0; i < fadeIn; i++) {
            part[i] = (short) (part[i] * (i / (float) fadeIn));
        }
        int fadeOut = Math.min(length / 2, ms(FADE_OUT_MS));
        for (int i = 0; i < fadeOut; i++) {
            int index = length - 1 - i;
            part[index] = (short) (part[index] * (i / (float) fadeOut));
        }

        writeSamples(part);
        if (gapMs > 0) writeSamples(new short[ms(gapMs)]);
        return true;
    }

    private int ms(int milliseconds) {
        return (int) ((long) Math.max(1, sampleRate) * milliseconds / 1000L);
    }

    // ------------------------------------------------------------------
    // Apertura / escritura / cierre
    // ------------------------------------------------------------------

    private void open() throws IOException {
        File parent = target.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        if (target.exists()) target.delete();
        if (useAac) {
            try {
                openAac();
                return;
            } catch (Exception e) {
                releaseAacQuietly();
                if (target.exists()) target.delete();
                useAac = false;
            }
        }
        openWav();
    }

    private void openAac() throws IOException {
        MediaFormat format = MediaFormat.createAudioFormat(AAC_MIME, sampleRate, 1);
        format.setInteger(MediaFormat.KEY_AAC_PROFILE,
                MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        format.setInteger(MediaFormat.KEY_BIT_RATE, AAC_BIT_RATE);
        format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
        codec = MediaCodec.createEncoderByType(AAC_MIME);
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        codec.start();
        muxer = new MediaMuxer(target.getAbsolutePath(),
                MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        trackIndex = -1;
        muxerStarted = false;
        samplesQueued = 0L;
    }

    private void openWav() throws IOException {
        wavOut = new RandomAccessFile(target, "rw");
        wavOut.setLength(0L);
        wavOut.write(new byte[44]);
        wavDataBytes = 0L;
    }

    private void writeSamples(short[] samples) throws IOException {
        if (samples.length == 0) return;
        byte[] bytes = new byte[samples.length * 2];
        for (int i = 0; i < samples.length; i++) {
            bytes[2 * i] = (byte) (samples[i] & 0xFF);
            bytes[2 * i + 1] = (byte) ((samples[i] >> 8) & 0xFF);
        }
        if (useAac) {
            feedAac(bytes, bytes.length);
        } else {
            wavOut.write(bytes);
            wavDataBytes += bytes.length;
        }
        samplesWritten += samples.length;
    }

    private void feedAac(byte[] data, int length) throws IOException {
        int offset = 0;
        int idleLoops = 0;
        while (offset < length) {
            int inIndex = codec.dequeueInputBuffer(CODEC_TIMEOUT_US);
            if (inIndex >= 0) {
                ByteBuffer input = codec.getInputBuffer(inIndex);
                if (input == null) throw new IOException("input buffer null");
                input.clear();
                int count = Math.min(input.remaining(), length - offset);
                count -= count % 2;
                if (count <= 0) throw new IOException("input buffer too small");
                input.put(data, offset, count);
                long ptsUs = samplesQueued * 1000000L / sampleRate;
                samplesQueued += count / 2;
                codec.queueInputBuffer(inIndex, 0, count, ptsUs, 0);
                offset += count;
                idleLoops = 0;
            } else if (++idleLoops > 3000) {
                throw new IOException("encoder stalled");
            }
            drainAac(false);
        }
    }

    private void drainAac(boolean untilEndOfStream) throws IOException {
        int waits = 0;
        while (true) {
            int outIndex = codec.dequeueOutputBuffer(bufferInfo,
                    untilEndOfStream ? CODEC_TIMEOUT_US : 0L);
            if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!untilEndOfStream) return;
                if (++waits > 3000) throw new IOException("encoder did not finish");
                continue;
            }
            if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (muxerStarted) throw new IOException("format changed twice");
                trackIndex = muxer.addTrack(codec.getOutputFormat());
                muxer.start();
                muxerStarted = true;
                continue;
            }
            if (outIndex < 0) continue;

            ByteBuffer output = codec.getOutputBuffer(outIndex);
            if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                bufferInfo.size = 0;
            }
            if (bufferInfo.size > 0 && output != null && muxerStarted) {
                output.position(bufferInfo.offset);
                output.limit(bufferInfo.offset + bufferInfo.size);
                muxer.writeSampleData(trackIndex, output, bufferInfo);
            }
            codec.releaseOutputBuffer(outIndex, false);
            if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return;
        }
    }

    /** Cierra el archivo. Devuelve true si quedo un audio valido. */
    boolean finish() throws IOException {
        if (finished) return target.exists() && samplesWritten > 0;
        finished = true;
        if (sampleRate <= 0 || samplesWritten <= 0) {
            abort();
            return false;
        }
        if (useAac) {
            try {
                int waits = 0;
                while (true) {
                    int inIndex = codec.dequeueInputBuffer(CODEC_TIMEOUT_US);
                    if (inIndex >= 0) {
                        long ptsUs = samplesQueued * 1000000L / sampleRate;
                        codec.queueInputBuffer(inIndex, 0, 0, ptsUs,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        break;
                    }
                    if (++waits > 3000) throw new IOException("no input for end of stream");
                    drainAac(false);
                }
                drainAac(true);
                if (!muxerStarted) throw new IOException("muxer never started");
                muxer.stop();
            } finally {
                releaseAacQuietly();
            }
            return target.exists() && target.length() > 0;
        }

        long riffSize = 36L + wavDataBytes;
        if (riffSize > 0xFFFFFFFFL) riffSize = 0xFFFFFFFFL;
        long dataSize = Math.min(wavDataBytes, 0xFFFFFFFFL);
        byte[] header = new byte[44];
        putAscii(header, 0, "RIFF");
        putInt32(header, 4, riffSize);
        putAscii(header, 8, "WAVE");
        putAscii(header, 12, "fmt ");
        putInt32(header, 16, 16);
        putInt16(header, 20, 1);
        putInt16(header, 22, 1);
        putInt32(header, 24, sampleRate);
        putInt32(header, 28, sampleRate * 2L);
        putInt16(header, 32, 2);
        putInt16(header, 34, 16);
        putAscii(header, 36, "data");
        putInt32(header, 40, dataSize);
        try {
            wavOut.seek(0L);
            wavOut.write(header);
        } finally {
            try { wavOut.close(); } catch (Exception ignored) { }
            wavOut = null;
        }
        return target.exists() && target.length() > 44L;
    }

    /** Descarta todo y borra el archivo a medio hacer. */
    void abort() {
        finished = true;
        releaseAacQuietly();
        if (wavOut != null) {
            try { wavOut.close(); } catch (Exception ignored) { }
            wavOut = null;
        }
        try { if (target.exists()) target.delete(); } catch (Exception ignored) { }
    }

    private void releaseAacQuietly() {
        if (codec != null) {
            try { codec.stop(); } catch (Exception ignored) { }
            try { codec.release(); } catch (Exception ignored) { }
            codec = null;
        }
        if (muxer != null) {
            try { muxer.release(); } catch (Exception ignored) { }
            muxer = null;
        }
        muxerStarted = false;
    }

    // ------------------------------------------------------------------
    // Lectura de los WAV que escribe el motor
    // ------------------------------------------------------------------

    /** Frecuencia del ultimo trozo leido. */
    private int lastPartRate = 22050;

    /**
     * Lee un WAV (PCM 8/16/24/32 bits o flotante) y lo devuelve en mono de 16
     * bits. Se busca el bloque "data" de verdad en vez de saltar 44 bytes fijos:
     * algunos motores agregan bloques extra en la cabecera.
     */
    private short[] readWavAsMono16(File file) throws IOException {
        if (file == null || !file.exists() || file.length() <= 44L) return null;
        long fileLength = file.length();
        if (fileLength > 256L * 1024L * 1024L) throw new IOException("part too large");
        byte[] all = new byte[(int) fileLength];
        try (FileInputStream in = new FileInputStream(file)) {
            int read = 0;
            while (read < all.length) {
                int count = in.read(all, read, all.length - read);
                if (count < 0) break;
                read += count;
            }
            if (read < 44) return null;
            if (read < all.length) {
                byte[] shorter = new byte[read];
                System.arraycopy(all, 0, shorter, 0, read);
                all = shorter;
            }
        }
        if (!"RIFF".equals(ascii(all, 0)) || !"WAVE".equals(ascii(all, 8))) return null;

        int format = 1;
        int channels = 1;
        int rate = 0;
        int bits = 16;
        int dataOffset = -1;
        int dataLength = 0;
        int pos = 12;
        while (pos + 8 <= all.length) {
            String id = ascii(all, pos);
            long size = int32(all, pos + 4);
            int body = pos + 8;
            if ("fmt ".equals(id) && body + 16 <= all.length) {
                format = int16(all, body);
                channels = Math.max(1, int16(all, body + 2));
                rate = (int) int32(all, body + 4);
                bits = int16(all, body + 14);
            } else if ("data".equals(id)) {
                dataOffset = body;
                long available = all.length - body;
                // El motor puede dejar el tamano en 0 o en 0xFFFFFFFF si escribe
                // en streaming: en ese caso vale lo que haya en el archivo.
                dataLength = (int) ((size <= 0 || size > available) ? available : size);
                break;
            }
            if (size < 0 || size > all.length) break;
            pos = body + (int) size + (int) (size & 1L);
        }
        if (dataOffset < 0 || dataLength <= 0 || rate <= 0) return null;
        lastPartRate = rate;

        boolean isFloat = format == 3;
        int bytesPerSample = Math.max(1, bits / 8);
        int frameBytes = bytesPerSample * channels;
        int frames = dataLength / frameBytes;
        short[] out = new short[frames];
        for (int f = 0; f < frames; f++) {
            int frameStart = dataOffset + f * frameBytes;
            int sum = 0;
            for (int c = 0; c < channels; c++) {
                int p = frameStart + c * bytesPerSample;
                int value;
                if (bytesPerSample == 1) {
                    value = ((all[p] & 0xFF) - 128) << 8;
                } else if (bytesPerSample == 2) {
                    value = (short) ((all[p] & 0xFF) | (all[p + 1] << 8));
                } else if (bytesPerSample == 3) {
                    value = (short) ((all[p + 1] & 0xFF) | (all[p + 2] << 8));
                } else if (isFloat) {
                    int bitsValue = (all[p] & 0xFF) | ((all[p + 1] & 0xFF) << 8)
                            | ((all[p + 2] & 0xFF) << 16) | (all[p + 3] << 24);
                    float sample = Float.intBitsToFloat(bitsValue);
                    if (sample > 1f) sample = 1f;
                    if (sample < -1f) sample = -1f;
                    value = (int) (sample * 32767f);
                } else {
                    value = (short) ((all[p + 2] & 0xFF) | (all[p + 3] << 8));
                }
                sum += value;
            }
            int mono = sum / channels;
            if (mono > Short.MAX_VALUE) mono = Short.MAX_VALUE;
            if (mono < Short.MIN_VALUE) mono = Short.MIN_VALUE;
            out[f] = (short) mono;
        }
        return out;
    }

    private static short[] resampleLinear(short[] input, int fromRate, int toRate) {
        if (fromRate <= 0 || toRate <= 0 || fromRate == toRate || input.length == 0) return input;
        int outLength = (int) ((long) input.length * toRate / fromRate);
        if (outLength <= 0) return new short[0];
        short[] out = new short[outLength];
        double step = fromRate / (double) toRate;
        for (int i = 0; i < outLength; i++) {
            double position = i * step;
            int index = (int) position;
            double fraction = position - index;
            int a = input[Math.min(index, input.length - 1)];
            int b = input[Math.min(index + 1, input.length - 1)];
            out[i] = (short) Math.round(a + (b - a) * fraction);
        }
        return out;
    }

    private static String ascii(byte[] data, int offset) {
        if (offset + 4 > data.length) return "";
        return new String(data, offset, 4, java.nio.charset.StandardCharsets.US_ASCII);
    }

    private static int int16(byte[] data, int offset) {
        return (data[offset] & 0xFF) | ((data[offset + 1] & 0xFF) << 8);
    }

    private static long int32(byte[] data, int offset) {
        return (data[offset] & 0xFFL) | ((data[offset + 1] & 0xFFL) << 8)
                | ((data[offset + 2] & 0xFFL) << 16) | ((data[offset + 3] & 0xFFL) << 24);
    }

    private static void putAscii(byte[] data, int offset, String value) {
        for (int i = 0; i < 4; i++) data[offset + i] = (byte) value.charAt(i);
    }

    private static void putInt16(byte[] data, int offset, int value) {
        data[offset] = (byte) (value & 0xFF);
        data[offset + 1] = (byte) ((value >> 8) & 0xFF);
    }

    private static void putInt32(byte[] data, int offset, long value) {
        data[offset] = (byte) (value & 0xFF);
        data[offset + 1] = (byte) ((value >> 8) & 0xFF);
        data[offset + 2] = (byte) ((value >> 16) & 0xFF);
        data[offset + 3] = (byte) ((value >> 24) & 0xFF);
    }
}
