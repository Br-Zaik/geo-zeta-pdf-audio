package com.geozeta.pdfaudio;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

public class SelectionTextRepository {
    public interface CharCallback {
        void onChars(ArrayList<CharBox> chars);
    }

    private final ThreadPoolExecutor executor;
    private final AtomicLong taskSequence;
    private static final int PRIORITY_OPEN = -100;
    private static final int PRIORITY_VISIBLE = 0;
    private static final int PRIORITY_PREFETCH = 20;
    private static final int PRIORITY_CLOSE = -120;
    private final Handler mainHandler;
    /** Paginas de coordenadas conservadas en memoria a la vez. */
    private static final int MAX_PAGES_IN_MEMORY = 24;

    private final Map<Integer, ArrayList<CharBox>> cache;
    private PDDocument document;
    private File openedFile;
    private boolean opening;

    public SelectionTextRepository(Context context) {
        PDFBoxResourceLoader.init(context);
        taskSequence = new AtomicLong();
        executor = new ThreadPoolExecutor(
                1, 1, 0L, TimeUnit.MILLISECONDS,
                new PriorityBlockingQueue<Runnable>());
        mainHandler = new Handler(Looper.getMainLooper());
        // Las coordenadas por pagina son pesadas: se acotan igual que el texto.
        cache = java.util.Collections.synchronizedMap(
                new java.util.LinkedHashMap<Integer, ArrayList<CharBox>>(16, 0.75f, true) {
                    @Override
                    protected boolean removeEldestEntry(
                            Map.Entry<Integer, ArrayList<CharBox>> eldest) {
                        return size() > MAX_PAGES_IN_MEMORY;
                    }
                });
    }

    public void open(final File file) {
        if (file == null) return;
        final PDDocument oldDocument;
        synchronized (this) {
            if (openedFile != null && openedFile.getAbsolutePath().equals(file.getAbsolutePath())
                    && (document != null || opening)) {
                return;
            }
            oldDocument = document;
            document = null;
            openedFile = file;
            opening = true;
            cache.clear();
        }

        submit(PRIORITY_OPEN, new Runnable() {
            @Override
            public void run() {
                try {
                    if (oldDocument != null) oldDocument.close();
                } catch (Exception ignored) {
                }
                try {
                    PDDocument doc = PDDocument.load(file);
                    synchronized (SelectionTextRepository.this) {
                        if (openedFile != null && openedFile.getAbsolutePath().equals(file.getAbsolutePath())) {
                            document = doc;
                        } else {
                            try { doc.close(); } catch (Exception ignored) { }
                        }
                        opening = false;
                    }
                } catch (Exception ignored) {
                    synchronized (SelectionTextRepository.this) {
                        opening = false;
                    }
                }
            }
        });
    }

    public void getChars(final int zeroBasedPage, final CharCallback callback) {
        ArrayList<CharBox> cached = cache.get(zeroBasedPage);
        if (cached != null) {
            final ArrayList<CharBox> copy = new ArrayList<CharBox>(cached);
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    callback.onChars(copy);
                }
            });
            return;
        }

        getCharsInternal(zeroBasedPage, callback, 0, PRIORITY_VISIBLE);
    }

    private void getCharsInternal(final int zeroBasedPage, final CharCallback callback,
                                  final int attempt, final int priority) {
        submit(priority, new Runnable() {
            @Override
            public void run() {
                ArrayList<CharBox> cachedNow = cache.get(zeroBasedPage);
                if (cachedNow != null) {
                    final ArrayList<CharBox> copy = new ArrayList<CharBox>(cachedNow);
                    mainHandler.post(new Runnable() {
                        @Override public void run() { callback.onChars(copy); }
                    });
                    return;
                }

                PDDocument doc;
                synchronized (SelectionTextRepository.this) {
                    doc = document;
                }

                // V218. Espera hasta ~12 s a que el PDF termine de abrirse. Con
                // 2 s, un libro grande abierto en frio devolvia coordenadas
                // vacias y el seguimiento de lectura no aparecia.
                if (doc == null && attempt < 60) {
                    mainHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            getCharsInternal(zeroBasedPage, callback, attempt + 1, priority);
                        }
                    }, 200);
                    return;
                }

                ArrayList<CharBox> result = new ArrayList<CharBox>();

                try {
                    if (doc != null && zeroBasedPage >= 0 && zeroBasedPage < doc.getNumberOfPages()) {
                        CharacterStripper stripper = new CharacterStripper(zeroBasedPage);
                        int p = zeroBasedPage + 1;
                        stripper.setStartPage(p);
                        stripper.setEndPage(p);
                        stripper.getText(doc);
                        result = stripper.getChars();
                        cache.put(zeroBasedPage, result);
                    }
                } catch (Exception ignored) {
                }

                final ArrayList<CharBox> finalResult = result;
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onChars(finalResult);
                    }
                });
            }
        });
    }

    public void prefetch(int fromPage, int count, int totalPages) {
        for (int i = 0; i < count; i++) {
            int page = fromPage + i;
            if (page >= 0 && page < totalPages && !cache.containsKey(page)) {
                final int requestedPage = page;
                getCharsInternal(requestedPage, new CharCallback() {
                    @Override
                    public void onChars(ArrayList<CharBox> chars) {
                        // Solo calienta la cache; nunca compite en prioridad con la pagina visible.
                    }
                }, 0, PRIORITY_PREFETCH);
            }
        }
    }


    private void submit(int priority, Runnable action) {
        if (action == null) return;
        executor.execute(new PriorityTask(priority, taskSequence.getAndIncrement(), action));
    }

    private static final class PriorityTask implements Runnable, Comparable<PriorityTask> {
        final int priority;
        final long sequence;
        final Runnable action;

        PriorityTask(int priority, long sequence, Runnable action) {
            this.priority = priority;
            this.sequence = sequence;
            this.action = action;
        }

        @Override public void run() {
            action.run();
        }

        @Override public int compareTo(PriorityTask other) {
            if (priority != other.priority) return priority < other.priority ? -1 : 1;
            return sequence < other.sequence ? -1 : (sequence == other.sequence ? 0 : 1);
        }
    }

    public void close() {
        final PDDocument oldDocument;
        synchronized (this) {
            oldDocument = document;
            document = null;
            openedFile = null;
            opening = false;
            cache.clear();
        }
        if (oldDocument != null) {
            submit(PRIORITY_CLOSE, new Runnable() {
                @Override
                public void run() {
                    try { oldDocument.close(); } catch (Exception ignored) { }
                }
            });
        }
    }

    private static class CharacterStripper extends PDFTextStripper {
        private final int pageIndex;
        private final ArrayList<RawChar> rawChars;

        CharacterStripper(int pageIndex) throws IOException {
            super();
            this.pageIndex = pageIndex;
            this.rawChars = new ArrayList<RawChar>();
            setSortByPosition(true);
        }

        @Override
        protected void processTextPosition(TextPosition text) {
            String unicode = text.getUnicode();
            if (unicode == null || unicode.length() == 0) return;
            if (unicode.trim().length() == 0) return;

            float pageWidth = Math.max(1f, text.getPageWidth());
            float pageHeight = Math.max(1f, text.getPageHeight());

            float left = clamp(text.getXDirAdj() / pageWidth);
            float right = clamp((text.getXDirAdj() + text.getWidthDirAdj()) / pageWidth);
            float top = clamp((text.getYDirAdj() - text.getHeightDir()) / pageHeight);
            float bottom = clamp(text.getYDirAdj() / pageHeight);

            if (right <= left || bottom <= top) return;

            rawChars.add(new RawChar(unicode, left, top, right, bottom));
        }

        ArrayList<CharBox> getChars() {
            ArrayList<CharBox> out = new ArrayList<CharBox>();
            int line = -1;
            float lastCenterY = -999f;

            for (int i = 0; i < rawChars.size(); i++) {
                RawChar r = rawChars.get(i);
                float cy = (r.top + r.bottom) / 2f;
                float height = Math.max(0.006f, r.bottom - r.top);
                if (line < 0 || Math.abs(cy - lastCenterY) > Math.max(0.012f, height * 0.65f)) {
                    line++;
                    lastCenterY = cy;
                }

                out.add(new CharBox(pageIndex, out.size(), line, r.text, r.left, r.top, r.right, r.bottom));
            }

            return out;
        }

        private static float clamp(float v) {
            if (v < 0f) return 0f;
            if (v > 1f) return 1f;
            return v;
        }
    }

    private static class RawChar {
        final String text;
        final float left;
        final float top;
        final float right;
        final float bottom;

        RawChar(String text, float left, float top, float right, float bottom) {
            this.text = text;
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
        }
    }
}
