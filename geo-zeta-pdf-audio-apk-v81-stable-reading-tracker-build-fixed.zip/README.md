# Geo Zeta PDF a Audio V81

Corrección de estabilidad de la V80.

- El seguimiento visual queda desactivado por defecto y se activa desde Ajustes.
- Se eliminó el botón ambiguo de seguimiento de la barra superior.
- Nuevo bloque profesional SEGUIMIENTO VISUAL con interruptor y color.
- Las actualizaciones del marcador se limitan y agrupan para no bloquear la interfaz.
- El texto de la página se indexa una sola vez y se reutiliza durante la lectura.
- Se evita solicitar repetidamente los caracteres de la misma página.
- Abrir y cerrar el repositorio de selección ya no bloquea el hilo principal.
- Se mantiene el color personalizado de reglas, exportación por rango, carpetas y demás funciones de V80.

VersionCode: 81
VersionName: 81.0-stable-optional-reading-tracker
