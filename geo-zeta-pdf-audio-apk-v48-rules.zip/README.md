# Geo Zeta PDF a Audio V48 Rules

Base:
- Desde V47 exact underline.

Agregado:
- Reglas arriba y abajo sobre el PDF.
- Se arrastran tocando cerca de cada línea.
- Las zonas fuera de las reglas se sombrean.
- Solo se lee el texto dentro de las reglas.
- Botón Reglas ON/OFF en la parte superior.
- Se guarda la posición de las reglas.
- Sirve para saltar encabezados, pies de página y números de página.

No se tocó:
- Zoom.
- Audio base.
- Subrayado exacto.
- PdfRenderer.
- TTS.
- PDFBox.

Pendiente:
- Exportar PNG/compartir.
