# Geo Zeta PDF a Audio V21

Mejoras:
- Panel inferior más compacto y profesional.
- Herramientas separadas por pestañas: Audio, Marcar, Vista y Exportar.
- El panel ya no tapa casi toda la pantalla cuando se abre.
- Botón Play mantiene el mismo color al reproducir/pausar.
- Audio prepara bloques más pequeños para iniciar más rápido y reducir trabas.
- Mantiene temas de color personalizados, subrayado por palabra/letra, PNG y audio.

Nota:
- Para controles en segundo plano, expande la notificación de Android.
