package com.geozeta.pdfaudio;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.os.Environment;
import android.util.Base64;
import android.widget.Toast;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private boolean savingAudio = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 55);
        }

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidTTS");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.evaluateJavascript("window.syncNativePage && window.syncNativePage();", null);
    }

    @Override protected void onPause() {
        if (webView != null) webView.evaluateJavascript("window.saveCurrentState && window.saveCurrentState();", null);
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.evaluateJavascript("window.saveCurrentState && window.saveCurrentState();", null);
        super.onDestroy();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) results = new Uri[]{data.getData()};
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private String safeName(String name, String fallback) {
        if (name == null || name.trim().isEmpty()) name = fallback;
        return name.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    private Uri saveBytes(byte[] data, String displayName, String mimeType, boolean image, boolean audio) throws Exception {
        displayName = safeName(displayName, audio ? "audio.wav" : image ? "pagina.png" : "texto.txt");
        ContentResolver resolver = getContentResolver();

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
            String dir = audio ? Environment.DIRECTORY_MUSIC : image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS;
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, dir + "/PDF a Audio");

            Uri collection;
            if (audio) collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            else if (image) collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            else collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;

            Uri uri = resolver.insert(collection, values);
            if (uri == null) throw new Exception("No se pudo crear archivo.");
            OutputStream os = resolver.openOutputStream(uri);
            if (os == null) throw new Exception("No se pudo abrir archivo.");
            os.write(data); os.flush(); os.close();
            return uri;
        } else {
            File dir = new File(getExternalFilesDir(audio ? Environment.DIRECTORY_MUSIC : image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS), "PDF a Audio");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, displayName);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(data); fos.flush(); fos.close();
            return Uri.fromFile(file);
        }
    }

    private ArrayList<String> splitText(String text) {
        ArrayList<String> chunks = new ArrayList<>();
        if (text == null) text = "";
        text = text.trim();
        int max = 3200;
        while (text.length() > max) {
            int cut = text.lastIndexOf(".", max);
            if (cut < 1200) cut = text.lastIndexOf("\n", max);
            if (cut < 1200) cut = max;
            chunks.add(text.substring(0, cut + 1).trim());
            text = text.substring(Math.min(cut + 1, text.length())).trim();
        }
        if (!text.isEmpty()) chunks.add(text);
        return chunks;
    }

    private void putIntLE(byte[] b, int offset, int value) {
        b[offset] = (byte)(value & 0xff);
        b[offset+1] = (byte)((value >> 8) & 0xff);
        b[offset+2] = (byte)((value >> 16) & 0xff);
        b[offset+3] = (byte)((value >> 24) & 0xff);
    }

    private byte[] readAll(File f) throws Exception {
        InputStream in = new FileInputStream(f);
        byte[] data = new byte[(int) f.length()];
        int pos = 0, read;
        while (pos < data.length && (read = in.read(data, pos, data.length - pos)) > 0) pos += read;
        in.close();
        return data;
    }

    private File combineWavFiles(ArrayList<File> parts, File outFile) throws Exception {
        if (parts.size() == 1) {
            byte[] one = readAll(parts.get(0));
            FileOutputStream fos = new FileOutputStream(outFile);
            fos.write(one); fos.close();
            return outFile;
        }

        byte[] header = readAll(parts.get(0));
        if (header.length < 44) throw new Exception("Audio inválido.");
        int totalData = 0;
        for (File p : parts) totalData += Math.max(0, (int)p.length() - 44);

        putIntLE(header, 4, 36 + totalData);
        putIntLE(header, 40, totalData);

        FileOutputStream fos = new FileOutputStream(outFile);
        fos.write(header, 0, 44);
        byte[] buffer = new byte[8192];
        for (File p : parts) {
            FileInputStream in = new FileInputStream(p);
            long skipped = in.skip(44);
            int n;
            while ((n = in.read(buffer)) > 0) fos.write(buffer, 0, n);
            in.close();
        }
        fos.flush(); fos.close();
        return outFile;
    }

    private void shareFile(Uri uri, String mimeType, String title) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType(mimeType);
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send, title));
    }

    private void saveAudioTextInternal(String text, String filename, float rate, float pitch, boolean share) {
        if (savingAudio) {
            runOnUiThread(() -> Toast.makeText(this, "Ya se está guardando un audio.", Toast.LENGTH_SHORT).show());
            return;
        }
        if (text == null || text.trim().isEmpty()) {
            runOnUiThread(() -> Toast.makeText(this, "No hay texto para convertir a audio.", Toast.LENGTH_SHORT).show());
            return;
        }
        savingAudio = true;
        filename = safeName(filename, "audio_pdf.wav");
        if (!filename.toLowerCase().endsWith(".wav")) filename += ".wav";

        final String finalFilename = filename;
        final ArrayList<String> chunks = splitText(text);
        final File dir = new File(getCacheDir(), "audio_export_" + System.currentTimeMillis());
        dir.mkdirs();
        final ArrayList<File> parts = new ArrayList<>();

        runOnUiThread(() -> Toast.makeText(this, "Guardando audio... no cierres la app.", Toast.LENGTH_LONG).show());

        // Recreate with external holder so listener can call next.
        final TextToSpeech[] ttsRef = new TextToSpeech[1];
        ttsRef[0] = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                savingAudio = false;
                runOnUiThread(() -> Toast.makeText(this, "No se pudo iniciar voz.", Toast.LENGTH_SHORT).show());
                return;
            }

            TextToSpeech t = ttsRef[0];
            int result = t.setLanguage(new Locale("es", "PE"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                t.setLanguage(new Locale("es", "ES"));
            }
            t.setSpeechRate(Math.max(0.55f, Math.min(2.0f, rate)));
            t.setPitch(Math.max(0.55f, Math.min(1.8f, pitch)));

            final int[] index = {0};

            t.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {}

                @Override public void onDone(String utteranceId) {
                    index[0]++;
                    if (index[0] < chunks.size()) {
                        synthNext(t, chunks, parts, dir, index[0]);
                    } else {
                        try {
                            File out = new File(dir, finalFilename);
                            combineWavFiles(parts, out);
                            byte[] data = readAll(out);
                            Uri uri = saveBytes(data, finalFilename, "audio/wav", false, true);
                            savingAudio = false;
                            t.shutdown();
                            runOnUiThread(() -> {
                                Toast.makeText(MainActivity.this, "Audio guardado en Música/PDF a Audio", Toast.LENGTH_LONG).show();
                                if (share) shareFile(uri, "audio/wav", "Compartir audio");
                            });
                        } catch (Exception e) {
                            savingAudio = false;
                            t.shutdown();
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, "No se pudo guardar audio.", Toast.LENGTH_SHORT).show());
                        }
                    }
                }

                @Override public void onError(String utteranceId) {
                    savingAudio = false;
                    try { t.shutdown(); } catch(Exception ignored) {}
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error al crear audio.", Toast.LENGTH_SHORT).show());
                }
            });

            synthNext(t, chunks, parts, dir, 0);
        });
    }

    private void synthNext(TextToSpeech t, ArrayList<String> chunks, ArrayList<File> parts, File dir, int index) {
        try {
            File part = new File(dir, "part_" + index + ".wav");
            parts.add(part);
            t.synthesizeToFile(chunks.get(index), null, part, "audio_part_" + index);
        } catch (Exception e) {
            savingAudio = false;
            try { t.shutdown(); } catch(Exception ignored) {}
            runOnUiThread(() -> Toast.makeText(this, "Error creando parte de audio.", Toast.LENGTH_SHORT).show());
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void clearNativePages() { TtsForegroundService.clearPages(); }
        @JavascriptInterface public void addNativePage(String text) { TtsForegroundService.addPage(text == null ? "" : text); }
        @JavascriptInterface public int getNativePageCount() { return TtsForegroundService.getPageCount(); }

        @JavascriptInterface
        public void startBackgroundRead(int startIndex, int pageOffset, String title, float rate, float pitch) {
            Intent i = new Intent(MainActivity.this, TtsForegroundService.class);
            i.setAction(TtsForegroundService.ACTION_START);
            i.putExtra("startIndex", startIndex);
            i.putExtra("pageOffset", pageOffset);
            i.putExtra("title", title == null ? "PDF a Audio" : title);
            i.putExtra("rate", rate);
            i.putExtra("pitch", pitch);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        }

        @JavascriptInterface
        public void stopBackgroundRead() {
            Intent i = new Intent(MainActivity.this, TtsForegroundService.class);
            i.setAction(TtsForegroundService.ACTION_STOP);
            startService(i);
        }

        @JavascriptInterface
        public int getCurrentPage() {
            SharedPreferences p = getSharedPreferences(TtsForegroundService.PREFS, MODE_PRIVATE);
            return p.getInt("currentPage", 1);
        }

        @JavascriptInterface
        public boolean isReading() {
            SharedPreferences p = getSharedPreferences(TtsForegroundService.PREFS, MODE_PRIVATE);
            return p.getBoolean("isReading", false);
        }

        @JavascriptInterface
        public void shareText(String text, String title) {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "PDF a Audio" : title);
                send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                startActivity(Intent.createChooser(send, "Compartir texto"));
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "No se pudo compartir.", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface
        public void saveTextFile(String text, String filename, boolean share) {
            try {
                byte[] bytes = (text == null ? "" : text).getBytes(StandardCharsets.UTF_8);
                Uri uri = saveBytes(bytes, filename, "text/plain", false, false);
                Toast.makeText(MainActivity.this, "Texto guardado en Descargas/PDF a Audio", Toast.LENGTH_LONG).show();
                if (share) shareFile(uri, "text/plain", "Compartir archivo");
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "No se pudo guardar texto.", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface
        public void savePng(String dataUrl, String filename, boolean share) {
            try {
                if (dataUrl == null) throw new Exception("Imagen vacía.");
                String base64 = dataUrl.contains(",") ? dataUrl.substring(dataUrl.indexOf(",") + 1) : dataUrl;
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                Uri uri = saveBytes(bytes, filename, "image/png", true, false);
                Toast.makeText(MainActivity.this, "Imagen guardada en Pictures/PDF a Audio", Toast.LENGTH_LONG).show();
                if (share) shareFile(uri, "image/png", "Compartir imagen");
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "No se pudo guardar imagen.", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface
        public void saveAudioText(String text, String filename, float rate, float pitch, boolean share) {
            saveAudioTextInternal(text, filename, rate, pitch, share);
        }
    }
}
