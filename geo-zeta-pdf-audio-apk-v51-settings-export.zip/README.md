# Geo Zeta PDF a Audio V51 Settings Export

Base:
- Desde V50 Text Selection Marker.

Agregado:
- Tema claro/oscuro.
- Pantalla de Ajustes.
- Guardar página actual como imagen PNG.
- Exportar audio de la página actual en WAV usando TextToSpeech.
- Ajustar página desde Ajustes.
- Reglas ON/OFF desde Ajustes.
- Subrayado preciso ON/OFF desde Ajustes.

Mantiene:
- Zoom fluido.
- Audio en segundo plano.
- Pantalla apagada.
- Reglas arriba/abajo.
- Subrayado por letras reales del PDF.
- Borrar y limpiar.
- Guardado por PDF.
- PdfRenderer.
- PDFBox.
- TextToSpeech.

Notas:
- Exportar audio depende del motor TTS instalado en el celular.
- El subrayado por letras funciona mejor en PDF con texto real. Si el PDF es imagen escaneada necesita OCR.
