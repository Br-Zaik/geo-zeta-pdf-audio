package com.geozeta.pdfaudio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.ScrollView;
import android.graphics.Typeface;
import android.widget.Toast;
import android.view.View;
import android.content.DialogInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_OPEN_PDF = 1001;

    private PdfPageView pdfView;
    private TextRepository textRepository;
    private SelectionTextRepository selectionRepository;
    private TextView titleView;
    private TextView pageView;
    private Button playButton;
    private File currentFile;
    private String currentTitle;
    private int currentPage;
    private int pageCount;
    private boolean audioStarted;
    private boolean audioPaused;
    private boolean markMode;
    private int markColorIndex;
    private Button markButton;
    private Button colorButton;
    private Button rulesButton;
    private boolean rulesEnabled;
    private float ruleTop;
    private float ruleBottom;
    private boolean restartAudioAfterRender;
    private int requestedAudioPage;
    private int audioRequestToken;
    private boolean darkTheme;
    private boolean settingsMode;
    private LinearLayout root;
    private TextToSpeech exportTts;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        currentTitle = "PDF a Audio";
        prefs = getSharedPreferences("pdf_audio_prefs", MODE_PRIVATE);
        darkTheme = prefs.getBoolean("dark_theme", true);
        textRepository = new TextRepository(this);
        selectionRepository = new SelectionTextRepository(this);
        buildUi();

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 33);
        }

        File last = new File(getFilesDir(), "last.pdf");
        if (last.exists()) {
            openLocalPdf(last, prefs.getString("last_title", "PDF guardado"), true);
        }
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(darkTheme ? Color.rgb(17, 24, 39) : Color.rgb(248, 250, 252));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(12, 12, 12, 8);
        top.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        Button openButton = makeButton("Abrir");
        
openButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        choosePdf();
    }
});

        titleView = new TextView(this);
        titleView.setText("PDF a Audio");
        titleView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        titleView.setTextSize(18);
        titleView.setSingleLine(true);
        titleView.setGravity(Gravity.CENTER_VERTICAL);

        pageView = new TextView(this);
        pageView.setText("0/0");
        pageView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        pageView.setTextSize(15);
        pageView.setSingleLine(true);
        pageView.setGravity(Gravity.CENTER);

        Button gotoButton = makeButton("#");
        
gotoButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        showGoto();
    }
});

        rulesButton = makeButton("Reglas");
        rulesButton.setTextSize(12);
        rulesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleRules();
            }
        });

        top.addView(openButton, new LinearLayout.LayoutParams(dp(72), dp(48)));
        top.addView(titleView, new LinearLayout.LayoutParams(0, dp(48), 1));
        top.addView(pageView, new LinearLayout.LayoutParams(dp(72), dp(48)));
        top.addView(rulesButton, new LinearLayout.LayoutParams(dp(76), dp(48)));
        top.addView(gotoButton, new LinearLayout.LayoutParams(dp(48), dp(48)));

        FrameLayout frame = new FrameLayout(this);
        pdfView = new PdfPageView(this);
        pdfView.setPageChangeListener(new PdfPageView.PageChangeListener() {
            @Override
            public void onPageRendered(int pageIndex, int total) {
                currentPage = pageIndex;
                pageCount = total;
                updatePageLabel();
                saveProgress();
                prefetchAroundCurrentPage();
                loadSelectionForPage(pageIndex);
                if (restartAudioAfterRender) {
                    restartAudioAfterRender = false;
                    startAudioFromPage(currentPage);
                }
            }

            @Override
            public void onError(String message) {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onHighlightsChanged(String serialized) {
                saveHighlights(serialized);
            }

            @Override
            public void onRulesChanged(boolean enabled, float top, float bottom) {
                saveRules(enabled, top, bottom);
                textRepository.setRules(enabled, top, bottom);
            }
        });
        frame.addView(pdfView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(8, 8, 8, 8);
        controls.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        Button prevButton = makeButton("‹");
        prevButton.setTextSize(30);
        
prevButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) requestManualPageChange(currentPage - 1);
    }
});

        playButton = makeButton("▶");
        playButton.setTextSize(26);
        
playButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        toggleAudio();
    }
});

        Button nextButton = makeButton("›");
        nextButton.setTextSize(30);
        
nextButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) requestManualPageChange(currentPage + 1);
    }
});

        Button fitButton = makeButton("Ajustes");
        
fitButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        showSettings();
    }
});

        controls.addView(prevButton, new LinearLayout.LayoutParams(0, dp(56), 1));
        controls.addView(playButton, new LinearLayout.LayoutParams(0, dp(56), 1));
        controls.addView(nextButton, new LinearLayout.LayoutParams(0, dp(56), 1));
        controls.addView(fitButton, new LinearLayout.LayoutParams(0, dp(56), 1));

        LinearLayout markControls = new LinearLayout(this);
        markControls.setOrientation(LinearLayout.HORIZONTAL);
        markControls.setGravity(Gravity.CENTER);
        markControls.setPadding(8, 0, 8, 8);
        markControls.setBackgroundColor(darkTheme ? Color.rgb(8, 40, 58) : Color.rgb(245, 248, 252));

        markButton = makeButton("Subrayar");
        markButton.setTextSize(13);
        markButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleMarkMode();
            }
        });

        colorButton = makeButton("Amarillo");
        colorButton.setTextSize(13);
        colorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rotateMarkColor();
            }
        });

        Button undoButton = makeButton("Borrar");
        undoButton.setTextSize(13);
        undoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.undoLastHighlight();
            }
        });

        Button clearButton = makeButton("Limpiar");
        clearButton.setTextSize(13);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfView.clearPageHighlights();
            }
        });

        markControls.addView(markButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        markControls.addView(colorButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        markControls.addView(undoButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        markControls.addView(clearButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.addView(controls, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)));
        bottom.addView(markControls, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));

        root.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)));
        root.addView(frame, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        root.addView(bottom, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(118)));

        setContentView(root);
        markColorIndex = 0;
        pdfView.setMarkColor(getCurrentMarkColor());
        loadRules();
    }

    private Button makeButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        button.setTextSize(16);
        button.setAllCaps(false);
        button.setBackgroundColor(darkTheme ? Color.rgb(11, 60, 88) : Color.rgb(226, 239, 255));
        return button;
    }



    private void showSettings() {
        settingsMode = true;
        buildSettingsScreen();
    }

    private void closeSettings() {
        settingsMode = false;
        buildUi();

        if (currentFile != null && currentFile.exists()) {
            int page = currentPage;
            openLocalPdf(currentFile, currentTitle, false);
            if (pageCount > 0) {
                pdfView.showPage(Math.max(0, Math.min(page, pageCount - 1)));
            }
        }
    }

    private void buildSettingsScreen() {
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(darkTheme ? Color.rgb(3, 20, 34) : Color.rgb(248, 250, 252));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), dp(8));
        top.setBackgroundColor(darkTheme ? Color.rgb(3, 30, 48) : Color.rgb(248, 250, 252));

        Button back = makeFlatIconButton("‹");
        back.setTextSize(34);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeSettings();
            }
        });

        TextView title = new TextView(this);
        title.setText("Ajustes");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        title.setGravity(Gravity.CENTER_VERTICAL);

        Button done = makeFlatIconButton("✓");
        done.setTextSize(28);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeSettings();
            }
        });

        top.addView(back, new LinearLayout.LayoutParams(dp(52), dp(56)));
        top.addView(title, new LinearLayout.LayoutParams(0, dp(56), 1));
        top.addView(done, new LinearLayout.LayoutParams(dp(52), dp(56)));

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(8), dp(14), dp(22));

        addSettingsSection(content, "APARIENCIA");
        addChoiceRow(content, "☀", "Tema claro", "Fondo blanco limpio", !darkTheme, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (darkTheme) toggleTheme();
            }
        });
        addChoiceRow(content, "☾", "Tema oscuro", "Fondo azul oscuro", darkTheme, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!darkTheme) toggleTheme();
            }
        });

        addSettingsSection(content, "LECTURA Y AUDIO");
        addActionRow(content, "♬", "Voz", "Español del sistema", "›", null);
        addActionRow(content, "◴", "Velocidad", "0.95x", "›", null);
        addSwitchRow(content, "▶", "Leer en segundo plano", "Notificación activa", true, null);
        addSwitchRow(content, "▯", "Continuar con pantalla apagada", "Mantener lectura", true, null);

        addSettingsSection(content, "VISOR PDF");
        addSwitchRow(content, "⌕", "Zoom fluido", "Renderizado nítido", true, null);
        addSwitchRow(content, "▣", "Recordar último PDF y página", "Abrir donde te quedaste", true, null);
        addActionRow(content, "1", "Ir a una página", "Abrir selector de página", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeSettings();
                showGoto();
            }
        });

        addSettingsSection(content, "MARCADO");
        addSwitchRow(content, "✎", "Subrayado preciso", markMode ? "Activo" : "Apagado", markMode, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleMarkMode();
                buildSettingsScreen();
            }
        });
        addActionRow(content, "●", "Color del subrayado", colorButton == null ? "Amarillo" : colorButton.getText().toString(), "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rotateMarkColor();
                buildSettingsScreen();
            }
        });
        addSwitchRow(content, "≡", "Reglas arriba y abajo", rulesEnabled ? "Activo" : "Apagado", rulesEnabled, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleRules();
                buildSettingsScreen();
            }
        });
        addActionRow(content, "⌫", "Borrar último subrayado", "Eliminar última marca", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pdfView != null) pdfView.undoLastHighlight();
            }
        });

        addSettingsSection(content, "EXPORTAR");
        addActionRow(content, "▧", "Guardar como imagen", "Página actual en PNG", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCurrentPageImage();
            }
        });
        addActionRow(content, "▥", "Guardar audio", "Página actual en WAV", "›", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportCurrentPageAudio();
            }
        });

        addSettingsSection(content, "SISTEMA");
        addSwitchRow(content, "▻", "Controles multimedia en notificación", "Reproducir, pausar y detener", true, null);

        scroll.addView(content);
        screen.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(78)));
        screen.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(screen);
    }

    private Button makeFlatIconButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));
        b.setTextSize(24);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private void addSettingsSection(LinearLayout parent, String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(14);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(Color.rgb(59, 130, 246));
        tv.setPadding(dp(4), dp(18), dp(4), dp(7));
        parent.addView(tv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private LinearLayout makeCardRow(String icon, String title, String sub) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(8), dp(10), dp(8));
        row.setBackgroundColor(darkTheme ? Color.rgb(12, 35, 54) : Color.WHITE);

        TextView iconView = new TextView(this);
        iconView.setText(icon);
        iconView.setTextSize(24);
        iconView.setGravity(Gravity.CENTER);
        iconView.setTextColor(Color.rgb(59, 130, 246));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);

        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextSize(17);
        titleView.setTextColor(darkTheme ? Color.WHITE : Color.rgb(15, 23, 42));

        TextView subView = new TextView(this);
        subView.setText(sub == null ? "" : sub);
        subView.setTextSize(12);
        subView.setTextColor(darkTheme ? Color.rgb(148, 163, 184) : Color.rgb(100, 116, 139));

        texts.addView(titleView);
        if (sub != null && sub.length() > 0) texts.addView(subView);

        row.addView(iconView, new LinearLayout.LayoutParams(dp(48), dp(52)));
        row.addView(texts, new LinearLayout.LayoutParams(0, dp(56), 1));
        return row;
    }

    private void addChoiceRow(LinearLayout parent, String icon, String title, String sub, boolean selected, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        TextView check = new TextView(this);
        check.setText(selected ? "◉" : "○");
        check.setTextSize(24);
        check.setTextColor(selected ? Color.rgb(59, 130, 246) : Color.rgb(148, 163, 184));
        check.setGravity(Gravity.CENTER);
        row.addView(check, new LinearLayout.LayoutParams(dp(46), dp(56)));
        row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private void addSwitchRow(LinearLayout parent, String icon, String title, String sub, boolean checked, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        Switch sw = new Switch(this);
        sw.setChecked(checked);
        sw.setEnabled(listener != null);
        if (listener != null) {
            sw.setOnClickListener(listener);
            row.setOnClickListener(listener);
        }
        row.addView(sw, new LinearLayout.LayoutParams(dp(64), dp(56)));
        addRowWithMargin(parent, row);
    }

    private void addActionRow(LinearLayout parent, String icon, String title, String sub, String right, View.OnClickListener listener) {
        LinearLayout row = makeCardRow(icon, title, sub);
        TextView arrow = new TextView(this);
        arrow.setText(right == null ? "" : right);
        arrow.setTextSize(25);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(darkTheme ? Color.rgb(226, 232, 240) : Color.rgb(71, 85, 105));
        row.addView(arrow, new LinearLayout.LayoutParams(dp(38), dp(56)));
        if (listener != null) row.setOnClickListener(listener);
        addRowWithMargin(parent, row);
    }

    private void addRowWithMargin(LinearLayout parent, View row) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(62));
        lp.setMargins(0, dp(3), 0, dp(3));
        parent.addView(row, lp);
    }

    private void toggleTheme() {
        darkTheme = !darkTheme;
        prefs.edit().putBoolean("dark_theme", darkTheme).apply();

        if (settingsMode) {
            buildSettingsScreen();
            return;
        }

        File file = currentFile;
        String title = currentTitle;
        int page = currentPage;

        buildUi();

        if (file != null && file.exists()) {
            openLocalPdf(file, title, false);
            if (pageCount > 0) {
                pdfView.showPage(Math.max(0, Math.min(page, pageCount - 1)));
            }
        }

        Toast.makeText(this, darkTheme ? "Tema oscuro activado" : "Tema claro activado", Toast.LENGTH_SHORT).show();
    }

    private void saveCurrentPageImage() {
        if (currentFile == null || pdfView == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Bitmap bitmap = Bitmap.createBitmap(Math.max(1, pdfView.getWidth()), Math.max(1, pdfView.getHeight()), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            pdfView.draw(canvas);

            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "PDF_Audio");
            if (!dir.exists()) dir.mkdirs();

            String clean = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
            File out = new File(dir, clean + "_pagina_" + (currentPage + 1) + ".png");

            FileOutputStream fos = new FileOutputStream(out);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
            bitmap.recycle();

            Toast.makeText(this, "Imagen guardada: " + out.getName(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo guardar la imagen", Toast.LENGTH_LONG).show();
        }
    }

    private void exportCurrentPageAudio() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Preparando audio...", Toast.LENGTH_SHORT).show();

        textRepository.getPageText(currentPage, new TextRepository.TextCallback() {
            @Override
            public void onText(final String text) {
                if (text == null || text.trim().length() == 0) {
                    Toast.makeText(MainActivity.this, "No hay texto para exportar", Toast.LENGTH_LONG).show();
                    return;
                }

                if (exportTts != null) {
                    try { exportTts.shutdown(); } catch (Exception ignored) {}
                    exportTts = null;
                }

                exportTts = new TextToSpeech(MainActivity.this, new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int status) {
                        if (status != TextToSpeech.SUCCESS) {
                            Toast.makeText(MainActivity.this, "No se pudo iniciar voz", Toast.LENGTH_LONG).show();
                            return;
                        }

                        try {
                            exportTts.setLanguage(new Locale("es", "PE"));

                            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "PDF_Audio");
                            if (!dir.exists()) dir.mkdirs();

                            String clean = currentTitle == null ? "pdf" : currentTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
                            File out = new File(dir, clean + "_pagina_" + (currentPage + 1) + ".wav");

                            String safeText = text;
                            if (safeText.length() > 12000) safeText = safeText.substring(0, 12000);

                            int result;
                            if (Build.VERSION.SDK_INT >= 21) {
                                result = exportTts.synthesizeToFile(safeText, null, out, "EXPORT_PAGE_AUDIO");
                            } else {
                                result = TextToSpeech.ERROR;
                            }

                            if (result == TextToSpeech.SUCCESS) {
                                Toast.makeText(MainActivity.this, "Audio guardado: " + out.getName(), Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(MainActivity.this, "No se pudo guardar el audio", Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Error al exportar audio", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }

    private void choosePdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        startActivityForResult(intent, REQ_OPEN_PDF);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OPEN_PDF && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            copyAndOpen(uri);
        }
    }

    private void copyAndOpen(Uri uri) {
        try {
            stopAudioOnly();
            String name = getDisplayName(uri);
            File target = new File(getFilesDir(), "last.pdf");

            InputStream input = getContentResolver().openInputStream(uri);
            FileOutputStream output = new FileOutputStream(target);
            byte[] buffer = new byte[65536];
            int read;
            while (input != null && (read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
            if (input != null) input.close();
            output.close();

            prefs.edit().putString("last_title", name).putInt("last_page", 0).apply();
            openLocalPdf(target, name, false);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir el PDF", Toast.LENGTH_LONG).show();
        }
    }

    private void openLocalPdf(File file, String title, boolean restore) {
        try {
            currentFile = file;
            currentTitle = title == null ? "PDF" : title;
            titleView.setText(currentTitle);
            textRepository.open(file);
            selectionRepository.open(file);
            pdfView.openFile(file);
            pdfView.loadHighlights(prefs.getString(highlightKey(), ""));
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
            pageCount = pdfView.getPageCount();
            int p = restore ? prefs.getInt("last_page", 0) : 0;
            p = Math.max(0, Math.min(p, Math.max(0, pageCount - 1)));
            pdfView.showPage(p);
            updatePageLabel();
            prefetchAroundPage(p);
        } catch (Exception e) {
            Toast.makeText(this, "Error al cargar PDF", Toast.LENGTH_LONG).show();
        }
    }

    private String getDisplayName(Uri uri) {
        String result = "PDF";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return result == null ? "PDF" : result;
    }



    private void requestManualPageChange(int targetPage) {
        if (pageCount <= 0) return;

        int nextPage = Math.max(0, Math.min(targetPage, pageCount - 1));
        restartAudioAfterRender = false;

        // Cambia visualmente primero.
        pdfView.showPage(nextPage);
        prefetchAroundPage(nextPage);

        // Si está reproduciendo, esta página se vuelve prioridad.
        // Se corta la lectura anterior y se prepara esta página.
        if (audioStarted && !audioPaused) {
            startAudioFromPage(nextPage);
        }
    }

    private void prefetchAroundCurrentPage() {
        prefetchAroundPage(currentPage);
    }

    private void prefetchAroundPage(int page) {
        if (pageCount <= 0) return;
        int start = Math.max(0, page);
        textRepository.prefetch(start, 1, pageCount);
        selectionRepository.prefetch(start, 1, pageCount);
    }




    private void loadSelectionForPage(final int page) {
        if (pageCount <= 0 || selectionRepository == null) return;

        selectionRepository.getChars(page, new SelectionTextRepository.CharCallback() {
            @Override
            public void onChars(java.util.ArrayList<CharBox> chars) {
                if (page == currentPage && pdfView != null) {
                    pdfView.setSelectionChars(chars);
                }
            }
        });
    }

    private void loadRules() {
        rulesEnabled = prefs.getBoolean("rules_enabled", true);
        ruleTop = prefs.getFloat("rule_top", 0.08f);
        ruleBottom = prefs.getFloat("rule_bottom", 0.92f);
        if (ruleBottom <= ruleTop + 0.05f) {
            ruleTop = 0.08f;
            ruleBottom = 0.92f;
        }

        if (pdfView != null) {
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        if (textRepository != null) {
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        updateRulesButton();
    }

    private void toggleRules() {
        rulesEnabled = !rulesEnabled;
        saveRules(rulesEnabled, ruleTop, ruleBottom);

        if (pdfView != null) {
            pdfView.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        if (textRepository != null) {
            textRepository.setRules(rulesEnabled, ruleTop, ruleBottom);
        }

        updateRulesButton();
        Toast.makeText(this, rulesEnabled ? "Reglas activadas. Arrastra las líneas." : "Reglas desactivadas", Toast.LENGTH_SHORT).show();
    }

    private void saveRules(boolean enabled, float top, float bottom) {
        rulesEnabled = enabled;
        ruleTop = top;
        ruleBottom = bottom;
        prefs.edit()
                .putBoolean("rules_enabled", enabled)
                .putFloat("rule_top", top)
                .putFloat("rule_bottom", bottom)
                .apply();
        updateRulesButton();
    }

    private void updateRulesButton() {
        if (rulesButton != null) {
            rulesButton.setText(rulesEnabled ? "Reglas ON" : "Reglas OFF");
        }
    }

    private void toggleMarkMode() {
        markMode = !markMode;
        pdfView.setMarkMode(markMode);
        markButton.setText(markMode ? "Activo" : "Subrayar");
        Toast.makeText(this, markMode ? "Arrastra sobre las letras; se dibuja debajo" : "Subrayado apagado", Toast.LENGTH_SHORT).show();
    }

    private void rotateMarkColor() {
        markColorIndex = (markColorIndex + 1) % 4;
        int color = getCurrentMarkColor();
        pdfView.setMarkColor(color);

        if (markColorIndex == 0) colorButton.setText("Amarillo");
        else if (markColorIndex == 1) colorButton.setText("Azul");
        else if (markColorIndex == 2) colorButton.setText("Verde");
        else colorButton.setText("Rojo");
    }

    private int getCurrentMarkColor() {
        if (markColorIndex == 1) return 0xE63B82F6;
        if (markColorIndex == 2) return 0xE622C55E;
        if (markColorIndex == 3) return 0xE6EF4444;
        return 0xE6FFD400;
    }

    private String highlightKey() {
        return "text_selection_markers_" + currentTitle;
    }

    private void saveHighlights(String serialized) {
        prefs.edit().putString(highlightKey(), serialized == null ? "" : serialized).apply();
    }

    private void toggleAudio() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        if (audioStarted && !audioPaused) {
            Intent intent = new Intent(this, TtsForegroundService.class);
            intent.setAction(TtsForegroundService.ACTION_TOGGLE);
            startService(intent);
            audioPaused = true;
            playButton.setText("▶");
            return;
        }

        // Si estaba pausado o aún no empezó, reproduce desde la página visible actual.
        startAudioFromPage(currentPage);
    }

    private void startAudioFromPage(final int pageToRead) {
        if (currentFile == null || pageCount <= 0) return;

        final int safePage = Math.max(0, Math.min(pageToRead, pageCount - 1));
        final int token = ++audioRequestToken;

        requestedAudioPage = safePage;
        audioStarted = true;
        audioPaused = false;
        if (playButton != null) playButton.setText("...");

        String cached = textRepository.getCachedText(safePage);
        if (cached != null) {
            beginTtsWithText(safePage, cached, token);
            return;
        }

        // Si no está listo el texto, cortamos la lectura anterior para que NO siga leyendo otra página.
        startAudioPreparing(safePage);

        textRepository.getPageText(safePage, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                if (token != audioRequestToken || requestedAudioPage != safePage) {
                    return;
                }
                beginTtsWithText(safePage, text, token);
            }
        });
    }

    private void startAudioPreparing(int safePage) {
        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_PREPARE);
        intent.putExtra("title", currentTitle);
        intent.putExtra("pageOffset", safePage);
        intent.putExtra("rate", 0.95f);
        intent.putExtra("pitch", 1.0f);

        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);
    }

    private void beginTtsWithText(final int safePage, String text, final int token) {
        if (token != audioRequestToken) return;

        TtsForegroundService.clearPages();
        TtsForegroundService.addPage(text);

        Intent intent = new Intent(MainActivity.this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_START);
        intent.putExtra("title", currentTitle);
        intent.putExtra("pageOffset", safePage);
        intent.putExtra("startIndex", 0);
        intent.putExtra("rate", 0.95f);
        intent.putExtra("pitch", 1.0f);

        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);

        audioStarted = true;
        audioPaused = false;
        if (playButton != null) playButton.setText("Ⅱ");

        // Solo prepara pocas páginas y cancela respuestas viejas con token.
        prepareNextAudioPages(safePage + 1, 1, token);
    }

    private void prepareNextAudioPages(int start, int count, final int token) {
        for (int i = 0; i < count; i++) {
            final int p = start + i;
            if (p >= pageCount) break;
            textRepository.getPageText(p, new TextRepository.TextCallback() {
                @Override
                public void onText(String text) {
                    if (token == audioRequestToken) {
                        TtsForegroundService.addPage(text);
                    }
                }
            });
        }
    }

    private void stopAudioOnly() {
        audioStarted = false;
        audioPaused = false;
        requestedAudioPage = -1;
        if (playButton != null) playButton.setText("▶");

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
    }

    private void showGoto() {
        if (pageCount <= 0) return;

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setHint("Página 1 - " + pageCount);

        new AlertDialog.Builder(this)
                .setTitle("Ir a página")
                .setView(input)
                .setPositiveButton("Ir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            int p = Integer.parseInt(input.getText().toString()) - 1;
                            p = Math.max(0, Math.min(p, pageCount - 1));
                            requestManualPageChange(p);
                        } catch (Exception ignored) {
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void updatePageLabel() {
        if (pageCount <= 0) pageView.setText("0/0");
        else pageView.setText((currentPage + 1) + "/" + pageCount);
    }

    private void saveProgress() {
        prefs.edit().putInt("last_page", currentPage).putString("last_title", currentTitle).apply();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        saveProgress();
        textRepository.close();
        if (selectionRepository != null) selectionRepository.close();
        if (exportTts != null) {
            try { exportTts.shutdown(); } catch (Exception ignored) {}
        }
    }
}
