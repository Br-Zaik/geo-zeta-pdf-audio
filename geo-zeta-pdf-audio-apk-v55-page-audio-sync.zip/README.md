# Geo Zeta PDF a Audio V55 Page Audio Sync

Base:
- V54 Audio Priority Underline.

Correcciones:
- Al escribir un número en "Ir a página", ahora usa el cambio de página correcto.
- Si el audio está sonando y cambias de página, corta la lectura anterior y prepara la nueva.
- Evita que respuestas viejas de texto/audio se mezclen si saltas rápido entre páginas.
- Reduce prefetch pesado para que el audio de la página actual tenga prioridad.
- Reintenta cargar el texto más rápido al iniciar un PDF.
- Notificación más limpia tipo multimedia:
  - título PDF a Audio;
  - texto con archivo y página;
  - controles compactos Anterior / Pausar / Siguiente.

Mantiene:
- Ajustes profesionales.
- Tema claro/oscuro.
- Subrayado fino debajo del texto.
- Reglas arriba/abajo.
- Guardar imagen PNG.
- Guardar audio WAV.
- Limpieza de texto para evitar "ene".
- PdfRenderer, PDFBox y TextToSpeech.
