package com.geozeta.pdfaudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class TtsForegroundService extends Service {
    public static final String ACTION_START = "com.geozeta.pdfaudio.START";
    public static final String ACTION_WARMUP = "com.geozeta.pdfaudio.WARMUP";
    public static final String ACTION_PREPARE = "com.geozeta.pdfaudio.PREPARE";
    public static final String ACTION_STOP = "com.geozeta.pdfaudio.STOP";
    public static final String ACTION_TOGGLE = "com.geozeta.pdfaudio.TOGGLE";
    public static final String ACTION_NEXT = "com.geozeta.pdfaudio.NEXT";
    public static final String ACTION_PREV = "com.geozeta.pdfaudio.PREV";
    public static final String ACTION_PAGE_CHANGED = "com.geozeta.pdfaudio.PAGE_CHANGED";

    public static final String EXTRA_PAGE = "page";
    public static final String EXTRA_ACTIVE = "active";
    public static final String EXTRA_PAUSED = "paused";
    public static final String EXTRA_PREPARING = "preparing";
    public static final String EXTRA_STATUS = "status";
    public static final String EXTRA_ERROR = "error";

    public static final String STATUS_STOPPED = "stopped";
    public static final String STATUS_PREPARING = "preparing";
    public static final String STATUS_PLAYING = "playing";
    public static final String STATUS_PAUSED = "paused";
    public static final String STATUS_ERROR = "error";

    private static final String CHANNEL_ID = "pdf_audio_playback_v64";
    private static final int NOTIFICATION_ID = 39;
    private static final String PREFS_NAME = "pdf_audio_prefs";
    private static final String PREF_TTS_ACTIVE = "tts_service_active";
    private static final String PREF_TTS_PAUSED = "tts_service_paused";
    private static final String PREF_TTS_PREPARING = "tts_service_preparing";
    private static final String PREF_TTS_CURRENT_PAGE = "tts_current_page";

    private static final Map<Integer, String> PAGE_MAP = new HashMap<Integer, String>();
    private static PageProvider pageProvider;
    private static volatile boolean serviceAlive;
    private static volatile boolean playbackActive;
    private static volatile boolean playbackPaused;
    private static volatile boolean playbackPreparing;

    public interface PageProvider {
        void requestPageText(int page, PageTextCallback callback);
    }

    public interface PageTextCallback {
        void onText(String text);
    }

    public static synchronized void setPageProvider(PageProvider provider) {
        pageProvider = provider;
    }

    public static synchronized void clearPages() {
        PAGE_MAP.clear();
    }

    public static synchronized void addPage(String text) {
        PAGE_MAP.put(PAGE_MAP.size(), text == null ? "" : text);
    }

    public static synchronized void setPageText(int page, String text) {
        PAGE_MAP.put(page, text == null ? "" : text);
    }

    private static synchronized String getStoredPage(int page) {
        return PAGE_MAP.get(page);
    }

    private static synchronized PageProvider getProvider() {
        return pageProvider;
    }

    public static synchronized int pageCount() {
        return PAGE_MAP.size();
    }

    public static boolean isServiceAlive() {
        return serviceAlive;
    }

    public static boolean isPlaybackActive() {
        return playbackActive;
    }

    public static boolean isPlaybackPaused() {
        return playbackPaused;
    }

    public static boolean isPlaybackPreparing() {
        return playbackPreparing;
    }

    private TextToSpeech tts;
    private Handler handler;
    private boolean ready;
    private boolean reading;
    private boolean paused;
    private int index;
    private int pageOffset;
    private int currentPageAbsolute;
    private boolean waitingForProvider;
    private int totalPages;
    private String title;
    private float rate;
    private float pitch;

    private final ArrayList<String> currentChunks = new ArrayList<String>();
    private int currentChunkIndex;
    private int currentChunkPage = -1;
    private String currentUtteranceId;
    private int utteranceSequence;
    private int speakRetryCount;
    private boolean speakRetryPending;

    @Override
    public void onCreate() {
        super.onCreate();
        serviceAlive = true;
        handler = new Handler(Looper.getMainLooper());
        title = "PDF a Audio";
        rate = 0.95f;
        pitch = 1.0f;
        createChannel();

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.SUCCESS) {
                    ready = false;
                    failPlayback("No se pudo iniciar el motor de voz");
                    return;
                }

                int result = tts.setLanguage(new Locale("es", "PE"));
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    result = tts.setLanguage(new Locale("es", "ES"));
                }

                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    ready = false;
                    failPlayback("No hay una voz en español instalada");
                    return;
                }

                if (Build.VERSION.SDK_INT >= 21) {
                    AudioAttributes attributes = new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build();
                    tts.setAudioAttributes(attributes);
                }

                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        if (!isCurrentUtterance(utteranceId)) return;
                        playbackActive = true;
                        playbackPaused = false;
                        playbackPreparing = false;
                        savePlaybackState(currentPageAbsolute, true, false, false, STATUS_PLAYING, null);
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        if (!isCurrentUtterance(utteranceId) || !reading || paused) return;

                        if (currentChunkIndex + 1 < currentChunks.size()) {
                            currentChunkIndex++;
                            speakRetryCount = 0;
                            speakCurrentChunk();
                            return;
                        }

                        currentChunks.clear();
                        currentChunkIndex = 0;
                        currentChunkPage = -1;
                        currentUtteranceId = null;
                        currentPageAbsolute++;
                        index = currentPageAbsolute - pageOffset;
                        speakAbsolutePage(currentPageAbsolute);
                    }

                    @Override
                    public void onError(String utteranceId) {
                        handleSpeakError(utteranceId);
                    }

                    @Override
                    public void onError(String utteranceId, int errorCode) {
                        handleSpeakError(utteranceId);
                    }
                });

                ready = true;
                if (reading && !paused) {
                    if (!currentChunks.isEmpty()) speakCurrentChunk();
                    else speakCurrent();
                }
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_STICKY;
        String action = intent.getAction();

        if (ACTION_WARMUP.equals(action)) {
            if (!reading) {
                playbackActive = false;
                playbackPaused = false;
                playbackPreparing = false;
            }
            return START_STICKY;
        }

        if (ACTION_PREPARE.equals(action)) {
            readPlaybackExtras(intent);
            resetCurrentSpeech();
            reading = false;
            paused = false;
            waitingForProvider = false;
            playbackActive = true;
            playbackPaused = false;
            playbackPreparing = true;
            if (tts != null) tts.stop();
            savePlaybackState(currentPageAbsolute, true, false, true, STATUS_PREPARING, null);
            startForeground(NOTIFICATION_ID, buildNotification("Preparando página " + (currentPageAbsolute + 1)));
            return START_STICKY;
        }

        if (ACTION_START.equals(action)) {
            readPlaybackExtras(intent);
            resetCurrentSpeech();
            reading = true;
            paused = false;
            waitingForProvider = false;
            playbackActive = true;
            playbackPaused = false;
            playbackPreparing = true;
            savePlaybackState(currentPageAbsolute, true, false, true, STATUS_PREPARING, null);
            startForeground(NOTIFICATION_ID, buildNotification("Preparando página " + (currentPageAbsolute + 1)));
            if (ready) speakCurrent();
            return START_STICKY;
        }

        if (ACTION_TOGGLE.equals(action)) {
            toggle();
        } else if (ACTION_NEXT.equals(action)) {
            moveToPage(currentPageAbsolute + 1);
        } else if (ACTION_PREV.equals(action)) {
            moveToPage(Math.max(0, currentPageAbsolute - 1));
        } else if (ACTION_STOP.equals(action)) {
            stopAll();
        }

        return START_STICKY;
    }

    private void readPlaybackExtras(Intent intent) {
        String extraTitle = intent.getStringExtra("title");
        title = extraTitle == null ? "PDF a Audio" : extraTitle;
        pageOffset = intent.getIntExtra("pageOffset", 0);
        totalPages = intent.getIntExtra("totalPages", 0);
        index = Math.max(0, intent.getIntExtra("startIndex", 0));
        currentPageAbsolute = pageOffset + index;
        rate = clampRate(intent.getFloatExtra("rate", 1.0f));
        pitch = intent.getFloatExtra("pitch", 1.0f);
    }

    private void moveToPage(int page) {
        resetCurrentSpeech();
        currentPageAbsolute = page;
        index = currentPageAbsolute - pageOffset;
        reading = true;
        paused = false;
        waitingForProvider = false;
        playbackActive = true;
        playbackPaused = false;
        playbackPreparing = true;
        savePlaybackState(currentPageAbsolute, true, false, true, STATUS_PREPARING, null);
        if (ready) speakAbsolutePage(currentPageAbsolute);
    }

    private void speakCurrent() {
        speakAbsolutePage(currentPageAbsolute);
    }

    private void speakAbsolutePage(final int absolutePage) {
        if (!ready || !reading || paused) return;

        if (totalPages > 0 && absolutePage >= totalPages) {
            updateNotification("Lectura finalizada");
            stopAll();
            return;
        }

        playbackPreparing = true;
        savePlaybackState(absolutePage, true, false, true, STATUS_PREPARING, null);

        String stored = getStoredPage(absolutePage);
        if (stored != null) {
            speakTextForPage(absolutePage, stored);
            return;
        }

        requestPageFromProvider(absolutePage);
    }

    private void requestPageFromProvider(final int absolutePage) {
        if (!reading || paused || waitingForProvider) return;

        if (totalPages > 0 && absolutePage >= totalPages) {
            stopAll();
            return;
        }

        PageProvider provider = getProvider();
        if (provider == null) {
            failPlayback("No se pudo obtener el texto de la página");
            return;
        }

        waitingForProvider = true;
        playbackPreparing = true;
        updateNotification("Preparando página " + (absolutePage + 1));

        provider.requestPageText(absolutePage, new PageTextCallback() {
            @Override
            public void onText(String text) {
                waitingForProvider = false;
                if (!reading || paused || absolutePage != currentPageAbsolute) return;

                setPageText(absolutePage, text);
                speakTextForPage(absolutePage, text);
            }
        });
    }

    private void speakTextForPage(int absolutePage, String rawText) {
        if (!ready || !reading || paused) return;

        currentPageAbsolute = absolutePage;
        index = currentPageAbsolute - pageOffset;

        String text = cleanForTts(rawText);
        if (text.trim().length() == 0) {
            currentPageAbsolute++;
            index = currentPageAbsolute - pageOffset;
            speakAbsolutePage(currentPageAbsolute);
            return;
        }

        currentChunks.clear();
        currentChunks.addAll(splitForTts(text));
        currentChunkIndex = 0;
        currentChunkPage = absolutePage;
        speakRetryCount = 0;

        if (currentChunks.isEmpty()) {
            currentPageAbsolute++;
            index = currentPageAbsolute - pageOffset;
            speakAbsolutePage(currentPageAbsolute);
            return;
        }

        speakCurrentChunk();
    }

    private void speakCurrentChunk() {
        if (!ready || !reading || paused) return;
        if (currentChunkIndex < 0 || currentChunkIndex >= currentChunks.size()) return;

        final String chunk = currentChunks.get(currentChunkIndex);
        if (chunk == null || chunk.trim().length() == 0) {
            if (currentChunkIndex + 1 < currentChunks.size()) {
                currentChunkIndex++;
                speakCurrentChunk();
            }
            return;
        }

        tts.setSpeechRate(rate);
        tts.setPitch(pitch);

        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);

        currentUtteranceId = "PAGE_" + currentChunkPage + "_PART_" + currentChunkIndex + "_" + (++utteranceSequence);
        int shownPart = currentChunkIndex + 1;
        int totalParts = currentChunks.size();
        String partText = totalParts > 1 ? " · parte " + shownPart + "/" + totalParts : "";
        updateNotification("Página " + (currentChunkPage + 1) + partText + " · " + String.format(Locale.US, "%.2fx", rate));

        int result = tts.speak(chunk, TextToSpeech.QUEUE_FLUSH, params, currentUtteranceId);
        if (result == TextToSpeech.ERROR) {
            handleSpeakError(currentUtteranceId);
        }
    }

    private ArrayList<String> splitForTts(String text) {
        ArrayList<String> parts = new ArrayList<String>();
        if (text == null) return parts;

        int platformLimit = TextToSpeech.getMaxSpeechInputLength();
        int maxLength = Math.min(3400, Math.max(1200, platformLimit - 200));
        int start = 0;
        int length = text.length();

        while (start < length) {
            while (start < length && Character.isWhitespace(text.charAt(start))) start++;
            if (start >= length) break;

            int hardEnd = Math.min(length, start + maxLength);
            int end = hardEnd;

            if (hardEnd < length) {
                int minimumBreak = start + Math.max(300, maxLength / 2);
                int candidate = findBreak(text, start, hardEnd, "\n\n");
                if (candidate < minimumBreak) candidate = findBreak(text, start, hardEnd, ". ");
                if (candidate < minimumBreak) candidate = findBreak(text, start, hardEnd, "? ");
                if (candidate < minimumBreak) candidate = findBreak(text, start, hardEnd, "! ");
                if (candidate < minimumBreak) candidate = findBreak(text, start, hardEnd, "; ");
                if (candidate < minimumBreak) candidate = findBreak(text, start, hardEnd, ", ");
                if (candidate < minimumBreak) candidate = findBreak(text, start, hardEnd, " ");
                if (candidate >= minimumBreak) end = candidate;
            }

            if (end <= start) end = hardEnd;
            String part = text.substring(start, end).trim();
            if (part.length() > 0) parts.add(part);
            start = end;
        }

        return parts;
    }

    private int findBreak(String text, int start, int end, String token) {
        int index = text.lastIndexOf(token, end - 1);
        if (index < start) return -1;
        return index + token.length();
    }

    private boolean isCurrentUtterance(String utteranceId) {
        return utteranceId != null && utteranceId.equals(currentUtteranceId);
    }

    private void handleSpeakError(final String utteranceId) {
        if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
        if (speakRetryPending) return;

        if (speakRetryCount < 1) {
            speakRetryCount++;
            speakRetryPending = true;
            if (handler != null) {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        speakRetryPending = false;
                        if (isCurrentUtterance(utteranceId) && reading && !paused) {
                            speakCurrentChunk();
                        }
                    }
                }, 350);
            }
            return;
        }

        failPlayback("El motor de voz rechazó el texto. Revisa la voz de Android");
    }

    private void resetCurrentSpeech() {
        if (tts != null) tts.stop();
        currentChunks.clear();
        currentChunkIndex = 0;
        currentChunkPage = -1;
        currentUtteranceId = null;
        speakRetryCount = 0;
        speakRetryPending = false;
    }

    private float clampRate(float value) {
        if (value < 0.5f) return 0.5f;
        if (value > 2.0f) return 2.0f;
        return value;
    }

    private String cleanForTts(String value) {
        if (value == null) return "";

        String text = value.replace('\u00A0', ' ');
        text = text.replace("\\r\\n", "\n");
        text = text.replace("\\n", "\n");
        text = text.replace("\\r", "\n");
        text = text.replace("/n", "\n");
        text = text.replace('\r', '\n');

        text = text.replaceAll("(?m)^\\s*[\\\\/]*[NnÑñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[A-ZÑ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[a-zñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[0-9]{1,4}\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[IVXLCDMivxlcdm]{1,8}\\s*$", "");
        text = text.replaceFirst("(?i)^(\\s*[nñ]\\s+){1,10}", "");

        text = text.replaceAll("(?i)(^|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-])[nñ](?=($|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-]))", "$1");
        text = text.replaceAll("(?iu)([a-záéíóúüñ])-\\s*\\n\\s*([a-záéíóúüñ])", "$1$2");
        text = text.replaceAll("[ \\t]{2,}", " ");
        text = text.replaceAll("\\n[ \\t]+", "\n");
        text = text.replaceAll("\\n{3,}", "\n\n");

        return text.trim();
    }

    private void toggle() {
        if (playbackPreparing) {
            return;
        }

        if (paused) {
            paused = false;
            reading = true;
            playbackActive = true;
            playbackPaused = false;
            playbackPreparing = true;
            savePlaybackState(currentPageAbsolute, true, false, true, STATUS_PREPARING, null);
            if (!currentChunks.isEmpty()) speakCurrentChunk();
            else speakCurrent();
        } else if (reading) {
            paused = true;
            reading = false;
            playbackActive = true;
            playbackPaused = true;
            playbackPreparing = false;
            if (tts != null) tts.stop();
            savePlaybackState(currentPageAbsolute, true, true, false, STATUS_PAUSED, null);
            updateNotification("Pausado");
        }
    }

    private void stopAll() {
        reading = false;
        paused = false;
        waitingForProvider = false;
        playbackActive = false;
        playbackPaused = false;
        playbackPreparing = false;
        resetCurrentSpeech();
        savePlaybackState(currentPageAbsolute, false, false, false, STATUS_STOPPED, null);
        stopForeground(true);
        stopSelf();
    }

    private void failPlayback(String message) {
        reading = false;
        paused = false;
        waitingForProvider = false;
        playbackActive = false;
        playbackPaused = false;
        playbackPreparing = false;
        resetCurrentSpeech();
        savePlaybackState(currentPageAbsolute, false, false, false, STATUS_ERROR, message);
        updateNotification(message);
    }

    private void savePlaybackState(int page, boolean active, boolean isPaused, boolean preparing, String status, String error) {
        try {
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(PREF_TTS_ACTIVE, active)
                    .putBoolean(PREF_TTS_PAUSED, isPaused)
                    .putBoolean(PREF_TTS_PREPARING, preparing)
                    .putInt(PREF_TTS_CURRENT_PAGE, page)
                    .apply();

            Intent update = new Intent(ACTION_PAGE_CHANGED);
            update.setPackage(getPackageName());
            update.putExtra(EXTRA_PAGE, page);
            update.putExtra(EXTRA_ACTIVE, active);
            update.putExtra(EXTRA_PAUSED, isPaused);
            update.putExtra(EXTRA_PREPARING, preparing);
            update.putExtra(EXTRA_STATUS, status);
            if (error != null) update.putExtra(EXTRA_ERROR, error);
            sendBroadcast(update);
        } catch (Exception ignored) {
        }
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        openIntent.putExtra("open_reading_page", true);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent prevPi = PendingIntent.getService(this, 1, new Intent(this, TtsForegroundService.class).setAction(ACTION_PREV), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent togglePi = PendingIntent.getService(this, 2, new Intent(this, TtsForegroundService.class).setAction(ACTION_TOGGLE), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent nextPi = PendingIntent.getService(this, 3, new Intent(this, TtsForegroundService.class).setAction(ACTION_NEXT), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stopPi = PendingIntent.getService(this, 4, new Intent(this, TtsForegroundService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) builder = new Notification.Builder(this, CHANNEL_ID);
        else builder = new Notification.Builder(this);

        builder.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("PDF a Audio")
                .setContentText(text)
                .setSubText(title)
                .setContentIntent(openPi)
                .setOngoing(playbackActive)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .addAction(android.R.drawable.ic_media_previous, "Anterior", prevPi)
                .addAction(playbackPaused ? android.R.drawable.ic_media_play : android.R.drawable.ic_media_pause, playbackPaused ? "Reanudar" : "Pausar", togglePi)
                .addAction(android.R.drawable.ic_media_next, "Siguiente", nextPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPi);

        if (Build.VERSION.SDK_INT >= 21) {
            builder.setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setCategory(Notification.CATEGORY_TRANSPORT)
                    .setColor(0xFF0B3C58)
                    .setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2));
        }

        if (Build.VERSION.SDK_INT >= 31) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }

        if (Build.VERSION.SDK_INT < 26) {
            builder.setPriority(Notification.PRIORITY_DEFAULT);
        }

        return builder.build();
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "PDF a Audio", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Lectura de PDF en segundo plano");
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.enableVibration(false);
            channel.setSound(null, null);
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        serviceAlive = false;
        playbackActive = false;
        playbackPaused = false;
        playbackPreparing = false;
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
