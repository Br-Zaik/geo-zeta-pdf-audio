# Geo Zeta PDF a Audio V64 - Audio TTS corregido + doble marcado

Esta versión corrige el fallo en el que el botón cambiaba a pausa, pero no se escuchaba ninguna voz.

## Correcciones de audio

- El texto de cada página ya no se envía completo de una sola vez al motor TTS.
- Cada página se divide en fragmentos seguros de hasta 3400 caracteres y se reproduce fragmento por fragmento.
- Se comprueba el resultado de `TextToSpeech.speak()` y se muestra un error real si Android rechaza la reproducción.
- Se configura la salida como audio multimedia y el volumen TTS al máximo permitido por el motor.
- Se separan los estados: preparando, reproduciendo, pausado, detenido y error.
- El botón permanece en `...` hasta que la voz realmente empieza.
- Se elimina el falso estado de reproducción que podía quedar guardado después de actualizar la app.
- Si la página no contiene texto legible, la app deja de preparar y lo informa en pantalla.
- Se redujo la precarga agresiva de páginas próximas para no competir con el inicio de la voz.

## Marcado conservado

- Subrayado debajo del texto.
- Resaltado transparente detrás del texto.
- Color independiente para cada tipo de marcado.
- Configuración desde Ajustes.
- Compatibilidad con las marcas creadas en versiones anteriores.

## Versión

- versionCode: 64
- versionName: 64.0-tts-chunked-reliable-dual-mark
