package com.geozeta.pdfaudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class TtsForegroundService extends Service {
    public static final String ACTION_START = "com.geozeta.pdfaudio.START";
    public static final String ACTION_WARMUP = "com.geozeta.pdfaudio.WARMUP";
    public static final String ACTION_TEST = "com.geozeta.pdfaudio.TEST";
    public static final String ACTION_STOP = "com.geozeta.pdfaudio.STOP";
    public static final String ACTION_TOGGLE = "com.geozeta.pdfaudio.TOGGLE";
    public static final String ACTION_NEXT = "com.geozeta.pdfaudio.NEXT";
    public static final String ACTION_PREV = "com.geozeta.pdfaudio.PREV";
    public static final String ACTION_PAGE_CHANGED = "com.geozeta.pdfaudio.PAGE_CHANGED";

    public static final String EXTRA_PAGE = "page";
    public static final String EXTRA_ACTIVE = "active";
    public static final String EXTRA_PAUSED = "paused";
    public static final String EXTRA_STATUS = "status";
    public static final String EXTRA_ERROR = "error";
    public static final String EXTRA_ENGINE = "engine";

    public static final String STATUS_STOPPED = "stopped";
    public static final String STATUS_INITIALIZING = "initializing";
    public static final String STATUS_PREPARING = "preparing";
    public static final String STATUS_PLAYING = "playing";
    public static final String STATUS_PAUSED = "paused";
    public static final String STATUS_ERROR = "error";
    public static final String STATUS_TEST_OK = "test_ok";

    private static final String TAG = "GeoZetaTTS";
    private static final String CHANNEL_ID = "pdf_audio_playback_v66";
    private static final int NOTIFICATION_ID = 39;
    private static final String PREFS_NAME = "pdf_audio_prefs";
    private static final String PREF_TTS_ACTIVE = "tts_service_active";
    private static final String PREF_TTS_PAUSED = "tts_service_paused";
    private static final String PREF_TTS_CURRENT_PAGE = "tts_current_page";
    private static final String PREF_TTS_STATUS = "tts_service_status";
    private static final String PREF_TTS_ERROR = "tts_service_error";
    private static final String PREF_TTS_ENGINE = "tts_service_engine";

    public interface PageProvider {
        void requestPageText(int page, PageTextCallback callback);
    }

    public interface PageTextCallback {
        void onText(String text);
    }

    private static final Map<Integer, String> PAGE_MAP = new HashMap<Integer, String>();
    private static PageProvider pageProvider;

    public static synchronized void setPageProvider(PageProvider provider) {
        pageProvider = provider;
    }

    public static synchronized void clearPages() {
        PAGE_MAP.clear();
    }

    public static synchronized void setPageText(int page, String text) {
        PAGE_MAP.put(page, text == null ? "" : text);
    }

    private static synchronized String getStoredPage(int page) {
        return PAGE_MAP.get(page);
    }

    private static synchronized PageProvider getProvider() {
        return pageProvider;
    }

    private TextToSpeech tts;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private boolean ready;
    private boolean initializing;
    private boolean initFailed;
    private boolean reading;
    private boolean paused;
    private boolean waitingForProvider;
    private boolean testMode;
    private int currentPageAbsolute;
    private int totalPages;
    private int playbackGeneration;
    private String title = "PDF a Audio";
    private float rate = 1.0f;
    private float pitch = 1.0f;
    private String currentEngine = "";
    private int initGeneration;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        initializeTts();
    }

    private void initializeTts() {
        if (initializing) return;
        initializing = true;
        initFailed = false;
        final int thisInit = ++initGeneration;
        ready = false;
        try {
            if (tts != null) tts.shutdown();
        } catch (Exception ignored) {
        }
        tts = null;
        Log.i(TAG, "tts_init_begin");

        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (thisInit != initGeneration) return;
                initializing = false;
                if (status != TextToSpeech.SUCCESS || tts == null) {
                    initFailed = true;
                    Log.e(TAG, "tts_init_failed status=" + status);
                    publishError("El motor de voz no pudo iniciarse. Revisa Texto a voz en los ajustes del celular.");
                    return;
                }

                try {
                    currentEngine = tts.getDefaultEngine();
                } catch (Exception ignored) {
                    currentEngine = "";
                }

                int languageResult = setBestLanguage();
                if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    initFailed = true;
                    Log.e(TAG, "tts_language_unavailable result=" + languageResult);
                    publishError("El motor de voz no tiene una voz instalada. Instala una voz en español en los ajustes del celular.");
                    return;
                }

                if (Build.VERSION.SDK_INT >= 21) {
                    try {
                        int audioResult = tts.setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build());
                        Log.i(TAG, "tts_audio_attributes result=" + audioResult);
                    } catch (Exception e) {
                        Log.w(TAG, "tts_audio_attributes_failed", e);
                    }
                }

                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        if (!isCurrentUtterance(utteranceId)) return;
                        Log.i(TAG, "tts_onStart id=" + utteranceId);
                        publishState(currentPageAbsolute, true, false, STATUS_PLAYING, "");
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        if (!isCurrentUtterance(utteranceId)) return;
                        Log.i(TAG, "tts_onDone id=" + utteranceId);
                        if (!isLastChunk(utteranceId)) return;

                        if (testMode) {
                            testMode = false;
                            reading = false;
                            paused = false;
                            publishState(currentPageAbsolute, false, false, STATUS_TEST_OK, "");
                            updateNotification("Prueba de voz completada");
                            releaseAudioFocus();
                            stopForeground(true);
                            stopSelf();
                            return;
                        }

                        if (!reading || paused) return;
                        currentPageAbsolute++;
                        speakAbsolutePage(currentPageAbsolute);
                    }

                    @Override
                    public void onError(String utteranceId) {
                        handleTtsError(utteranceId, TextToSpeech.ERROR);
                    }

                    @Override
                    public void onError(String utteranceId, int errorCode) {
                        handleTtsError(utteranceId, errorCode);
                    }

                    @Override
                    public void onStop(String utteranceId, boolean interrupted) {
                        if (!isCurrentUtterance(utteranceId)) return;
                        Log.w(TAG, "tts_onStop id=" + utteranceId + " interrupted=" + interrupted);
                        if (paused) {
                            publishState(currentPageAbsolute, true, true, STATUS_PAUSED, "");
                        }
                    }
                });

                ready = true;
                initFailed = false;
                Log.i(TAG, "tts_init_success engine=" + currentEngine + " language=" + tts.getLanguage());
                publishState(currentPageAbsolute, reading, paused, reading ? STATUS_PREPARING : STATUS_STOPPED, "");
                if (reading && !paused) {
                    if (testMode) speakTestPhrase();
                    else speakAbsolutePage(currentPageAbsolute);
                }
            }
        });

        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (thisInit != initGeneration || !initializing) return;
                initializing = false;
                initFailed = true;
                initGeneration++;
                Log.e(TAG, "tts_init_timeout");
                publishError("El motor de voz no respondió en 6 segundos. Abre los ajustes de Texto a voz y selecciona un motor activo.");
            }
        }, 6000L);
    }

    private int setBestLanguage() {
        int result = tts.setLanguage(new Locale("es", "PE"));
        if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) return result;
        result = tts.setLanguage(new Locale("es", "ES"));
        if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) return result;
        result = tts.setLanguage(Locale.getDefault());
        if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) return result;
        return tts.setLanguage(Locale.US);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_NOT_STICKY;
        String action = intent.getAction();
        Log.i(TAG, "service_action=" + action + " ready=" + ready + " reading=" + reading + " paused=" + paused);

        if (ACTION_WARMUP.equals(action)) {
            return START_NOT_STICKY;
        }

        if (ACTION_TEST.equals(action)) {
            if (initFailed || tts == null) initializeTts();
            title = "Prueba de voz";
            rate = 1.0f;
            pitch = 1.0f;
            currentPageAbsolute = -1;
            totalPages = 0;
            reading = true;
            paused = false;
            testMode = true;
            waitingForProvider = false;
            playbackGeneration++;
            startForeground(NOTIFICATION_ID, buildNotification("Preparando prueba de voz"));
            publishState(currentPageAbsolute, true, false, STATUS_PREPARING, "");
            requestAudioFocus();
            if (ready) speakTestPhrase();
            return START_NOT_STICKY;
        }

        if (ACTION_START.equals(action)) {
            if (initFailed || tts == null) initializeTts();
            String extraTitle = intent.getStringExtra("title");
            title = extraTitle == null ? "PDF a Audio" : extraTitle;
            totalPages = intent.getIntExtra("totalPages", 0);
            currentPageAbsolute = Math.max(0, intent.getIntExtra("page", intent.getIntExtra("pageOffset", 0)));
            rate = clampRate(intent.getFloatExtra("rate", 1.0f));
            pitch = intent.getFloatExtra("pitch", 1.0f);
            reading = true;
            paused = false;
            testMode = false;
            waitingForProvider = false;
            playbackGeneration++;
            startForeground(NOTIFICATION_ID, buildNotification("Preparando página " + (currentPageAbsolute + 1)));
            publishState(currentPageAbsolute, true, false, STATUS_PREPARING, "");
            requestAudioFocus();
            if (ready) speakAbsolutePage(currentPageAbsolute);
            return START_NOT_STICKY;
        }

        if (ACTION_TOGGLE.equals(action)) {
            toggle();
        } else if (ACTION_NEXT.equals(action)) {
            if (!reading) return START_NOT_STICKY;
            playbackGeneration++;
            currentPageAbsolute++;
            paused = false;
            publishState(currentPageAbsolute, true, false, STATUS_PREPARING, "");
            if (ready) speakAbsolutePage(currentPageAbsolute);
        } else if (ACTION_PREV.equals(action)) {
            if (!reading) return START_NOT_STICKY;
            playbackGeneration++;
            currentPageAbsolute = Math.max(0, currentPageAbsolute - 1);
            paused = false;
            publishState(currentPageAbsolute, true, false, STATUS_PREPARING, "");
            if (ready) speakAbsolutePage(currentPageAbsolute);
        } else if (ACTION_STOP.equals(action)) {
            stopAll();
        }

        return START_NOT_STICKY;
    }

    private void speakTestPhrase() {
        queueText(-1, "Prueba de voz correcta. El audio de la aplicación está funcionando.");
    }

    private void speakAbsolutePage(final int absolutePage) {
        if (!ready || !reading || paused) return;

        if (totalPages > 0 && absolutePage >= totalPages) {
            updateNotification("Lectura finalizada");
            stopAll();
            return;
        }

        String stored = getStoredPage(absolutePage);
        if (stored != null) {
            queueText(absolutePage, stored);
            return;
        }

        requestPageFromProvider(absolutePage);
    }

    private void requestPageFromProvider(final int absolutePage) {
        if (!reading || paused || waitingForProvider) return;

        final PageProvider provider = getProvider();
        if (provider == null) {
            publishError("La aplicación perdió el acceso al texto del PDF. Cierra y vuelve a abrir el documento.");
            return;
        }

        waitingForProvider = true;
        publishState(absolutePage, true, false, STATUS_PREPARING, "");
        updateNotification("Extrayendo texto de página " + (absolutePage + 1));
        final int requestGeneration = playbackGeneration;

        provider.requestPageText(absolutePage, new PageTextCallback() {
            @Override
            public void onText(String text) {
                waitingForProvider = false;
                if (!reading || paused || requestGeneration != playbackGeneration || absolutePage != currentPageAbsolute) return;
                setPageText(absolutePage, text);
                queueText(absolutePage, text);
            }
        });
    }

    private void queueText(int page, String rawText) {
        if (!ready || !reading || paused || tts == null) return;

        String text = cleanForTts(rawText);
        if (text.length() == 0) {
            publishError("No se encontró texto legible en esta página. Puede ser una página escaneada como imagen.");
            return;
        }

        ArrayList<String> chunks = splitForTts(text);
        if (chunks.isEmpty()) {
            publishError("No se pudo preparar el texto para la voz.");
            return;
        }

        currentPageAbsolute = page;
        publishState(page, true, false, STATUS_PREPARING, "");
        updateNotification(testMode ? "Iniciando prueba de voz" : "Página " + (page + 1) + " · " + String.format(Locale.US, "%.2fx", rate));

        tts.setSpeechRate(rate);
        tts.setPitch(pitch);
        int generation = playbackGeneration;

        for (int i = 0; i < chunks.size(); i++) {
            Bundle params = new Bundle();
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
            if (Build.VERSION.SDK_INT < 21) {
                params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC);
            }

            String utteranceId = makeUtteranceId(generation, page, i, chunks.size());
            int queueMode = i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD;
            int result = tts.speak(chunks.get(i), queueMode, params, utteranceId);
            Log.i(TAG, "tts_speak page=" + page + " chunk=" + i + "/" + chunks.size() + " len=" + chunks.get(i).length() + " result=" + result);
            if (result == TextToSpeech.ERROR) {
                publishError("El motor de voz rechazó el texto. Revisa o cambia el motor de Texto a voz del celular.");
                return;
            }
        }
    }

    private ArrayList<String> splitForTts(String text) {
        ArrayList<String> parts = new ArrayList<String>();
        int platformLimit = TextToSpeech.getMaxSpeechInputLength();
        int maxLen = Math.max(500, Math.min(3500, platformLimit - 128));
        int start = 0;

        while (start < text.length()) {
            while (start < text.length() && Character.isWhitespace(text.charAt(start))) start++;
            if (start >= text.length()) break;

            int hardEnd = Math.min(text.length(), start + maxLen);
            int end = hardEnd;
            if (hardEnd < text.length()) {
                int candidate = text.lastIndexOf(". ", hardEnd - 1);
                if (candidate <= start + 100) candidate = text.lastIndexOf("\n", hardEnd - 1);
                if (candidate <= start + 100) candidate = text.lastIndexOf(" ", hardEnd - 1);
                if (candidate > start) end = candidate + 1;
            }

            String part = text.substring(start, end).trim();
            if (part.length() > 0) parts.add(part);
            start = end;
        }
        return parts;
    }

    private String makeUtteranceId(int generation, int page, int chunk, int total) {
        return "G" + generation + "_P" + page + "_C" + chunk + "_N" + total;
    }

    private boolean isCurrentUtterance(String id) {
        return id != null && id.startsWith("G" + playbackGeneration + "_");
    }

    private boolean isLastChunk(String id) {
        if (id == null) return false;
        try {
            int cPos = id.lastIndexOf("_C");
            int nPos = id.lastIndexOf("_N");
            if (cPos < 0 || nPos < 0 || nPos <= cPos) return false;
            int chunk = Integer.parseInt(id.substring(cPos + 2, nPos));
            int total = Integer.parseInt(id.substring(nPos + 2));
            return chunk == total - 1;
        } catch (Exception ignored) {
            return false;
        }
    }

    private void handleTtsError(String utteranceId, int errorCode) {
        if (!isCurrentUtterance(utteranceId)) return;
        Log.e(TAG, "tts_onError id=" + utteranceId + " code=" + errorCode);
        publishError("Error del motor de voz: código " + errorCode + ". Prueba otro motor o descarga la voz en español.");
    }

    private void toggle() {
        if (!reading) {
            publishState(currentPageAbsolute, false, false, STATUS_STOPPED, "");
            return;
        }

        if (paused) {
            paused = false;
            playbackGeneration++;
            publishState(currentPageAbsolute, true, false, STATUS_PREPARING, "");
            requestAudioFocus();
            if (ready) speakAbsolutePage(currentPageAbsolute);
        } else {
            paused = true;
            if (tts != null) tts.stop();
            publishState(currentPageAbsolute, true, true, STATUS_PAUSED, "");
            updateNotification("Pausado");
            releaseAudioFocus();
        }
    }

    private void stopAll() {
        playbackGeneration++;
        reading = false;
        paused = false;
        waitingForProvider = false;
        testMode = false;
        if (tts != null) tts.stop();
        publishState(currentPageAbsolute, false, false, STATUS_STOPPED, "");
        releaseAudioFocus();
        stopForeground(true);
        stopSelf();
    }

    private void publishError(String message) {
        playbackGeneration++;
        reading = false;
        paused = false;
        waitingForProvider = false;
        testMode = false;
        try {
            if (tts != null) tts.stop();
        } catch (Exception ignored) {
        }
        Log.e(TAG, "playback_error=" + message);
        publishState(currentPageAbsolute, false, false, STATUS_ERROR, message);
        updateNotification(message);
        releaseAudioFocus();
    }

    private void publishState(int page, boolean active, boolean isPaused, String status, String error) {
        try {
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(PREF_TTS_ACTIVE, active)
                    .putBoolean(PREF_TTS_PAUSED, isPaused)
                    .putInt(PREF_TTS_CURRENT_PAGE, page)
                    .putString(PREF_TTS_STATUS, status == null ? STATUS_STOPPED : status)
                    .putString(PREF_TTS_ERROR, error == null ? "" : error)
                    .putString(PREF_TTS_ENGINE, currentEngine == null ? "" : currentEngine)
                    .commit();

            Intent update = new Intent(ACTION_PAGE_CHANGED);
            update.setPackage(getPackageName());
            update.putExtra(EXTRA_PAGE, page);
            update.putExtra(EXTRA_ACTIVE, active);
            update.putExtra(EXTRA_PAUSED, isPaused);
            update.putExtra(EXTRA_STATUS, status);
            update.putExtra(EXTRA_ERROR, error);
            update.putExtra(EXTRA_ENGINE, currentEngine);
            sendBroadcast(update);
        } catch (Exception e) {
            Log.e(TAG, "publish_state_failed", e);
        }
    }

    private float clampRate(float value) {
        if (value < 0.5f) return 0.5f;
        if (value > 2.0f) return 2.0f;
        return value;
    }

    private String cleanForTts(String value) {
        if (value == null) return "";
        String text = value.replace('\u00A0', ' ');
        text = text.replace("\\r\\n", "\n");
        text = text.replace("\\n", "\n");
        text = text.replace("\\r", "\n");
        text = text.replace("/n", "\n");
        text = text.replace('\r', '\n');
        text = text.replaceAll("(?m)^\\s*[\\\\/]*[NnÑñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[A-ZÑ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[a-zñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[0-9]{1,4}\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[IVXLCDMivxlcdm]{1,8}\\s*$", "");
        text = text.replaceFirst("(?i)^(\\s*[nñ]\\s+){1,10}", "");
        text = text.replaceAll("(?i)(^|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-])[nñ](?=($|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-]))", "$1");
        text = text.replaceAll("(?iu)([a-záéíóúüñ])-\\s*\\n\\s*([a-záéíóúüñ])", "$1$2");
        text = text.replaceAll("[ \\t]{2,}", " ");
        text = text.replaceAll("\\n[ \\t]+", "\n");
        text = text.replaceAll("\\n{3,}", "\n\n");
        return text.trim();
    }

    private void requestAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build();
                audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                        .setAudioAttributes(attrs)
                        .setAcceptsDelayedFocusGain(false)
                        .setOnAudioFocusChangeListener(new AudioManager.OnAudioFocusChangeListener() {
                            @Override
                            public void onAudioFocusChange(int focusChange) {
                                Log.i(TAG, "audio_focus_change=" + focusChange);
                            }
                        })
                        .build();
                int result = audioManager.requestAudioFocus(audioFocusRequest);
                Log.i(TAG, "audio_focus_result=" + result);
            } else {
                int result = audioManager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
                Log.i(TAG, "audio_focus_result=" + result);
            }
        } catch (Exception e) {
            Log.w(TAG, "audio_focus_failed", e);
        }
    }

    private void releaseAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) {
                audioManager.abandonAudioFocusRequest(audioFocusRequest);
                audioFocusRequest = null;
            } else {
                audioManager.abandonAudioFocus(null);
            }
        } catch (Exception ignored) {
        }
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent prevPi = PendingIntent.getService(this, 1, new Intent(this, TtsForegroundService.class).setAction(ACTION_PREV), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent togglePi = PendingIntent.getService(this, 2, new Intent(this, TtsForegroundService.class).setAction(ACTION_TOGGLE), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent nextPi = PendingIntent.getService(this, 3, new Intent(this, TtsForegroundService.class).setAction(ACTION_NEXT), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stopPi = PendingIntent.getService(this, 4, new Intent(this, TtsForegroundService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        builder.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("PDF a Audio")
                .setContentText(text)
                .setSubText(title)
                .setContentIntent(openPi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .addAction(android.R.drawable.ic_media_previous, "Anterior", prevPi)
                .addAction(paused ? android.R.drawable.ic_media_play : android.R.drawable.ic_media_pause, paused ? "Reanudar" : "Pausar", togglePi)
                .addAction(android.R.drawable.ic_media_next, "Siguiente", nextPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPi);

        if (Build.VERSION.SDK_INT >= 21) {
            builder.setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setCategory(Notification.CATEGORY_TRANSPORT)
                    .setColor(0xFF0B3C58)
                    .setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2));
        }
        if (Build.VERSION.SDK_INT >= 31) builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        if (Build.VERSION.SDK_INT < 26) builder.setPriority(Notification.PRIORITY_DEFAULT);
        return builder.build();
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "PDF a Audio", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Lectura de PDF en segundo plano");
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.enableVibration(false);
            channel.setSound(null, null);
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        releaseAudioFocus();
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) {}
            try { tts.shutdown(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
