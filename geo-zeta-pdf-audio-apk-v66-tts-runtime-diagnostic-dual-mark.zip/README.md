# Geo Zeta PDF a Audio V66

Esta versión no oculta el fallo del motor TTS: muestra el estado real y el error exacto en pantalla.

Cambios de audio:
- Se añadió la declaración obligatoria de motores TTS en `<queries>` para Android 11 o superior.
- El botón solo muestra pausa después de que Android confirme `onStart()` y la voz haya comenzado realmente.
- Se añadieron estados reales: inicializando, preparando, reproduciendo, pausado, detenido y error.
- El texto se divide según el límite real de `TextToSpeech.getMaxSpeechInputLength()`.
- Se configura la salida como audio multimedia y voz, volumen TTS completo y audio focus.
- Se manejan `onStart`, `onDone`, `onStop` y los códigos de `onError`.
- Se eliminó la preparación duplicada del servicio antes de tener el texto.
- Se redujo la precarga agresiva de cientos de páginas para no saturar el teléfono.
- En Ajustes se añadió **Probar voz**, que habla una frase sin depender del PDF.
- En Ajustes se muestra el estado del motor, paquete del motor y error real.
- Se muestra claramente la versión 66.0.

Marcado conservado:
- Subrayado debajo del texto.
- Resaltado transparente detrás del texto.
- Color independiente para ambos tipos.

Diagnóstico:
1. Abre Ajustes.
2. Pulsa Probar voz.
3. Si no se escucha, revisa Estado del motor: la app mostrará si faltan datos de voz, si el motor no inicia o si rechazó la síntesis.
4. Si la prueba sí se escucha, abre el PDF y pulsa Play; cualquier página sin texto legible mostrará un aviso específico.
