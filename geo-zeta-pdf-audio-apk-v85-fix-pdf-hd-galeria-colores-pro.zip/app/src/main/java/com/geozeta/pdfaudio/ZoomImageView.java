package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

/**
 * Visor de galería con ajuste inicial al ancho, zoom y desplazamiento real.
 * Las páginas verticales se abren desde arriba y pueden recorrerse sin ampliar.
 */
public class ZoomImageView extends ImageView {
    public interface OnSingleTapListener {
        void onSingleTap();
    }

    private static final float MIN_USER_SCALE = 1.0f;
    private static final float MAX_USER_SCALE = 5.0f;

    private final Matrix matrix = new Matrix();
    private final float[] matrixValues = new float[9];
    private final PointF last = new PointF();
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestureDetector;
    private float userScale = 1.0f;
    private float baseScale = 1.0f;
    private boolean dragging;
    private OnSingleTapListener onSingleTapListener;

    public ZoomImageView(Context context) {
        this(context, null);
    }

    public ZoomImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        super.setScaleType(ScaleType.MATRIX);

        scaleDetector = new ScaleGestureDetector(context,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override
                    public boolean onScale(ScaleGestureDetector detector) {
                        Drawable drawable = getDrawable();
                        if (drawable == null) return false;
                        float next = Math.max(MIN_USER_SCALE,
                                Math.min(MAX_USER_SCALE, userScale * detector.getScaleFactor()));
                        float factor = next / userScale;
                        userScale = next;
                        matrix.postScale(factor, factor,
                                detector.getFocusX(), detector.getFocusY());
                        clampMatrix();
                        setImageMatrix(matrix);
                        return true;
                    }
                });

        gestureDetector = new GestureDetector(context,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDoubleTap(MotionEvent e) {
                        if (userScale > 1.05f) {
                            resetZoom();
                        } else {
                            float factor = 2.2f;
                            userScale = factor;
                            matrix.postScale(factor, factor, e.getX(), e.getY());
                            clampMatrix();
                            setImageMatrix(matrix);
                        }
                        return true;
                    }

                    @Override
                    public boolean onSingleTapConfirmed(MotionEvent e) {
                        if (onSingleTapListener != null) onSingleTapListener.onSingleTap();
                        return true;
                    }
                });
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        scheduleFit();
    }

    @Override
    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        scheduleFit();
    }

    public void resetZoom() {
        fitImageToView();
    }

    public void setOnSingleTapListener(OnSingleTapListener listener) {
        this.onSingleTapListener = listener;
    }

    private void scheduleFit() {
        post(new Runnable() {
            @Override
            public void run() {
                fitImageToView();
            }
        });
    }

    private void fitImageToView() {
        Drawable drawable = getDrawable();
        if (drawable == null || getWidth() <= 0 || getHeight() <= 0) return;

        float drawableWidth = Math.max(1f, drawable.getIntrinsicWidth());
        float drawableHeight = Math.max(1f, drawable.getIntrinsicHeight());
        float availableWidth = Math.max(1f,
                getWidth() - getPaddingLeft() - getPaddingRight());
        float availableHeight = Math.max(1f,
                getHeight() - getPaddingTop() - getPaddingBottom());

        // Galería: siempre ocupa todo el ancho. Una página alta inicia arriba y
        // se desplaza verticalmente sin obligar al usuario a hacer zoom.
        baseScale = availableWidth / drawableWidth;
        float scaledHeight = drawableHeight * baseScale;
        float dx = getPaddingLeft();
        float dy = scaledHeight <= availableHeight
                ? getPaddingTop() + (availableHeight - scaledHeight) / 2f
                : getPaddingTop();

        matrix.reset();
        matrix.setScale(baseScale, baseScale);
        matrix.postTranslate(dx, dy);
        userScale = 1.0f;
        clampMatrix();
        setImageMatrix(matrix);
        invalidate();
    }

    private void clampMatrix() {
        Drawable drawable = getDrawable();
        if (drawable == null) return;

        matrix.getValues(matrixValues);
        float scale = matrixValues[Matrix.MSCALE_X];
        float tx = matrixValues[Matrix.MTRANS_X];
        float ty = matrixValues[Matrix.MTRANS_Y];

        float availableWidth = Math.max(1f,
                getWidth() - getPaddingLeft() - getPaddingRight());
        float availableHeight = Math.max(1f,
                getHeight() - getPaddingTop() - getPaddingBottom());
        float displayWidth = drawable.getIntrinsicWidth() * scale;
        float displayHeight = drawable.getIntrinsicHeight() * scale;

        float correctedX;
        if (displayWidth <= availableWidth) {
            correctedX = getPaddingLeft() + (availableWidth - displayWidth) / 2f;
        } else {
            float minX = getPaddingLeft() + availableWidth - displayWidth;
            float maxX = getPaddingLeft();
            correctedX = Math.max(minX, Math.min(maxX, tx));
        }

        float correctedY;
        if (displayHeight <= availableHeight) {
            correctedY = getPaddingTop() + (availableHeight - displayHeight) / 2f;
        } else {
            float minY = getPaddingTop() + availableHeight - displayHeight;
            float maxY = getPaddingTop();
            correctedY = Math.max(minY, Math.min(maxY, ty));
        }

        matrix.postTranslate(correctedX - tx, correctedY - ty);
    }

    private boolean canPan() {
        Drawable drawable = getDrawable();
        if (drawable == null) return false;
        matrix.getValues(matrixValues);
        float scale = matrixValues[Matrix.MSCALE_X];
        float availableWidth = getWidth() - getPaddingLeft() - getPaddingRight();
        float availableHeight = getHeight() - getPaddingTop() - getPaddingBottom();
        return drawable.getIntrinsicWidth() * scale > availableWidth + 1f
                || drawable.getIntrinsicHeight() * scale > availableHeight + 1f;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        scaleDetector.onTouchEvent(event);
        gestureDetector.onTouchEvent(event);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                last.set(event.getX(), event.getY());
                dragging = true;
                break;
            case MotionEvent.ACTION_MOVE:
                if (dragging && !scaleDetector.isInProgress() && canPan()) {
                    float dx = event.getX() - last.x;
                    float dy = event.getY() - last.y;
                    matrix.postTranslate(dx, dy);
                    clampMatrix();
                    setImageMatrix(matrix);
                    last.set(event.getX(), event.getY());
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                performClick();
                break;
            default:
                break;
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }
}
