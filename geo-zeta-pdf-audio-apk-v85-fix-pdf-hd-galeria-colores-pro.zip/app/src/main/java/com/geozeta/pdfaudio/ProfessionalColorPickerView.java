package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Compact two-dimensional color picker.
 * Horizontal movement changes hue. Vertical movement goes from white,
 * through the selected hue, to black.
 */
public class ProfessionalColorPickerView extends View {
    public interface OnColorChangedListener {
        void onColorChanged(int color);
    }

    private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indicatorOuterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indicatorInnerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Bitmap paletteBitmap;
    private float selectedX = 0.08f;
    private float selectedY = 0.50f;
    private int selectedColor = Color.RED;
    private OnColorChangedListener listener;

    public ProfessionalColorPickerView(Context context) {
        this(context, null);
    }

    public ProfessionalColorPickerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setFocusable(true);
        setClickable(true);

        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(1));
        borderPaint.setColor(Color.rgb(203, 213, 225));

        indicatorOuterPaint.setStyle(Paint.Style.STROKE);
        indicatorOuterPaint.setStrokeWidth(dp(4));
        indicatorOuterPaint.setColor(Color.WHITE);
        indicatorOuterPaint.setShadowLayer(dp(3), 0f, dp(1), 0x99000000);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        indicatorInnerPaint.setStyle(Paint.Style.STROKE);
        indicatorInnerPaint.setStrokeWidth(dp(1));
        indicatorInnerPaint.setColor(Color.rgb(15, 23, 42));
    }

    public void setOnColorChangedListener(OnColorChangedListener listener) {
        this.listener = listener;
    }

    public int getSelectedColor() {
        return selectedColor;
    }

    public void setColor(int color) {
        float[] hsv = new float[3];
        Color.colorToHSV(0xFF000000 | (color & 0x00FFFFFF), hsv);
        selectedX = clamp(hsv[0] / 360f, 0f, 1f);
        if (hsv[2] < 0.995f) {
            selectedY = 0.5f + (1f - hsv[2]) * 0.5f;
        } else {
            selectedY = clamp(hsv[1] * 0.5f, 0f, 0.5f);
        }
        selectedColor = colorAt(selectedX, selectedY);
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        rebuildPalette(w, h);
    }

    private void rebuildPalette(int width, int height) {
        if (width <= 0 || height <= 0) return;
        if (paletteBitmap != null && !paletteBitmap.isRecycled()) paletteBitmap.recycle();
        int bitmapWidth = Math.max(120, Math.min(width, 360));
        int bitmapHeight = Math.max(100, Math.min(height, 220));
        paletteBitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888);
        int[] pixels = new int[bitmapWidth * bitmapHeight];
        for (int y = 0; y < bitmapHeight; y++) {
            float ny = bitmapHeight <= 1 ? 0.5f : y / (float) (bitmapHeight - 1);
            for (int x = 0; x < bitmapWidth; x++) {
                float nx = bitmapWidth <= 1 ? 0f : x / (float) (bitmapWidth - 1);
                pixels[y * bitmapWidth + x] = colorAt(nx, ny);
            }
        }
        paletteBitmap.setPixels(pixels, 0, bitmapWidth, 0, 0, bitmapWidth, bitmapHeight);
    }

    private int colorAt(float nx, float ny) {
        float hue = clamp(nx, 0f, 1f) * 360f;
        int hueColor = Color.HSVToColor(new float[]{hue, 1f, 1f});
        float y = clamp(ny, 0f, 1f);
        if (y <= 0.5f) {
            return blend(Color.WHITE, hueColor, y * 2f);
        }
        return blend(hueColor, Color.BLACK, (y - 0.5f) * 2f);
    }

    private int blend(int from, int to, float amount) {
        float t = clamp(amount, 0f, 1f);
        int r = Math.round(Color.red(from) + (Color.red(to) - Color.red(from)) * t);
        int g = Math.round(Color.green(from) + (Color.green(to) - Color.green(from)) * t);
        int b = Math.round(Color.blue(from) + (Color.blue(to) - Color.blue(from)) * t);
        return Color.rgb(r, g, b);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        RectF paletteRect = new RectF(0f, 0f, getWidth(), getHeight());
        int save = canvas.save();
        Path clip = new Path();
        clip.addRoundRect(paletteRect, dp(12), dp(12), Path.Direction.CW);
        canvas.clipPath(clip);
        if (paletteBitmap != null && !paletteBitmap.isRecycled()) {
            canvas.drawBitmap(paletteBitmap, null, paletteRect, bitmapPaint);
        }
        canvas.restoreToCount(save);
        RectF border = new RectF(dp(0.5f), dp(0.5f), getWidth() - dp(0.5f), getHeight() - dp(0.5f));
        canvas.drawRoundRect(border, dp(12), dp(12), borderPaint);

        float cx = selectedX * Math.max(1, getWidth() - 1);
        float cy = selectedY * Math.max(1, getHeight() - 1);
        float radius = dp(10);
        canvas.drawCircle(cx, cy, radius, indicatorOuterPaint);
        canvas.drawCircle(cx, cy, radius - dp(2), indicatorInnerPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            selectedX = clamp(event.getX() / Math.max(1f, getWidth()), 0f, 1f);
            selectedY = clamp(event.getY() / Math.max(1f, getHeight()), 0f, 1f);
            selectedColor = colorAt(selectedX, selectedY);
            if (listener != null) listener.onColorChanged(selectedColor);
            invalidate();
            return true;
        }
        return action == MotionEvent.ACTION_UP || super.onTouchEvent(event);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (paletteBitmap != null && !paletteBitmap.isRecycled()) {
            paletteBitmap.recycle();
            paletteBitmap = null;
        }
        super.onDetachedFromWindow();
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
