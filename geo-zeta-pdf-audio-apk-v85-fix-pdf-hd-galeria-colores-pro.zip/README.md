# Geo Zeta PDF a Audio V85

Correcciones aplicadas sobre la versión V84 entregada por el usuario:

- Ventana oscura estable al cambiar entre Ajustes, Mis archivos y el lector, evitando el destello blanco.
- Visor de imágenes con ajuste inicial al ancho, desplazamiento vertical sin zoom, pellizco y doble toque.
- Exportación PNG renderizada directamente desde el PDF a aproximadamente 300 ppp, sin reutilizar la imagen reducida de pantalla.
- Mis archivos > Imágenes con dos vistas conmutables: lista y cuadrícula compacta de tres columnas.
- Selector de colores rediseñado con paleta más limpia, selección visible y tarjeta personalizada.
- Color personalizado con vista previa completa del color y código hexadecimal centrado.
- El mismo diseño se aplica a los colores de reglas y seguimiento de lectura.
- La lógica y el comportamiento del subrayado no se modificaron.

VersionCode: 85
VersionName: 85.0-pdf-hd-gallery-color-pro
