# Geo Zeta PDF a Audio V54 Audio Priority Underline

Base:
- V53 Professional Settings.

Correcciones fuertes:
- El subrayado ya no tapa el texto.
- Ahora dibuja una línea fina debajo de las letras detectadas.
- Al cambiar de página con audio activo, ya no se corta en silencio mientras prepara.
- La página anterior sigue sonando hasta que el texto nuevo esté listo.
- Cuando el texto nuevo está listo, cambia al audio de la página nueva.
- Si el audio está pausado, cambiar página no mata el audio; al tocar reproducir lee la página actual.
- El audio solo debe pausarse cuando el usuario toca pausa.

Mantiene:
- Pantalla de ajustes profesional.
- Tema claro/oscuro.
- Guardar imagen PNG.
- Guardar audio WAV.
- Limpieza de texto para evitar letras sueltas como "ene".
- Reglas arriba/abajo.
- Zoom fluido.
- PdfRenderer, PDFBox, TextToSpeech.
