package com.geozeta.pdfaudio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.content.DialogInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int REQ_OPEN_PDF = 1001;

    private PdfPageView pdfView;
    private TextRepository textRepository;
    private TextView titleView;
    private TextView pageView;
    private Button playButton;
    private File currentFile;
    private String currentTitle;
    private int currentPage;
    private int pageCount;
    private boolean audioStarted;
    private boolean audioPaused;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        currentTitle = "PDF a Audio";
        prefs = getSharedPreferences("pdf_audio_prefs", MODE_PRIVATE);
        textRepository = new TextRepository(this);
        buildUi();

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 33);
        }

        File last = new File(getFilesDir(), "last.pdf");
        if (last.exists()) {
            openLocalPdf(last, prefs.getString("last_title", "PDF guardado"), true);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(17, 24, 39));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(12, 12, 12, 8);
        top.setBackgroundColor(Color.rgb(8, 40, 58));

        Button openButton = makeButton("Abrir");
        
openButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        choosePdf();
    }
});

        titleView = new TextView(this);
        titleView.setText("PDF a Audio");
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(18);
        titleView.setSingleLine(true);
        titleView.setGravity(Gravity.CENTER_VERTICAL);

        pageView = new TextView(this);
        pageView.setText("0/0");
        pageView.setTextColor(Color.WHITE);
        pageView.setTextSize(18);
        pageView.setGravity(Gravity.CENTER);

        Button gotoButton = makeButton("#");
        
gotoButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        showGoto();
    }
});

        top.addView(openButton, new LinearLayout.LayoutParams(dp(82), dp(48)));
        top.addView(titleView, new LinearLayout.LayoutParams(0, dp(48), 1));
        top.addView(pageView, new LinearLayout.LayoutParams(dp(78), dp(48)));
        top.addView(gotoButton, new LinearLayout.LayoutParams(dp(56), dp(48)));

        FrameLayout frame = new FrameLayout(this);
        pdfView = new PdfPageView(this);
        pdfView.setPageChangeListener(new PdfPageView.PageChangeListener() {
            @Override
            public void onPageRendered(int pageIndex, int total) {
                currentPage = pageIndex;
                pageCount = total;
                updatePageLabel();
                saveProgress();
                textRepository.prefetch(currentPage, 3, pageCount);
            }

            @Override
            public void onError(String message) {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
        frame.addView(pdfView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(8, 8, 8, 8);
        controls.setBackgroundColor(Color.rgb(8, 40, 58));

        Button prevButton = makeButton("‹");
        prevButton.setTextSize(30);
        
prevButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) pdfView.previousPage();
    }
});

        playButton = makeButton("▶");
        playButton.setTextSize(26);
        
playButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        toggleAudio();
    }
});

        Button nextButton = makeButton("›");
        nextButton.setTextSize(30);
        
nextButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (pageCount > 0) pdfView.nextPage();
    }
});

        Button fitButton = makeButton("Ajustar");
        
fitButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        pdfView.fitPage();
    }
});

        controls.addView(prevButton, new LinearLayout.LayoutParams(0, dp(58), 1));
        controls.addView(playButton, new LinearLayout.LayoutParams(0, dp(58), 1));
        controls.addView(nextButton, new LinearLayout.LayoutParams(0, dp(58), 1));
        controls.addView(fitButton, new LinearLayout.LayoutParams(0, dp(58), 1));

        root.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)));
        root.addView(frame, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        root.addView(controls, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(78)));

        setContentView(root);
    }

    private Button makeButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(16);
        button.setAllCaps(false);
        button.setBackgroundColor(Color.rgb(11, 60, 88));
        return button;
    }

    private void choosePdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        startActivityForResult(intent, REQ_OPEN_PDF);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OPEN_PDF && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            copyAndOpen(uri);
        }
    }

    private void copyAndOpen(Uri uri) {
        try {
            stopAudioOnly();
            String name = getDisplayName(uri);
            File target = new File(getFilesDir(), "last.pdf");

            InputStream input = getContentResolver().openInputStream(uri);
            FileOutputStream output = new FileOutputStream(target);
            byte[] buffer = new byte[65536];
            int read;
            while (input != null && (read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
            if (input != null) input.close();
            output.close();

            prefs.edit().putString("last_title", name).putInt("last_page", 0).apply();
            openLocalPdf(target, name, false);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir el PDF", Toast.LENGTH_LONG).show();
        }
    }

    private void openLocalPdf(File file, String title, boolean restore) {
        try {
            currentFile = file;
            currentTitle = title == null ? "PDF" : title;
            titleView.setText(currentTitle);
            textRepository.open(file);
            pdfView.openFile(file);
            pageCount = pdfView.getPageCount();
            int p = restore ? prefs.getInt("last_page", 0) : 0;
            p = Math.max(0, Math.min(p, Math.max(0, pageCount - 1)));
            pdfView.showPage(p);
            updatePageLabel();
        } catch (Exception e) {
            Toast.makeText(this, "Error al cargar PDF", Toast.LENGTH_LONG).show();
        }
    }

    private String getDisplayName(Uri uri) {
        String result = "PDF";
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return result == null ? "PDF" : result;
    }

    private void toggleAudio() {
        if (currentFile == null || pageCount <= 0) {
            Toast.makeText(this, "Abre un PDF primero", Toast.LENGTH_SHORT).show();
            return;
        }

        if (audioStarted) {
            Intent intent = new Intent(this, TtsForegroundService.class);
            intent.setAction(TtsForegroundService.ACTION_TOGGLE);
            startService(intent);
            audioPaused = !audioPaused;
            playButton.setText(audioPaused ? "▶" : "Ⅱ");
            return;
        }

        startAudioFromCurrentPage();
    }

    private void startAudioFromCurrentPage() {
        playButton.setText("...");
        textRepository.getPageText(currentPage, new TextRepository.TextCallback() {
            @Override
            public void onText(String text) {
                TtsForegroundService.clearPages();
                TtsForegroundService.addPage(text);

                Intent intent = new Intent(MainActivity.this, TtsForegroundService.class);
                intent.setAction(TtsForegroundService.ACTION_START);
                intent.putExtra("title", currentTitle);
                intent.putExtra("pageOffset", currentPage);
                intent.putExtra("startIndex", 0);
                intent.putExtra("rate", 0.95f);
                intent.putExtra("pitch", 1.0f);

                if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
                else startService(intent);

                audioStarted = true;
                audioPaused = false;
                playButton.setText("Ⅱ");
                prepareNextAudioPages(currentPage + 1, 25);
            }
        });
    }

    private void prepareNextAudioPages(int start, int count) {
        for (int i = 0; i < count; i++) {
            int p = start + i;
            if (p >= pageCount) break;
            textRepository.getPageText(p, new TextRepository.TextCallback() {
                @Override
                public void onText(String text) {
                    TtsForegroundService.addPage(text);
                }
            });
        }
    }

    private void stopAudioOnly() {
        audioStarted = false;
        audioPaused = false;
        if (playButton != null) playButton.setText("▶");

        Intent intent = new Intent(this, TtsForegroundService.class);
        intent.setAction(TtsForegroundService.ACTION_STOP);
        startService(intent);
    }

    private void showGoto() {
        if (pageCount <= 0) return;

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setHint("Página 1 - " + pageCount);

        new AlertDialog.Builder(this)
                .setTitle("Ir a página")
                .setView(input)
                .setPositiveButton("Ir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            int p = Integer.parseInt(input.getText().toString()) - 1;
                            p = Math.max(0, Math.min(p, pageCount - 1));
                            pdfView.showPage(p);
                        } catch (Exception ignored) {
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void updatePageLabel() {
        if (pageCount <= 0) pageView.setText("0/0");
        else pageView.setText((currentPage + 1) + "/" + pageCount);
    }

    private void saveProgress() {
        prefs.edit().putInt("last_page", currentPage).putString("last_title", currentTitle).apply();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        saveProgress();
        textRepository.close();
    }
}
