# Geo Zeta PDF a Audio V6

Interfaz más profesional:
- PDF grande como lector.
- Reproductor compacto abajo.
- Zoom flotante.
- Saltar encabezado, pie y número de página.
- Guarda PDF y última página.
- Reproducción en segundo plano con pantalla apagada.
