package com.geozeta.pdfaudio;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TextRepository {
    public interface TextCallback {
        void onText(String text);
    }

    private ExecutorService executor;
    private Handler mainHandler;
    private Map<Integer, String> cache;
    private PDDocument document;
    private boolean rulesEnabled;
    private float ruleTop;
    private float ruleBottom;

    public TextRepository(Context context) {
        PDFBoxResourceLoader.init(context);
        executor = Executors.newSingleThreadExecutor();
        mainHandler = new Handler(Looper.getMainLooper());
        cache = new ConcurrentHashMap<Integer, String>();
        rulesEnabled = true;
        ruleTop = 0.08f;
        ruleBottom = 0.92f;
    }

    public synchronized void setRules(boolean enabled, float top, float bottom) {
        rulesEnabled = enabled;
        ruleTop = Math.max(0f, Math.min(top, 0.95f));
        ruleBottom = Math.max(0.05f, Math.min(bottom, 1f));
        if (ruleBottom <= ruleTop + 0.05f) {
            ruleTop = 0.08f;
            ruleBottom = 0.92f;
        }
        cache.clear();
    }

    public synchronized void open(final File file) {
        close();
        cache.clear();

        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    PDDocument doc = PDDocument.load(file);
                    synchronized (TextRepository.this) {
                        document = doc;
                    }
                } catch (Exception ignored) {
                }
            }
        });
    }


    public void getPageText(final int zeroBasedPage, final TextCallback callback) {
        getPageTextInternal(zeroBasedPage, callback, 0);
    }

    private void getPageTextInternal(final int zeroBasedPage, final TextCallback callback, final int attempt) {
        String cached = cache.get(zeroBasedPage);
        if (cached != null) {
            final String value = cached;
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    callback.onText(value);
                }
            });
            return;
        }

        executor.execute(new Runnable() {
            @Override
            public void run() {
                String text = "";

                try {
                    PDDocument doc;
                    synchronized (TextRepository.this) {
                        doc = document;
                    }

                    if (doc == null && attempt < 10) {
                        mainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                getPageTextInternal(zeroBasedPage, callback, attempt + 1);
                            }
                        }, 250);
                        return;
                    }

                    if (doc != null) {
                        PDFTextStripper stripper;
                        if (rulesEnabled) {
                            stripper = new RuleTextStripper(ruleTop, ruleBottom);
                        } else {
                            stripper = new PDFTextStripper();
                        }

                        int page = zeroBasedPage + 1;
                        stripper.setStartPage(page);
                        stripper.setEndPage(page);
                        text = stripper.getText(doc);
                        if (text == null) text = "";
                        text = text.replaceAll("\\s+\\n", "\\n").trim();
                        cache.put(zeroBasedPage, text);
                    }
                } catch (Exception ignored) {
                }

                final String result = text;
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onText(result);
                    }
                });
            }
        });
    }


    public boolean hasCachedText(int page) {
        return cache.containsKey(page);
    }

    public void prefetch(int fromPage, int count, int totalPages) {
        for (int i = 0; i < count; i++) {
            int p = fromPage + i;
            if (p >= 0 && p < totalPages && !cache.containsKey(p)) {
                getPageText(p, new TextCallback() {
                    @Override
                    public void onText(String text) {
                    }
                });
            }
        }
    }

    public synchronized void close() {
        try {
            if (document != null) document.close();
        } catch (Exception ignored) {
        }
        document = null;
    }

    private static class RuleTextStripper extends PDFTextStripper {
        private final float topRatio;
        private final float bottomRatio;

        RuleTextStripper(float topRatio, float bottomRatio) throws java.io.IOException {
            super();
            this.topRatio = topRatio;
            this.bottomRatio = bottomRatio;
            setSortByPosition(true);
        }

        @Override
        protected void processTextPosition(TextPosition text) {
            float pageHeight = Math.max(1f, text.getPageHeight());
            float y = text.getYDirAdj() / pageHeight;

            if (y >= topRatio && y <= bottomRatio) {
                super.processTextPosition(text);
            }
        }
    }

}
