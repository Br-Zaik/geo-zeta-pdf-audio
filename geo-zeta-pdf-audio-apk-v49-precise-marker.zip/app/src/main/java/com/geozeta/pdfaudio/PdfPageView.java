package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfPageView extends View {
    public interface PageChangeListener {
        void onPageRendered(int pageIndex, int pageCount);
        void onError(String message);
        void onHighlightsChanged(String serialized);
        void onRulesChanged(boolean enabled, float top, float bottom);
    }

    private static class MarkerMark {
        int page;
        int color;
        float x1;
        float y;
        float x2;
        float thickness;

        MarkerMark(int page, int color, float x1, float y, float x2, float thickness) {
            this.page = page;
            this.color = color;
            this.x1 = x1;
            this.y = y;
            this.x2 = x2;
            this.thickness = thickness;
        }
    }

    private final Paint paint;
    private final Paint underlinePaint;
    private final Paint previewPaint;
    private final Paint rulePaint;
    private final Paint blockedPaint;
    private final ExecutorService executor;
    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private Bitmap bitmap;
    private int pageIndex;
    private int pageCount;
    private boolean renderBusy;
    private int pendingPage;
    private int serial;
    private float zoom;
    private float panX;
    private float panY;
    private PageChangeListener listener;
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestureDetector;
    private final Object lock = new Object();

    private boolean markMode;
    private int markColor;
    private boolean rulesEnabled;
    private float ruleTop;
    private float ruleBottom;
    private boolean draggingTopRule;
    private boolean draggingBottomRule;
    private boolean selecting;
    private float startX;
    private float startY;
    private float endX;
    private float endY;
    private final Map<Integer, ArrayList<MarkerMark>> marks;

    public PdfPageView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(238, 238, 238));
        paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);

        underlinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        underlinePaint.setStyle(Paint.Style.FILL);

        previewPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        previewPaint.setStyle(Paint.Style.FILL);
        previewPaint.setColor(0xD0FFD400);

        rulePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        rulePaint.setStyle(Paint.Style.FILL);
        rulePaint.setColor(0xFF2F6BFF);

        blockedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        blockedPaint.setStyle(Paint.Style.FILL);
        blockedPaint.setColor(0x33000000);

        executor = Executors.newSingleThreadExecutor();
        pendingPage = -1;
        zoom = 1.0f;
        markMode = false;
        markColor = 0xD0FFD400;
        rulesEnabled = true;
        ruleTop = 0.08f;
        ruleBottom = 0.92f;
        draggingTopRule = false;
        draggingBottomRule = false;
        marks = new HashMap<Integer, ArrayList<MarkerMark>>();

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float oldZoom = zoom;
                zoom = clamp(zoom * detector.getScaleFactor(), 1.0f, 4.0f);
                float focusX = detector.getFocusX();
                float focusY = detector.getFocusY();
                panX = focusX - (focusX - panX) * (zoom / oldZoom);
                panY = focusY - (focusY - panY) * (zoom / oldZoom);
                clampPan();
                invalidate();
                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {
                requestRender();
            }
        });

        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (markMode) return true;

                if (zoom > 1.2f) {
                    zoom = 1.0f;
                    panX = 0f;
                    panY = 0f;
                } else {
                    zoom = 2.0f;
                    panX = e.getX() - e.getX() * zoom;
                    panY = e.getY() - e.getY() * zoom;
                    clampPan();
                }

                requestRender();
                invalidate();
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                if (markMode) return true;

                panX -= distanceX;
                panY -= distanceY;
                clampPan();
                invalidate();
                return true;
            }
        });
    }

    public void setPageChangeListener(PageChangeListener listener) {
        this.listener = listener;
    }

    public int getPageCount() {
        return pageCount;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setMarkMode(boolean enabled) {
        markMode = enabled;
        selecting = false;
        invalidate();
    }

    public boolean isMarkMode() {
        return markMode;
    }

    public void setMarkColor(int color) {
        markColor = color;
        previewPaint.setColor(color);
        invalidate();
    }

    public void setRules(boolean enabled, float top, float bottom) {
        rulesEnabled = enabled;
        ruleTop = clamp(top, 0f, 0.95f);
        ruleBottom = clamp(bottom, 0.05f, 1f);
        if (ruleBottom <= ruleTop + 0.05f) {
            ruleTop = 0.08f;
            ruleBottom = 0.92f;
        }
        invalidate();
    }

    public boolean areRulesEnabled() {
        return rulesEnabled;
    }

    public float getRuleTop() {
        return ruleTop;
    }

    public float getRuleBottom() {
        return ruleBottom;
    }

    public void undoLastHighlight() {
        ArrayList<MarkerMark> list = marks.get(pageIndex);
        if (list != null && list.size() > 0) {
            list.remove(list.size() - 1);
            notifyHighlightsChanged();
            invalidate();
        }
    }

    public void clearPageHighlights() {
        marks.remove(pageIndex);
        notifyHighlightsChanged();
        invalidate();
    }

    public void loadHighlights(String data) {
        marks.clear();

        if (data == null || data.trim().length() == 0) {
            invalidate();
            return;
        }

        try {
            String[] items = data.split(";");
            for (int i = 0; i < items.length; i++) {
                String item = items[i].trim();
                if (item.length() == 0) continue;

                String[] p = item.split(",");
                if (p.length != 6) continue;

                int page = Integer.parseInt(p[0]);
                int color = (int) Long.parseLong(p[1], 16);
                float x1 = Float.parseFloat(p[2]);
                float y = Float.parseFloat(p[3]);
                float x2 = Float.parseFloat(p[4]);
                float thickness = Float.parseFloat(p[5]);

                addMarkObject(new MarkerMark(page, color, x1, y, x2, thickness), false);
            }
        } catch (Exception ignored) {
        }

        invalidate();
    }

    public String serializeHighlights() {
        StringBuilder builder = new StringBuilder();

        for (Map.Entry<Integer, ArrayList<MarkerMark>> entry : marks.entrySet()) {
            ArrayList<MarkerMark> list = entry.getValue();
            if (list == null) continue;

            for (int i = 0; i < list.size(); i++) {
                MarkerMark h = list.get(i);
                builder.append(h.page).append(",");
                builder.append(Integer.toHexString(h.color)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.x1)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.y)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.x2)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.thickness)).append(";");
            }
        }

        return builder.toString();
    }

    public void openFile(File file) throws IOException {
        closeDocument();
        descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
        renderer = new PdfRenderer(descriptor);
        pageCount = renderer.getPageCount();
        pageIndex = 0;
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        requestRender();
    }

    public void showPage(int index) {
        if (renderer == null || pageCount <= 0) return;

        pageIndex = Math.max(0, Math.min(index, pageCount - 1));
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        requestRender();
    }

    public void nextPage() {
        showPage(pageIndex + 1);
    }

    public void previousPage() {
        showPage(pageIndex - 1);
    }

    public void fitPage() {
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        requestRender();
    }

    private void requestRender() {
        if (renderer == null || getWidth() <= 0 || getHeight() <= 0) return;

        if (renderBusy) {
            pendingPage = pageIndex;
            return;
        }

        renderBusy = true;
        final int requestedPage = pageIndex;
        final int token = ++serial;

        executor.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap produced = null;
                PdfRenderer.Page openedPage = null;

                try {
                    synchronized (lock) {
                        if (renderer == null) return;

                        openedPage = renderer.openPage(requestedPage);
                        int viewWidth = Math.max(320, getWidth());
                        float ratio = openedPage.getHeight() / (float) openedPage.getWidth();

                        int targetWidth = Math.round(viewWidth * zoom * 1.5f);
                        targetWidth = Math.max(viewWidth, Math.min(targetWidth, 3200));
                        int targetHeight = Math.round(targetWidth * ratio);
                        targetHeight = Math.max(1, Math.min(targetHeight, 4800));

                        produced = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
                        produced.eraseColor(Color.WHITE);
                        openedPage.render(produced, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    }

                    final Bitmap readyBitmap = produced;
                    produced = null;

                    post(new Runnable() {
                        @Override
                        public void run() {
                            applyRenderedBitmap(readyBitmap, token);
                        }
                    });
                } catch (Exception ex) {
                    if (produced != null && !produced.isRecycled()) produced.recycle();

                    post(new Runnable() {
                        @Override
                        public void run() {
                            notifyRenderError();
                        }
                    });
                } finally {
                    if (openedPage != null) {
                        try {
                            openedPage.close();
                        } catch (Exception ignored) {
                        }
                    }

                    post(new Runnable() {
                        @Override
                        public void run() {
                            finishRenderQueue();
                        }
                    });
                }
            }
        });
    }

    private void applyRenderedBitmap(Bitmap readyBitmap, int token) {
        if (token != serial) {
            if (readyBitmap != null && !readyBitmap.isRecycled()) readyBitmap.recycle();
            return;
        }

        Bitmap old = bitmap;
        bitmap = readyBitmap;
        if (old != null && !old.isRecycled()) old.recycle();

        clampPan();
        invalidate();

        if (listener != null) {
            listener.onPageRendered(pageIndex, pageCount);
        }
    }

    private void notifyRenderError() {
        if (listener != null) listener.onError("Error al renderizar PDF");
    }

    private void finishRenderQueue() {
        renderBusy = false;

        if (pendingPage >= 0) {
            int p = pendingPage;
            pendingPage = -1;
            pageIndex = p;
            requestRender();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        requestRender();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (bitmap == null || bitmap.isRecycled()) {
            Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            textPaint.setColor(Color.DKGRAY);
            textPaint.setTextSize(42f);
            textPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Abre un PDF", getWidth() / 2f, getHeight() / 2f, textPaint);
            return;
        }

        RectF pageRect = getCurrentPageRect();
        canvas.drawBitmap(bitmap, null, pageRect, paint);
        drawSavedMarkers(canvas, pageRect);
        drawReadingRules(canvas, pageRect);

        if (selecting) {
            drawSelectionPreview(canvas, pageRect);
        }
    }

    private void drawSavedMarkers(Canvas canvas, RectF pageRect) {
        ArrayList<MarkerMark> list = marks.get(pageIndex);
        if (list == null) return;

        for (int i = 0; i < list.size(); i++) {
            MarkerMark h = list.get(i);
            drawMarker(canvas, pageRect, h.x1, h.y, h.x2, h.thickness, h.color);
        }
    }

    private void drawReadingRules(Canvas canvas, RectF pageRect) {
        if (!rulesEnabled) return;

        float topY = pageRect.top + ruleTop * pageRect.height();
        float bottomY = pageRect.top + ruleBottom * pageRect.height();
        float h = Math.max(4f, 4f * zoom);

        canvas.drawRect(pageRect.left, pageRect.top, pageRect.right, topY, blockedPaint);
        canvas.drawRect(pageRect.left, bottomY, pageRect.right, pageRect.bottom, blockedPaint);

        RectF topLine = new RectF(pageRect.left, topY - h / 2f, pageRect.right, topY + h / 2f);
        RectF bottomLine = new RectF(pageRect.left, bottomY - h / 2f, pageRect.right, bottomY + h / 2f);

        canvas.drawRoundRect(topLine, h, h, rulePaint);
        canvas.drawRoundRect(bottomLine, h, h, rulePaint);
    }

    private void drawSelectionPreview(Canvas canvas, RectF pageRect) {
        float x1 = Math.min(startX, endX);
        float x2 = Math.max(startX, endX);
        float y = (startY + endY) / 2f;

        x1 = clamp(x1, pageRect.left, pageRect.right);
        x2 = clamp(x2, pageRect.left, pageRect.right);
        y = clamp(y, pageRect.top, pageRect.bottom);

        if (x2 - x1 < 6f) return;

        float nx1 = clamp((x1 - pageRect.left) / pageRect.width(), 0f, 1f);
        float nx2 = clamp((x2 - pageRect.left) / pageRect.width(), 0f, 1f);
        float ny = clamp((y - pageRect.top) / pageRect.height(), 0f, 1f);
        float nt = clamp(20f / Math.max(1f, pageRect.height()), 0.008f, 0.022f);

        drawMarker(canvas, pageRect, nx1, ny, nx2, nt, markColor);
    }

    private void drawMarker(Canvas canvas, RectF pageRect, float nx1, float ny, float nx2, float nthickness, int color) {
        underlinePaint.setColor(color);

        float x1 = pageRect.left + nx1 * pageRect.width();
        float x2 = pageRect.left + nx2 * pageRect.width();
        float y = pageRect.top + ny * pageRect.height();
        float thickness = Math.max(14f, nthickness * pageRect.height());

        RectF marker = new RectF(x1, y - thickness / 2f, x2, y + thickness / 2f);
        float radius = Math.max(5f, thickness / 4f);
        canvas.drawRoundRect(marker, radius, radius, underlinePaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (markMode && event.getPointerCount() == 1) {
            handleExactMarkerTouch(event);
            return true;
        }

        if (rulesEnabled && event.getPointerCount() == 1 && handleRuleTouch(event)) {
            return true;
        }

        scaleDetector.onTouchEvent(event);
        if (!scaleDetector.isInProgress()) gestureDetector.onTouchEvent(event);

        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            clampPan();
            invalidate();
        }

        return true;
    }

    private boolean handleRuleTouch(MotionEvent event) {
        if (bitmap == null) return false;

        RectF pageRect = getCurrentPageRect();
        if (!pageRect.contains(event.getX(), event.getY())) return false;

        float topY = pageRect.top + ruleTop * pageRect.height();
        float bottomY = pageRect.top + ruleBottom * pageRect.height();
        float threshold = Math.max(24f, 18f * zoom);
        int action = event.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            if (Math.abs(event.getY() - topY) <= threshold) {
                draggingTopRule = true;
                draggingBottomRule = false;
                return true;
            }

            if (Math.abs(event.getY() - bottomY) <= threshold) {
                draggingTopRule = false;
                draggingBottomRule = true;
                return true;
            }

            return false;
        }

        if (action == MotionEvent.ACTION_MOVE && (draggingTopRule || draggingBottomRule)) {
            float ratio = clamp((event.getY() - pageRect.top) / pageRect.height(), 0f, 1f);

            if (draggingTopRule) {
                ruleTop = clamp(ratio, 0f, ruleBottom - 0.08f);
            } else {
                ruleBottom = clamp(ratio, ruleTop + 0.08f, 1f);
            }

            invalidate();
            return true;
        }

        if ((action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) && (draggingTopRule || draggingBottomRule)) {
            draggingTopRule = false;
            draggingBottomRule = false;
            notifyRulesChanged();
            invalidate();
            return true;
        }

        return draggingTopRule || draggingBottomRule;
    }

    private void notifyRulesChanged() {
        if (listener != null) {
            listener.onRulesChanged(rulesEnabled, ruleTop, ruleBottom);
        }
    }

    private void handleExactMarkerTouch(MotionEvent event) {
        int action = event.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            selecting = true;
            startX = event.getX();
            startY = event.getY();
            endX = startX;
            endY = startY;
            invalidate();
        } else if (action == MotionEvent.ACTION_MOVE) {
            endX = event.getX();
            endY = event.getY();
            invalidate();
        } else if (action == MotionEvent.ACTION_UP) {
            endX = event.getX();
            endY = event.getY();
            selecting = false;
            saveExactMarker();
            invalidate();
        } else if (action == MotionEvent.ACTION_CANCEL) {
            selecting = false;
            invalidate();
        }
    }

    private void saveExactMarker() {
        if (bitmap == null) return;

        RectF pageRect = getCurrentPageRect();

        float x1 = Math.min(startX, endX);
        float x2 = Math.max(startX, endX);
        float y = (startY + endY) / 2f;

        x1 = clamp(x1, pageRect.left, pageRect.right);
        x2 = clamp(x2, pageRect.left, pageRect.right);
        y = clamp(y, pageRect.top, pageRect.bottom);

        if (x2 - x1 < 8f) return;

        float nx1 = clamp((x1 - pageRect.left) / pageRect.width(), 0f, 1f);
        float nx2 = clamp((x2 - pageRect.left) / pageRect.width(), 0f, 1f);
        float ny = clamp((y - pageRect.top) / pageRect.height(), 0f, 1f);
        float nt = clamp(20f / Math.max(1f, pageRect.height()), 0.008f, 0.022f);

        addMarkObject(new MarkerMark(pageIndex, markColor, nx1, ny, nx2, nt), true);
    }

    private void addMarkObject(MarkerMark mark, boolean notify) {
        ArrayList<MarkerMark> list = marks.get(mark.page);

        if (list == null) {
            list = new ArrayList<MarkerMark>();
            marks.put(mark.page, list);
        }

        list.add(mark);

        if (notify) {
            notifyHighlightsChanged();
        }
    }

    private void notifyHighlightsChanged() {
        if (listener != null) {
            listener.onHighlightsChanged(serializeHighlights());
        }
    }

    private RectF getCurrentPageRect() {
        float displayWidth = getWidth() * zoom;
        float displayHeight = displayWidth * (bitmap.getHeight() / (float) bitmap.getWidth());

        if (displayWidth <= getWidth()) panX = (getWidth() - displayWidth) / 2f;
        if (displayHeight <= getHeight()) panY = (getHeight() - displayHeight) / 2f;

        return new RectF(panX, panY, panX + displayWidth, panY + displayHeight);
    }

    private void clampPan() {
        if (bitmap == null) return;

        float displayWidth = getWidth() * zoom;
        float displayHeight = displayWidth * (bitmap.getHeight() / (float) bitmap.getWidth());

        if (displayWidth <= getWidth()) {
            panX = (getWidth() - displayWidth) / 2f;
        } else {
            panX = clamp(panX, getWidth() - displayWidth, 0f);
        }

        if (displayHeight <= getHeight()) {
            panY = (getHeight() - displayHeight) / 2f;
        } else {
            panY = clamp(panY, getHeight() - displayHeight, 0f);
        }
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public void closeDocument() {
        try {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            bitmap = null;

            if (renderer != null) renderer.close();
            if (descriptor != null) descriptor.close();
        } catch (Exception ignored) {
        }

        renderer = null;
        descriptor = null;
        pageCount = 0;
        pageIndex = 0;
    }
}
