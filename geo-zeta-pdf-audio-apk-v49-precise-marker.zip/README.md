# Geo Zeta PDF a Audio V49 Precise Marker

Base:
- Desde V48 Rules.

Cambio principal:
- El marcado ya no es línea debajo.
- Ahora es marcador suave sobre el texto, parecido a la imagen de referencia.
- El usuario arrastra exactamente el tramo que quiere marcar.
- No selecciona palabra completa automáticamente.
- No hace bloques grandes.
- No cubre toda la línea.
- No hay lunas ni manijas.

Mantiene:
- Zoom.
- Audio.
- Reglas arriba/abajo.
- Borrar último.
- Limpiar página.
- Guardado local por PDF.

Pendiente:
- Exportar PNG/compartir.
