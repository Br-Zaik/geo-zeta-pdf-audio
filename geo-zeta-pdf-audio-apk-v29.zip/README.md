# Geo Zeta PDF a Audio V29

Base:
- Hecha desde V26 estable.
- No usa V27 ni V28 como base.

Optimización segura:
- Rápido / Balanceado / Nítido.
- Balanceado por defecto.
- Rápido para celulares gama baja.
- Nítido solo si el celular aguanta.
- Menos carga de render.
- Zoom máximo controlado.
- Audio por bloques según rendimiento.
- Mejor mensaje si un PDF no abre.
- Mantiene funciones de V26: audio continuo, pausa/reanudar, notificación, subrayado, modo estudio, reglas y colores.

Recomendación:
- En gama baja prueba primero Balanceado.
- Si hay lag, usa Rápido.
- Si se ve borroso y el celular aguanta, usa Nítido.
