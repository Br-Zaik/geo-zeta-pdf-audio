package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfPageView extends View {
    public static final int MARK_STYLE_UNDERLINE_FINE = 0;
    public static final int MARK_STYLE_UNDERLINE_DOUBLE = 1;
    public static final int MARK_STYLE_UNDERLINE_WAVY = 2;
    public static final int MARK_STYLE_UNDERLINE_DOTTED = 3;
    public static final int MARK_STYLE_HIGHLIGHT_SOFT = 4;
    public static final int MARK_STYLE_HIGHLIGHT_INTENSE = 5;
    public static final int MARK_STYLE_TEXT_BOX = 6;
    public interface PageChangeListener {
        void onPageRendered(int pageIndex, int pageCount);
        void onError(String message);
        void onHighlightsChanged(String serialized);
        void onRulesChanged(boolean enabled, float top, float bottom);
    }


    private static class TextMarker {
        int page;
        int color;
        float left;
        float top;
        float right;
        float bottom;
        int style;
        int thickness;

        TextMarker(int page, int color, float left, float top, float right, float bottom, int style, int thickness) {
            this.page = page;
            this.color = color;
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
            this.style = safeStyle(style);
            this.thickness = safeThickness(thickness);
        }
    }

    private final Paint paint;
    private final Paint markerPaint;
    private final Paint previewPaint;
    private final Paint rulePaint;
    private final Paint blockedPaint;
    private final ExecutorService executor;

    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private Bitmap bitmap;
    private int pageIndex;
    private int pageCount;
    private boolean renderBusy;
    private int pendingPage;
    private int serial;

    private float zoom;
    private float panX;
    private float panY;

    private PageChangeListener listener;
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestureDetector;
    private final Object lock = new Object();

    private boolean markMode;
    private int markColor;
    private int markStyle;
    private int markThickness;
    private boolean rulesEnabled;
    private float ruleTop;
    private float ruleBottom;
    private boolean draggingTopRule;
    private boolean draggingBottomRule;

    private boolean selecting;
    private boolean markGesturePanning;
    private boolean multiTouchPanning;
    private float startX;
    private float startY;
    private float endX;
    private float endY;
    private float lastPanGestureX;
    private float lastPanGestureY;
    private CharBox selectionStartChar;
    private CharBox selectionEndChar;

    private boolean readingMarkerEnabled;
    private int readingMarkerColor;
    private int readingMarkerPage;
    private String readingMarkerChunk;
    private int readingMarkerChunkIndex;
    private int readingMarkerRangeStart;
    private int readingMarkerRangeEnd;
    private int readingChunkSearchOffset;
    private int readingChunkBaseOffset;
    private final ArrayList<RectF> readingMarkerRects;
    private String readingNormalizedPage;
    private final ArrayList<CharBox> readingNormalizedMapping;
    private String readingNormalizedChunk;
    private int[] readingChunkPrefix;

    private ArrayList<CharBox> charBoxes;
    private final Map<Integer, ArrayList<TextMarker>> markers;
    private final ArrayList<TextMarker> redoMarkers;

    public PdfPageView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(238, 238, 238));

        paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);

        markerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        markerPaint.setStyle(Paint.Style.FILL);

        previewPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        previewPaint.setStyle(Paint.Style.FILL);
        previewPaint.setColor(0xE6FFD400);

        rulePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        rulePaint.setStyle(Paint.Style.FILL);
        rulePaint.setColor(0xFF2F6BFF);

        blockedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        blockedPaint.setStyle(Paint.Style.FILL);
        blockedPaint.setColor(0x33000000);

        executor = Executors.newSingleThreadExecutor();
        pendingPage = -1;
        zoom = 1.0f;
        markMode = false;
        markColor = 0xE6FFD400;
        markStyle = MARK_STYLE_UNDERLINE_FINE;
        markThickness = 1;
        rulesEnabled = true;
        ruleTop = 0.08f;
        ruleBottom = 0.92f;
        charBoxes = new ArrayList<CharBox>();
        markers = new HashMap<Integer, ArrayList<TextMarker>>();
        redoMarkers = new ArrayList<TextMarker>();
        readingMarkerRects = new ArrayList<RectF>();
        readingMarkerEnabled = true;
        readingMarkerColor = 0x663B82F6;
        readingMarkerPage = -1;
        readingMarkerChunk = "";
        readingMarkerChunkIndex = -1;

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float oldZoom = zoom;
                zoom = clamp(zoom * detector.getScaleFactor(), 1.0f, 4.0f);
                float focusX = detector.getFocusX();
                float focusY = detector.getFocusY();
                panX = focusX - (focusX - panX) * (zoom / oldZoom);
                panY = focusY - (focusY - panY) * (zoom / oldZoom);
                clampPan();
                invalidate();
                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {
                requestRender();
            }
        });

        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (markMode) return true;

                if (zoom > 1.2f) {
                    zoom = 1.0f;
                    panX = 0f;
                    panY = 0f;
                } else {
                    zoom = 2.0f;
                    panX = e.getX() - e.getX() * zoom;
                    panY = e.getY() - e.getY() * zoom;
                    clampPan();
                }

                requestRender();
                invalidate();
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                if (markMode) return true;

                panX -= distanceX;
                panY -= distanceY;
                clampPan();
                invalidate();
                return true;
            }
        });
    }

    public void setPageChangeListener(PageChangeListener listener) {
        this.listener = listener;
    }

    public int getPageCount() {
        return pageCount;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setMarkMode(boolean enabled) {
        markMode = enabled;
        selecting = false;
        invalidate();
    }

    public boolean isMarkMode() {
        return markMode;
    }

    public void setMarkColor(int color) {
        markColor = color;
        previewPaint.setColor(color);
        invalidate();
    }

    public void setMarkStyle(int style) {
        markStyle = safeStyle(style);
        selecting = false;
        invalidate();
    }

    public void setMarkThickness(int level) {
        markThickness = safeThickness(level);
        invalidate();
    }

    public void setSelectionChars(ArrayList<CharBox> chars) {
        if (chars == null) charBoxes = new ArrayList<CharBox>();
        else charBoxes = chars;
        if (readingMarkerEnabled) rebuildReadingSearchCache();
        else clearReadingSearchCache();
        rebuildReadingMarkerRects();
        invalidate();
    }

    public void setRuleColor(int color) {
        rulePaint.setColor(0xFF000000 | (color & 0x00FFFFFF));
        invalidate();
    }

    public void setReadingMarkerEnabled(boolean enabled) {
        readingMarkerEnabled = enabled;
        if (!enabled) {
            readingMarkerRects.clear();
            clearReadingSearchCache();
        } else {
            rebuildReadingSearchCache();
            rebuildReadingMarkerRects();
        }
        invalidate();
    }

    public void setReadingMarkerColor(int color) {
        readingMarkerColor = (0x66000000 | (color & 0x00FFFFFF));
        invalidate();
    }

    public void updateReadingMarker(int page, String chunk, int chunkIndex, int rangeStart, int rangeEnd) {
        if (page != readingMarkerPage || chunkIndex != readingMarkerChunkIndex) {
            boolean pageChanged = page != readingMarkerPage;
            readingMarkerPage = page;
            readingMarkerChunkIndex = chunkIndex;
            readingMarkerChunk = chunk == null ? "" : chunk;
            rebuildReadingChunkCache();
            readingMarkerRangeStart = Math.max(0, rangeStart);
            readingMarkerRangeEnd = Math.max(readingMarkerRangeStart + 1, rangeEnd);
            readingChunkBaseOffset = -1;
            if (pageChanged) readingChunkSearchOffset = 0;
        } else {
            if (chunk != null && !chunk.equals(readingMarkerChunk)) {
                readingMarkerChunk = chunk;
                rebuildReadingChunkCache();
            } else if (chunk == null) {
                readingMarkerChunk = "";
                rebuildReadingChunkCache();
            }
            readingMarkerRangeStart = Math.max(0, rangeStart);
            readingMarkerRangeEnd = Math.max(readingMarkerRangeStart + 1, rangeEnd);
        }
        rebuildReadingMarkerRects();
        invalidate();
    }

    public void clearReadingMarker() {
        readingMarkerPage = -1;
        readingMarkerChunkIndex = -1;
        readingMarkerChunk = "";
        readingMarkerRangeStart = 0;
        readingMarkerRangeEnd = 0;
        readingChunkBaseOffset = -1;
        readingChunkSearchOffset = 0;
        readingMarkerRects.clear();
        readingNormalizedChunk = "";
        readingChunkPrefix = new int[0];
        invalidate();
    }

    public void setRules(boolean enabled, float top, float bottom) {
        rulesEnabled = enabled;
        ruleTop = clamp(top, 0f, 0.95f);
        ruleBottom = clamp(bottom, 0.05f, 1f);
        if (ruleBottom <= ruleTop + 0.05f) {
            ruleTop = 0.08f;
            ruleBottom = 0.92f;
        }
        invalidate();
    }

    public boolean areRulesEnabled() {
        return rulesEnabled;
    }

    public float getRuleTop() {
        return ruleTop;
    }

    public float getRuleBottom() {
        return ruleBottom;
    }

    public void undoLastHighlight() {
        ArrayList<TextMarker> list = markers.get(pageIndex);
        if (list != null && list.size() > 0) {
            TextMarker removed = list.remove(list.size() - 1);
            redoMarkers.add(removed);
            notifyHighlightsChanged();
            invalidate();
        }
    }

    public void redoLastHighlight() {
        if (redoMarkers.size() == 0) return;
        TextMarker marker = redoMarkers.remove(redoMarkers.size() - 1);
        addMarkerObject(marker, true, false);
        invalidate();
    }

    public void clearPageHighlights() {
        ArrayList<TextMarker> list = markers.get(pageIndex);
        if (list != null) {
            redoMarkers.clear();
        }
        markers.remove(pageIndex);
        notifyHighlightsChanged();
        invalidate();
    }

    public void loadHighlights(String data) {
        markers.clear();
        redoMarkers.clear();

        if (data == null || data.trim().length() == 0) {
            invalidate();
            return;
        }

        try {
            String[] items = data.split(";");
            for (String item : items) {
                String trimmed = item.trim();
                if (trimmed.length() == 0) continue;

                String[] p = trimmed.split(",");
                if (p.length < 6 || p.length > 8) continue;

                int page = Integer.parseInt(p[0]);
                int color = (int) Long.parseLong(p[1], 16);
                float left = Float.parseFloat(p[2]);
                float top = Float.parseFloat(p[3]);
                float right = Float.parseFloat(p[4]);
                float bottom = Float.parseFloat(p[5]);

                int style;
                int thickness = 1;
                if (p.length == 8) {
                    style = Integer.parseInt(p[6]);
                    thickness = Integer.parseInt(p[7]);
                } else if (p.length == 7) {
                    // Compatibilidad con V71: 0=subrayado, 1=resaltado.
                    int oldStyle = Integer.parseInt(p[6]);
                    style = oldStyle == 1 ? MARK_STYLE_HIGHLIGHT_SOFT : MARK_STYLE_UNDERLINE_FINE;
                } else {
                    style = MARK_STYLE_UNDERLINE_FINE;
                }

                addMarkerObject(new TextMarker(page, color, left, top, right, bottom, style, thickness), false, false);
            }
        } catch (Exception ignored) {
        }

        invalidate();
    }

    public String serializeHighlights() {
        StringBuilder builder = new StringBuilder();

        for (Map.Entry<Integer, ArrayList<TextMarker>> entry : markers.entrySet()) {
            ArrayList<TextMarker> list = entry.getValue();
            if (list == null) continue;

            for (TextMarker h : list) {
                builder.append(h.page).append(",");
                builder.append(Integer.toHexString(h.color)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.left)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.top)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.right)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.bottom)).append(",");
                builder.append(h.style).append(",");
                builder.append(h.thickness).append(";");
            }
        }

        return builder.toString();
    }

    public void openFile(File file) throws IOException {
        closeDocument();
        descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
        renderer = new PdfRenderer(descriptor);
        pageCount = renderer.getPageCount();
        pageIndex = 0;
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        charBoxes = new ArrayList<CharBox>();
        readingMarkerRects.clear();
        clearReadingSearchCache();
        requestRender();
    }

    public void showPage(int index) {
        if (renderer == null || pageCount <= 0) return;

        pageIndex = Math.max(0, Math.min(index, pageCount - 1));
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        charBoxes = new ArrayList<CharBox>();
        readingMarkerRects.clear();
        clearReadingSearchCache();
        requestRender();
    }

    public void nextPage() {
        showPage(pageIndex + 1);
    }

    public void previousPage() {
        showPage(pageIndex - 1);
    }

    public void fitPage() {
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        requestRender();
    }

    private void requestRender() {
        if (renderer == null || getWidth() <= 0 || getHeight() <= 0) return;

        if (renderBusy) {
            pendingPage = pageIndex;
            return;
        }

        renderBusy = true;
        final int requestedPage = pageIndex;
        final int token = ++serial;

        executor.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap produced = null;
                PdfRenderer.Page openedPage = null;

                try {
                    synchronized (lock) {
                        if (renderer == null) return;

                        openedPage = renderer.openPage(requestedPage);
                        int viewWidth = Math.max(320, getWidth());
                        float ratio = openedPage.getHeight() / (float) openedPage.getWidth();

                        int targetWidth = Math.round(viewWidth * zoom * 1.5f);
                        targetWidth = Math.max(viewWidth, Math.min(targetWidth, 3200));
                        int targetHeight = Math.round(targetWidth * ratio);
                        targetHeight = Math.max(1, Math.min(targetHeight, 4800));

                        produced = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
                        produced.eraseColor(Color.WHITE);
                        openedPage.render(produced, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    }

                    final Bitmap readyBitmap = produced;
                    produced = null;

                    post(new Runnable() {
                        @Override
                        public void run() {
                            applyRenderedBitmap(readyBitmap, token);
                        }
                    });
                } catch (Exception ex) {
                    if (produced != null && !produced.isRecycled()) produced.recycle();

                    post(new Runnable() {
                        @Override
                        public void run() {
                            notifyRenderError();
                        }
                    });
                } finally {
                    if (openedPage != null) {
                        try {
                            openedPage.close();
                        } catch (Exception ignored) {
                        }
                    }

                    post(new Runnable() {
                        @Override
                        public void run() {
                            finishRenderQueue();
                        }
                    });
                }
            }
        });
    }

    private void applyRenderedBitmap(Bitmap readyBitmap, int token) {
        if (token != serial) {
            if (readyBitmap != null && !readyBitmap.isRecycled()) readyBitmap.recycle();
            return;
        }

        Bitmap old = bitmap;
        bitmap = readyBitmap;
        if (old != null && !old.isRecycled()) old.recycle();

        clampPan();
        invalidate();

        if (listener != null) {
            listener.onPageRendered(pageIndex, pageCount);
        }
    }

    private void notifyRenderError() {
        if (listener != null) listener.onError("Error al renderizar PDF");
    }

    private void finishRenderQueue() {
        renderBusy = false;

        if (pendingPage >= 0) {
            int p = pendingPage;
            pendingPage = -1;
            pageIndex = p;
            requestRender();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        requestRender();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (bitmap == null || bitmap.isRecycled()) {
            Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            textPaint.setColor(Color.DKGRAY);
            textPaint.setTextSize(42f);
            textPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Abre un PDF", getWidth() / 2f, getHeight() / 2f, textPaint);
            return;
        }

        RectF pageRect = getCurrentPageRect();
        canvas.drawBitmap(bitmap, null, pageRect, paint);
        drawSavedMarkers(canvas, pageRect);
        drawReadingMarker(canvas, pageRect);

        if (selecting) {
            drawSelectionPreview(canvas, pageRect);
        }

        drawReadingRules(canvas, pageRect);
    }


    private void drawReadingMarker(Canvas canvas, RectF pageRect) {
        if (!readingMarkerEnabled || readingMarkerPage != pageIndex || readingMarkerRects.isEmpty()) return;
        markerPaint.setStyle(Paint.Style.FILL);
        markerPaint.setColor(readingMarkerColor);
        for (RectF normalized : readingMarkerRects) {
            RectF actual = new RectF(
                    pageRect.left + normalized.left * pageRect.width(),
                    pageRect.top + normalized.top * pageRect.height(),
                    pageRect.left + normalized.right * pageRect.width(),
                    pageRect.top + normalized.bottom * pageRect.height());
            float radius = Math.max(3f, actual.height() * 0.18f);
            canvas.drawRoundRect(actual, radius, radius, markerPaint);
        }
    }

    private void rebuildReadingSearchCache() {
        readingNormalizedMapping.clear();
        StringBuilder page = new StringBuilder();
        if (charBoxes != null) {
            for (CharBox box : charBoxes) {
                if (box == null || box.page != pageIndex || box.text == null) continue;
                String normalized = normalizeLight(box.text);
                for (int i = 0; i < normalized.length(); i++) {
                    page.append(normalized.charAt(i));
                    readingNormalizedMapping.add(box);
                }
            }
        }
        readingNormalizedPage = page.toString();
        readingChunkBaseOffset = -1;
    }

    private void clearReadingSearchCache() {
        readingNormalizedPage = "";
        readingNormalizedMapping.clear();
        readingChunkBaseOffset = -1;
    }

    private void rebuildReadingChunkCache() {
        String source = readingMarkerChunk == null ? "" : readingMarkerChunk;
        StringBuilder normalized = new StringBuilder();
        readingChunkPrefix = new int[source.length() + 1];
        int count = 0;
        for (int i = 0; i < source.length(); i++) {
            String part = normalizeLight(String.valueOf(source.charAt(i)));
            normalized.append(part);
            count += part.length();
            readingChunkPrefix[i + 1] = count;
        }
        readingNormalizedChunk = normalized.toString();
    }

    private void rebuildReadingMarkerRects() {
        readingMarkerRects.clear();
        if (!readingMarkerEnabled || readingMarkerPage != pageIndex || charBoxes == null || charBoxes.isEmpty()) return;
        if (readingMarkerChunk == null || readingMarkerChunk.trim().length() == 0) return;
        if (readingNormalizedPage.length() == 0 || readingNormalizedMapping.isEmpty()) rebuildReadingSearchCache();
        if (readingNormalizedChunk.length() == 0) rebuildReadingChunkCache();
        if (readingNormalizedPage.length() == 0 || readingNormalizedMapping.isEmpty() || readingNormalizedChunk.length() == 0) return;

        if (readingChunkBaseOffset < 0) {
            String key = readingNormalizedChunk.substring(0, Math.min(28, readingNormalizedChunk.length()));
            int searchFrom = Math.max(0, Math.min(readingChunkSearchOffset, readingNormalizedPage.length()));
            int found = readingNormalizedPage.indexOf(key, searchFrom);
            if (found < 0) found = readingNormalizedPage.indexOf(key);
            readingChunkBaseOffset = found < 0 ? 0 : found;
            readingChunkSearchOffset = Math.max(readingChunkSearchOffset,
                    readingChunkBaseOffset + Math.max(1, readingNormalizedChunk.length() / 2));
        }

        int maxPrefix = readingChunkPrefix.length - 1;
        int startOriginal = Math.max(0, Math.min(readingMarkerRangeStart, maxPrefix));
        int endOriginal = Math.max(startOriginal, Math.min(readingMarkerRangeEnd, maxPrefix));
        int localStart = readingChunkPrefix[startOriginal];
        int localEnd = readingChunkPrefix[endOriginal];

        int absolute = Math.max(0, Math.min(readingNormalizedMapping.size() - 1, readingChunkBaseOffset + localStart));
        int absoluteEnd = Math.max(absolute, Math.min(readingNormalizedMapping.size() - 1,
                readingChunkBaseOffset + Math.max(localStart + 1, localEnd) - 1));
        CharBox first = readingNormalizedMapping.get(absolute);
        CharBox last = readingNormalizedMapping.get(absoluteEnd);
        int targetLine = first.line;
        if (last.line != targetLine && localEnd - localStart > 1) targetLine = last.line;

        float left = 1f;
        float top = 1f;
        float right = 0f;
        float bottom = 0f;
        boolean foundLine = false;
        for (CharBox box : charBoxes) {
            if (box != null && box.page == pageIndex && box.line == targetLine) {
                left = Math.min(left, box.left);
                top = Math.min(top, box.top);
                right = Math.max(right, box.right);
                bottom = Math.max(bottom, box.bottom);
                foundLine = true;
            }
        }
        if (foundLine) {
            float height = Math.max(0.006f, bottom - top);
            float padX = Math.max(0.003f, height * 0.14f);
            float padY = Math.max(0.0015f, height * 0.06f);
            readingMarkerRects.add(new RectF(clamp(left - padX, 0f, 1f), clamp(top - padY, 0f, 1f),
                    clamp(right + padX, 0f, 1f), clamp(bottom + padY, 0f, 1f)));
        }
    }

    private String normalizeLight(String value) {
        if (value == null || value.length() == 0) return "";
        StringBuilder out = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char c = Character.toLowerCase(value.charAt(i));
            switch (c) {
                case 'á': case 'à': case 'ä': case 'â': c = 'a'; break;
                case 'é': case 'è': case 'ë': case 'ê': c = 'e'; break;
                case 'í': case 'ì': case 'ï': case 'î': c = 'i'; break;
                case 'ó': case 'ò': case 'ö': case 'ô': c = 'o'; break;
                case 'ú': case 'ù': case 'ü': case 'û': c = 'u'; break;
                default: break;
            }
            if (Character.isLetterOrDigit(c)) out.append(c);
        }
        return out.toString();
    }

    private void drawSavedMarkers(Canvas canvas, RectF pageRect) {
        drawMarkersForPage(canvas, pageRect, pageIndex);
    }

    private void drawMarkersForPage(Canvas canvas, RectF pageRect, int targetPage) {
        ArrayList<TextMarker> list = markers.get(targetPage);
        if (list == null) return;

        for (TextMarker h : list) {
            drawMarkerRect(canvas, pageRect, h.left, h.top, h.right, h.bottom, h.color, h.style, h.thickness);
        }
    }

    private void drawSelectionPreview(Canvas canvas, RectF pageRect) {
        ArrayList<TextMarker> preview = buildMarkersFromSelection();
        for (TextMarker h : preview) {
            drawMarkerRect(canvas, pageRect, h.left, h.top, h.right, h.bottom, markColor, markStyle, markThickness);
        }
    }

    private void drawMarkerRect(Canvas canvas, RectF pageRect, float left, float top, float right, float bottom, int color, int style, int thicknessLevel) {
        markerPaint.setColor(color);
        markerPaint.setStyle(Paint.Style.FILL);

        float x1 = pageRect.left + left * pageRect.width();
        float x2 = pageRect.left + right * pageRect.width();
        float yTop = pageRect.top + top * pageRect.height();
        float yBottom = pageRect.top + bottom * pageRect.height();
        float textHeight = Math.max(1f, yBottom - yTop);
        float thicknessMultiplier = thicknessLevel == 0 ? 0.72f : (thicknessLevel == 2 ? 1.65f : 1.0f);
        float lineThickness = Math.max(2.0f, pageRect.height() * 0.0022f) * thicknessMultiplier;

        if (style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE) {
            int rgb = color & 0x00FFFFFF;
            int alpha = style == MARK_STYLE_HIGHLIGHT_INTENSE ? 0x82 : 0x4A;
            markerPaint.setColor((alpha << 24) | rgb);
            float paddingY = Math.max(0.5f, textHeight * 0.03f);
            RectF highlight = new RectF(
                    Math.max(pageRect.left, x1),
                    Math.max(pageRect.top, yTop - paddingY),
                    Math.min(pageRect.right, x2),
                    Math.min(pageRect.bottom, yBottom + paddingY)
            );
            float radius = Math.max(1.5f, textHeight * 0.10f);
            canvas.drawRoundRect(highlight, radius, radius, markerPaint);
            markerPaint.setColor(color);
            return;
        }


        float baseY = yBottom + lineThickness * 1.1f;

        if (style == MARK_STYLE_UNDERLINE_DOUBLE) {
            RectF first = new RectF(x1, baseY, x2, baseY + lineThickness);
            RectF second = new RectF(x1, baseY + lineThickness * 2.0f, x2, baseY + lineThickness * 3.0f);
            canvas.drawRoundRect(first, lineThickness, lineThickness, markerPaint);
            canvas.drawRoundRect(second, lineThickness, lineThickness, markerPaint);
            return;
        }

        if (style == MARK_STYLE_UNDERLINE_WAVY) {
            markerPaint.setStyle(Paint.Style.STROKE);
            markerPaint.setStrokeWidth(lineThickness);
            markerPaint.setStrokeCap(Paint.Cap.ROUND);
            Path path = new Path();
            float amplitude = Math.max(2f, lineThickness * 1.8f);
            float wavelength = Math.max(10f, textHeight * 0.55f);
            path.moveTo(x1, baseY);
            float x = x1;
            boolean up = true;
            while (x < x2) {
                float next = Math.min(x + wavelength / 2f, x2);
                float mid = (x + next) / 2f;
                path.quadTo(mid, baseY + (up ? -amplitude : amplitude), next, baseY);
                up = !up;
                x = next;
            }
            canvas.drawPath(path, markerPaint);
            markerPaint.setStyle(Paint.Style.FILL);
            return;
        }

        if (style == MARK_STYLE_UNDERLINE_DOTTED) {
            float radius = Math.max(1.6f, lineThickness * 0.75f);
            float gap = radius * 3.1f;
            for (float x = x1 + radius; x <= x2; x += gap) {
                canvas.drawCircle(x, baseY + radius, radius, markerPaint);
            }
            return;
        }

        RectF line = new RectF(x1, baseY, x2, baseY + lineThickness);
        canvas.drawRoundRect(line, lineThickness, lineThickness, markerPaint);
    }

    private void drawReadingRules(Canvas canvas, RectF pageRect) {
        if (!rulesEnabled) return;

        float topY = pageRect.top + ruleTop * pageRect.height();
        float bottomY = pageRect.top + ruleBottom * pageRect.height();
        float h = Math.max(4f, 4f * zoom);

        canvas.drawRect(pageRect.left, pageRect.top, pageRect.right, topY, blockedPaint);
        canvas.drawRect(pageRect.left, bottomY, pageRect.right, pageRect.bottom, blockedPaint);

        RectF topLine = new RectF(pageRect.left, topY - h / 2f, pageRect.right, topY + h / 2f);
        RectF bottomLine = new RectF(pageRect.left, bottomY - h / 2f, pageRect.right, bottomY + h / 2f);

        canvas.drawRoundRect(topLine, h, h, rulePaint);
        canvas.drawRoundRect(bottomLine, h, h, rulePaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();

        if (markMode && (event.getPointerCount() >= 2 || multiTouchPanning)) {
            if (action == MotionEvent.ACTION_POINTER_DOWN || action == MotionEvent.ACTION_DOWN) {
                multiTouchPanning = true;
                selecting = false;
                markGesturePanning = false;
                selectionStartChar = null;
                selectionEndChar = null;
                lastPanGestureX = averagePointerX(event);
                lastPanGestureY = averagePointerY(event);
            } else if (action == MotionEvent.ACTION_MOVE && event.getPointerCount() >= 2) {
                float focusX = averagePointerX(event);
                float focusY = averagePointerY(event);
                panX += focusX - lastPanGestureX;
                panY += focusY - lastPanGestureY;
                lastPanGestureX = focusX;
                lastPanGestureY = focusY;
                clampPan();
            } else if (action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                if (event.getPointerCount() <= 2) multiTouchPanning = false;
            }
            scaleDetector.onTouchEvent(event);
            invalidate();
            return true;
        }

        if (markMode && event.getPointerCount() == 1) {
            handleTextSelectionTouch(event);
            return true;
        }

        if (rulesEnabled && event.getPointerCount() == 1 && handleRuleTouch(event)) {
            return true;
        }

        scaleDetector.onTouchEvent(event);
        if (!scaleDetector.isInProgress()) gestureDetector.onTouchEvent(event);

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            clampPan();
            invalidate();
        }

        return true;
    }

    private float averagePointerX(MotionEvent event) {
        float total = 0f;
        int count = Math.max(1, event.getPointerCount());
        for (int i = 0; i < count; i++) total += event.getX(i);
        return total / count;
    }

    private float averagePointerY(MotionEvent event) {
        float total = 0f;
        int count = Math.max(1, event.getPointerCount());
        for (int i = 0; i < count; i++) total += event.getY(i);
        return total / count;
    }

    private void handleTextSelectionTouch(MotionEvent event) {
        int action = event.getActionMasked();
        RectF pageRect = getCurrentPageRect();

        if (action == MotionEvent.ACTION_DOWN) {
            startX = event.getX();
            startY = event.getY();
            endX = startX;
            endY = startY;
            lastPanGestureX = startX;
            lastPanGestureY = startY;

            float nx = clamp((startX - pageRect.left) / pageRect.width(), 0f, 1f);
            float ny = clamp((startY - pageRect.top) / pageRect.height(), 0f, 1f);
            selectionStartChar = findCharAt(nx, ny, true);
            selectionEndChar = selectionStartChar;
            selecting = selectionStartChar != null;
            markGesturePanning = !selecting;
            invalidate();
            return;
        }

        if (action == MotionEvent.ACTION_MOVE) {
            endX = event.getX();
            endY = event.getY();
            if (markGesturePanning) {
                panX += endX - lastPanGestureX;
                panY += endY - lastPanGestureY;
                lastPanGestureX = endX;
                lastPanGestureY = endY;
                clampPan();
            } else if (selecting) {
                float nx = clamp((endX - pageRect.left) / pageRect.width(), 0f, 1f);
                float ny = clamp((endY - pageRect.top) / pageRect.height(), 0f, 1f);
                CharBox candidate = findCharAt(nx, ny, false);
                if (candidate != null) selectionEndChar = candidate;
            }
            invalidate();
            return;
        }

        if (action == MotionEvent.ACTION_UP) {
            endX = event.getX();
            endY = event.getY();
            if (selecting && selectionStartChar != null && selectionEndChar != null) {
                ArrayList<TextMarker> newMarkers = buildMarkersFromSelection();
                if (newMarkers.size() > 0) {
                    redoMarkers.clear();
                    for (TextMarker marker : newMarkers) addMarkerObject(marker, false, false);
                    notifyHighlightsChanged();
                }
            }
            selecting = false;
            markGesturePanning = false;
            selectionStartChar = null;
            selectionEndChar = null;
            clampPan();
            invalidate();
        } else if (action == MotionEvent.ACTION_CANCEL) {
            selecting = false;
            markGesturePanning = false;
            selectionStartChar = null;
            selectionEndChar = null;
            invalidate();
        }
    }

    private ArrayList<TextMarker> buildMarkersFromSelection() {
        ArrayList<TextMarker> result = new ArrayList<TextMarker>();
        if (bitmap == null || charBoxes == null || charBoxes.size() == 0) return result;

        CharBox startChar = selectionStartChar;
        CharBox endChar = selectionEndChar;
        if (startChar == null || endChar == null) return result;

        int a = Math.min(startChar.index, endChar.index);
        int b = Math.max(startChar.index, endChar.index);

        ArrayList<CharBox> selected = new ArrayList<CharBox>();
        for (CharBox c : charBoxes) {
            if (c.page == pageIndex && c.index >= a && c.index <= b) {
                selected.add(c);
            }
        }

        if (selected.size() == 0) return result;

        int currentLine = -999;
        float left = 1f;
        float top = 1f;
        float right = 0f;
        float bottom = 0f;
        boolean hasSegment = false;

        for (int i = 0; i < selected.size(); i++) {
            CharBox c = selected.get(i);
            boolean visible = c.text != null && c.text.trim().length() > 0;

            if (!visible) {
                if (hasSegment) {
                    addSegment(result, left, top, right, bottom);
                    hasSegment = false;
                }
                continue;
            }

            float charHeight = Math.max(0.0001f, c.bottom - c.top);
            boolean sameLine = hasSegment && c.line == currentLine;
            boolean gapIsSmall = sameLine && (c.left - right) <= Math.max(0.005f, charHeight * 0.80f);

            if (!hasSegment) {
                currentLine = c.line;
                left = c.left;
                top = c.top;
                right = c.right;
                bottom = c.bottom;
                hasSegment = true;
            } else if (sameLine && gapIsSmall) {
                left = Math.min(left, c.left);
                top = Math.min(top, c.top);
                right = Math.max(right, c.right);
                bottom = Math.max(bottom, c.bottom);
            } else {
                addSegment(result, left, top, right, bottom);
                currentLine = c.line;
                left = c.left;
                top = c.top;
                right = c.right;
                bottom = c.bottom;
                hasSegment = true;
            }
        }

        if (hasSegment) addSegment(result, left, top, right, bottom);
        return result;
    }

    private void addSegment(ArrayList<TextMarker> result, float left, float top, float right, float bottom) {
        if (right <= left || bottom <= top) return;

        float height = bottom - top;
        float adjustedTop = clamp(top + height * 0.05f, 0f, 1f);
        float adjustedBottom = clamp(bottom - height * 0.02f, 0f, 1f);

        result.add(new TextMarker(pageIndex, markColor, left, adjustedTop, right, adjustedBottom, markStyle, markThickness));
    }

    private CharBox findNearestChar(float x, float y) {
        return findCharAt(x, y, false);
    }

    private CharBox findCharAt(float x, float y, boolean strict) {
        CharBox best = null;
        float bestScore = Float.MAX_VALUE;

        for (CharBox c : charBoxes) {
            if (c.page != pageIndex || c.text == null || c.text.trim().length() == 0) continue;

            float width = Math.max(0.002f, c.right - c.left);
            float height = Math.max(0.004f, c.bottom - c.top);
            float padX = strict ? Math.max(0.0025f, width * 0.28f) : Math.max(0.005f, width * 0.75f);
            float padY = strict ? Math.max(0.004f, height * 0.32f) : Math.max(0.008f, height * 0.75f);
            boolean inside = x >= c.left - padX && x <= c.right + padX
                    && y >= c.top - padY && y <= c.bottom + padY;
            if (strict && !inside) continue;

            float dx = x - c.centerX();
            float dy = y - c.centerY();
            float score = dx * dx + dy * dy;
            if (inside) score *= 0.05f;
            if (score < bestScore) {
                bestScore = score;
                best = c;
            }
        }

        if (best == null) return null;
        float maxDistance = strict ? 0.026f : 0.045f;
        return bestScore <= maxDistance * maxDistance ? best : null;
    }

    private boolean handleRuleTouch(MotionEvent event) {
        if (bitmap == null) return false;

        RectF pageRect = getCurrentPageRect();
        if (!pageRect.contains(event.getX(), event.getY())) return false;

        float topY = pageRect.top + ruleTop * pageRect.height();
        float bottomY = pageRect.top + ruleBottom * pageRect.height();
        float threshold = Math.max(24f, 18f * zoom);
        int action = event.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            if (Math.abs(event.getY() - topY) <= threshold) {
                draggingTopRule = true;
                draggingBottomRule = false;
                return true;
            }

            if (Math.abs(event.getY() - bottomY) <= threshold) {
                draggingTopRule = false;
                draggingBottomRule = true;
                return true;
            }

            return false;
        }

        if (action == MotionEvent.ACTION_MOVE && (draggingTopRule || draggingBottomRule)) {
            float ratio = clamp((event.getY() - pageRect.top) / pageRect.height(), 0f, 1f);

            if (draggingTopRule) {
                ruleTop = clamp(ratio, 0f, ruleBottom - 0.08f);
            } else {
                ruleBottom = clamp(ratio, ruleTop + 0.08f, 1f);
            }

            invalidate();
            return true;
        }

        if ((action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) && (draggingTopRule || draggingBottomRule)) {
            draggingTopRule = false;
            draggingBottomRule = false;
            notifyRulesChanged();
            invalidate();
            return true;
        }

        return draggingTopRule || draggingBottomRule;
    }

    private void notifyRulesChanged() {
        if (listener != null) {
            listener.onRulesChanged(rulesEnabled, ruleTop, ruleBottom);
        }
    }

    private void addMarkerObject(TextMarker marker, boolean notify, boolean clearRedo) {
        ArrayList<TextMarker> list = markers.get(marker.page);

        if (list == null) {
            list = new ArrayList<TextMarker>();
            markers.put(marker.page, list);
        }

        removeOverlappingMarkers(list, marker);
        list.add(marker);

        if (clearRedo) {
            redoMarkers.clear();
        }

        if (notify) {
            notifyHighlightsChanged();
        }
    }

    private void removeOverlappingMarkers(ArrayList<TextMarker> list, TextMarker incoming) {
        if (list == null || incoming == null) return;

        for (int i = list.size() - 1; i >= 0; i--) {
            TextMarker existing = list.get(i);
            if (existing == null) continue;
            if (sameMarkerFamily(existing.style, incoming.style) && overlapEnough(existing, incoming)) {
                list.remove(i);
            }
        }
    }

    private boolean sameMarkerFamily(int a, int b) {
        boolean underlineA = a >= MARK_STYLE_UNDERLINE_FINE && a <= MARK_STYLE_UNDERLINE_DOTTED;
        boolean underlineB = b >= MARK_STYLE_UNDERLINE_FINE && b <= MARK_STYLE_UNDERLINE_DOTTED;
        boolean highlightA = a == MARK_STYLE_HIGHLIGHT_SOFT || a == MARK_STYLE_HIGHLIGHT_INTENSE;
        boolean highlightB = b == MARK_STYLE_HIGHLIGHT_SOFT || b == MARK_STYLE_HIGHLIGHT_INTENSE;
        if (underlineA && underlineB) return true;
        if (highlightA && highlightB) return true;
        return a == b;
    }

    private boolean overlapEnough(TextMarker a, TextMarker b) {
        float left = Math.max(a.left, b.left);
        float top = Math.max(a.top, b.top);
        float right = Math.min(a.right, b.right);
        float bottom = Math.min(a.bottom, b.bottom);
        if (right <= left || bottom <= top) return false;

        float intersection = (right - left) * (bottom - top);
        float areaA = Math.max(0.00001f, (a.right - a.left) * (a.bottom - a.top));
        float areaB = Math.max(0.00001f, (b.right - b.left) * (b.bottom - b.top));
        float ratio = intersection / Math.min(areaA, areaB);

        float verticalCenterA = (a.top + a.bottom) * 0.5f;
        float verticalCenterB = (b.top + b.bottom) * 0.5f;
        float verticalDistance = Math.abs(verticalCenterA - verticalCenterB);

        return ratio >= 0.55f && verticalDistance <= Math.max(0.018f, Math.max(a.bottom - a.top, b.bottom - b.top) * 0.75f);
    }

    private void notifyHighlightsChanged() {
        if (listener != null) {
            listener.onHighlightsChanged(serializeHighlights());
        }
    }

    private RectF getCurrentPageRect() {
        float displayWidth = getWidth() * zoom;
        float displayHeight = displayWidth * (bitmap.getHeight() / (float) bitmap.getWidth());

        if (displayWidth <= getWidth()) panX = (getWidth() - displayWidth) / 2f;
        if (displayHeight <= getHeight()) panY = (getHeight() - displayHeight) / 2f;

        return new RectF(panX, panY, panX + displayWidth, panY + displayHeight);
    }

    private void clampPan() {
        if (bitmap == null) return;

        float displayWidth = getWidth() * zoom;
        float displayHeight = displayWidth * (bitmap.getHeight() / (float) bitmap.getWidth());

        if (displayWidth <= getWidth()) {
            panX = (getWidth() - displayWidth) / 2f;
        } else {
            panX = clamp(panX, getWidth() - displayWidth, 0f);
        }

        if (displayHeight <= getHeight()) {
            panY = (getHeight() - displayHeight) / 2f;
        } else {
            panY = clamp(panY, getHeight() - displayHeight, 0f);
        }
    }

    private static int safeStyle(int style) {
        if (style == MARK_STYLE_TEXT_BOX) return MARK_STYLE_UNDERLINE_FINE;
        if (style < MARK_STYLE_UNDERLINE_FINE || style > MARK_STYLE_HIGHLIGHT_INTENSE) {
            return MARK_STYLE_UNDERLINE_FINE;
        }
        return style;
    }

    private static int safeThickness(int thickness) {
        if (thickness < 0 || thickness > 2) return 1;
        return thickness;
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public Bitmap exportCurrentPageBitmap(boolean includeRules) {
        if (bitmap == null || bitmap.isRecycled()) return null;

        Bitmap out;
        try {
            out = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        } catch (Exception e) {
            return null;
        }

        Canvas canvas = new Canvas(out);
        canvas.drawColor(Color.WHITE);
        RectF pageRect = new RectF(0f, 0f, out.getWidth(), out.getHeight());
        canvas.drawBitmap(bitmap, null, pageRect, paint);
        drawSavedMarkers(canvas, pageRect);
        if (includeRules) {
            drawReadingRules(canvas, pageRect);
        }
        return out;
    }

    public Bitmap exportPageBitmap(int targetPage, boolean includeRules) {
        synchronized (lock) {
            if (renderer == null || targetPage < 0 || targetPage >= pageCount) return null;

            PdfRenderer.Page page = null;
            Bitmap rendered = null;
            Bitmap out = null;
            try {
                page = renderer.openPage(targetPage);
                int width = Math.max(page.getWidth() * 2, 1200);
                int height = Math.max(page.getHeight() * 2, 1600);
                rendered = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                rendered.eraseColor(Color.WHITE);
                page.render(rendered, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);

                out = Bitmap.createBitmap(rendered.getWidth(), rendered.getHeight(), Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(out);
                canvas.drawColor(Color.WHITE);
                RectF pageRect = new RectF(0f, 0f, out.getWidth(), out.getHeight());
                canvas.drawBitmap(rendered, null, pageRect, paint);
                drawMarkersForPage(canvas, pageRect, targetPage);
                if (includeRules) {
                    drawReadingRules(canvas, pageRect);
                }
                return out;
            } catch (Exception e) {
                if (out != null && !out.isRecycled()) out.recycle();
                return null;
            } finally {
                if (rendered != null && !rendered.isRecycled()) rendered.recycle();
                if (page != null) page.close();
            }
        }
    }

    public void closeDocument() {
        try {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            bitmap = null;

            if (renderer != null) renderer.close();
            if (descriptor != null) descriptor.close();
        } catch (Exception ignored) {
        }

        renderer = null;
        descriptor = null;
        pageCount = 0;
        pageIndex = 0;
        charBoxes = new ArrayList<CharBox>();
    }
}
