# Geo Zeta PDF a Audio V61 Page Notification Sync

Base:
- V60 Clean Sync.

Correcciones:
- Sincroniza la página visible con la página que el audio está leyendo.
- Al terminar una página, la app cambia sola a la siguiente página mientras sigue leyendo.
- Al prender la pantalla o tocar la notificación, vuelve a la página real de lectura.
- Mejora la notificación de reproducción:
  - canal nuevo para evitar configuraciones antiguas bloqueadas;
  - mayor prioridad visual;
  - visibilidad en pantalla bloqueada;
  - controles Anterior / Pausar / Siguiente / Detener.
- Pide permiso de notificaciones en Android 13 o superior si todavía no está autorizado.
- Mantiene la limpieza del problema de “ene / n” en algunos PDFs.

Mantiene:
- Audio continuo.
- Lectura con pantalla apagada.
- Ajustes actuales.
- Tema claro/oscuro.
- Subrayado.
- Reglas.
- Guardar imagen PNG.
- Guardar audio WAV.
