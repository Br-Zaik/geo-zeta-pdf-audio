package com.geozeta.pdfaudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.HashMap;
import java.util.Map;
import java.util.Locale;

public class TtsForegroundService extends Service {
    public static final String ACTION_START = "com.geozeta.pdfaudio.START";
    public static final String ACTION_WARMUP = "com.geozeta.pdfaudio.WARMUP";
    public static final String ACTION_PREPARE = "com.geozeta.pdfaudio.PREPARE";
    public static final String ACTION_STOP = "com.geozeta.pdfaudio.STOP";
    public static final String ACTION_TOGGLE = "com.geozeta.pdfaudio.TOGGLE";
    public static final String ACTION_NEXT = "com.geozeta.pdfaudio.NEXT";
    public static final String ACTION_PREV = "com.geozeta.pdfaudio.PREV";
    public static final String ACTION_PAGE_CHANGED = "com.geozeta.pdfaudio.PAGE_CHANGED";
    public static final String EXTRA_PAGE = "page";
    public static final String EXTRA_ACTIVE = "active";
    public static final String EXTRA_PAUSED = "paused";

    private static final String CHANNEL_ID = "pdf_audio_playback_v61";
    private static final int NOTIFICATION_ID = 39;
    private static final String PREFS_NAME = "pdf_audio_prefs";
    private static final String PREF_TTS_ACTIVE = "tts_service_active";
    private static final String PREF_TTS_PAUSED = "tts_service_paused";
    private static final String PREF_TTS_CURRENT_PAGE = "tts_current_page";
    public interface PageProvider {
        void requestPageText(int page, PageTextCallback callback);
    }

    public interface PageTextCallback {
        void onText(String text);
    }

    private static final Map<Integer, String> PAGE_MAP = new HashMap<Integer, String>();
    private static PageProvider pageProvider;

    public static synchronized void setPageProvider(PageProvider provider) {
        pageProvider = provider;
    }

    public static synchronized void clearPages() {
        PAGE_MAP.clear();
    }

    public static synchronized void addPage(String text) {
        PAGE_MAP.put(PAGE_MAP.size(), text == null ? "" : text);
    }

    public static synchronized void setPageText(int page, String text) {
        PAGE_MAP.put(page, text == null ? "" : text);
    }

    private static synchronized String getStoredPage(int page) {
        return PAGE_MAP.get(page);
    }

    private static synchronized PageProvider getProvider() {
        return pageProvider;
    }

    public static synchronized int pageCount() {
        return PAGE_MAP.size();
    }

    private TextToSpeech tts;
    private boolean ready;
    private boolean reading;
    private boolean paused;
    private int index;
    private int pageOffset;
    private int currentPageAbsolute;
    private boolean waitingForProvider;
    private int totalPages;
    private String title;
    private float rate;
    private float pitch;

    @Override
    public void onCreate() {
        super.onCreate();
        title = "PDF a Audio";
        rate = 0.95f;
        pitch = 1.0f;
        createChannel();

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = tts.setLanguage(new Locale("es", "PE"));
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts.setLanguage(new Locale("es", "ES"));
                    }

                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override
                        public void onStart(String utteranceId) {
                        }

                        @Override
                        public void onDone(String utteranceId) {
                            if (!reading || paused) return;
                            currentPageAbsolute++;
                            index = currentPageAbsolute - pageOffset;
                            speakAbsolutePage(currentPageAbsolute);
                        }

                        @Override
                        public void onError(String utteranceId) {
                            updateNotification("Error de audio");
                        }
                    });

                    ready = true;
                    if (reading && !paused) speakCurrent();
                }
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_STICKY;
        String action = intent.getAction();

        if (ACTION_WARMUP.equals(action)) {
            // Solo mantiene listo el motor TTS. No muestra notificación ni lee nada.
            return START_STICKY;
        } else if (ACTION_PREPARE.equals(action)) {
            String extraTitle = intent.getStringExtra("title");
            title = extraTitle == null ? "PDF a Audio" : extraTitle;
            pageOffset = intent.getIntExtra("pageOffset", 0);
            totalPages = intent.getIntExtra("totalPages", 0);
            index = 0;
            currentPageAbsolute = pageOffset;
            waitingForProvider = false;
            rate = clampRate(intent.getFloatExtra("rate", 1.0f));
            pitch = intent.getFloatExtra("pitch", 1.0f);
            reading = true;
            paused = false;
            savePlaybackState(currentPageAbsolute, true, false);
            if (tts != null) tts.stop();
            startForeground(NOTIFICATION_ID, buildNotification("Preparando página " + (pageOffset + 1)));
        } else if (ACTION_START.equals(action)) {
            String extraTitle = intent.getStringExtra("title");
            title = extraTitle == null ? "PDF a Audio" : extraTitle;
            pageOffset = intent.getIntExtra("pageOffset", 0);
            totalPages = intent.getIntExtra("totalPages", 0);
            index = Math.max(0, intent.getIntExtra("startIndex", 0));
            currentPageAbsolute = pageOffset + index;
            waitingForProvider = false;
            rate = clampRate(intent.getFloatExtra("rate", 1.0f));
            pitch = intent.getFloatExtra("pitch", 1.0f);
            reading = true;
            paused = false;
            savePlaybackState(currentPageAbsolute, true, false);
            startForeground(NOTIFICATION_ID, buildNotification("Cambiando página..."));
            if (ready) speakCurrent();
        } else if (ACTION_TOGGLE.equals(action)) {
            toggle();
        } else if (ACTION_NEXT.equals(action)) {
            currentPageAbsolute++;
            index = currentPageAbsolute - pageOffset;
            reading = true;
            paused = false;
            savePlaybackState(currentPageAbsolute, true, false);
            if (ready) speakAbsolutePage(currentPageAbsolute);
        } else if (ACTION_PREV.equals(action)) {
            currentPageAbsolute = Math.max(0, currentPageAbsolute - 1);
            index = currentPageAbsolute - pageOffset;
            reading = true;
            paused = false;
            savePlaybackState(currentPageAbsolute, true, false);
            if (ready) speakAbsolutePage(currentPageAbsolute);
        } else if (ACTION_STOP.equals(action)) {
            stopAll();
        }

        return START_STICKY;
    }

    private void speakCurrent() {
        speakAbsolutePage(currentPageAbsolute);
    }

    private void speakAbsolutePage(final int absolutePage) {
        if (!ready || !reading || paused) return;

        if (totalPages > 0 && absolutePage >= totalPages) {
            updateNotification("Lectura finalizada");
            stopAll();
            return;
        }

        String stored = getStoredPage(absolutePage);
        if (stored != null) {
            speakTextForPage(absolutePage, stored);
            return;
        }

        requestPageFromProvider(absolutePage);
    }

    private void requestPageFromProvider(final int absolutePage) {
        if (!reading || paused || waitingForProvider) return;

        if (totalPages > 0 && absolutePage >= totalPages) {
            stopAll();
            return;
        }

        PageProvider provider = getProvider();
        if (provider == null) {
            updateNotification("Esperando texto de página " + (absolutePage + 1));
            return;
        }

        waitingForProvider = true;
        updateNotification("Preparando página " + (absolutePage + 1));

        provider.requestPageText(absolutePage, new PageTextCallback() {
            @Override
            public void onText(String text) {
                waitingForProvider = false;
                if (!reading || paused || absolutePage != currentPageAbsolute) return;

                setPageText(absolutePage, text);
                speakTextForPage(absolutePage, text);
            }
        });
    }

    private void speakTextForPage(int absolutePage, String rawText) {
        if (!ready || !reading || paused) return;

        currentPageAbsolute = absolutePage;
        index = currentPageAbsolute - pageOffset;
        savePlaybackState(currentPageAbsolute, true, paused);

        String text = cleanForTts(rawText);
        if (text.trim().length() == 0) {
            currentPageAbsolute++;
            index = currentPageAbsolute - pageOffset;
            speakAbsolutePage(currentPageAbsolute);
            return;
        }

        if (text.length() > 28000) text = text.substring(0, 28000);

        tts.stop();
        tts.setSpeechRate(rate);
        tts.setPitch(pitch);
        updateNotification("Página " + (absolutePage + 1) + " · " + String.format(Locale.US, "%.2fx", rate));
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "PAGE_" + absolutePage);
    }


    private float clampRate(float value) {
        if (value < 0.5f) return 0.5f;
        if (value > 2.0f) return 2.0f;
        return value;
    }

    private String cleanForTts(String value) {
        if (value == null) return "";

        String text = value.replace('\u00A0', ' ');
        text = text.replace("\\r\\n", "\n");
        text = text.replace("\\n", "\n");
        text = text.replace("\\r", "\n");
        text = text.replace("/n", "\n");
        text = text.replace('\r', '\n');

        text = text.replaceAll("(?m)^\\s*[\\\\/]*[NnÑñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[A-ZÑ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[a-zñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[0-9]{1,4}\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[IVXLCDMivxlcdm]{1,8}\\s*$", "");
        text = text.replaceFirst("(?i)^(\\s*[nñ]\\s+){1,10}", "");

        // Algunos PDF guardan el salto de línea como una letra n suelta.
        // Si llega al TTS, Android la pronuncia como "ene".
        text = text.replaceAll("(?i)(^|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-])[nñ](?=($|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-]))", "$1");

        text = text.replaceAll("(?iu)([a-záéíóúüñ])-\\s*\\n\\s*([a-záéíóúüñ])", "$1$2");
        text = text.replaceAll("[ \\t]{2,}", " ");
        text = text.replaceAll("\\n[ \\t]+", "\n");
        text = text.replaceAll("\\n{3,}", "\n\n");

        return text.trim();
    }

    private void savePlaybackState(int page, boolean active, boolean isPaused) {
        try {
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(PREF_TTS_ACTIVE, active)
                    .putBoolean(PREF_TTS_PAUSED, isPaused)
                    .putInt(PREF_TTS_CURRENT_PAGE, page)
                    .apply();

            Intent update = new Intent(ACTION_PAGE_CHANGED);
            update.setPackage(getPackageName());
            update.putExtra(EXTRA_PAGE, page);
            update.putExtra(EXTRA_ACTIVE, active);
            update.putExtra(EXTRA_PAUSED, isPaused);
            sendBroadcast(update);
        } catch (Exception ignored) {
        }
    }

    private void toggle() {
        if (paused) {
            paused = false;
            reading = true;
            savePlaybackState(currentPageAbsolute, true, false);
            speakCurrent();
        } else {
            paused = true;
            reading = false;
            savePlaybackState(currentPageAbsolute, true, true);
            if (tts != null) tts.stop();
            updateNotification("Pausado");
        }
    }

    private void stopAll() {
        reading = false;
        paused = false;
        waitingForProvider = false;
        savePlaybackState(currentPageAbsolute, false, false);
        if (tts != null) tts.stop();
        stopForeground(true);
        stopSelf();
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        openIntent.putExtra("open_reading_page", true);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent prevPi = PendingIntent.getService(this, 1, new Intent(this, TtsForegroundService.class).setAction(ACTION_PREV), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent togglePi = PendingIntent.getService(this, 2, new Intent(this, TtsForegroundService.class).setAction(ACTION_TOGGLE), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent nextPi = PendingIntent.getService(this, 3, new Intent(this, TtsForegroundService.class).setAction(ACTION_NEXT), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stopPi = PendingIntent.getService(this, 4, new Intent(this, TtsForegroundService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        builder.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("PDF a Audio")
                .setContentText(text)
                .setSubText(title)
                .setContentIntent(openPi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .addAction(android.R.drawable.ic_media_previous, "Anterior", prevPi)
                .addAction(paused ? android.R.drawable.ic_media_play : android.R.drawable.ic_media_pause, paused ? "Reanudar" : "Pausar", togglePi)
                .addAction(android.R.drawable.ic_media_next, "Siguiente", nextPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPi);

        if (Build.VERSION.SDK_INT >= 21) {
            builder.setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setCategory(Notification.CATEGORY_TRANSPORT)
                    .setColor(0xFF0B3C58)
                    .setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2));
        }

        if (Build.VERSION.SDK_INT >= 31) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }

        if (Build.VERSION.SDK_INT < 26) {
            builder.setPriority(Notification.PRIORITY_DEFAULT);
        }

        return builder.build();
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "PDF a Audio", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Lectura de PDF en segundo plano");
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.enableVibration(false);
            channel.setSound(null, null);
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
