# Geo Zeta PDF a Audio V18

Mejoras:
- Mantiene audio de página, rango y subrayado.
- Subrayado tipo texto guardado por PDF y página.
- Nuevo modo **Borrar 1** para quitar solo un subrayado específico.
- Sigue existiendo **Borrar último** y **Limpiar pág.**.
- Guardar y compartir PNG con subrayado.
- Compartir texto y reglas automáticas para el audio.

Objetivo de esta versión:
- Nada de Word.
- PDF + audio + imagen + texto subrayado estable.
