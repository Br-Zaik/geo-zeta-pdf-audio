package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.pdf.PdfRenderer;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Proveedor de texto para PDFs escaneados.
 *
 * Renderiza cada pagina localmente con PdfRenderer y reconoce el texto con los
 * modelos EMPAQUETADOS de ML Kit. No sube el PDF, la imagen ni el texto a un
 * servidor. La interfaz publica es la misma que TextRepository, por eso el
 * lector/TTS existente puede usar OCR sin reescribir su logica estable.
 */
public final class OcrTextRepository extends TextRepository {
    private static final int MAX_MEMORY_PAGES = 28;
    private static final int FIRST_PASS_LONG_EDGE = 2000;
    private static final int RETRY_LONG_EDGE = 2500;
    private static final long MAX_RENDER_PIXELS = 4_500_000L;
    private static final int MAX_CACHE_DIRECTORIES = 8;
    private static final String OCR_CACHE_VERSION = "ocr_v156_1";

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "GeoZetaOcr");
        try { t.setPriority(Thread.NORM_PRIORITY); } catch (Throwable ignored) { }
        return t;
    });
    private final Object rendererLock = new Object();
    private final AtomicInteger generation = new AtomicInteger(1);
    private final Set<Integer> inFlight = Collections.newSetFromMap(new ConcurrentHashMap<Integer, Boolean>());
    private final Map<Integer, List<TextCallback>> waiters = new ConcurrentHashMap<Integer, List<TextCallback>>();
    private final Map<Integer, String> memoryCache = Collections.synchronizedMap(
            new LinkedHashMap<Integer, String>(16, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<Integer, String> eldest) {
                    return size() > MAX_MEMORY_PAGES;
                }
            });

    private final File cacheRoot;
    private final TextRecognizer latinRecognizer;
    private final TextRecognizer devanagariRecognizer;

    private volatile File sourceFile;
    private volatile File cacheDir;
    private volatile ParcelFileDescriptor parcelFileDescriptor;
    private volatile PdfRenderer pdfRenderer;
    private volatile boolean rulesEnabled = true;
    private volatile float ruleTop = 0.08f;
    private volatile float ruleBottom = 0.92f;
    private volatile boolean preferDevanagari;
    private volatile boolean permanentlyShutdown;

    public OcrTextRepository(Context context) {
        super(context);
        Context app = context.getApplicationContext();
        cacheRoot = new File(app.getFilesDir(), "ocr_text_cache");
        if (!cacheRoot.exists()) cacheRoot.mkdirs();
        latinRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        devanagariRecognizer = TextRecognition.getClient(
                new DevanagariTextRecognizerOptions.Builder().build());
    }

    public synchronized void setPreferDevanagari(boolean prefer) {
        if (preferDevanagari == prefer) return;
        preferDevanagari = prefer;
        generation.incrementAndGet();
        memoryCache.clear();
        waiters.clear();
        inFlight.clear();
        cacheDir = buildCacheDirectory(sourceFile);
    }

    @Override
    public synchronized void setRules(boolean enabled, float top, float bottom) {
        float safeTop = Math.max(0f, Math.min(top, 0.95f));
        float safeBottom = Math.max(0.05f, Math.min(bottom, 1f));
        if (safeBottom <= safeTop + 0.05f) {
            safeTop = 0.08f;
            safeBottom = 0.92f;
        }
        boolean changed = rulesEnabled != enabled
                || Math.abs(ruleTop - safeTop) > 0.0001f
                || Math.abs(ruleBottom - safeBottom) > 0.0001f;
        rulesEnabled = enabled;
        ruleTop = safeTop;
        ruleBottom = safeBottom;
        if (changed) {
            generation.incrementAndGet();
            memoryCache.clear();
            waiters.clear();
            inFlight.clear();
            cacheDir = buildCacheDirectory(sourceFile);
        }
    }

    @Override
    public synchronized void open(final File file) {
        if (permanentlyShutdown) return;
        generation.incrementAndGet();
        memoryCache.clear();
        waiters.clear();
        inFlight.clear();
        sourceFile = file;
        cacheDir = buildCacheDirectory(file);
        pruneOldCacheDirectories(cacheDir);
        closeRendererAsync();
        final int openGeneration = generation.get();
        executor.execute(new Runnable() {
            @Override
            public void run() {
                if (openGeneration != generation.get() || file == null || !file.equals(sourceFile)) return;
                ensureRenderer(openGeneration);
            }
        });
    }

    @Override
    public String getCachedText(int page) {
        String text = memoryCache.get(page);
        if (text != null) return text;
        text = readDisk(page);
        if (text != null) memoryCache.put(page, text);
        return text;
    }

    @Override
    public String getFastStartText(int page) {
        String text = getCachedText(page);
        return text == null ? null : makeFastStart(text);
    }

    @Override
    public void getPageTextFastStart(final int page,
                                     final TextCallback fastCallback,
                                     final TextCallback fullCallback) {
        requestPage(page, new TextCallback() {
            @Override
            public void onText(String text) {
                if (fastCallback != null) fastCallback.onText(makeFastStart(text));
                if (fullCallback != null) fullCallback.onText(text);
            }
        });
    }

    @Override
    public void getPageText(int page, TextCallback callback) {
        requestPage(page, callback);
    }

    @Override
    public void getPageTextPriority(int page, TextCallback callback) {
        requestPage(page, callback);
    }

    @Override
    public void noteInteractivePage(int page) {
        // No hay indexado masivo en OCR. La pagina pedida siempre entra en la
        // misma cola unica para limitar memoria y bateria.
    }

    @Override
    public boolean isPageCached(int page) {
        return getCachedText(page) != null;
    }

    @Override
    public void preloadAudioWindow(int centerPage, int radius, int totalPages) {
        if (permanentlyShutdown || sourceFile == null || totalPages <= 0) return;
        int safeRadius = Math.max(0, Math.min(radius, 2));
        for (int offset = 1; offset <= safeRadius; offset++) {
            int next = centerPage + offset;
            if (next >= 0 && next < totalPages && getCachedText(next) == null) requestPage(next, null);
        }
        int previous = centerPage - 1;
        if (previous >= 0 && previous < totalPages && getCachedText(previous) == null) {
            requestPage(previous, null);
        }
    }

    @Override
    public synchronized void startFullPreload(int startPage, int totalPages) {
        // OCR de cientos de paginas en segundo plano gastaria mucha bateria y
        // memoria. Solo se precargan paginas vecinas cuando realmente se leen.
    }

    @Override
    public void prefetch(int fromPage, int count, int totalPages) {
        if (count <= 0 || totalPages <= 0) return;
        int end = Math.min(totalPages, fromPage + Math.min(count, 2));
        for (int page = Math.max(0, fromPage); page < end; page++) {
            if (getCachedText(page) == null) requestPage(page, null);
        }
    }

    @Override
    public synchronized void close() {
        generation.incrementAndGet();
        sourceFile = null;
        cacheDir = null;
        memoryCache.clear();
        waiters.clear();
        inFlight.clear();
        closeRendererAsync();
    }

    /** Cierre definitivo, usado solo al destruir la Activity sin TTS activo. */
    public synchronized void shutdownOcr() {
        if (permanentlyShutdown) return;
        permanentlyShutdown = true;
        generation.incrementAndGet();
        sourceFile = null;
        cacheDir = null;
        memoryCache.clear();
        waiters.clear();
        inFlight.clear();
        synchronized (rendererLock) {
            closeRendererLocked();
        }
        try { latinRecognizer.close(); } catch (Throwable ignored) { }
        try { devanagariRecognizer.close(); } catch (Throwable ignored) { }
        executor.shutdownNow();
    }

    private void requestPage(final int page, final TextCallback callback) {
        if (page < 0 || permanentlyShutdown) {
            post(callback, "");
            return;
        }
        String cached = getCachedText(page);
        if (cached != null) {
            post(callback, cached);
            return;
        }

        if (callback != null) {
            List<TextCallback> list = waiters.get(page);
            if (list == null) {
                List<TextCallback> fresh = Collections.synchronizedList(new ArrayList<TextCallback>());
                List<TextCallback> raced = waiters.putIfAbsent(page, fresh);
                list = raced == null ? fresh : raced;
            }
            list.add(callback);
        }
        if (!inFlight.add(page)) return;

        final int requestGeneration = generation.get();
        final File requestFile = sourceFile;
        executor.execute(new Runnable() {
            @Override
            public void run() {
                String result = "";
                try {
                    if (requestFile != null && requestFile.equals(sourceFile)
                            && requestGeneration == generation.get()) {
                        result = recognizePage(page, requestGeneration);
                    }
                } catch (Throwable ignored) {
                    result = "";
                }
                if (requestGeneration != generation.get()
                        || requestFile == null || !requestFile.equals(sourceFile)) {
                    inFlight.remove(page);
                    waiters.remove(page);
                    return;
                }
                result = normalizeText(result);
                memoryCache.put(page, result);
                writeDisk(page, result);
                inFlight.remove(page);
                final List<TextCallback> callbacks = waiters.remove(page);
                if (callbacks != null) {
                    final String ready = result;
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            synchronized (callbacks) {
                                for (TextCallback cb : callbacks) {
                                    if (cb != null) cb.onText(ready);
                                }
                            }
                        }
                    });
                }
            }
        });
    }

    private String recognizePage(int pageIndex, int requestGeneration) throws Exception {
        String first = recognizePageAtSize(pageIndex, FIRST_PASS_LONG_EDGE, requestGeneration);
        if (qualityScore(first) >= 24) return first;
        String retry = recognizePageAtSize(pageIndex, RETRY_LONG_EDGE, requestGeneration);
        return qualityScore(retry) >= qualityScore(first) ? retry : first;
    }

    private String recognizePageAtSize(int pageIndex, int longEdge,
                                       int requestGeneration) throws Exception {
        Bitmap bitmap = renderPage(pageIndex, longEdge, requestGeneration);
        if (bitmap == null) return "";
        try {
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            Text firstResult;
            Text secondResult = null;
            if (preferDevanagari) {
                firstResult = Tasks.await(devanagariRecognizer.process(image));
                if (qualityScore(firstResult == null ? "" : firstResult.getText()) < 24) {
                    secondResult = Tasks.await(latinRecognizer.process(image));
                }
            } else {
                firstResult = Tasks.await(latinRecognizer.process(image));
                if (qualityScore(firstResult == null ? "" : firstResult.getText()) < 24) {
                    secondResult = Tasks.await(devanagariRecognizer.process(image));
                }
            }
            String a = firstResult == null ? "" : firstResult.getText();
            String b = secondResult == null ? "" : secondResult.getText();
            return qualityScore(b) > qualityScore(a) ? b : a;
        } finally {
            if (!bitmap.isRecycled()) bitmap.recycle();
        }
    }

    private Bitmap renderPage(int pageIndex, int desiredLongEdge,
                              int requestGeneration) throws Exception {
        synchronized (rendererLock) {
            if (!ensureRenderer(requestGeneration) || pdfRenderer == null) return null;
            if (pageIndex < 0 || pageIndex >= pdfRenderer.getPageCount()) return null;
            PdfRenderer.Page page = null;
            Bitmap full = null;
            try {
                page = pdfRenderer.openPage(pageIndex);
                int baseWidth = Math.max(1, page.getWidth());
                int baseHeight = Math.max(1, page.getHeight());
                float scale = desiredLongEdge / (float) Math.max(baseWidth, baseHeight);
                scale = Math.max(1f, Math.min(scale, 4.5f));
                int width = Math.max(1, Math.round(baseWidth * scale));
                int height = Math.max(1, Math.round(baseHeight * scale));
                long pixels = (long) width * (long) height;
                if (pixels > MAX_RENDER_PIXELS) {
                    float reduce = (float) Math.sqrt(MAX_RENDER_PIXELS / (double) pixels);
                    width = Math.max(1, Math.round(width * reduce));
                    height = Math.max(1, Math.round(height * reduce));
                    scale *= reduce;
                }
                full = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(full);
                canvas.drawColor(Color.WHITE);
                Matrix matrix = new Matrix();
                matrix.setScale(scale, scale);
                page.render(full, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);

                if (!rulesEnabled) return full;
                int top = Math.max(0, Math.min(height - 1, Math.round(height * ruleTop)));
                int bottom = Math.max(top + 1, Math.min(height, Math.round(height * ruleBottom)));
                if (top <= 0 && bottom >= height) return full;
                Bitmap cropped = Bitmap.createBitmap(full, 0, top, width, bottom - top);
                full.recycle();
                full = null;
                return cropped;
            } finally {
                if (page != null) try { page.close(); } catch (Throwable ignored) { }
                // full is returned to the caller when non-null; do not recycle here.
            }
        }
    }

    private boolean ensureRenderer(int expectedGeneration) {
        synchronized (rendererLock) {
            if (expectedGeneration != generation.get() || sourceFile == null) return false;
            if (pdfRenderer != null && parcelFileDescriptor != null) return true;
            closeRendererLocked();
            try {
                parcelFileDescriptor = ParcelFileDescriptor.open(
                        sourceFile, ParcelFileDescriptor.MODE_READ_ONLY);
                pdfRenderer = new PdfRenderer(parcelFileDescriptor);
                return true;
            } catch (Throwable e) {
                closeRendererLocked();
                return false;
            }
        }
    }

    private void closeRendererAsync() {
        try {
            executor.execute(new Runnable() {
                @Override
                public void run() {
                    synchronized (rendererLock) {
                        closeRendererLocked();
                    }
                }
            });
        } catch (Throwable ignored) {
            synchronized (rendererLock) {
                closeRendererLocked();
            }
        }
    }

    private void closeRendererLocked() {
        if (pdfRenderer != null) {
            try { pdfRenderer.close(); } catch (Throwable ignored) { }
            pdfRenderer = null;
        }
        if (parcelFileDescriptor != null) {
            try { parcelFileDescriptor.close(); } catch (Throwable ignored) { }
            parcelFileDescriptor = null;
        }
    }

    private File buildCacheDirectory(File file) {
        if (file == null) return null;
        String source = OCR_CACHE_VERSION + "|" + file.getAbsolutePath() + "|"
                + file.length() + "|" + file.lastModified()
                + "|" + rulesEnabled + "|"
                + String.format(Locale.US, "%.4f|%.4f", ruleTop, ruleBottom)
                + "|devanagari=" + preferDevanagari;
        String key = sha256(source);
        File dir = new File(cacheRoot, key);
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private String readDisk(int page) {
        File dir = cacheDir;
        if (dir == null) return null;
        File file = new File(dir, page + ".txt");
        if (!file.exists()) return null;
        try { dir.setLastModified(System.currentTimeMillis()); } catch (Throwable ignored) { }
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (out.length() > 0) out.append('\n');
                out.append(line);
            }
            return out.toString();
        } catch (Throwable ignored) {
            return null;
        }
    }

    private void writeDisk(int page, String text) {
        File dir = cacheDir;
        if (dir == null) return;
        File tmp = new File(dir, page + ".tmp");
        File dest = new File(dir, page + ".txt");
        try { dir.setLastModified(System.currentTimeMillis()); } catch (Throwable ignored) { }
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(tmp, false), StandardCharsets.UTF_8))) {
            writer.write(text == null ? "" : text);
            writer.flush();
            if (dest.exists()) dest.delete();
            if (!tmp.renameTo(dest)) {
                try (FileInputStream in = new FileInputStream(tmp);
                     FileOutputStream out = new FileOutputStream(dest, false)) {
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }
                tmp.delete();
            }
        } catch (Throwable ignored) {
            tmp.delete();
        }
    }

    private void pruneOldCacheDirectories(File keep) {
        try {
            File[] dirs = cacheRoot.listFiles();
            if (dirs == null || dirs.length <= MAX_CACHE_DIRECTORIES) return;
            java.util.Arrays.sort(dirs, new java.util.Comparator<File>() {
                @Override
                public int compare(File a, File b) {
                    return Long.compare(b.lastModified(), a.lastModified());
                }
            });
            int otherKept = 0;
            int otherLimit = keep == null ? MAX_CACHE_DIRECTORIES : MAX_CACHE_DIRECTORIES - 1;
            for (File dir : dirs) {
                if (dir == null || !dir.isDirectory()) continue;
                if (keep != null && keep.equals(dir)) continue;
                if (otherKept < otherLimit) {
                    otherKept++;
                    continue;
                }
                deleteRecursively(dir);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) deleteRecursively(child);
            }
        }
        try { file.delete(); } catch (Throwable ignored) { }
    }

    private void post(final TextCallback callback, final String text) {
        if (callback == null) return;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                callback.onText(text == null ? "" : text);
            }
        });
    }

    private static int qualityScore(String text) {
        if (text == null) return 0;
        int score = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetterOrDigit(c)) score++;
        }
        return score;
    }

    private static String normalizeText(String text) {
        if (text == null) return "";
        text = text.replace('\u00A0', ' ')
                .replaceAll("[ \\t]{2,}", " ")
                .replaceAll("\\n[ \\t]+", "\\n")
                .replaceAll("\\n{3,}", "\\n\\n")
                .replaceAll("(?iu)([a-záéíóúüñ])-\\s*\\n\\s*([a-záéíóúüñ])", "$1$2");
        return text.trim();
    }

    private static String makeFastStart(String text) {
        String clean = normalizeText(text);
        if (clean.length() <= 420) return clean;
        int limit = Math.min(520, clean.length());
        int best = -1;
        for (int i = Math.min(420, clean.length() - 1); i < limit; i++) {
            char c = clean.charAt(i);
            if (c == '.' || c == '!' || c == '?' || c == '\n') {
                best = i + 1;
                break;
            }
        }
        if (best < 0) best = Math.min(420, clean.length());
        return clean.substring(0, best).trim();
    }

    private static String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format(Locale.US, "%02x", b & 0xff));
            return sb.toString();
        } catch (Throwable ignored) {
            return Integer.toHexString(value.hashCode());
        }
    }
}
