# Geo Zeta PDF a Audio V53 Professional Settings

Base:
- V52 Audio Clean Fast.

Agregado:
- Pantalla completa de Ajustes profesional.
- Diseño tipo tarjetas.
- Modo claro/oscuro más ordenado.
- Secciones: Apariencia, Lectura y Audio, Visor PDF, Marcado, Exportar y Sistema.
- Ajustes con switches, flechas y opciones.
- Mantiene guardar imagen PNG y guardar audio WAV.
- Mantiene corrección de audio que evita leer letras sueltas como "ene".
- Mantiene cambio de página más rápido.
- Mantiene subrayado por letras reales.
- Mantiene reglas arriba/abajo.
- Mantiene zoom fluido.
