package com.geozeta.pdfaudio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Process-wide TextToSpeech owner.
 *
 * The engine is created once from the Application process and is not tied to
 * the short lifecycle of a Service. If the default engine does not answer, the
 * manager tries the configured engine and every installed TTS service.
 */
public final class TtsEngineManager {
    public static final String PREF_ENGINE_PACKAGE = "tts_engine_package";
    private static final String PREF_LAST_WORKING_ENGINE = "tts_last_working_engine";

    public interface ReadyCallback {
        void onReady(String enginePackage);
        void onError(String message);
    }

    public interface StateListener {
        void onStateChanged(String status, boolean ready, String enginePackage);
    }

    public interface UtteranceListener {
        void onStart(String utteranceId);
        void onDone(String utteranceId);
        void onError(String utteranceId, int errorCode);
        void onStop(String utteranceId, boolean interrupted);
        void onRangeStart(String utteranceId, int start, int end);
    }

    public interface TestCallback {
        void onStarted();
        void onCompleted();
        void onError(String message);
    }

    public static final class EngineChoice {
        public final String packageName;
        public final String label;

        EngineChoice(String packageName, String label) {
            this.packageName = packageName;
            this.label = label;
        }
    }

    private static final String PREFS_NAME = "pdf_audio_prefs";
    private static final long ATTEMPT_TIMEOUT_MS = 7000L;
    private static volatile TtsEngineManager instance;

    public static TtsEngineManager getInstance(Context context) {
        if (instance == null) {
            synchronized (TtsEngineManager.class) {
                if (instance == null) {
                    instance = new TtsEngineManager(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    private final Context appContext;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final CopyOnWriteArrayList<ReadyCallback> readyCallbacks =
            new CopyOnWriteArrayList<ReadyCallback>();
    private final CopyOnWriteArrayList<StateListener> stateListeners =
            new CopyOnWriteArrayList<StateListener>();
    private final CopyOnWriteArrayList<UtteranceListener> utteranceListeners =
            new CopyOnWriteArrayList<UtteranceListener>();
    private final Map<String, TestCallback> testCallbacks =
            new ConcurrentHashMap<String, TestCallback>();

    private TextToSpeech tts;
    private TextToSpeech pendingTts;
    private boolean ready;
    private boolean initializing;
    private int generation;
    private int candidateIndex;
    private List<String> candidates = Collections.emptyList();
    private String activeEnginePackage = "";
    private String statusText = "Motor de voz sin iniciar";
    private boolean pipelineWarmed;
    private Runnable attemptTimeout;

    private TtsEngineManager(Context context) {
        appContext = context;
    }

    public void initialize(ReadyCallback callback) {
        runOnMain(new Runnable() {
            @Override
            public void run() {
                if (callback != null) readyCallbacks.add(callback);
                if (ready && tts != null) {
                    notifyReadyCallbacks();
                    return;
                }
                if (initializing) return;
                beginInitialization();
            }
        });
    }

    public void retryInitialization() {
        runOnMain(new Runnable() {
            @Override
            public void run() {
                resetInternal(true);
                beginInitialization();
            }
        });
    }

    public boolean isReady() {
        return ready && tts != null;
    }

    public String getActiveEnginePackage() {
        return activeEnginePackage == null ? "" : activeEnginePackage;
    }

    public String getStatusText() {
        return statusText == null ? "" : statusText;
    }

    public void addStateListener(StateListener listener) {
        if (listener == null) return;
        stateListeners.addIfAbsent(listener);
        listener.onStateChanged(getStatusText(), isReady(), getActiveEnginePackage());
    }

    public void removeStateListener(StateListener listener) {
        if (listener != null) stateListeners.remove(listener);
    }

    public void addUtteranceListener(UtteranceListener listener) {
        if (listener != null) utteranceListeners.addIfAbsent(listener);
    }

    public void removeUtteranceListener(UtteranceListener listener) {
        if (listener != null) utteranceListeners.remove(listener);
    }

    public List<EngineChoice> getInstalledEngines() {
        ArrayList<EngineChoice> result = new ArrayList<EngineChoice>();
        try {
            PackageManager pm = appContext.getPackageManager();
            Intent query = new Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE);
            List<ResolveInfo> services;
            if (Build.VERSION.SDK_INT >= 33) {
                services = pm.queryIntentServices(query,
                        PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL));
            } else {
                services = pm.queryIntentServices(query, PackageManager.MATCH_ALL);
            }
            if (services != null) {
                LinkedHashSet<String> seen = new LinkedHashSet<String>();
                for (ResolveInfo info : services) {
                    if (info == null || info.serviceInfo == null) continue;
                    String pkg = info.serviceInfo.packageName;
                    if (pkg == null || pkg.length() == 0 || !seen.add(pkg)) continue;
                    CharSequence labelSequence = info.loadLabel(pm);
                    String label = labelSequence == null ? pkg : labelSequence.toString();
                    result.add(new EngineChoice(pkg, label));
                }
            }
        } catch (Exception ignored) {
        }
        return result;
    }

    public void selectEngine(String packageName) {
        final String value = packageName == null ? "" : packageName.trim();
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putString(PREF_ENGINE_PACKAGE, value).apply();
        retryInitialization();
    }

    public int speak(String text, int queueMode, Bundle params, String utteranceId) {
        TextToSpeech current = tts;
        if (!ready || current == null || text == null || text.trim().length() == 0) {
            return TextToSpeech.ERROR;
        }
        try {
            if (Build.VERSION.SDK_INT >= 21) {
                return current.speak(text, queueMode, params, utteranceId);
            }
            return TextToSpeech.ERROR;
        } catch (Exception ignored) {
            return TextToSpeech.ERROR;
        }
    }

    public void setSpeechRate(float value) {
        TextToSpeech current = tts;
        if (current == null || !ready) return;
        try { current.setSpeechRate(value); } catch (Exception ignored) {}
    }

    public void setPitch(float value) {
        TextToSpeech current = tts;
        if (current == null || !ready) return;
        try { current.setPitch(value); } catch (Exception ignored) {}
    }

    public void stop() {
        TextToSpeech current = tts;
        if (current == null) return;
        try { current.stop(); } catch (Exception ignored) {}
    }

    public boolean isSpeaking() {
        TextToSpeech current = tts;
        if (current == null || !ready) return false;
        try { return current.isSpeaking(); } catch (Exception ignored) { return false; }
    }

    public void testVoice(final String text, final TestCallback callback) {
        initialize(new ReadyCallback() {
            @Override
            public void onReady(String enginePackage) {
                final String id = "TEST_" + System.currentTimeMillis();
                if (callback != null) testCallbacks.put(id, callback);
                Bundle params = new Bundle();
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
                int result = speak(text, TextToSpeech.QUEUE_FLUSH, params, id);
                if (result == TextToSpeech.ERROR) {
                    TestCallback pending = testCallbacks.remove(id);
                    if (pending != null) pending.onError("El motor rechazo la prueba de voz");
                }
            }

            @Override
            public void onError(String message) {
                if (callback != null) callback.onError(message);
            }
        });
    }

    private void beginInitialization() {
        generation++;
        candidateIndex = 0;
        candidates = buildCandidateList();
        initializing = true;
        ready = false;
        activeEnginePackage = "";
        updateStatus("Buscando motor de voz", false);
        tryNextCandidate(generation);
    }

    private List<String> buildCandidateList() {
        LinkedHashSet<String> ordered = new LinkedHashSet<String>();
        SharedPreferences prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String selected = prefs.getString(PREF_ENGINE_PACKAGE, "");
        if (selected != null && selected.trim().length() > 0) ordered.add(selected.trim());
        String lastWorking = prefs.getString(PREF_LAST_WORKING_ENGINE, "");
        if (lastWorking != null && lastWorking.trim().length() > 0) {
            ordered.add(lastWorking.trim());
        }

        try {
            String systemDefault = Settings.Secure.getString(
                    appContext.getContentResolver(), Settings.Secure.TTS_DEFAULT_SYNTH);
            if (systemDefault != null && systemDefault.trim().length() > 0) {
                ordered.add(systemDefault.trim());
            }
        } catch (Exception ignored) {
        }

        List<EngineChoice> installed = getInstalledEngines();
        for (EngineChoice choice : installed) {
            if ("com.google.android.tts".equals(choice.packageName)) {
                ordered.add(choice.packageName);
            }
        }
        for (EngineChoice choice : installed) ordered.add(choice.packageName);

        // Empty string means the Android default constructor.
        ordered.add("");
        return new ArrayList<String>(ordered);
    }

    private void tryNextCandidate(final int requestGeneration) {
        if (requestGeneration != generation) return;
        shutdownPending();
        cancelAttemptTimeout();

        if (candidateIndex >= candidates.size()) {
            initializing = false;
            ready = false;
            String message = "Android no pudo iniciar ningun motor de voz instalado";
            updateStatus(message, false);
            notifyErrorCallbacks(message);
            return;
        }

        final String candidate = candidates.get(candidateIndex++);
        String display = candidate.length() == 0 ? "motor predeterminado" : candidate;
        updateStatus("Iniciando " + display, false);
        final int attemptGeneration = requestGeneration;
        final TextToSpeech[] holder = new TextToSpeech[1];

        TextToSpeech.OnInitListener listener = new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(final int status) {
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (attemptGeneration != generation) {
                            shutdownSafely(holder[0]);
                            return;
                        }
                        cancelAttemptTimeout();
                        TextToSpeech created = holder[0];
                        if (status != TextToSpeech.SUCCESS || created == null) {
                            shutdownSafely(created);
                            tryNextCandidate(attemptGeneration);
                            return;
                        }
                        acceptEngine(created, candidate);
                    }
                });
            }
        };

        try {
            if (candidate.length() == 0) {
                holder[0] = new TextToSpeech(appContext, listener);
            } else {
                holder[0] = new TextToSpeech(appContext, listener, candidate);
            }
            pendingTts = holder[0];
        } catch (Exception ignored) {
            shutdownSafely(holder[0]);
            tryNextCandidate(attemptGeneration);
            return;
        }

        attemptTimeout = new Runnable() {
            @Override
            public void run() {
                if (attemptGeneration != generation || !initializing || ready) return;
                shutdownSafely(holder[0]);
                if (pendingTts == holder[0]) pendingTts = null;
                tryNextCandidate(attemptGeneration);
            }
        };
        mainHandler.postDelayed(attemptTimeout, ATTEMPT_TIMEOUT_MS);
    }

    private void acceptEngine(TextToSpeech created, String requestedPackage) {
        cancelAttemptTimeout();
        shutdownSafely(tts);
        if (pendingTts == created) pendingTts = null;
        tts = created;
        configureEngine(created);
        ready = true;
        initializing = false;

        String actual = requestedPackage;
        if (actual == null || actual.length() == 0) {
            try {
                String fromEngine = created.getDefaultEngine();
                if (fromEngine != null && fromEngine.trim().length() > 0) {
                    actual = fromEngine.trim();
                }
            } catch (Exception ignored) {
            }
        }
        activeEnginePackage = actual == null ? "" : actual;
        if (activeEnginePackage.length() > 0) {
            appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit().putString(PREF_LAST_WORKING_ENGINE, activeEnginePackage).apply();
        }
        updateStatus("Motor listo" + (activeEnginePackage.length() > 0
                ? ": " + activeEnginePackage : ""), true);
        primeAudioPipeline(created);
        notifyReadyCallbacks();
    }


    private void primeAudioPipeline(TextToSpeech engine) {
        if (pipelineWarmed || engine == null || Build.VERSION.SDK_INT < 21) return;
        pipelineWarmed = true;
        try {
            Bundle params = new Bundle();
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 0.0f);
            engine.speak(".", TextToSpeech.QUEUE_FLUSH, params,
                    "__GEO_ZETA_SILENT_WARMUP__");
        } catch (Exception ignored) {
            pipelineWarmed = false;
        }
    }

    private void configureEngine(TextToSpeech engine) {
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                engine.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build());
            } catch (Exception ignored) {
            }
        }

        boolean languageSet = tryLanguage(engine, new Locale("es", "PE"));
        if (!languageSet) languageSet = tryLanguage(engine, new Locale("es", "ES"));
        if (!languageSet) languageSet = tryLanguage(engine, Locale.getDefault());
        if (!languageSet) tryLanguage(engine, Locale.US);

        // V102: si el motor tiene una voz española instalada que no depende de
        // red, se usa primero. Evita la latencia de una voz de síntesis remota.
        selectPreferredOfflineSpanishVoice(engine);

        engine.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
                TestCallback test = utteranceId == null ? null : testCallbacks.get(utteranceId);
                if (test != null) test.onStarted();
                for (UtteranceListener listener : utteranceListeners) {
                    listener.onStart(utteranceId);
                }
            }

            @Override
            public void onDone(String utteranceId) {
                TestCallback test = utteranceId == null ? null : testCallbacks.remove(utteranceId);
                if (test != null) test.onCompleted();
                for (UtteranceListener listener : utteranceListeners) {
                    listener.onDone(utteranceId);
                }
            }

            @Override
            public void onError(String utteranceId) {
                dispatchError(utteranceId, TextToSpeech.ERROR);
            }

            @Override
            public void onError(String utteranceId, int errorCode) {
                dispatchError(utteranceId, errorCode);
            }

            @Override
            public void onStop(String utteranceId, boolean interrupted) {
                TestCallback test = utteranceId == null ? null : testCallbacks.remove(utteranceId);
                if (test != null && interrupted) test.onError("La prueba de voz fue interrumpida");
                for (UtteranceListener listener : utteranceListeners) {
                    listener.onStop(utteranceId, interrupted);
                }
            }

            @Override
            public void onRangeStart(String utteranceId, int start, int end, int frame) {
                for (UtteranceListener listener : utteranceListeners) {
                    listener.onRangeStart(utteranceId, start, end);
                }
            }
        });
    }

    private void dispatchError(String utteranceId, int errorCode) {
        TestCallback test = utteranceId == null ? null : testCallbacks.remove(utteranceId);
        if (test != null) test.onError("Error del motor de voz: " + errorCode);
        for (UtteranceListener listener : utteranceListeners) {
            listener.onError(utteranceId, errorCode);
        }
    }

    private void selectPreferredOfflineSpanishVoice(TextToSpeech engine) {
        if (engine == null || Build.VERSION.SDK_INT < 21) return;
        try {
            Set<Voice> voices = engine.getVoices();
            if (voices == null || voices.isEmpty()) return;

            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            for (Voice voice : voices) {
                if (voice == null || voice.getLocale() == null) continue;
                Locale locale = voice.getLocale();
                if (!"es".equalsIgnoreCase(locale.getLanguage())) continue;
                if (voice.isNetworkConnectionRequired()) continue;

                int score = 10000;
                String country = locale.getCountry() == null ? "" : locale.getCountry();
                if ("PE".equalsIgnoreCase(country)) score += 4000;
                else if ("ES".equalsIgnoreCase(country)) score += 2500;
                else if (country.length() > 0) score += 1200;

                // Mayor calidad y menor latencia son preferibles, sin asumir
                // nombres concretos del motor instalado.
                score += Math.max(0, voice.getQuality());
                score -= Math.max(0, voice.getLatency()) / 2;

                if (best == null || score > bestScore) {
                    best = voice;
                    bestScore = score;
                }
            }

            if (best != null) {
                engine.setVoice(best);
            }
        } catch (Exception ignored) {
            // Si el motor no expone voces locales, se conserva el idioma normal.
        }
    }

    private boolean tryLanguage(TextToSpeech engine, Locale locale) {
        if (engine == null || locale == null) return false;
        try {
            int available = engine.isLanguageAvailable(locale);
            if (available == TextToSpeech.LANG_MISSING_DATA
                    || available == TextToSpeech.LANG_NOT_SUPPORTED) return false;
            int result = engine.setLanguage(locale);
            return result != TextToSpeech.LANG_MISSING_DATA
                    && result != TextToSpeech.LANG_NOT_SUPPORTED;
        } catch (Exception ignored) {
            return false;
        }
    }

    private void notifyReadyCallbacks() {
        ArrayList<ReadyCallback> copy = new ArrayList<ReadyCallback>(readyCallbacks);
        readyCallbacks.clear();
        for (ReadyCallback callback : copy) {
            if (callback != null) callback.onReady(activeEnginePackage);
        }
    }

    private void notifyErrorCallbacks(String message) {
        ArrayList<ReadyCallback> copy = new ArrayList<ReadyCallback>(readyCallbacks);
        readyCallbacks.clear();
        for (ReadyCallback callback : copy) {
            if (callback != null) callback.onError(message);
        }
    }

    private void updateStatus(String status, boolean isReady) {
        statusText = status == null ? "" : status;
        for (StateListener listener : stateListeners) {
            listener.onStateChanged(statusText, isReady, activeEnginePackage);
        }
    }

    private void resetInternal(boolean keepCallbacks) {
        generation++;
        cancelAttemptTimeout();
        shutdownPending();
        shutdownSafely(tts);
        tts = null;
        ready = false;
        initializing = false;
        activeEnginePackage = "";
        pipelineWarmed = false;
        if (!keepCallbacks) readyCallbacks.clear();
        testCallbacks.clear();
        updateStatus("Reiniciando motor de voz", false);
    }

    private void shutdownPending() {
        shutdownSafely(pendingTts);
        pendingTts = null;
    }

    private void shutdownSafely(TextToSpeech engine) {
        if (engine == null) return;
        try { engine.stop(); } catch (Exception ignored) {}
        try { engine.shutdown(); } catch (Exception ignored) {}
    }

    private void cancelAttemptTimeout() {
        if (attemptTimeout != null) {
            mainHandler.removeCallbacks(attemptTimeout);
            attemptTimeout = null;
        }
    }

    private void runOnMain(Runnable runnable) {
        if (Looper.myLooper() == Looper.getMainLooper()) runnable.run();
        else mainHandler.post(runnable);
    }
}
