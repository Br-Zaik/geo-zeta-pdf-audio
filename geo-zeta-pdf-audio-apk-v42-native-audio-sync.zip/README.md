# Geo Zeta PDF a Audio V42 Native Audio Sync

Base:
- Hecha desde V41, la versión nativa que ya compiló y abrió PDF.

Cambio principal:
- Si el audio está reproduciendo y cambias de página, ahora se reinicia la lectura desde la nueva página.
- Ya no debe quedarse leyendo la página anterior.
- Si cambias de página estando pausado, se detiene la lectura anterior y el botón Play vuelve a iniciar desde la página actual.
- TextRepository ahora espera un poco si el texto del PDF todavía se está cargando.

No se tocó:
- Zoom.
- PdfRenderer.
- Diseño principal.
- Subrayado/exportar todavía no se agrega en esta versión para no romper la base funcional.

Próxima versión:
- V43: subrayado y guardar imagen, después de confirmar que V42 mantiene zoom y audio estable.
